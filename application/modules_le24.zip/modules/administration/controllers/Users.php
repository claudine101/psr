<?php
/*
  NIZIGIYIMANA Cedric
  debut : 17/03/2021
  fin : 17/03/2021
*/
  class Users extends CI_Controller
  {
   public function __construct()
   {
     parent::__construct();

   }
   public function index()
   {
     $data['title']="Utilisateurs";
     $this->load->view('Users_list_view',$data);
   }
   public function listing() 
   {
     $var_search=!empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
     $query_principal="SELECT ad_user.USER_ID,ad_user.USER_NAME,ad_user.EMAIL,int_pro.PROFIL_ID,int_pro.PROFIL_DESCR,rh.INTERVENANT_RH_ID,CONCAT(rh.NOM,' ',rh.PRENOM) NOM FROM admin_users ad_user  JOIN admin_profil int_pro ON ad_user.PROFIL_ID=int_pro.PROFIL_ID  JOIN intervenants_rh rh ON ad_user.INTERVENANT_RH_ID=rh.INTERVENANT_RH_ID";
     $limit='LIMIT 0,10';
     if($_POST['length'] != -1)
     {
      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
    }
    $order_by='';
    if($_POST['order']['0']['column']!=0)
    {
      $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY ad_user.USER_ID';
    }


    $search = !empty($_POST['search']['value']) ? (" AND (CONCAT(rh.NOM,' ',rh.PRENOM) LIKE '%$var_search%' OR ad_user.USER_NAME LIKE '%$var_search%' OR ad_user.EMAIL LIKE '%$var_search%' OR int_pro.PROFIL_DESCR LIKE '%$var_search%')") : '';




    $query_secondaire=$query_principal.' '.$search.' '.$order_by.'   '.$limit;
    $query_filter=$query_principal.' '.$search;
    $fetch_parcours = $this->Modele->datatable($query_secondaire);
    $u=0;
    $data = array();
    foreach ($fetch_parcours as $row)
    {
      $u++;
      $sub_array = array();
      $sub_array[]=$u;
      $sub_array[]= $row->USER_NAME;
      $sub_array[]= $row->EMAIL;
      $sub_array[]= $row->PROFIL_DESCR;
      $sub_array[]= $row->NOM;

      // $point= '<a href="'.base_url('administration/Admin_User/getOne/'.$row->USER_ID).'" class="btn btn-success btn-xs btn-rounded tooltip1"><center> <span class="tooltiptext1">Modifier</span> </center><i class="fa fa-edit"></i></a>';

      // $point.='<a href="'.base_url('administration/Admin_User/delete/'.$row->USER_ID).'" class="btn btn-success btn-xs btn-rounded tooltip1"><center> <span class="tooltiptext1">Supprimer</b></span> </center><i class="fa fa-trash"></i></a>' ;
      $point = '<div class="dropdown ">
      <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-cog"></i>
      Action
      <span class="caret"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-left">
      ';

      $point .="
      <li>
      <a class='btn-md' href='" . base_url('administration/Users/getOne/'.$row->USER_ID)."'>&nbsp;&nbsp;Modifier
      </a>
      </li>
      <li>
      <a href='#' data-toggle='modal' data-target='#mydelete" . $row->USER_ID . "' style='color:white;'><font color='red'>&nbsp;&nbsp;Supprimer</font><i class='fa fa-trash'></i></a>
      </li>
      </u></div>";

      $point.= '<div class="modal fade" id="mydelete' .$row->USER_ID. '">
      <div class="modal-dialog">
      <div class="modal-content">

      <div class="modal-body">
      <h5>Supprimer le profil <b>'.$row->USER_NAME.'</b> ?</h5>
      </div>

      <div class="modal-footer">
      <a class="btn btn-danger btn-md" href="' .base_url('administration/Users/delete/'.$row->USER_ID).'">Supprimer</a>
      <button class="btn btn-primary" class="close" data-dismiss="modal">Quitter</button>
      </div>
      </div>
      </div>
      </div>';
      $sub_array[]=$point;
      $data[]=$sub_array;
    }
    $output = array(
      "draw" => intval($_POST['draw']),
      "recordsTotal" =>$this->Modele->all_data($query_principal),
      "recordsFiltered" => $this->Modele->filtrer($query_filter),
      "data" => $data
    );
    echo json_encode($output);
  }

  function nouveau()
  {
    $data['title'] = "Ajouter un nouveau utilisateur";
    $data['error']='';
    $data['profils']=$this->Modele->getListOrder('admin_profil','PROFIL_DESCR');
    $this->load->view('Users_add_view',$data);

  }

  function getOne($id)
  {
    $data['profils']=$this->Modele->getListOrder('admin_profil',array(),'PROFIL_DESCR');
    $data['get_user']=$this->Modele->getOne('admin_users',array('USER_ID'=>$id));
    $data['title'] = "Modifier un utilisateur";
    $data['error']='';
    $this->load->view('Users_mod_view',$data);
  }

  public function check_username()
  {
    $id = $this->input->post('USER_ID');
    $username = $this->input->post('USER_NAME');
    if (empty($username))
    {
      $this->form_validation->set_message('check_username', 'Ce champ est obligatoire');
      return FALSE;
    } else {
      $get = $this->Modele->getRequeteOne('SELECT USER_ID FROM admin_users WHERE USER_NAME = "'.$username.'" AND USER_ID != '.$id.' ');
      if (!empty($get)) {
        $this->form_validation->set_message('check_username', "Ce nom d'utilisateur existe déjà");
        return FALSE;
      }else{
        return TRUE;
      }  
    }
  }

  function update()
  {
    $this->form_validation->set_rules('USER_NAME','Username','callback_check_username');
    $this->form_validation->set_rules('IS_ACTIVE','Is active', 'trim|required',array('required'=>'Ce champs est obligatoire'));
    $this->form_validation->set_rules('PROFIL_ID','Profil', 'trim|required',array('required'=>'champ requis'));
    if ($this->form_validation->run() == FALSE)
    {
      $id=$this->input->post('USER_ID'); 
      $data['type']=$this->Modele->getListOrder('admin_profil',array(),'NOM_PROFIL');
      $data['data']=$this->Modele->getOne('admin_users',array('USER_ID'=>$id));
      $this->getOne($this->input->post('USER_ID'));
    } else {
      $id=$this->input->post('USER_ID');
      $data=array(
        'USER_NAME' => $this->input->post('USER_NAME') ,
        'EMAIL' => $this->input->post('EMAIL'),
        'PROFIL_ID' => $this->input->post('PROFIL_ID'),
        'IS_ACTIVE' => $this->input->post('IS_ACTIVE')
      );
      $this->Modele->update('admin_users',array('USER_ID'=>$id),$data);
      $datas['message']='<div class="alert alert-success text-center" id="message">La modification du  '.$this->input->post('USER_NAME').'</b> Faite avec Succes</div>';
      $this->session->set_flashdata($datas);
      redirect(base_url('administration/Users/'));
    }
  }
  function delete()
  {
    $table="admin_users";
    $criteres['USER_ID']=$this->uri->segment(4);
    $data['rows']= $this->Modele->getOne( $table,$criteres);
    $this->Modele->delete($table,$criteres);
    $data['message']='<div class="alert alert-success text-center" id="message">'."Suppression de l'utilisateur".' '.$data['rows']['USER_NAME'].'  '."est faite avec succès".'</div>';
    $this->session->set_flashdata($data);
    redirect(base_url('administration/Users'));
  }
}
