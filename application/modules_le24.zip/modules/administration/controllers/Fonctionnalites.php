<?php
/**
* NIZIGIYIMANA Cédric
* début : 17/03/2021
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Fonctionnalites extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
  }
  function index()
  {
    $data['error']='';
    $this->listing();
  }
  function nouveau()
  {
    $data['error']='';
    $data['title'] = 'Nouvelle fonctionnalité';
    $this->load->view('Fonct_add_view',$data);
  }

  function listing()
  {
    $sql="SELECT FONCTIONNALITE_ID,FONCTIONNALITE_CODE,FONCTIONNALITE_DESCR FROM admin_fonctionnalites";
    // $table="maladies";
    $get = $this->Modele->getRequete($sql);
    $data_array = array();
    foreach ($get as $fonctionnalite) {
     $sub_array = array();
     $sub_array[] = $fonctionnalite['FONCTIONNALITE_DESCR'];
     $sub_array[] = $fonctionnalite['FONCTIONNALITE_CODE'];
     $sub_array['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" >
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydelete" . $fonctionnalite['FONCTIONNALITE_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
     $sub_array['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('administration/Fonctionnalites/getOne/'. $fonctionnalite['FONCTIONNALITE_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";
     $sub_array['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $fonctionnalite['FONCTIONNALITE_ID'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h6><strong>Voulez-vous supprimer cette fonctionnalité</strong>?<br> <b style:'background-color:prink';><i style='color:green;'>" . $fonctionnalite['FONCTIONNALITE_DESCR']."</i></b></h6></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('administration/Fonctionnalites/delete/'. $fonctionnalite['FONCTIONNALITE_ID']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";


     $data_array[] = $sub_array;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-striped table-bordered table-stripped table-hover table-condensed">',
    'table_close' => '</table>'

    // class="table table-bordered table-striped table-responsive table-hover table-condensed"
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('DESCRIPTION','CODE','ACTIONS'));
   $data['data']=$data_array;
   $data['title'] = "Fonctionnalités";
   $this->load->view('Fonct_list_view',$data);

 }
 public function add(){
  $this->form_validation->set_rules('FONCTIONNALITE_CODE', ' Code ', 'trim|required|is_unique[admin_fonctionnalites.FONCTIONNALITE_CODE]',array('required'=>'Ce champs est obligatoire','is_unique'=>'Ce code est déjà utilisé'));
  $this->form_validation->set_rules('FONCTIONNALITE_DESCR','', 'trim|required|is_unique[admin_fonctionnalites.FONCTIONNALITE_DESCR]',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>','is_unique'=>'Cette fonctionnalité existe déjà'));
  if ($this->form_validation->run() == FALSE)
  {
    $this->nouveau();
  } else {
    $data = array(
      'FONCTIONNALITE_CODE'=>$this->input->post('FONCTIONNALITE_CODE'),
      'FONCTIONNALITE_DESCR'=>$this->input->post('FONCTIONNALITE_DESCR')
    );
    $this->Modele->create('admin_fonctionnalites',$data);
    $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'une Fonctionnalite <b>".' '.$this->input->post('FONCTIONNALITE_DESCR').'</b> '." est faite avec succès".'</div>';
    $this->session->set_flashdata($data);
    redirect(base_url('administration/Fonctionnalites/listing'));
  }
}



public function check_code()
{
  $id = $this->input->post('FONCTIONNALITE_ID');
  $code = $this->input->post('FONCTIONNALITE_CODE');
  if (empty($code))
  {
    $this->form_validation->set_message('check_code', 'Ce champ est obligatoire');
    return FALSE;
  } else {
    $get = $this->Modele->getRequeteOne('SELECT FONCTIONNALITE_ID FROM admin_fonctionnalites WHERE FONCTIONNALITE_CODE = "'.$code.'" AND FONCTIONNALITE_ID != '.$id.' ');
    if (!empty($get)) {
      $this->form_validation->set_message('check_code', "Ce code existe déjà");
      return FALSE;
    }else{
      return TRUE;
    }  
  }
}
public function check_fonc()
{
  $id = $this->input->post('FONCTIONNALITE_ID');
  $fonc = $this->input->post('FONCTIONNALITE_DESCR');
  if (empty($fonc))
  {
    $this->form_validation->set_message('check_fonc', 'Ce champ est obligatoire');
    return FALSE;
  } else {
    $get = $this->Modele->getRequeteOne('SELECT FONCTIONNALITE_ID FROM admin_fonctionnalites WHERE FONCTIONNALITE_DESCR = "'.$fonc.'" AND FONCTIONNALITE_ID != '.$id.' ');
    if (!empty($get)) {
      $this->form_validation->set_message('check_fonc', "Cette fonctionnalité existe déjà");
      return FALSE;
    }else{
      return TRUE;
    }  
  }
}

public function update()
{
  $id=$this->input->post('FONCTIONNALITE_ID');
  $this->form_validation->set_rules('FONCTIONNALITE_CODE','', 'callback_check_code');
  $this->form_validation->set_rules('FONCTIONNALITE_DESCR','', 'callback_check_fonc');

  if ($this->form_validation->run() == FALSE){
    $data['data']=$this->Modele->getOne('admin_fonctionnalites',array('FONCTIONNALITE_ID'=>$id));
    $this->getOne($id);
  } else {
    $data=array(
      'FONCTIONNALITE_CODE'=>$this->input->post('FONCTIONNALITE_CODE'),
      'FONCTIONNALITE_DESCR'=>$this->input->post('FONCTIONNALITE_DESCR')
    );
    $this->Modele->update('admin_fonctionnalites',array('FONCTIONNALITE_ID'=>$id),$data);
    $datas['message']='<div class="alert alert-success text-center" id="message">La modification de <b>'.$this->input->post('FONCTIONNALITE_DESCR').'</b> est faite avec succès</div>';
    $this->session->set_flashdata($datas);
    redirect(base_url('administration/Fonctionnalites/listing'));
  }
}
public function delete()
{
  $table="admin_fonctionnalites";
  $criteres['FONCTIONNALITE_ID']=$this->uri->segment(4);
  $data['rows']= $this->Modele->getOne( $table,$criteres);
  $this->Modele->delete($table,$criteres);
  $data['message']='<div class="alert alert-success text-center" id="message">'."La fonctionnalité <b> ".' '.$data['rows']['FONCTIONNALITE_DESCR'].' </b> '." est supprimée avec succès".'</div>';
  $this->session->set_flashdata($data);
  redirect(base_url('administration/Fonctionnalites/listing'));
}
public function getOne($id)
{
  $data['data']=$this->Modele->getOne('admin_fonctionnalites',array('FONCTIONNALITE_ID'=>$id));
  $data['error']='';
  $data['title'] = "Modifier une fonctionnalité";
  $this->load->view('Fonct_mod_view',$data);
}
}
?>
