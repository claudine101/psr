<?php 

/**
 * christa
 * Autorisation de créer des comptes
 */
class Liste_Activation_Compte extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index($USER_ID=0)
	{
		$data['title'] = 'Activation Compte';
		$data['USER_ID']=$USER_ID;
		$this->load->view('Liste_Activation_Compte_View',$data);
	}


	function getInfo()
	{


		$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		$var_search=str_replace("'", "\'", $var_search);  

		$query_principal="SELECT admin.USER_ID,admin.EMAIL,CONCAT(rh.NOM,' ',rh.PRENOM,' [',rh.TELEPHONE1,']') INTERVENA,intv.INTERVENANT_STRUCTURE_DESCR,admin.IS_ACTIVE,profil.PROFIL_DESCR,DATE_ACTIVATION FROM admin_users admin JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=admin.INTERVENANT_RH_ID JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID JOIN admin_profil profil ON profil.PROFIL_ID=admin.PROFIL_ID WHERE 1";


		$group="";
		$critaire="";

		$limit='LIMIT 0,10';
		if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$order_by='';
		if($_POST['order']['0']['column']!=0){
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY admin.USER_ID DESC';
		}

		
		$search = !empty($_POST['search']['value']) ? (" AND (CONCAT(rh.NOM,' ',rh.PRENOM,' [',rh.TELEPHONE1,']') LIKE '%$var_search%' OR admin.EMAIL LIKE '%$var_search%' OR intv.INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR profil.PROFIL_DESCR LIKE '%$var_search%' OR DATE_FORMAT(DATE_ACTIVATION,'%Y-%m-%d %h:%i:%s') LIKE '%$var_search%')") : '';



		$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
		$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

		$fetch_data = $this->Modele->datatable($query_secondaire);
		$u=0;
		$data = array();


		foreach ($fetch_data as $row) {

			$u++;
			$sub_array = array();
			// $sub_array[] =  $u;
			$sub_array[]=$row->INTERVENA;
			$sub_array[]=$row->EMAIL;
			$sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
			$sub_array[]=$row->PROFIL_DESCR;
			

			$status = ($row->IS_ACTIVE==1) ? '<center><span class="fa fa-check-circle" data-toggle="tooltip" title="Activé" style="color:green;"></span></center>' : '<center><span class="fa fa-ban" data-toggle="tooltip" title="Déactivé" style="color:red;"></span></center>' ;
			
			$sub_array[]=date('Y-m-d',strtotime($row->DATE_ACTIVATION));
			$sub_array[]=$status;

			$point='<div class="dropdown" style="color:#fff;">
			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
			<i class="fa fa-cog"></i> Options<span class="caret">
			</span></a>
			<ul class="dropdown-menu dropdown-menu-left">';

			if ($row->IS_ACTIVE==1){
				$state=0;
				$point .= "<li><a class='btn-md' hre='#' onclick='traiter_status(".$row->USER_ID.",".$state.")' style='text-decoration:none;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Déactiver</a></li>";
			}else{
				$state=1;
				$point .= "<li><a class='btn-md' hre='#' onclick='traiter_status(".$row->USER_ID.",".$state.")' style='text-decoration:none;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Activer</a></li>";
			}
			$point.='</ul>';

			

			$sub_array[]=$point;


			$data[] = $sub_array;

		}

		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
			"recordsFiltered" => $this->Modele->filtrer($query_filter),
			"data" => $data
		);
		echo json_encode($output);

	}



	function insert()
	{
		$ID=$this->input->post('ID');
		$PROFIL_ID=$this->input->post('PROFIL_ID');

		//print_r($PROFIL_ID);die();
		//echo $optio;
		$admin=$this->Modele->getOne('admin_creation_compte',array('ID'=>$ID));


		$data_Insert=array(
			'INTERVENANT_RH_CODE'=>$admin['TELEPHONE'],
			'NOM'=>$admin['NOM'],
			'TELEPHONE1'=>$admin['TELEPHONE'],
			'PRENOM'=>$admin['PRENOM'],
			'EMAIL'=>$admin['EMAIL'],
			'SEXE_ID'=>$admin['SEXE_ID'],
			'INTERVENANT_STRUCTURE_ID'=>$admin['INTERVENANT_STRUCTURE_ID']
		);

		$intervenant=$this->Modele->insert_last_id('intervenants_rh',$data_Insert);

		$psw=$this->mylibrary->generate_password(8);
		$data_users=array(
			'EMAIL'=>$admin['EMAIL'],
			'IS_ACTIVE'=>1,
			'PASSWORD'=>md5($psw),
			'INTERVENANT_RH_ID'=>$intervenant,
			'USER_NAME'=>$admin['NOM'],

		);

		$admin_users=$this->Modele->insert_last_id('admin_users',$data_users);

		$insert=array(
			'PROFIL_ID'=>$PROFIL_ID,
			'TYPE_INTERVENANT_STRUCTURE_ID'=>$admin['TYPE_INTERVENANT_STRUCTURE_ID'],
			'USER_ID'=>$admin_users,
		);

		$ID_PROFIL=$this->Modele->insert_last_id('admin_profil_type_intervenant',$insert);

		$data=array(
			'TRAITER'=>1,
			'DATE_ACTIVATION'=>date("Y-m-d H:i:s")
		);
		$this->Modele->update('admin_creation_compte',array('ID'=>$ID),$data);

		if ($ID_PROFIL) {
			$to=$admin['EMAIL'];
			$subject='Projet ICCM - Identifiants de connexion';

			

			if ($row->SEXE_ID==1) {
				# code...

				$message = "Cher ".$admin['NOM']." </br>Vous avez été crée comme utilisateur du système et voici vos identifiants de connexion sur la plateforme iccm:<br><br>";
			}else{

				$message = "Cher ".$admin['NOM']." </br>Vous avez été crée comme utilisateur du système et voici vos identifiants de connexion sur la plateforme iccm:<br><br>";
			}
			$message .="<b> Username:".$admin['EMAIL']." </b><br>
			<b>Mot de passe:".$psw." </b>";
			$this->notifications->send_mail($to,$subject,array(),$message,array());



			redirect(base_url('administration/Liste_Activation_Compte/'));

		}


	}

	function get_icon($TRAITER)
	{
		$html = ($TRAITER == 1) ? '<center><span class="fa fa-check-circle" data-toggle="tooltip" title="Activé" style="color:green;"></span></center>' : '<center><span class="fa fa-ban" data-toggle="tooltip" title="Déactivé" style="color:red;"></span></center>' ;

		return $html;
	}


	function traiter_user()
	{
		$USER_ID=$this->input->post('USER_ID');
		$IS_ACTIVE=$this->input->post('IS_ACTIVE');

		$get_rh=$this->Modele->getOne('admin_users',array('USER_ID'=>$USER_ID));

		// PREPARATION DE L'EMAIL
		$get_nom=$this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_ID'=>$get_rh['INTERVENANT_RH_ID']));
		$pwd=$this->notifications->generate_password(8);

		$message_active="Cher ".$get_nom['NOM']." ".$get_nom['PRENOM']." ,votre compte sur la plateforme ICCM a été activé.<br>En cliquant  <a href='".base_url()."'>ici</a> ,vous pouvez vous connecter par ces identifiants.<br>Mot de passe:".$pwd."<br> Nom d'utilisateur:".$get_rh['EMAIL']."<br>Merci cordialement";

		$message_desactive="Cher ".$get_nom['NOM']." ".$get_nom['PRENOM']." ,votre compte sur la plateforme ICCM a été désactivé<br>Merci cordialement";

		$subject="ICCM traitement du compte";
		$email=$get_rh['EMAIL'];
		

		$this->Modele->update('admin_users',array('USER_ID'=>$USER_ID),array('IS_ACTIVE'=>$IS_ACTIVE,'DATE_ACTIVATION'=>date('Y-m-d h:i:s'),'PASSWORD'=>md5($pwd)));

		if ($IS_ACTIVE==0) {
			# code...
			$this->notifications->send_mail($email,$subject,'',$message_desactive,array());
		} else {
			# code...
			$this->notifications->send_mail($email,$subject,'',$message_active,array());
		}
		

		echo json_encode(array('status'=>TRUE));
	}

}
?>

