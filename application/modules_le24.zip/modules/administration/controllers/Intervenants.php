<?php 

/**
* auteur:NIZIGIYIMANA Cedric
* date : 17 / 03 / 2021
*/
class Intervenants extends My_Controller
{

  function __construct()
  {
    parent::__construct();
  }

  function index()
  {
    $data['error']='';
    $this->listing();
  }

  function listing()
  {
    $sql="SELECT inter.INTERVENANT_RH_ID,inter.NOM,inter.PRENOM,inter.TELEPHONE1,inter.TELEPHONE2,inter.EMAIL,inter_s.INTERVENANT_STRUCTURE_ID,inter_s.INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh inter LEFT JOIN intervenants_structure inter_s ON inter.INTERVENANT_STRUCTURE_ID=inter_s.INTERVENANT_STRUCTURE_ID ";
    $intervenants_rh=$this->Modele->getRequete($sql);
    $data_users = array(); 
    $intervenants_structure=array();
    foreach ($intervenants_rh as $key) {
      $sub_array = array();
      $intervenants_structure=$this->Modele->getOne('intervenants_structure', array('INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID']));
      $sub_array[] = $key['NOM'];
      $sub_array[]= $key['PRENOM'];
      $sub_array[]= $key['TELEPHONE1'];
      $sub_array[]= $key['TELEPHONE2'];
      $sub_array[]=$key['EMAIL'];
      $sub_array[]=$intervenants_structure['INTERVENANT_STRUCTURE_DESCR'];
      $sub_array['OPTIONS'] ='<div class="dropdown ">
      <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-cog"></i>
      Action
      <span class="caret"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-left">
      ';

      $sub_array['OPTIONS'] .="<li>
      <a class='btn-md' href='" . base_url('administration/Intervenants/nouveau_utilisteur/'.$key['INTERVENANT_RH_ID'])."'>&nbsp;&nbsp;User
      </a>
      </li></div>";
      $data_users[] = $sub_array;
    }
    $template = array(
     'table_open' => '<table id="mytable" class="table table-bordered table-striped table-responsive table-hover table-condensed">',
     'table_close' => '</table>'
   );
    $this->table->set_template($template);
    $this->table->set_heading(array('NOM','PRENOM','TELEPHONE','TELEPHONE 2','EMAIL','INTERVENANT','OPTIONS'));
    $data['donnees_users']=$data_users;
    $data['title'] = "Liste des intervenants";
    $this->load->view('Intervenants_list_view',$data);
  }
  function nouveau_utilisteur($id)
  {
    $data['error']='';
    // $id=$this->uri->segment(4);
    $data['get_interv']=$this->Modele->getRequeteOne('SELECT INTERVENANT_RH_ID,EMAIL FROM intervenants_rh WHERE INTERVENANT_RH_ID = '.$id.'');
    $data['profils']=$this->Modele->getListOrder('admin_profil','PROFIL_DESCR');
    $data['intervenants_rh']=$this->Modele->getListOrder('intervenants_rh','NOM','PRENOM');
    $data['title'] = "Nouveau utilisateur";
    $this->load->view('Users_add_from_interv',$data);
  }

  function add_user()
  {
    $this->form_validation->set_rules('USER_NAME','', 'trim|required|is_unique[admin_users.USER_NAME]',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>',
      'is_unique'=>'<font style="color:red;size:2px;">Ce nom d\'utilisateur existe déjà </font>',));
    $this->form_validation->set_rules('EMAIL','', 'trim|valid_email|required|is_unique[admin_users.EMAIL]',array(
      'required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>',
      'is_unique'=>'<font style="color:red;size:2px;">L\'adresse email existe déjà </font>',
      'valid_email'=>'<font style="color:red;size:2px;">Email invalide </font>'
    ));


    $this->form_validation->set_rules('PROFIL_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));

    if ($this->form_validation->run() == FALSE)
    {
      $data['data_users']=$this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_ID'=>$this->input->post('INTERVENANT_RH_ID')));
      $data['intervenants_structure']=$this->Modele->getList('intervenants_structure');
      $data['admin_profil']=$this->Modele->getList('admin_profil');
      $data['error']='';
      $this->nouveau_utilisteur(1);

    } else {
      $psw=$this->mylibrary->generate_password(8);
      $dataInsert=array(
        'USER_NAME' => $this->input->post('USER_NAME'),
        'EMAIL'=>$this->input->post('EMAIL'),
        'PASSWORD'=>md5($psw),
        'PROFIL_ID'=>$this->input->post('PROFIL_ID'),
        'INTERVENANT_RH_ID'=>$this->input->post('INTERVENANT_RH_ID')
      );
      $table='admin_users';
      $sql=$this->Modele->create('admin_users',$dataInsert);
      if ($sql) {
        $to=$this->input->post('EMAIL');
        $subject='votre mot de passe';
        $message = "Monsieur /Madame ".$this->input->post('NOM')." </br>Vous avez été crée comme utilisateur du système et voici vos identifiants de connexion sur la plateforme iccm:<br><br>";$message .="<b> Username:".$this->input->post('EMAIL')." </b><br>
        <b>Mot de passe:".$psw." </b>";
      }
      $this->mylibrary->send_mail($to,'Identifiants sur le système ICCM',NULL,$message,NULL);
      $data['message']='<div class="alert alert-success text-center" id="message">'."L'utilisateur ".$this->input->post('NOM')." est créé avec succès".'</div>';
      $this->session->set_flashdata($data);
      redirect(base_url('administration/Users'));
    }
  }

}


?>