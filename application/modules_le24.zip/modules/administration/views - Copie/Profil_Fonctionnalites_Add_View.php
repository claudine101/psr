  <div class="row">
    <legend>
      Nouveau Profil Fonctionnalite
      <div class="pull-right" style="padding-bottom:20px;">
        <a href="<?= base_url('administration/Profil_Fonctionnalites/listing'); ?>" class="btn btn-primary"><i class="fa fa-list"></i>
          Liste
        </a>
      </div>
    </legend>
  </div>
  <form  name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Profil_Fonctionnalites/addProfil'); ?>">
    <div class="row">

     <div class="col-md-6 col-sm-6 col-xs-6">
      <label>Profil</label>

      <select id="PROFIL_ID" name="PROFIL_ID" class="form-control selectpicker" data-live-search="true">
       <option value="">--Sélectionnez--</option>
       <?php
       foreach ($type as $profil) {
         if ($PROFIL_ID==$profil['PROFIL_ID']) 
         {
           echo "<option value=".$profil['PROFIL_ID']." selected=''>".$profil['PROFIL_DESCR']."</option>";
         } else {
          echo "<option value=".$profil['PROFIL_ID'].">".$profil['PROFIL_DESCR']." </option>";
        }
      }
      ?>           
    </select>
    <div style="color: red"><?php echo form_error('PROFIL_ID'); ?></div>
  </div> 

  <div class="col-md-6 col-sm-6 col-xs-6">
    <label>Fonctionnalite</label>

    <select id="FONCTIONNALITE_ID" name="FONCTIONNALITE_ID" class="form-control js-example-basic-single" data-live-search="true">
     <option value="">--Sélectionnez--</option>
     <?php
     foreach ($types as $fonction) {
       if ($FONCTIONNALITE_ID==$fonction['FONCTIONNALITE_ID']) 
       {
         echo "<option value=".$fonction['FONCTIONNALITE_ID']." selected=''>".$fonction['FONCTIONNALITE_DESCR']."</option>";
       } else {
        echo "<option value=".$fonction['FONCTIONNALITE_ID'].">".$fonction['FONCTIONNALITE_DESCR']." </option>";
      }
    }
    ?>           
  </select>
  <div style="color: red"><?php echo form_error('FONCTIONNALITE_ID'); ?></div>

  <?php 
  foreach ($types as $type) {
    ?>
    <div class="form-check">
     <input class="form-check-input" type="checkbox" name="TYPE[<?=$type['FONCTIONNALITE_ID']?>]" value="<?=$type['FONCTIONNALITE_ID']?>"> 
     <label class="form-check-label"><?=$type['FONCTIONNALITE_DESCR']?></label> 
   </div>
   <?php
 }
 ?>
</div> 
</div>
<div class="row">
 <div class="col-md-6 col-sm-6 col-xs-6 offset-md-3">
  <button type="submit" class="btn btn-secondary btn-block" style="margin-top: 20px">Enregistrer</button>
</div>
</div>
</form> 