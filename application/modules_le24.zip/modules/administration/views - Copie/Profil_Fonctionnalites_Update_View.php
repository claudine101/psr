<div class="row">
  <legend>
   Nouveau Profil Fonctionnalite
   <div class="pull-right" style="padding-bottom:20px;">
    <a href="<?= base_url('administration/Profil_Fonctionnalites/listing'); ?>" class="btn btn-secondary"><i class="fa fa-list"></i>
      Liste
    </a>
  </div>
</legend>
</div>
<form  name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Profil_Fonctionnalites/updateProfil'); ?>">
  <div class="row">

   <input type="hidden" class="form-control" name="PROFIL_FONCTIONNALITE_ID" value="<?=$profil_Fonction['PROFIL_FONCTIONNALITE_ID']?>" >
   <div class="col-md-6 col-sm-6 col-xs-6">
    <label>Profil</label>

    <select id="PROFIL_ID" name="PROFIL_ID" class="form-control selectpicker" data-live-search="true">
      <option value="">--Sélectionnez--</option>
      <?php
      foreach ($type as $t) {
       if  ($t['PROFIL_ID'] ==$profil_Fonction['PROFIL_ID']) 
       {
         echo "<option value=".$t['PROFIL_ID']." selected=''>".$t['PROFIL_DESCR']."</option>";
       } else {
        echo "<option value=".$t['PROFIL_ID'].">".$t['PROFIL_DESCR']." </option>";
      }
    }
    ?>           
  </select>
  <div style="color: red"><?php echo form_error('PROFIL_ID'); ?></div>
</div> 

<div class="col-md-6 col-sm-6 col-xs-6">
  <label>Fonctionnalite</label>

  <select id="FONCTIONNALITE_ID" name="FONCTIONNALITE_ID" class="form-control selectpicker" data-live-search="true">
    <option value="">--Sélectionnez--</option>
    <?php
    foreach ($types as $data) {
     if  ($data['FONCTIONNALITE_ID'] ==$profil_Fonction['FONCTIONNALITE_ID']) 
     {
       echo "<option value=".$data['FONCTIONNALITE_ID']." selected=''>".$data['FONCTIONNALITE_DESCR']."</option>";
     } else {
      echo "<option value=".$data['FONCTIONNALITE_ID'].">".$data['FONCTIONNALITE_DESCR']." </option>";
    }
  }
  ?>           
</select>
<div style="color: red"><?php echo form_error('FONCTIONNALITE_ID'); ?></div>
</div> 
</div>
<div class="row">


  <div class="col-md-6 col-sm-6 col-xs-6 offset-md-3">
    <button type="submit" class="btn btn-secondary btn-block" style="margin-top: 20px">Modifier</button>

  </div>
</div>
</form>






<!-- partial -->




<!-- End custom js for this page-->






