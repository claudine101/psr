<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('administration/Affectation_Users/liste')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">

              <div class="col-md-12">

               <form id="myform">
                <div class="row">
                  <div class="col-md-6">
                    <input type="hidden" name="USER_ID" value="<?=$user['USER_ID']?>" id='USER_ID'>
                    <label for="FName">Type intervenant</label>

                    <select class="form-control" onchange="get_structures(this.value),get_bds_cds(this.value)" id="TYPE_INTERVENANT_STRUCTURE_ID" name="TYPE_INTERVENANT_STRUCTURE_ID">
                      
                      <?php
                      foreach ($types as $key) 
                      {
                        if ($TYPE_INTERVENANT_STRUCTURE_ID==$key['TYPE_INTERVENANT_STRUCTURE_ID']) {?>
                          <option value="<?=$key['TYPE_INTERVENANT_STRUCTURE_ID']?>" selected=""><?=$key['TYPE_INTERVENANT_STRUCTURE_DESCR']?></option>
                          
                        <?php } else {?>
                          <option value="<?=$key['TYPE_INTERVENANT_STRUCTURE_ID']?>"><?=$key['TYPE_INTERVENANT_STRUCTURE_DESCR']?></option>

                        <?php }
                        
                     } 
                     ?>
                   </select>
                   <span id="error_type"></span>
                 </div>

                 <div class="col-md-6" id="STRUCTURE_ID">
                  <label for="LName">Structure</label>
                  <select class="form-control select2" onchange="get_intervenant_rh(this.value)" id="INTERVENANT_STRUCTURE_ID" name="INTERVENANT_STRUCTURE_ID">

                    <?php
                    // if ($TYPE_INTERVENANT_STRUCTURE_ID) {

                    foreach ($stuctures_intervenants as $value) {
                      if ($INTERVENANT_STRUCTURE_ID==$value['INTERVENANT_STRUCTURE_ID']) {?>
                        <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>" selected=""><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                       
                     <?php } else {?>
                      <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>"><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                   
                      <?php 
                    } 
                  }?>

          
                  </select>
                  <span id="error_stucture"></span>
                </div>

                 <div class="col-md-6" id="BDS_CDS" style="display: none;">
                  <label for="LName">BDS-CDS</label>
                  <select class="form-control select2" id="BDS_ID" onchange="get_cds_bds(this.value)" name="BDS_ID">
                    <!-- <option value="0" selected="" disabled="">--BDS</option> -->
                    <?php
                    

                    foreach ($bds as $value) {
                      if ($value['INTERVENANT_STRUCTURE_ID']==$BDS_ID) {?>
                        <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>" selected=""><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                       
                     <?php } else {?>
                      <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>"><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                   
                      <?php 
                    } 
                  }

                  ?>

                  </select>
                  <span id="error"></span>
                </div>

                <div class="col-md-6"  id="CDS_BDS" style="display:none;">
                  <label for="LName">CDS</label>
                  <select class="form-control select2" onchange="get_intervenant_rh(this.value)" 
                  id="CDS_ID" name="CDS_ID">

                    <?php

                    foreach ($cds as $value) {
                      if ($value['INTERVENANT_STRUCTURE_ID']==$CDS_ID) {?>
                        <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>" selected=""><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                       
                     <?php } else {?>
                      <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>"><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                   
                      <?php 
                    } 
                  }


                    ?>

                  </select>
                  <span id="error"></span>
                </div>

                <div class="col-md-6">
                  <label for="LName">Utilisateur</label>
                  <select class="form-control" onchange="get_intervenant_info(this.value),add_new_rh(this.value);" name="INTERVENANT_RH_ID"  id="INTERVENANT_RH_ID">
                    
                    <!-- <option value="-1">Membre non listé</option> -->
                    <?php
                    
                    foreach ($utilisateurs as $value) {
                      if ($value['USER_ID']==$user['USER_ID']) {?>
                        <option value="<?=$value['USER_ID']?>" selected=""><?=$value['INTERVENA']?></option>
                       
                     <?php } else {?>
                      <option value="<?=$value['USER_ID']?>"><?=$value['INTERVENA']?></option>
                   
                      <?php 
                    } 
                  }?>
                  </select> 
                  <span id="error_user"></span>
                </div>


                <div class="col-md-6">
                  <label for="LName">Profil</label>
                  <select class="form-control" name="PROFIL_ID" id="PROFIL_ID">
                    
                    <?php
                    foreach ($profile as $key) 
                    {
                      if ($user['PROFIL_ID']==$key['PROFIL_ID']) {?>
                        <option value="<?=$key['PROFIL_ID']?>" selected=''><?=$key['PROFIL_DESCR']?></option>
                      <?php } else {?>
                        <option value="<?=$key['PROFIL_ID']?>"><?=$key['PROFIL_DESCR']?></option>
                      <?php }
                      
                            
                      
                    }
                    ?>

                  </select>
                  <span id="error_profil"></span> 
                </div>


              </div>

              <div class="row">
                <div class="col-md-12" style="margin-top:31px;">
                  <button type="button" onclick="soumettre()" style="float: right;" id="button" class="btn btn-primary"><span class="fas fa-edit"></span> Modifier</button>

                </div>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </section>
</div>
</div>
</body>

<?php include VIEWPATH.'templates/footer.php'; ?>

<script>

  $(document).on('change',function(){
    
    chargement_data();

  });

  $(document).ready(function()
  {
    chargement_data();
  });

  function chargement_data()
  {
    var type_intev=$('#TYPE_INTERVENANT_STRUCTURE_ID').val();
    if (type_intev==5) { 
      $('#BDS_CDS').show();
      $('#CDS_BDS').show();
      $('#STRUCTURE_ID').hide();
    }else{
      $('#BDS_CDS').hide();
      $('#CDS_BDS').hide();
      $('#STRUCTURE_ID').show();
    }
  }

  function soumettre()
  {
    
    var USER_ID=$('#USER_ID').val();
    var TYPE_INTERVENANT_STRUCTURE_ID=$('#TYPE_INTERVENANT_STRUCTURE_ID').val();
    var INTERVENANT_STRUCTURE_ID=$('#INTERVENANT_STRUCTURE_ID').val();
    var PROFIL_ID=$('#PROFIL_ID').val();
    var INTERVENANT_RH_ID=$('#INTERVENANT_RH_ID').val();

    if (TYPE_INTERVENANT_STRUCTURE_ID=="") 
    {
      $('#error_type').html('Champ obligatoire');
      $('#error_type').css('color','red');
    }else{
      $('#error_type').html('');
    }

    if (INTERVENANT_STRUCTURE_ID=="") 
    {
      var test2=1;

      INTERVENANT_STRUCTURE_ID=test2;

      $('#error_stucture').html('Champ obligatoire');
      $('#error_stucture').css('color','red');
    }else{
      $('#error_stucture').html('');
    }


    if (PROFIL_ID=="") 
    {
      var test1=1;
      PROFIL_ID=test1;
      $('#error_profil').html('Champ obligatoire');
      $('#error_profil').css('color','red');
    }else{
      $('#error_profil').html('');
    }

    if (INTERVENANT_RH_ID=="") 
    {

      var test=1;
      INTERVENANT_RH_ID=test;

      $('#error_user').html('Champ obligatoire');
      $('#error_user').css('color','red');

      
    }else{
      $('#error_user').html('');
    }

    if (PROFIL_ID>0 && INTERVENANT_RH_ID>0) 
    {


     $.post('<?php echo base_url();?>administration/Affectation_Users/update/',
     {
      PROFIL_ID:PROFIL_ID,
      USER_ID:USER_ID,
      INTERVENANT_RH_ID:INTERVENANT_RH_ID
    },
    function(data)
    {


     window.location.href="<?=base_url('administration/Affectation_Users/liste')?>";


   });
   }
 }


function get_intervenant_info()
 {
  var INTERVENANT_RH_ID=$('#INTERVENANT_RH_ID').val();

  $.post("<?=base_url('administration/Affectation_Users/add/')?>",
  {
    INTERVENANT_RH_ID:INTERVENANT_RH_ID
  });

          //alert(INTERVENANT_RH_ID);
}



function get_structures()
        {

          var TYPE_INTERVENANT_STRUCTURE_ID=$('#TYPE_INTERVENANT_STRUCTURE_ID').val();
          // alert(TYPE_INTERVENANT_STRUCTURE_ID);

          $.post("<?=base_url('administration/Affectation_Users/get_structure/')?>",
          {
            TYPE_INTERVENANT_STRUCTURE_ID:TYPE_INTERVENANT_STRUCTURE_ID

          },
          function(data)
          {

           INTERVENANT_STRUCTURE_ID.innerHTML = data;
           $('#INTERVENANT_STRUCTURE_ID').html(data);
         }
         );

          
        }




        function get_bds_cds()
        {
          // var BDS_ID=$('#TYPE_INTERVENANT_STRUCTURE_ID').val();

          $.post("<?=base_url('administration/Affectation_Users/get_bds_cds')?>",
            function(data)
            {
              BDS_ID.innerHTML=data;
              $("#BDS_ID").html(data);
            });

        }


        function get_cds_bds()
        {

          var BDS_ID=$("#BDS_ID").val();

          // alert(CDS_ID)

          $.post("<?=base_url('administration/Affectation_Users/get_cds_bds/')?>",
          {
            BDS_ID:BDS_ID
          },
          function(data)
          {
            CDS_ID.innerHTML=data;
            $('#CDS_ID').html(data);
          }
          );

        }


        function get_intervenant_rh()
        {
          var CDS_ID=$('#CDS_ID').val();
          var INTERVENANT_STRUCTURE_ID=$('#INTERVENANT_STRUCTURE_ID').val();

          var INFO_STRUCTURE;

          if (CDS_ID>0) 
          {
            INFO_STRUCTURE=CDS_ID;

          }else{
            
            INFO_STRUCTURE=INTERVENANT_STRUCTURE_ID;
          }

          $.post("<?=base_url('administration/Affectation_Users/get_intervenant_rh/')?>",
          {
            INFO_STRUCTURE:INFO_STRUCTURE
          },
          function(data)
          {


            INTERVENANT_RH_ID.innerHTML=data;
            $('#INTERVENANT_RH_ID').html(data);
          });
        }


        function get_intervenant_rh_CDS()
        {
          var CDS_ID=$('#CDS_ID').val();

          $.post("<?=base_url('administration/Affectation_Users/get_intervenant_rh_CDS/')?>",
          {
            CDS_ID:CDS_ID
          },
          function(data)
          {

            INTERVENANT_RH_ID.innerHTML=data;
            $('#INTERVENANT_RH_ID').html(data);
          });
        }






        /**********************************ADD NEW RH*************************************************/



  function add_new_rh(test_id) {
  // body...

  var INTERVENANT_STRUCTURE_ID=$('#INTERVENANT_STRUCTURE_ID').val();
  var CDS_ID=$('#CDS_ID').val();

  if (Number(test_id)==-1 && (Number(INTERVENANT_STRUCTURE_ID)>0 || Number(CDS_ID)>0)) {
    
    if (INTERVENANT_STRUCTURE_ID>0) 
    {
      $('#structure').val(INTERVENANT_STRUCTURE_ID);
    }
    else{
      $('#structure').val(CDS_ID);
    }
    
    $('#add_new_rh').modal({backdrop:false});
    $('#nom').focus();
  }
}

function send_new_rh() {
  // body...
  var nom=$('#nom').val();
  var prenom=$('#prenom').val();
  var tel=$('#tel').val();
  var autre_tel=$('#autre_tel').val();
  var email=$('#email').val();
  var interv_sexe=$('#interv_sexe').val();
  var structure=$('#structure').val();

  var CDS_ID=$("#CDS_ID").val();
  var INTERVENANT_STRUCTURE_ID=$("#INTERVENANT_STRUCTURE_ID").val();

  if (nom=="") {
    $('#error_nom').html('Champ obligatoire');

  }else{
    $('#error_nom').html('');
  }
  if (prenom=="") {
    $('#error_prenom').html('Champ obligatoire');

  }else{
    $('#error_prenom').html('');
  }
  if (tel=="") {
    $('#error_tel1').html('Champ obligatoire');

  }else{
    $('#error_tel1').html('');
  }
  if (email=="") {
    $('#error_email').html('Champ obligatoire');

  }else{
    $('#error_email').html('');
  }
  if (interv_sexe=="") {
    $('#error_sexe').html('Champ obligatoire');

  }else{
    $('#error_sexe').html('');
  }
  if (email!="") {
   var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

   var test_email=1;

   if(!emailReg.test(email)){
    $('#error_email').html('Email invalide!');
    test_email=0
  }else{
    $('#error_email').html('');
  }
}


if (interv_sexe!="" && tel!="" && nom!="" && prenom!="" && email!="" && structure!="" && test_email==1) {

  $('#btn_new_rh').attr('disabled', true);

  $.post('<?php echo base_url();?>administration/Affectation_Users/add_new_rh',
  {

    nom:nom,
    prenom:prenom,
    tel:tel,
    autre_tel:autre_tel,
    email:email,
    interv_sexe:interv_sexe,
    structure:structure

  },
  function(data)
  {

    var msrt=data.split("@",2);
    if (Number(msrt[1])!=0) {

      // if (CDS_ID>0 && INTERVENANT_STRUCTURE_ID>0) {
      //   get_intervenant_rh_CDS();
      // }

      // if (INTERVENANT_STRUCTURE_ID>0) {
      //   get_structure_rh();
      // }

       get_structure_rh();

      vider_structure();
      $('#nom').val("");
      $('#prenom').val("");
      $('#tel').val("");
      $('#autre_tel').val("");
      $('#email').val("");
      $('#interv_sexe').val("");
      $('#add_new_rh').modal('hide');
    }

    message_retour.innerHTML = msrt[0];
    $('#message_retour').html(msrt[0]);
    $('#btn_new_rh').attr('disabled', false);

  });

}else{
  $('#btn_new_rh').attr('disabled', false);
}

}







function get_structure_rh(id=0)
{
  var structure=$('#structure').val();  
  var CDS_ID=$('#CDS_ID').val();  
  var ID=$('#INTERVENANT_STRUCTURE_ID').val();
  var INTERVENANT_STRUCTURE_ID;
  if (ID!="") {
    INTERVENANT_STRUCTURE_ID=ID;

    // alert(ID);
  }
  if (structure!="") {
    INTERVENANT_STRUCTURE_ID=structure;
    // alert(structure);
  }
  if (CDS_ID!="") 
  {
    // alert(CDS_ID);
    INTERVENANT_STRUCTURE_ID=CDS_ID;
    // alert(CDS_ID);
  }

  $.post('<?php echo base_url();?>administration/Affectation_Users/get_intervenant_rh_up/',
  {
    INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID

  },
  function(data)
  {
    INTERVENANT_RH_ID.innerHTML = data;
    $('#INTERVENANT_RH_ID').html(data);

    //$('#INTERVENANT_RH_ID').selectpicker('refresh');
  });

}






function vider_structure() {
  // body...
  $('#structure').val('');
}

</script>











<!-- Large modal -->


<div class="modal fade bd-example-modal-lg" id="add_new_rh" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="add_new_rh">Ajouter un membre</h4>
          <button type="button" onclick="get_structure_rh();" class="close btn btn-outline-danger btn-sm" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="container-fluid" style="padding: 20px;">
          <center><span id="message_retour"></span></center>
          <div class="col-md-12">
            <form action="" method="post">
             <div class="row">
              <div class="col-md-6">
               <label>Nom</label>
               <input type="text" class="form-control" name="nom" id="nom" autofocus="">
               <label class="text-danger" id="error_nom"></label>
             </div>
             <div class="col-md-6">
               <label>Prénom</label>
               <input type="text" class="form-control" name="prenom" id="prenom">
               <label class="text-danger" id="error_prenom"></label>
             </div>
           </div>

           <div class="row">
            <div class="col-md-6">
             <label>Sexe</label>
             <select class="form-control" name="interv_sexe" id="interv_sexe">
              <option value="" selected="">Sélectionner</option>
              <?php foreach ($admin_interv_sexe as $value) {
                if (set_value('interv_sexe')==$value['SEXE_ID']) {  ?>
                  <option selected value="<?= $value['SEXE_ID'];?>">
                    <?= $value['SEXE_DESCR'];?>
                  </option>
                  <?php  } else {  ?>
                    <option value="<?= $value['SEXE_ID'];?>">
                      <?= $value['SEXE_DESCR'];?>
                    </option>
                    <?php  }

                  }  ?>
                </select>

                <label class="text-danger" id="error_sexe"></label>
              </div>
              <div class="col-md-6">
               <label>Tél</label>
               <input type="number"  class="form-control" name="tel" id="tel">
               <label class="text-danger" id="error_tel1"></label>
             </div>

           </div>

           <div class="row">
            <div class="col-md-6">
             <label>Email</label>
             <input type="text"  class="form-control" name="email" id="email">
             <label class="text-danger" id="error_email"></label>
           </div>

         </div>
         <input type="hidden" name="structure" id="structure">
         <div class="row">

          <div class="col-md-6">
            <button type="button" id="btn_new_rh" class="btn btn-primary btn-sm" style="margin-top: 25px;" onclick="send_new_rh()">
              <i class="nav-icon fas fa-save"></i>
              <b>Enregistrer</b>
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</div>
</div>
</div>


