<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}
.mapbox-logo {
  display: none;
}
.laces-checkbox {
  display:inline-block;
  width:2rem;
  height:2rem;
  font-size:1.2rem;
  line-height:1.8rem;
  text-align:center;
  border:1px solid #999;
  border-radius:1.1rem;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">


              <span style="margin-right: 15px">
                <div class="col-sm-6" style="float:right;">
                  <a href="<?=base_url('administration/Profils/')?>" class='btn btn-primary float-right'>
                    <i class="nav-icon fas fa-list"></i>
                    Liste
                  </a>
                </div>

              </span>

            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="col-md-12">
                <form  name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Profils/add'); ?>">

                  <div class="row">
                    <div class="col-md-6">
                      <label>Description</label>
                      <input type="text" autocomplete="off" name="PROFIL_DESCR" value="<?=set_value('PROFIL_DESCR')?>" class="form-control" id="PROFIL_DESCR">
                      <?php echo form_error('PROFIL_DESCR', '<div class="text-danger">', '</div>'); ?>
                    </div>
                    <div class="col-md-6">
                      <label>Code</label>
                      <input type="text" autocomplete="off" name="PROFIL_CODE" value="<?=set_value('PROFIL_CODE')?>" class="form-control" id="PROFIL_CODE">
                      <?php echo form_error('PROFIL_CODE', '<div class="text-danger">', '</div>'); ?>
                    </div>

                    <div class="col-md-12">
                      <br>
                      <table class="table " >
                        <tr>
                          <th>ADMINISTRATION</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('ADMINISTRATION') == 1) ? 'checked' : '' ?>  name="ADMINISTRATION" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau de bord par PTF</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DASHBOARD_PTF') == 1) ? 'checked' : '' ?>  name="DASHBOARD_PTF" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau de bord par intrants</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DASHBOARD_INTRANT') == 1) ? 'checked' : '' ?>  name="DASHBOARD_INTRANT" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau de bord par incidents</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DASHBOARD_INCIDENT') == 1) ? 'checked' : '' ?>  name="DASHBOARD_INCIDENT" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau de bord par demande</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DASHBOARD_DEMANDE') == 1) ? 'checked' : '' ?>  name="DASHBOARD_DEMANDE" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau de bord par maladie</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DASHBOARD_MALADIE') == 1) ? 'checked' : '' ?>  name="DASHBOARD_MALADIE" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau de bord des cas mal traités</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DASHBOARD_MAL_TRAITE') == 1) ? 'checked' : '' ?>  name="DASHBOARD_MAL_TRAITE" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Validation des protocoles de traitement ICCM</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('VALIDATION_PROTOCOLE_TRAITEMENT_ICCM') == 1) ? 'checked' : '' ?>  name="VALIDATION_PROTOCOLE_TRAITEMENT_ICCM" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Approbation DODS/PNLIP</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('APPROBATION_DODS_PNLIP') == 1) ? 'checked' : '' ?>  name="APPROBATION_DODS_PNLIP" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Approbation DISTRICT</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('APPROBATION_DISTRICT') == 1) ? 'checked' : '' ?>  name="APPROBATION_DISTRICT" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Approbation CDS</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('APPROBATION_CDS') == 1) ? 'checked' : '' ?>  name="APPROBATION_CDS" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau des PTF (Unicef, WV)</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('TABLEAU_PTF') == 1) ? 'checked' : '' ?>  name="TABLEAU_PTF" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau CAMEBU</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('TABLEAU_CAMEBU') == 1) ? 'checked' : '' ?>  name="TABLEAU_CAMEBU" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau des districts</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('TABLEAU_DISTRICT') == 1) ? 'checked' : '' ?>  name="TABLEAU_DISTRICT" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Validation des protocoles de traitement ICCM</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('VALIDATION_PROTOCOLE_TRAITEMENT_ICCM') == 1) ? 'checked' : '' ?>  name="VALIDATION_PROTOCOLE_TRAITEMENT_ICCM" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau des CDS</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('TABLEAU_CDS') == 1) ? 'checked' : '' ?>  name="TABLEAU_CDS" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Tableau des ASC</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('TABLEAU_ASC') == 1) ? 'checked' : '' ?>  name="TABLEAU_ASC" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Rapport</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('RAPPORT') == 1) ? 'checked' : '' ?>  name="RAPPORT" value="1" ></td>
                        </tr>
                        <tr>
                          <th>SIG</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('SIG') == 1) ? 'checked' : '' ?>  name="SIG" value="1" ></td>
                        </tr>
                        <tr>
                          <th>Données</th>
                          <td style="cursor: pointer;" ><input type="checkbox"  <?= $m = (set_value('DONNEES') == 1) ? 'checked' : '' ?>  name="DONNEES" value="1" ></td>
                        </tr>
                      </table>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-12" style="margin-top:31px;">
                      <button type="submit"  style="float: right;" id="button" class="btn btn-primary"><span class="fas fa-edit"></span> Enregistrer</button>

                    </div>
                  </div>
                </form> 
              </div>

            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>

  </div>
  <!-- ./wrapper -->
  <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">

  $('input[type=checkbox]').css('display','none');
  $('input[type=checkbox]').after('<div class="laces-checkbox"><i class="fa"></i></div>');
  $('input[type=checkbox]').each(function(){
    if($(this).prop('checked') == true) {
      $(this).find('~ .laces-checkbox .fa').addClass('fa-check');
    }
  });

  $('input[type=checkbox]').on('change', function(){
    if($(this).find('.fa').hasClass('fa-check')) {
      $(this).prev('input[type=checkbox]').prop('checked', false);
      $(this).find('.fa').removeClass('fa-check');
    } else {
      $(this).prev('input[type=checkbox]').prop('checked', true);
      $(this).find('.fa').addClass('fa-check');
    }
  });

  $('.laces-checkbox').on('click', function() {
    if($(this).find('.fa').hasClass('fa-check')) {
      $(this).prev('input[type=checkbox]').prop('checked', false);
      $(this).find('.fa').removeClass('fa-check');
    } else {
      $(this).prev('input[type=checkbox]').prop('checked', true);
      $(this).find('.fa').addClass('fa-check');
    }
  });
  $('#message').delay('slow').fadeOut(3000);
  $(document).ready(function(){
    var row_count ="1000000";
    $("#mytable").DataTable({
      "processing":true,
      "serverSide":false,
      "order":[],
      lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
      pageLength: 10,
      "columnDefs":[{
        "targets":[],
        "orderable":false
      }],

      dom: 'Bfrtlip',
      buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
      ],
      language: {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      }
    });
  });
</script>