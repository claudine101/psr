<div class="row">
  <legend>
  	<?= $title;?>
  	<div class="row pull-right">
      <div class="col-md-2" style="margin-right: 50px;">
      <a href="<?= base_url('ihm/Demande/add_demande')?>" class="btn btn-secondary">
        <i class="fa fa-plus"></i> Ajouter
      </a>  
    </div>
    <div class="col-md-2">
      <a href="<?= base_url('ihm/Historique_Demande')?>" class="btn btn-secondary">
        <i class="fa fa-book"></i> Historique
      </a>  
    </div>
    </div>
  </legend>
</div>
<div class="row">
  <div class="col-md-12">
  <?= $this->table->generate($demandes);?>
  </div>
</div>

