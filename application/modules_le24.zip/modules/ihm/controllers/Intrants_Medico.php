<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 01/2/2021
 Date fin :Le 01/2/2021
 Commentaire: controller pour le CRUD des Intrants_Medico
 */

 class Intrants_Medico extends CI_Controller
 {

 	public function __construct()
 	{
 		parent::__construct();
 	}


 	public function index()
 	{
 		$data['title']='Liste des Intrants ICCM';
 		$query="SELECT INTRANT_MEDICAUX_ID,DEGRE_HUMIDITE,INTRANT_MEDICAUX_DESCR,t.TYPE_INTRANT_DESCR,unit.INTRANT_UNITE_DESCR, INTRANT_MEDICAUX_CODE,intr.TYPE_INTRANT_ID,intr.INTRANT_UNITE_ID, QUANTITE_SEUIL, QUANTITE_SEUIL_BDS,QUANTITE_SEUIL_CDS,MODE_RECEPTION_ID,intr.NOMBRE_DOSE, TEMPERATURE_MIN_CONSERVATION, TEMPERATURE_MAX_CONSERVATION FROM intrant_medicaux intr left JOIN type_intrants t ON t.TYPE_INTRANT_ID=intr.TYPE_INTRANT_ID left JOIN intrant_unites unit ON unit.INTRANT_UNITE_ID=intr.INTRANT_UNITE_ID ORDER BY intr.INTRANT_MEDICAUX_ID DESC";
 		$intrants=$this->Modele->getRequete($query);

 		$tabledata = array();
 		foreach ($intrants as $intrant ) {

 			$type=array();
 			$type[]=$intrant['INTRANT_MEDICAUX_CODE'];
 			$type[]=$intrant['INTRANT_MEDICAUX_DESCR'];
 			$type[]=$intrant['INTRANT_UNITE_DESCR'];
 			$type[]=$intrant['TYPE_INTRANT_DESCR'];
 			//$type[]=$intrant['QUANTITE_SEUIL'];
 			// $type[]=$intrant['QUANTITE_SEUIL_BDS'];
 			// $type[]=$intrant['QUANTITE_SEUIL_CDS'];

 			if ($intrant['MODE_RECEPTION_ID']==1) 
 			{
 			 $type[]="DODS";
 			} elseif($intrant['MODE_RECEPTION_ID']==2) {
 				# code...
 				$type[]="PNILP";
 			}else
 			{
 				$type[]="N/A";
 			}

 			$type[]=$intrant['NOMBRE_DOSE'];
 			$type[]=$intrant['DEGRE_HUMIDITE'];
 			$type[]=$intrant['TEMPERATURE_MIN_CONSERVATION'];
 			$type[]=$intrant['TEMPERATURE_MAX_CONSERVATION'];



 			$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
 			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
 			<i class="fa fa-cog"></i> Options  <span class="caret">
 			</span></a>
 			<ul class="dropdown-menu dropdown-menu-right">';
 			$type['OPTIONS'] .="<li>
 			<a href='".base_url('ihm/Intrants_Medico/update_intrant_view/'.$intrant['INTRANT_MEDICAUX_ID'].'')."'>
 			<label class='text-info'>&nbsp;&nbsp;Modifier</label>
 			</a>
 			</li>";
 			$type['OPTIONS'] .="<li>
 			<a href='#' data-toggle='modal' data-target='#mydelete".$intrant['INTRANT_MEDICAUX_ID']."'>
 			<label class='text-danger'>&nbsp;&nbsp;Supprimer</label>
 			</a>
 			</li>";



 			$type['OPTIONS'] .= " </ul>
 			</div>
 			<div class='modal fade' id='mydelete".$intrant['INTRANT_MEDICAUX_ID']."'>
 			<div class='modal-dialog'>
 			<div class='modal-content'>

 			<div class='modal-body'>
 			<center><h5><strong>Voulez-vous supprimé un intrant </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $intrant['TYPE_INTRANT_DESCR']."</i></b>?</h5>
 			</center>
 			</div>

 			<div class='modal-footer'>
 			<a class='btn btn-danger btn-md' href='" . base_url('ihm/Intrants_Medico/delete_intrant/').$intrant['INTRANT_MEDICAUX_ID'] . "'>Supprimer
 			</a>
 			<button class='btn btn-primary btn-md' data-dismiss='modal'>
 			Quitter
 			</button>
 			</div>

 			</div>
 			</div>
 			</div>";


 			$tabledata[]=$type;
 		}

 		$template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-responsive table-hover table-condensed">', 'table_close' => '</table>');

 		// class="table table-bordered table-striped table-hover table-condensed"

 		$this->table->set_template($template);
 		$this->table->set_heading(array('CODE','INTRANT','UNITE','TYPE','MODE','DOSE','°C','T°(min) ','T°(max) ','ACTIONS'));
 		$data['tableau']=$tabledata;

 		$this->load->view('ihm/Intrants_Medico_Listing_view',$data);



 	}


 	public function add_intrant_view(){
 		$data['title']='Intrants ICCM';
 		$data['type_intrants']=$this->Modele->getList('type_intrants');
 		$data['unite_intrants']=$this->Modele->getList('intrant_unites');
 		$data['modes']=$this->Modele->getList('rc_mode_reception');
 		$this->load->view('ihm/Intrants_Medico_Add_View',$data);

 	}

 	public function insert_intrant(){
 		$this->form_validation->set_rules('description','Description','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('type','Type','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('unite','Unite','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		//$this->form_validation->set_rules('seuil','Seuil','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('min','Min','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('min','Min','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('max','Max','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('degre','Degre','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));

 		if ($this->form_validation->run()==FALSE) {
 			$data['title']='Nouvel Intrant';
 			$data['type_intrants']=$this->Modele->getList('type_intrants');
 			$data['unite_intrants']=$this->Modele->getList('intrant_unites');
 			$data['modes']=$this->Modele->getList('rc_mode_reception');

 			$this->load->view('ihm/Intrants_Medico_Add_View',$data);

	    // $this->page='ihm/Intrants_Medico_Add_View';
	    // $this->layout($data);
 		} else {

 			$description=$this->input->post('description');
 			$type=$this->input->post('type');
 			$unite=$this->input->post('unite');
 			$seuil=$this->input->post('seuil');
 			$min=$this->input->post('min');
 			$max=$this->input->post('max');
 			$degre=$this->input->post('degre');
 			$QUANTITE_SEUIL_CDS=$this->input->post('QUANTITE_SEUIL_CDS');
 			$QUANTITE_SEUIL_BDS=$this->input->post('QUANTITE_SEUIL_BDS');
 			$MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
 			$NOMBRE_DOSE=$this->input->post('NOMBRE_DOSE');


 			$data=array('INTRANT_MEDICAUX_CODE'=>1,
 				'INTRANT_MEDICAUX_DESCR'=>$description,
 				'TYPE_INTRANT_ID'=>$type,
 				'INTRANT_UNITE_ID'=>$unite,
 				'QUANTITE_SEUIL'=>$seuil,
 				'TEMPERATURE_MIN_CONSERVATION'=>$min,
 				'TEMPERATURE_MAX_CONSERVATION'=>$max,
 				'DEGRE_HUMIDITE'=>$degre,
 				'QUANTITE_SEUIL_CDS'=>$QUANTITE_SEUIL_CDS,
 				'QUANTITE_SEUIL_BDS'=>$QUANTITE_SEUIL_BDS,
 				'MODE_RECEPTION_ID'=>$MODE_RECEPTION_ID,
 				'NOMBRE_DOSE'=>$NOMBRE_DOSE
 			);
 			$sql=$this->Modele->insert_last_id('intrant_medicaux',$data);

 			if($sql >0){
 				$code_intrant = "C-".date('Y').'-'.$sql;
 				$this->Modele->update('intrant_medicaux',['INTRANT_MEDICAUX_ID'=>$sql],['INTRANT_MEDICAUX_CODE'=>$code_intrant]) ;

 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Intrant ajouté avec succes ! .
 				</div>
 				<br>' ;
 			}else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produite ! .
 				</div>
 				<br>' ;
 			}

 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/Intrants_Medico');
 		}
 	}




 	public function delete_intrant($id){

 		$sql=$this->Modele->delete('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$id));
 		if ($sql) {
 			$sms['sms']='<br>
 			<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			Intrant supprimé avec succes ! .
 			</div>
 			<br>' ;

 		} else {
 			$sms['sms']='<br>
 			<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			Une erreur s\'est produite ! .
 			</div>
 			<br>' ;
 		}

 		$this->session->set_flashdata($sms) ;
 		redirect('ihm/Intrants_Medico/index');
 	}

 	public function update_intrant_view($id){

 		$data['title']='Intrants ICCM';
 		$data['type_intrants']=$this->Modele->getList('type_intrants');
 		$data['unite_intrants']=$this->Modele->getList('intrant_unites');
 		$data['modes']=$this->Modele->getList('rc_mode_reception');
 		$query="SELECT INTRANT_MEDICAUX_ID,DEGRE_HUMIDITE,INTRANT_MEDICAUX_DESCR,QUANTITE_SEUIL_CDS,QUANTITE_SEUIL_BDS,NOMBRE_DOSE,MODE_RECEPTION_ID,t.TYPE_INTRANT_DESCR,unit.INTRANT_UNITE_DESCR, INTRANT_MEDICAUX_CODE,intr.TYPE_INTRANT_ID,intr.INTRANT_UNITE_ID, QUANTITE_SEUIL, QUANTITE_NATIONALE_DISPO, TEMPERATURE_MIN_CONSERVATION, TEMPERATURE_MAX_CONSERVATION FROM intrant_medicaux intr JOIN type_intrants t ON t.TYPE_INTRANT_ID=intr.TYPE_INTRANT_ID JOIN intrant_unites unit ON unit.INTRANT_UNITE_ID=intr.INTRANT_UNITE_ID AND INTRANT_MEDICAUX_ID=$id";
 		$data['intrants']=$this->Modele->getRequeteOne($query);


 		$this->load->view('ihm/Intrants_Medico_Update_View',$data);
  //    $this->page='ihm/Intrants_Medico_Update_View';
	 // $this->layout($data);
 	}

 	public function update_intrant($id){
 		$this->form_validation->set_rules('description','Description','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('type','Type','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('unite','Unite','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		//$this->form_validation->set_rules('seuil','Seuil','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('min','Min','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('min','Min','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('max','Max','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('degre','Degre','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		if ($this->form_validation->run()==FALSE) {

 			$data['title']='Formulaire de modification';
 			$data['type_intrants']=$this->Modele->getList('type_intrants');
 			$data['unite_intrants']=$this->Modele->getList('intrant_unites');
 			$query="SELECT INTRANT_MEDICAUX_ID,DEGRE_HUMIDITE,INTRANT_MEDICAUX_DESCR,t.TYPE_INTRANT_DESCR,unit.INTRANT_UNITE_DESCR, INTRANT_MEDICAUX_CODE,intr.TYPE_INTRANT_ID,intr.INTRANT_UNITE_ID, QUANTITE_SEUIL, QUANTITE_NATIONALE_DISPO, TEMPERATURE_MIN_CONSERVATION, TEMPERATURE_MAX_CONSERVATION FROM intrant_medicaux intr JOIN type_intrants t ON t.TYPE_INTRANT_ID=intr.TYPE_INTRANT_ID JOIN intrant_unites unit ON unit.INTRANT_UNITE_ID=intr.INTRANT_UNITE_ID AND INTRANT_MEDICAUX_ID=$id";
 			$data['modes']=$this->Modele->getList('rc_mode_reception');
 			$data['intrants']=$this->Modele->getRequeteOne($query);
 			$data['error']='';

 			$this->load->view('Intrants_Medico_Update_View',$data);
		 // $this->layout($data);
 		}else{
 			$description=$this->input->post('description');
 			$type=$this->input->post('type');
 			$unite=$this->input->post('unite');

 			$seuil=$this->input->post('seuil');
 			$min=$this->input->post('min');
 			$max=$this->input->post('max');
 			$degre=$this->input->post('degre');
 			$QUANTITE_SEUIL_CDS=$this->input->post('QUANTITE_SEUIL_CDS');
 			$QUANTITE_SEUIL_BDS=$this->input->post('QUANTITE_SEUIL_BDS');
 			$MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
 			$NOMBRE_DOSE=$this->input->post('NOMBRE_DOSE');

 			$data=array(
 				'INTRANT_MEDICAUX_DESCR'=>$description,
 				'TYPE_INTRANT_ID'=>$type,
 				'INTRANT_UNITE_ID'=>$unite,
 				'QUANTITE_SEUIL'=>$seuil,
 				'TEMPERATURE_MIN_CONSERVATION'=>$min,
 				'TEMPERATURE_MAX_CONSERVATION'=>$max,
 				'DEGRE_HUMIDITE'=>$degre,
 				'QUANTITE_SEUIL_CDS'=>$QUANTITE_SEUIL_CDS,
 				'QUANTITE_SEUIL_BDS'=>$QUANTITE_SEUIL_BDS,
 				'MODE_RECEPTION_ID'=>$MODE_RECEPTION_ID,
 				'NOMBRE_DOSE'=>$NOMBRE_DOSE
 			);


 			$sql=$this->Modele->update('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$id),$data);
 			if ($sql) {
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Intrant modifié avec succes ! .
 				</div>
 				<br>' ;

 			} else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produite ! .
 				</div>
 				<br>' ;
 			}
 		}

 		$this->session->set_flashdata($sms) ;
 		redirect('ihm/Intrants_Medico');
 	}



 }
