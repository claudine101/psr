<?php
/**
*Auteur du fichier:Mutunge Ixella
Date debut:le 1/02/2021
Date fin:le 1/02/2021
commentaire: CRUD ASC
*/


defined('BASEPATH') OR exit('No direct script access allowed');

class Agents_Sante extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }


  function index()
  {
    $data['error']='';
    $this->listing();
  }

  function ajouterAgent()
  {
    $data['error']='';
    $data['type']=$this->Modele->getListOrder('cds','CDS_NOM');

    $this->page = 'Agents_Sante_Add_View';
    $this->layout($data);


  }

  function listing()
  {
    $sql="SELECT ASC_ID,ASC_NOM,ASC_PRENOM,TELEPHONE1,TELEPHONE2,EMAIL,cds.CDS_ID,cds.CDS_NOM,ASC_CODE FROM ascs LEFT JOIN cds ON cds.CDS_ID = ascs.CDS_ID";
    $agents=$this->Modele->getRequete($sql);
    $agents_array=array();
    foreach ($agents as $agent) {
     $sub_array_agent=array();
     $sub_array_agent[]=$agent['ASC_NOM'];
     $sub_array_agent[]=$agent['ASC_PRENOM'];
     $sub_array_agent[]=$agent['TELEPHONE1'];
     $sub_array_agent[]=$agent['TELEPHONE2'];
     $sub_array_agent[]=$agent['EMAIL'];
     $type=$this->Modele->getOne('cds', array('CDS_ID' =>$agent['CDS_ID']));

     $sub_array_agent[]=$type['CDS_NOM'];




     $sub_array_agent['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array_agent['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydelete" . $agent['ASC_ID'] . "'><font color='red'>Supprimer</font></a></li>";
     $sub_array_agent['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Agents_Sante/getOneAgent/'. $agent['ASC_ID']) . "'>Modifier</a></li>";
     $sub_array_agent['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $agent['ASC_ID'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h5><strong>VOULEZ-VOUS SUPPRIMER UNE MALADIE</strong> : <b style:'background-color:prink';><i style='color:green;'>" . $agent['ASC_NOM']."</i></b>?</h5></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Agents_Sante/deleteAgent/'. $agent['ASC_ID']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";


     $agents_array[]=$sub_array_agent;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table  table-stripped table-hover table-condensed col-sm-4">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('Nom','Prenom','TELEPHONE1','TELEPHONE2','EMAIL','CDS','Actions'));
   $data['data_Agent']=$agents_array;
   $data['title'] = "Liste des agents";
        //$this->make_bread->add('Liste des Cultures', 'CULTURE/listing/', 1);
        // $data['breadcrumb'] = $this->make_bread->output();
   $this->page = 'Agents_Sante_List_View';
   $this->layout($data);

 }
 public function addAgent()
 {
   $this->form_validation->set_rules('ASC_NOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('ASC_PRENOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('TELEPHONE1','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('TELEPHONE2','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('EMAIL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('ASC_CODE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


   if ($this->form_validation->run() == FALSE)
   {
     $data['title'] = "Nouveau Agent";
     $data['error']='';

     $data['type']=$this->Modele->getListOrder('cds',array(),'CDS_NOM');


     $this->page = 'Agents_Sante_Add_View';
     $this->layout($data);
   }

   else
   {
     $dataInsert=array('ASC_NOM'=>$this->input->post('ASC_NOM'),
       'ASC_PRENOM'=>$this->input->post('ASC_PRENOM'),
       'TELEPHONE1'=>$this->input->post('TELEPHONE1'),
       'TELEPHONE2'=>$this->input->post('TELEPHONE2'),
       'EMAIL'=>$this->input->post('EMAIL'),
       'CDS_ID'=>$this->input->post('CDS_ID'),
       'ASC_CODE'=>$this->input->post('ASC_CODE'));

     $table='ascs';
     $this->Modele->create('ascs',$dataInsert);
     $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un agent <b>".' '.$this->input->post('ASC_NOM').'</b> '." est faite avec succès".'</div>';
     $this->session->set_flashdata($data);
     redirect(base_url('ihm/Agents_Sante/listing'));
   }
 }

 public function updateAgent()
 {
   $this->form_validation->set_rules('ASC_NOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('ASC_PRENOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('TELEPHONE1','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('TELEPHONE2','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('EMAIL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('ASC_CODE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


   if ($this->form_validation->run() == FALSE)
   {
     $id=$this->input->post('ASC_ID');
     $data['type']=$this->Modele->getListOrder('cds',array(),'CDS_NOM');
     $data['asc']=$this->Modele->getOne('ascs',array('ASC_ID'=>$id));
     $data['error']='';

     $this->page = 'Agents_Sante_Update_View';
     $this->layout($data);
   }

   else
   {
     $id=$this->input->post('ASC_ID');
     $data=array('ASC_NOM'=>$this->input->post('ASC_NOM'),
       'ASC_PRENOM'=>$this->input->post('ASC_PRENOM'),
       'TELEPHONE1'=>$this->input->post('TELEPHONE1'),
       'TELEPHONE2'=>$this->input->post('TELEPHONE2'),
       'EMAIL'=>$this->input->post('EMAIL'),
       'CDS_ID'=>$this->input->post('CDS_ID'),
       'ASC_CODE'=>$this->input->post('ASC_CODE')
     );
     $this->Modele->update('ascs',array('ASC_ID'=>$id),$data);
     $datas['message']='<div class="alert alert-success text-center" id="message">La modification du  '.$this->input->post('ASC_NOM').'</b> Faite avec Succes</div>';
     $this->session->set_flashdata($datas);
     redirect(base_url('ihm/Agents_Sante/listing'));
   }

 }
 public function deleteAgent()
 {
   $table="ascs";
   $criteres['ASC_ID']=$this->uri->segment(4);
   $data['rows']= $this->Modele->getOne( $table,$criteres);
   $this->Modele->delete($table,$criteres);

   $data['message']='<div class="alert alert-success text-center" id="message">'."Agent <b> ".' '.$data['rows']['ASC_NOM'].' </b> '." est supprimé avec succès".'</div>';
   $this->session->set_flashdata($data);
   redirect(base_url('ihm/Agents_Sante/listing'));


 }
 public function getOneAgent()
 {
   $id=$this->uri->segment(4);
   $data['type']=$this->Modele->getListOrder('cds',array(),'CDS_NOM');
   $data['asc']=$this->Modele->getOne('ascs',array('ASC_ID'=>$id));
   $data['error']='';
   $this->page = 'Agents_Sante_Update_View';
   $this->layout($data);

 }



}
?>
