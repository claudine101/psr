<?php

/**
 *Auteur du fichier:NIYINDORERA Simon
 Date début:le 29/01/2021
 Date fin :le 01/02/2021
 Commentaire:CRUD PROVINCES
 */
 class Provinces extends CI_Controller
 {

   public function __construct()
   {
    parent::__construct();
  }


  public function Add_province(){
    $data['title']='Formulaire des provinces';
    $this->page='ihm/Provinces_Ajouter_View';
    $this->layout($data);
  }

  function index()
  {

    $provinces=$this->Modele->getList('provinces');
    $data_provinces=array();

    foreach ($provinces as $key_provinces) {

     $Provinces=array();
     $Provinces[]= $key_provinces['PROVINCE_CODE'];
     $Provinces[]= $key_provinces['PROVINCE_NOM'];
     $Provinces[]= $key_provinces['LATITUDE'];
     $Provinces[]= $key_provinces['LONGITUDE'];



     $Provinces['OPTIONS'] = '<div class="dropdown">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff">
     <i class="fa fa-cog"></i>
     Options
     <span class="caret"></span>
     </a>
     <ul class="dropdown-menu dropdown-menu-left">';

     $Provinces['OPTIONS'] .="<li>
     <a href='".base_url('ihm/Provinces/Update_view/'. $key_provinces['PROVINCE_ID']) ."'>
     <label class='text-info'>Modifier</label>
     </a>
     </li>";
     $Provinces['OPTIONS'] .="<li>
     <a href='#' data-toggle='modal' data-target='#mydelete".$key_provinces['PROVINCE_ID']."'>
     <label class='text-danger'>Supprimer</label>
     </a>
     </li>
     </ul>
     </div>";


     $Provinces['OPTIONS'] .= "
     <div class='modal fade' id='mydelete".$key_provinces['PROVINCE_ID']."'>
     <div class='modal-dialog'>
     <div class='modal-content'>
     <div class='modal-body'>
     <center>
     <h5><strong>VOULEZ-VOUS SUPPRIMER UNE PROVINCE</strong> : <b style:'background-color:prink';>
     <i style='color:green;'>" .$key_provinces['PROVINCE_NOM']."</i></b>?
     </h5>
     </center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='".base_url('ihm/Provinces/Delete_Province/'.$key_provinces['PROVINCE_ID']) . "'>Supprimer
     </a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div>";

     $data_provinces[]=$Provinces;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed col-md-12">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('Code','Province','Latitude','Longitude','Actions'));
   $data['data']=$data_provinces;
   $data['title'] = "LISTE DES PROVINCES SANITAIRE";
   $this->page = 'ihm/Provinces_List_view';

   $this->layout($data);

 }

 public function Ajouter(){
   $this->form_validation->set_rules('code', 'Code','required|is_unique[provinces.PROVINCE_CODE]',array('required'=> 'You have not provided %s.','is_unique'     => 'This %s already exists.'));

   $this->form_validation->set_rules('nom', 'nom','required',array('required'=> 'You have not provided %s.'));

   $this->form_validation->set_rules('latitude', 'latitude','required',array('required'=> 'You have not provided %s.'));

   $this->form_validation->set_rules('longitude', 'longitude','required',array('required'=> 'You have not provided %s.'));

   if ($this->form_validation->run() == FALSE){
    $data['code'] = $this->input->post('code');
    $data['title'] = "LISTE DES PROVINCES SANITAIRE";
    $this->page = 'ihm/Provinces_Ajouter_View';
    $this->layout($data);

  }else{
    $code=$this->input->post('code');
    $nom=$this->input->post('nom');
    $latitude=$this->input->post('latitude');
    $longitude=$this->input->post('longitude');

    $data=array('PROVINCE_CODE'=>$code,
      'PROVINCE_NOM'=>$nom,
      'LATITUDE'=>$latitude,
      'LONGITUDE'=>$longitude
    );

    $this->Modele->create('provinces',$data);
    redirect('ihm/Provinces/index');
  }

}


public function Update_view($id){
  $data['title']='Formulaire de Modification';

  $data['province']=$this->Modele->getOne('provinces',array('PROVINCE_ID'=>$id));
  $this->page='ihm/Provinces_Modifier_View';
  $this->layout($data);

}
public function Modifier($id){
  $this->form_validation->set_rules('code', 'Code','required',array('required'=> 'You have not provided %s.'));

  $this->form_validation->set_rules('nom', 'nom','required',array('required'=> 'You have not provided %s.'));

  $this->form_validation->set_rules('latitude', 'latitude','required',array('required'=> 'You have not provided %s.'));

  $this->form_validation->set_rules('longitude', 'longitude','required',array('required'=> 'You have not provided %s.'));

  if ($this->form_validation->run() == FALSE){
   $data['title']='Formulaire de Modification';

   $data['province']=$this->Modele->getOne('provinces',array('PROVINCE_ID'=>$id));
   $data['error']='';
   $this->page='ihm/Provinces_Modifier_View';
   $this->layout($data);
 }else{

  $code=$this->input->post('code');
  $nom=$this->input->post('nom');
  $latitude=$this->input->post('latitude');
  $longitude=$this->input->post('longitude');
  $data=array('PROVINCE_CODE'=>$code,
   'PROVINCE_NOM'=>$nom,
   'LATITUDE'=>$latitude,
   'LONGITUDE'=>$longitude
 );

  $this->Modele->update('provinces',$data,array('PROVINCE_ID'=>$id));
  redirect('ihm/Provinces/index');

}
}

public function Delete_Province($id){
  $this->Modele->delete('provinces',array('PROVINCE_ID'=>$id));
  redirect(base_url('ihm/Provinces/index'));
}


}
