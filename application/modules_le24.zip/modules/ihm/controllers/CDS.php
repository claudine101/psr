<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 25/2/2021
 Date fin :Le 25/2/2021
 Commentaire: controller pour le CRUD des CDS
 */
 class CDS extends CI_Controller
 {

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $data['title']='Liste des CDS';
    $query="SELECT cds.*,districts.DISTRICT_NOM FROM cds JOIN districts ON cds.DISTRICT_ID=districts.DISTRICT_ID ORDER BY cds.CDS_ID DESC";
    $CDS=$this->Modele->getRequete($query);

    $tabledata = array();
    foreach ($CDS as $CDS_info ) {

      $type=array();
      $type[]=$CDS_info['CDS_CODE'];
      $type[]=$CDS_info['CDS_NOM'];
      $type[]=$CDS_info['DISTRICT_NOM'];
      $type[]=$CDS_info['LATITUDE'];
      $type[]=$CDS_info['LONGITUDE'];


      $type['OPTIONS'] = '<div class="dropdown">
      <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
      <i class="fa fa-cog"></i>
      Options <span class="caret"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-left">';
      $type['OPTIONS'] .="<li><a href='".base_url('ihm/CDS/update_CDS_view/').$CDS_info['CDS_ID'] ."'><label class='text-info'>Modifier</label></a></li>";
      $type['OPTIONS'] .="<li><a href='#' data-toggle='modal' data-target='#mydelete".$CDS_info['CDS_ID']."'><label class='text-danger'>Supprimer</label></a></li>";


      $type['OPTIONS'] .= " </ul>
      </div>
      <div class='modal fade' id='mydelete".$CDS_info['CDS_ID']."'>
      <div class='modal-dialog'>
      <div class='modal-content'>

      <div class='modal-body'>
      <center>
      <h5><strong>VOULEZ-VOUS SUPPRIMER CDS </strong> : <b style:'background-color:prink';>
      <i style='color:green;'>" . $CDS_info['CDS_NOM']."</i></b> ?
      </h5>
      </center>
      </div>

      <div class='modal-footer'>
      <a class='btn btn-danger btn-md' href='" . base_url('ihm/CDS/delete_CDS/').$CDS_info['CDS_ID'] . "'>Supprimer
      </a>
      <button class='btn btn-primary btn-md' data-dismiss='modal'>
      Quitter
      </button>
      </div>

      </div>
      </div>
      </div>";


      $tabledata[]=$type;
    }

    $template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
    $this->table->set_template($template);
    $this->table->set_heading(array('CODE CDS','CDS','DISTRICT','LATITUDE','LONGITUDE','ACTIONS'));
    $data['CDS']=$tabledata;
    $this->page='ihm/CDS_Listing_View';
    $this->layout($data);

  }


  public function add_CDS(){
   $data['title']='Nouveau CDS';
   $data['districts']=$this->Modele->getList('districts');
   $this->page='ihm/CDS_Add_View';
   $this->layout($data);
 }

 public function insert_CDS(){
  $this->form_validation->set_rules('cds', 'Nom CDS', 'trim|required');
  $this->form_validation->set_rules('district', 'DISTRICT', 'trim|required');
  $this->form_validation->set_rules('latitude', 'LATITUDE', 'trim|required');
  $this->form_validation->set_rules('longitude', 'LONGITUDE', 'trim|required');

  if ($this->form_validation->run() == FALSE) {
   $this->add_CDS();
 }else{
  $cds=$this->input->post('cds');
  $district=$this->input->post('district');
  $latitude=$this->input->post('latitude');
  $longitude=$this->input->post('longitude');

  $data=array('CDS_CODE'=>1,
    'CDS_NOM'=>$cds,
    'LATITUDE'=>$latitude,
    'LONGITUDE'=>$longitude,
    'DISTRICT_ID'=>$district,
  );
  $sql=$this->Modele->insert_last_id('cds',$data);

  if($sql >0){
   $code_CDS = "C-".date('Y').'-'.$sql;
   $this->Modele->update('cds',['CDS_ID'=>$sql],['CDS_CODE'=>$code_CDS]) ;
   $sms['sms']='<br>
   <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
   <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
   </a><strong> Oup! </strong>
   CDS ajouté avec succès ! .
   </div>
   <br>' ;
 }else {
  $sms['sms']='<br>
  <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
  </a><strong> Oup! </strong>
  Une erreur s\'est produite ! .
  </div>
  <br>' ;
}


$this->session->set_flashdata($sms) ;
redirect('ihm/CDS');
}
}

public function delete_CDS($id){
  $sql=$this->Modele->delete('cds',array('CDS_ID'=>$id));
  if ($sql) {
    $sms['sms']='<br>
    <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
    </a><strong> Oup! </strong>
    CDS supprimé avec succès ! .
    </div>
    <br>' ;
    $this->session->set_flashdata($sms) ;
    redirect('ihm/CDS');
  } else {
    $sms['sms']='<br>
    <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
    </a><strong> Oup! </strong>
    Une erreur s\'est produite ! .
    </div>
    <br>' ;
    $this->session->set_flashdata($sms) ;
    redirect('ihm/CDS');
  }
}

public function update_CDS_view($id){
 $data['title']='Formulaire de modification';
 $data['districts']=$this->Modele->getList('districts');
 $data['CDS']=$this->Modele->getOne('CDS',array('CDS_ID'=>$id));
 $data['id_district']=$this->Modele->getOne('districts',array('DISTRICT_ID'=>$data['CDS']['DISTRICT_ID']));
 $this->page='ihm/CDS_Update_View';
 $this->layout($data);
}

public function update_CDS($id){
  $this->form_validation->set_rules('cds', 'Nom CDS', 'trim|required');
  $this->form_validation->set_rules('district', 'DISTRICT', 'trim|required');
  $this->form_validation->set_rules('latitude', 'LATITUDE', 'trim|required');
  $this->form_validation->set_rules('longitude', 'LONGITUDE', 'trim|required');

  if ($this->form_validation->run() == FALSE) {
   $this->update_CDS_view($id);
 }else{
  $cds=$this->input->post('cds');
  $district=$this->input->post('district');
  $latitude=$this->input->post('latitude');
  $longitude=$this->input->post('longitude');

  $data=array('CDS_NOM'=>$cds,
    'LATITUDE'=>$latitude,
    'LONGITUDE'=>$longitude,
    'DISTRICT_ID'=>$district,
  );
  $sql=$this->Modele->update('cds',array('CDS_ID'=>$id),$data);
  if ($sql) {
    $sms['sms']='<br>
    <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
    </a><strong> Oup! </strong>
    CDS modifié avec succès ! .
    </div>
    <br>' ;
    $this->session->set_flashdata($sms) ;
    redirect('ihm/CDS');
  } else {
    $sms['sms']='<br>
    <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
    </a><strong> Oup! </strong>
    Une erreur s\'est produite ! .
    </div>
    <br>' ;
    $this->session->set_flashdata($sms) ;
    redirect('ihm/CDS');
  }

}
}



}
