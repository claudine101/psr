
<?php
/**
* auteur:christa
* date debut:28/01/2021
* date fin:29/01/2021
* commentaire:crud de la table intervenants_structure
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Intervenant_Structure extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function index()
  {
    $data['error']='';
    $this->listing();

    //$data = [];
    //$this->load->view('Type_intervenants_New', $data);
  }

  function listing()
  {
   $this->load->view('Intervenant_Structure_New_View');
  }

  function ajouter(){

   $data['error']='';
   $data['title'] = "Nouvel Intervenant";
   $data['types']=$this->Modele->getListOrder('type_intervenants_structures','TYPE_INTERVENANT_STRUCTURE_DESCR');
   // $data['type']=$this->Modele->getListOrder('provinces','PROVINCE_NOM');
   $this->load->view('Intervenant_Structure_View',$data);
   
 }


public function getinfo()
{


$query_principal='SELECT inter.INTERVENANT_STRUCTURE_ID, inter.INTERVENANT_STRUCTURE_DESCR,inter.INTERVENANT_STRUCTURE_CODE, inter.TELEPHONE,inter.EMAIL, type_inter.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure inter  JOIN type_intervenants_structures type_inter ON type_inter.TYPE_INTERVENANT_STRUCTURE_ID=inter.TYPE_INTERVENANT_STRUCTURE_ID';

  



$var_search= !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

$limit='LIMIT 0,10';


if($_POST['length'] != -1){
  $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
}
$order_by='';



$order_column=array('INTERVENANT_STRUCTURE_DESCR','INTERVENANT_STRUCTURE_CODE','TYPE_INTERVENANT_STRUCTURE_DESCR','TELEPHONE','EMAIL');

$order_by = isset($_POST['order']) ? ' ORDER BY '.$order_column[$_POST['order']['0']['column']] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INCIDENT_ID   DESC';

$search = !empty($_POST['search']['value']) ? (" AND  (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR TYPE_INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR TELEPHONE LIKE '%$var_search%' OR EMAIL LIKE '%$var_search%') ") : '';     
      
$critaire = '';

 $query_secondaire=$query_principal.' '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
 $query_filter = $query_principal.' '.$critaire.' '.$search;


 $fetch_op = $this->Modele->datatable($query_secondaire);
 $data = array();
 foreach ($fetch_op as $row) {

$option = '<div class="dropdown ">
    <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
    <i class="fa fa-cog"></i>
    Action
    <span class="caret"></span></a>
    <ul class="dropdown-menu dropdown-menu-left">
    ';

    $option .= "<li><a hre='#' data-toggle='modal'
    data-target='#mydelete" . $row->INTERVENANT_STRUCTURE_ID . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
    $option .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenant_Structure/getOne/'.$row->INTERVENANT_STRUCTURE_ID) . "'><label class='text-info'>&nbsp;&nbsp;Modifier</label></a></li>";
    $option .= " </ul>
    </div>
    <div class='modal fade' id='mydelete" .  $row->INTERVENANT_STRUCTURE_ID . "'>
    <div class='modal-dialog'>
    <div class='modal-content'>

    <div class='modal-body'>
    <center><h5><strong>Voulez-vous supprimer?</strong> <br><b style='background-color:prink;color:green;'><i>" .$row->INTERVENANT_STRUCTURE_ID."</i></b></h5></center>
    </div>

    <div class='modal-footer'>
    <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenant_Structure/delete/'.$row->INTERVENANT_STRUCTURE_ID) . "'>Supprimer</a>
    <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
    </div>

    </div>
    </div>
    </div>";

   $sub_array = array();
   $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;  
   $sub_array[]=$row->INTERVENANT_STRUCTURE_CODE;  
   $sub_array[]=$row->TYPE_INTERVENANT_STRUCTURE_DESCR;
   $sub_array[]=$row->TELEPHONE;
   $sub_array[]=$row->EMAIL;
   $sub_array[]=$option;   


  

   $data[] = $sub_array;
 }
 $output = array(
  "draw" => intval($_POST['draw']),
  "recordsTotal" =>$this->Modele->all_data($query_principal),
  "recordsFiltered" => $this->Modele->filtrer($query_filter),
  "data" => $data
);
echo json_encode($output);

}


 function listing2()
 {

      //$intervenants=$this->Modele->getList('intervenants_structure');
  $sql="SELECT inter.INTERVENANT_STRUCTURE_ID, inter.INTERVENANT_STRUCTURE_DESCR,inter.INTERVENANT_STRUCTURE_CODE, inter.TELEPHONE,inter.EMAIL, type_inter.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure inter  JOIN type_intervenants_structures type_inter ON type_inter.TYPE_INTERVENANT_STRUCTURE_ID=inter.TYPE_INTERVENANT_STRUCTURE_ID";

  $intervenants=$this->Modele->getRequete($sql);
  $data_intervenant=array();

  foreach ($intervenants as $key_intervenants) {
    
    $intervenants_structure=array();
    $intervenants_structure[]=$key_intervenants['INTERVENANT_STRUCTURE_DESCR'];
    $intervenants_structure[]=$key_intervenants['INTERVENANT_STRUCTURE_CODE'];
    $intervenants_structure[]=$key_intervenants['TYPE_INTERVENANT_STRUCTURE_DESCR'];
    $intervenants_structure[]=$key_intervenants['TELEPHONE'];
    $intervenants_structure[]=$key_intervenants['EMAIL'];
    

    $intervenants_structure['OPTIONS'] = '<div class="dropdown ">
    <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
    <i class="fa fa-cog"></i>
    Action
    <span class="caret"></span></a>
    <ul class="dropdown-menu dropdown-menu-left">
    ';

    $intervenants_structure['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
    data-target='#mydelete" . $key_intervenants['INTERVENANT_STRUCTURE_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
    $intervenants_structure['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenant_Structure/getOne/'. $key_intervenants['INTERVENANT_STRUCTURE_ID']) . "'><label class='text-info'>&nbsp;&nbsp;Modifier</label></a></li>";
    $intervenants_structure['OPTIONS'] .= " </ul>
    </div>
    <div class='modal fade' id='mydelete" . $key_intervenants['INTERVENANT_STRUCTURE_ID'] . "'>
    <div class='modal-dialog'>
    <div class='modal-content'>

    <div class='modal-body'>
    <center><h5><strong>Voulez-vous supprimer?</strong> <br><b style='background-color:prink;color:green;'><i>" . $key_intervenants['INTERVENANT_STRUCTURE_DESCR']."</i></b></h5></center>
    </div>

    <div class='modal-footer'>
    <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenant_Structure/delete/'. $key_intervenants['INTERVENANT_STRUCTURE_ID']) . "'>Supprimer</a>
    <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
    </div>

    </div>
    </div>
    </div>";

    $data_intervenant[]=$intervenants_structure;
  }

  $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
    'table_close' => '</table>'
  );
  $this->table->set_template($template);
  $this->table->set_heading(array('STRUCTURE','CODE','INTERVENANT','TELEPHONE','EMAIL','OPTIONS'));
  $data['data']=$data_intervenant;
  $data['title'] = "Liste des structures intervenants";
  $this->load->view('Intervenant_Structure_List_View',$data);
}






public function add()
{


 $this->form_validation->set_rules('INTERVENANT_STRUCTURE_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 $this->form_validation->set_rules('INTERVENANT_STRUCTURE_CODE','', 'trim|required|is_unique[intervenants_structure.INTERVENANT_STRUCTURE_CODE]',array(
  'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>',
  'is_unique'=>'<font style="color:red;size:2px;">Le code existe déjà</font>'));

 $this->form_validation->set_rules('TELEPHONE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 $this->form_validation->set_rules('EMAIL','', 'trim|required|is_unique[intervenants_structure.EMAIL]|valid_email',array(
  'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>',
  'is_unique'=>'<font style="color:red;size:2px;">L\'email doît être unique</font>','valid_email'=>'<font style="color:red;size:2px;">L\'email doît être valide</font>'
));

 $this->form_validation->set_rules('LATITUDE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 $this->form_validation->set_rules('LONGITUDE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 // $this->form_validation->set_rules('PROVINCE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 $this->form_validation->set_rules('TYPE_INTERVENANT_STRUCTURE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 if ($this->form_validation->run() == FALSE)
 {
  $this->ajouter();
}

else
{

 $dataInsert=array('INTERVENANT_STRUCTURE_DESCR'=>$this->input->post('INTERVENANT_STRUCTURE_DESCR'),
   'INTERVENANT_STRUCTURE_CODE'=>$this->input->post('INTERVENANT_STRUCTURE_CODE'),
   'TELEPHONE'=>$this->input->post('TELEPHONE'),
   'EMAIL'=>$this->input->post('EMAIL'),
   'LATITUDE'=>$this->input->post('LATITUDE'),
   'LONGITUDE'=>$this->input->post('LONGITUDE'),
   'TYPE_INTERVENANT_STRUCTURE_ID'=>$this->input->post('TYPE_INTERVENANT_STRUCTURE_ID'));

 $table='intervenants_structure';
 $this->Modele->create('intervenants_structure',$dataInsert);

 $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un intervenant <b>".' '.$this->input->post('INTERVENANT_STRUCTURE_DESCR').'</b> '." est faite avec succès".'</div>';
 $this->session->set_flashdata($data);
 redirect(base_url('ihm/Intervenant_Structure/listing'));


}
}


// function check_code()
// {
//   $INTERVENANT_STRUCTURE_CODE=$this->input->post('INTERVENANT_STRUCTURE_CODE');
//   if (empty($INTERVENANT_STRUCTURE_CODE)) 
//   {
//     $this->form_validation->set_message('check_code','<font style="color:red;size:2px;">Le champ est Obligatoire</font>');
//     return FALSE;
//   } else {
//     $code=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID !='=>$this->input->post('INTERVENANT_STRUCTURE_ID'),'INTERVENANT_STRUCTURE_CODE'=>$INTERVENANT_STRUCTURE_CODE));
    
//     if ($code>1) 
//     {
//       $this->form_validation->set_message('check_code','<font style="color:red;size:2px;">Le code existe déjà!</font>');
//     return FALSE;

//     } else {
//       return TRUE;
//     }
    
//   }
  
// }


public function getOne()
{

  $id=$this->uri->segment(4);
  $data['data']=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$id));
  $data['types']=$this->Modele->getList('type_intervenants_structures');
  $data['error']='';
  $data['title'] = "Modification des intervenants";
  $this->load->view('Intervenant_Structure_Modif_View',$data);

}

public function update()
{


  $this->form_validation->set_rules('INTERVENANT_STRUCTURE_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  $this->form_validation->set_rules('INTERVENANT_STRUCTURE_CODE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  $this->form_validation->set_rules('TELEPHONE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  $this->form_validation->set_rules('EMAIL','', 'trim|required|valid_email',array(
  'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>','valid_email'=>'<font style="color:red;size:2px;">L\'email doît être valide</font>'
));

  $this->form_validation->set_rules('LATITUDE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  $this->form_validation->set_rules('LONGITUDE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 
  $this->form_validation->set_rules('TYPE_INTERVENANT_STRUCTURE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));



  if ($this->form_validation->run() == FALSE)
  {

    $id=$this->input->post('INTERVENANT_STRUCTURE_ID');
    $data['title'] = "Modifier un intervenant";

    $data['types']=$this->Modele->getListOrder('type_intervenants_structures',array(),'TYPE_INTERVENANT_STRUCTURE_DESCR');
    // $data['type']=$this->Modele->getListOrder('provinces',array(),'PROVINCE_NOM');

    $data['data']=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$id));
    $data['error']='';
    $this->load->view('Intervenant_Structure_Modif_View',$data);

  }

  else
  {


    $id=$this->input->post('INTERVENANT_STRUCTURE_ID');
    $data=array(
     'INTERVENANT_STRUCTURE_DESCR'=>$this->input->post('INTERVENANT_STRUCTURE_DESCR'),
     'INTERVENANT_STRUCTURE_CODE'=>$this->input->post('INTERVENANT_STRUCTURE_CODE'),
     'TELEPHONE'=>$this->input->post('TELEPHONE'),
     'EMAIL'=>$this->input->post('EMAIL'),

     'TYPE_INTERVENANT_STRUCTURE_ID'=>$this->input->post('TYPE_INTERVENANT_STRUCTURE_ID')
   );

    $this->Modele->update('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$id),$data);
    $datas['message']='<div class="alert alert-success text-center" id="message">La modification du  '.$this->input->post('INTERVENANT_STRUCTURE_DESCR').'</b> est faite avec succès</div>';
    $this->session->set_flashdata($datas);
    redirect(base_url('ihm/Intervenant_Structure/listing'));
  }

}

public function delete()
{
  $table="intervenants_structure";
  $criteres['INTERVENANT_STRUCTURE_ID']=$this->uri->segment(4);
  $data['rows']= $this->Modele->getOne( $table,$criteres);
  $this->Modele->delete($table,$criteres);

  $data['message']='<div class="alert alert-success text-center" id="message">'."".$data['rows']['INTERVENANT_STRUCTURE_DESCR'].' </b> '." est supprimé avec succès".'</div>';
  $this->session->set_flashdata($data);
  redirect(base_url('ihm/Intervenant_Structure/listing'));


}


}
?>
