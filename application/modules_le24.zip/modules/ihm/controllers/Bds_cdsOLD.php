<?php

/**
 * auteur:Cedric
 * date debut:02/03/2021
 * date fin:01/02/2021
 * commentaire:crud de la table Partenaires technique financier
 *Auteur: Nandou
 * date debut:16/04/2021
 * date fin:16/04/2021
 * commentaire:Liste json
 */
class Bds_cds extends CI_Controller
{

	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['title']="Liste des partenaires technique financier";
		$this->load->view('Bds_cds_List_View',$data);
		// $this->listing();
	}

	function getInfo()
	{
		$critere_array =array();
  	$var_search = $_POST['search']['value'];
  	$sql='SELECT bds_cds.BDS_CDS_ID,intr_bds.INTERVENANT_STRUCTURE_DESCR AS BDS,intr_cds.INTERVENANT_STRUCTURE_DESCR AS CDS FROM bds_cds JOIN intervenants_structure AS intr_bds ON intr_bds.INTERVENANT_STRUCTURE_ID=bds_cds.BDS_ID JOIN intervenants_structure AS intr_cds ON intr_cds.INTERVENANT_STRUCTURE_ID=bds_cds.CDS_ID';
  	$limit='LIMIT 0,10';
  	if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$search = !empty($_POST['search']['value']) ? ("WHERE intr_bds.INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR intr_cds.INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%'") : '';
  	$query_secondaire=$sql.' '.$search.' '.$limit;
  	$query_filtrer=$sql.' '.$search;
  	$fetch_data = $this->Modele->datatable($query_secondaire);
  	$tabledata=array();
  	foreach ($fetch_data as $req)
  	{
  		$ptf_structure=array();
  		$ptf_structure[]=$req->BDS;
 			$ptf_structure[]=$req->CDS;
 			$OPTIONS='
				<div class="dropdown">
					<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
							<i class="fa fa-cog"></i>Action<span class="caret"></span></a>
					<ul class="dropdown-menu dropdown-menu-left">';

			$OPTIONS.="<li><a hre='#' data-toggle='modal'
			data-target='#mydelete" .$req->BDS_CDS_ID. "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";

			$OPTIONS.="<li><a class='btn-md' href='" . base_url('ihm/Bds_cds/getOne/'.$req->BDS_CDS_ID) . "'>&nbsp;&nbsp;Modifier</a></li>";

			$OPTIONS.="</ul></div>
					<div class='modal fade' id='mydelete" .$req->BDS_CDS_ID. "'>
						<div class='modal-dialog'>
							<div class='modal-content'>
								<div class='modal-body'>
									<center><h5><strong>Voulez-vous supprimer?</strong><br> <b style='background-color:prink;color:green;'><i>" . $req->CDS."(".$req->BDS_CDS_ID.")"."</i></b></h5></center>
								</div>
								<div class='modal-footer'>
									<a class='btn btn-danger btn-md' href='" . base_url('ihm/Bds_cds/delete/'.$req->BDS_CDS_ID) . "'>Supprimer</a>
									<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
								</div>
							</div>
						</div>
					</div>";
			$ptf_structure[]=$OPTIONS;
			$tabledata[]=$ptf_structure;
  	}

  	$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($sql),
			"recordsFiltered" => $this->Modele->filtrer($query_filtrer),
			"data" => $tabledata
		);
		echo json_encode($output);
	}
	function listing()
	{
		redirect(base_url('ihm/Bds_cds/index'));
	}

	// function index()
	// {
	// 	$data['error']='';
	// 	$this->listing();
	// }
	// function listing()
	// {
	// 	$sql='SELECT BDS_CDS_ID, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID = BDS_ID) AS BDS, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID = CDS_ID) AS CDS FROM bds_cds WHERE 1 ';
	// 	$affectations = $this->Modele->getRequete($sql);

	// 	$data_bds=array();

	// 	foreach ($affectations as $key) {
	// 		$ptf_structure= array();
	// 		$ptf_structure[]= $key['BDS'];
	// 		$ptf_structure[]= $key['CDS'];

	// 		$ptf_structure["OPTIONS"]= '<div class="dropdown">
	// 		<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
	// 		<i class="fa fa-cog"></i>
	// 		Action
	// 		<span class="caret"></span></a>
	// 		<ul class="dropdown-menu dropdown-menu-left">
	// 		';

	// 		$ptf_structure["OPTIONS"].= "<li><a hre='#' data-toggle='modal'
	// 		data-target='#mydelete" . $key['BDS_CDS_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
	// 		$ptf_structure["OPTIONS"] .= "<li><a class='btn-md' href='" . base_url('ihm/Bds_cds/getOne/'. $key['BDS_CDS_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";
	// 		$ptf_structure["OPTIONS"] .= " </ul>
	// 		</div>
	// 		<div class='modal fade' id='mydelete" . $key['BDS_CDS_ID'] . "'>
	// 		<div class='modal-dialog'>
	// 		<div class='modal-content'>

	// 		<div class='modal-body'>
	// 		<center><h5><strong>Voulez-vous supprimer?</strong><br> <b style='background-color:prink;color:green;'><i>" . $key['CDS']."(".$key['BDS'].")"."</i></b></h5></center>
	// 		</div>

	// 		<div class='modal-footer'>
	// 		<a class='btn btn-danger btn-md' href='" . base_url('ihm/Bds_cds/delete/'. $key['BDS_CDS_ID']) . "'>Supprimer</a>
	// 		<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
	// 		</div>

	// 		</div>
	// 		</div>
	// 		</div>";


	// 		$data_bds[]=$ptf_structure;
	// 	}
	// 	$template = array(
	// 		'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
	// 		'table_close' => '</table>'
	// 	);
	// 	$this->table->set_template($template);
	// 	$this->table->set_heading(array('BDS','CDS','Actions'));

	// 	$data['donnees_ptf']=$data_bds;

	// 	$data['title']="Liste des partenaires technique financier";
	// 	$this->load->view('Bds_cds_List_View',$data);

	// }

	function nouveau($bds_id = null ,$cds_id = null)
	{
		$data['error']='';
		$data['title']="Affectation des CDS aux BDS";
		$data['bds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "BDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR ASC');
		$data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "CDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR ASC');
		$data['BDS_ID'] = $bds_id;
		$data['CDS_ID'] = $cds_id;
		$this->load->view('Bds_cds_Add_View',$data);
	}

	public function check_double_cds()
	{
		$bds_id = $this->input->post('BDS_ID');
		$cds_id = $this->input->post('CDS_ID');
		$bds_cds_id = $this->input->post('BDS_CDS_ID');
		$critere = !empty($bds_cds_id) ? ' AND BDS_CDS_ID != '.$bds_cds_id.' ' : '' ;
		if (!empty($bds_id)) {
			if (!empty($cds_id)) {
				$get = $this->Modele->getRequete('SELECT CDS_ID FROM bds_cds WHERE BDS_ID = '.$bds_id.' AND CDS_ID = '.$cds_id.'  '.$critere.'');
				if (!empty($get)) {
					$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Cette affectation existe déjà!</font>');
					return FALSE;
				}else{
					return TRUE;
				}
			}else{
				$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Ce champ est obligatoire!</font>');
				return FALSE;
			}
		}else{
			$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Ce champ est obligatoire!</font>');
			return FALSE;
		}
	}

	function ajouter()
	{
		$this->form_validation->set_rules('BDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('CDS_ID','', 'trim|required|is_unique[bds_cds.CDS_ID]',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>','is_unique'=>'<font style="color:red;size:2px;">Existe déjà</font>'));
		//$this->form_validation->set_rules('CDS_ID','', 'callback_check_double_cds');

		if ($this->form_validation->run() == FALSE) {
			$this->nouveau($this->input->post('BDS_ID'),$this->input->post('CDS_ID'));
		} else {
			$dataInsert=array(
				'BDS_ID'=>$this->input->post('BDS_ID'),
				'CDS_ID'=>$this->input->post('CDS_ID')
			);
			$this->Modele->create('bds_cds',$dataInsert);
			$data['message']='<div class="alert alert-success text-center" id="message">'."L'affectation est faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Bds_cds/index'));
		}
	}


	function getOne()
	{
		$data['bds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "BDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR ASC');
		$data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "CDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR ASC');
		$id=$this->uri->segment(4);
		$data['bds_cds'] = $this->Modele->getOne('bds_cds',array('BDS_CDS_ID'=>$id));
		$data['error']='';
		$data['title'] = "Modification d'une affectation";
		$this->load->view('Bds_cds_Modif_View',$data);

	}

	function modifier()
	{
		$this->form_validation->set_rules('BDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('CDS_ID','', 'callback_check_double_cds');
		if ($this->form_validation->run() == FALSE) {
			$this->nouveau($this->input->post('BDS_ID'),$this->input->post('CDS_ID'));
		} else {
			$data_mod=array(
				'BDS_ID'=>$this->input->post('BDS_ID'),
				'CDS_ID'=>$this->input->post('CDS_ID')
			);
			$this->Modele->update('bds_cds',array('BDS_CDS_ID'=>$this->input->post('BDS_CDS_ID')),$data_mod);
			$data['message']='<div class="alert alert-success text-center" id="message">'."Modification faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Bds_cds/index'));
		}
	}
	function delete()
	{
		$criteres['BDS_CDS_ID']=$this->uri->segment(4);
		$this->Modele->delete('bds_cds',$criteres);
		$data['message']='<div class="alert alert-success text-center" id="message">'."Suppression faite avec succès!".'</div>';
		$this->session->set_flashdata($data);
		redirect(base_url('ihm/Bds_cds/index'));
	}


}

?>
