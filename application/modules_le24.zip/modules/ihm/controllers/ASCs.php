<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 25/2/2021
 Date fin :Le 25/2/2021
 Commentaire: controller pour le CRUD des ASCs
 */
 class ASCs extends CI_Controller
 {

 	public function __construct()
 	{
 		parent::__construct();
 	}

 	public function index()
 	{
 		$data['title']='Liste des ASCs';
 		$query="SELECT ascs.*,cds.CDS_NOM  FROM ascs JOIN cds ON ascs.CDS_ID=cds.CDS_ID ORDER BY ascs.ASC_ID DESC";
 		$ASCs=$this->Modele->getRequete($query);

 		$tabledata = array();
 		foreach ($ASCs as $ASC ) {

 			$type=array();
 			$type[]=$ASC['ASC_CODE'];
 			$type[]=$ASC['CDS_NOM'];
 			$type[]=$ASC['ASC_NOM'];
 			$type[]=$ASC['ASC_PRENOM'];
 			$type[]=$ASC['TELEPHONE1'].' / '.$ASC['TELEPHONE2'];
 			$type[]=$ASC['EMAIL'];


 			$type['OPTIONS'] = '<div class="dropdown">
 			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
 			<i class="fa fa-cog"></i>
 			Options <span class="caret"></span>
 			</a>
 			<ul class="dropdown-menu dropdown-menu-left">';
 			$type['OPTIONS'] .="<li><a href='".base_url('ihm/ASCs/update_ASC_view/').$ASC['ASC_ID'] ."'><label class='text-info'>Modifier</label></a></li>";
 			$type['OPTIONS'] .="<li><a href='#' data-toggle='modal' data-target='#mydelete".$ASC['ASC_ID']."'><label class='text-danger'>Supprimer</label></a></li>";


 			$type['OPTIONS'] .= " </ul>
 			</div>
 			<div class='modal fade' id='mydelete".$ASC['ASC_ID']."'>
 			<div class='modal-dialog'>
 			<div class='modal-content'>

 			<div class='modal-body'>
 			<center>
 			<h5><strong>VOULEZ-VOUS SUPPRIMER L'ASC </strong> : <b style:'background-color:prink';>
 			<i style='color:green;'>" . $ASC['ASC_NOM']."</i></b> ?
 			</h5>
 			</center>
 			</div>

 			<div class='modal-footer'>
 			<a class='btn btn-danger btn-md' href='" . base_url('ihm/ASCs/delete_ASC/').$ASC['ASC_ID'] . "'>Supprimer
 			</a>
 			<button class='btn btn-primary btn-md' data-dismiss='modal'>
 			Quitter
 			</button>
 			</div>

 			</div>
 			</div>
 			</div>";


 			$tabledata[]=$type;
 		}

 		$template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
 		$this->table->set_template($template);
 		$this->table->set_heading(array('CODE ASC','CDS','NOM','PRENOM','TELEPHONE','EMAIL','ACTIONS'));
 		$data['ASCs']=$tabledata;
 		$this->page='ihm/ASCs_Listing_View';
 		$this->layout($data);

 	}


 	public function add_ASC(){
 		$data['title']='Nouveau ASC';
 		$data['cds']=$this->Modele->getList('cds');
 		$this->page='ihm/ASCs_Add_View';
 		$this->layout($data);
 	}

 	public function insert_ASC(){
 		$this->form_validation->set_rules('nom', 'Nom', 'trim|required');
 		$this->form_validation->set_rules('prenom', 'Prenom', 'trim|required');
 		$this->form_validation->set_rules('tel1', 'TELEPHONE', 'trim|required');
 		$this->form_validation->set_rules('tel2', 'TELEPHONE', 'trim|required');
 		$this->form_validation->set_rules('id_cds', 'CDS', 'trim|required');
 		$this->form_validation->set_rules('email', 'Email', 'trim|required');

 		if ($this->form_validation->run() == FALSE) {
 			$data['title']='Formulaire pour les ASCs';
 			$data['cds']=$this->Modele->getList('cds');
 			$this->page='ihm/ASCs_Add_View';
 			$this->layout($data);
 		}else{
 			$nom=$this->input->post('nom');
 			$prenom=$this->input->post('prenom');
 			$tel1=$this->input->post('tel1');
 			$tel2=$this->input->post('tel2');
 			$email=$this->input->post('email');
 			$cds_id=$this->input->post('id_cds');

 			$data=array('ASC_CODE'=>1,
 				'ASC_NOM'=>$nom,
 				'ASC_PRENOM'=>$prenom,
 				'TELEPHONE1'=>$tel1,
 				'TELEPHONE2'=>$tel2,
 				'EMAIL'=>$email,
 				'CDS_ID'=>$cds_id
 			);
 			$sql=$this->Modele->insert_last_id('ascs',$data);

 			if($sql >0){
 				$code_ASC = "A-".date('Y').'-'.$sql;
 				$this->Modele->update('ascs',['ASC_ID'=>$sql],['ASC_CODE'=>$code_ASC]) ;
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				ASC ajouté avec succès ! .
 				</div>
 				<br>' ;
 			}else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produite ! .
 				</div>
 				<br>' ;
 			}


 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/ASCs');
 		}
 	}

 	public function delete_ASC($id){
 		$sql=$this->Modele->delete('ascs',array('ASC_ID'=>$id));
 		if ($sql) {
 			$sms['sms']='<br>
 			<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			ASC supprimé avec succès ! .
 			</div>
 			<br>' ;
 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/ASCs');
 		} else {
 			$sms['sms']='<br>
 			<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			Une erreur s\'est produite ! .
 			</div>
 			<br>' ;
 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/ASCs');
 		}
 	}

 	public function update_ASC_view($id){
 		$data['title']='Formulaire de modification';
 		$data['cds']=$this->Modele->getList('cds');
 		$data['ASCs']=$this->Modele->getOne('ascs',array('ASC_ID'=>$id));
 		$data['id_cds']=$this->Modele->getOne('cds',array('CDS_ID'=>$data['ASCs']['CDS_ID']));
 		$this->page='ihm/ASCs_Update_View';
 		$this->layout($data);
 	}

 	public function update_ASC($id){
 		$this->form_validation->set_rules('nom', 'Nom', 'trim|required');
 		$this->form_validation->set_rules('prenom', 'Prenom', 'trim|required');
 		$this->form_validation->set_rules('tel1', 'TELEPHONE', 'trim|required');
 		$this->form_validation->set_rules('tel2', 'TELEPHONE', 'trim|required');
 		$this->form_validation->set_rules('id_cds', 'CDS', 'trim|required');
 		$this->form_validation->set_rules('email', 'Email', 'trim|required');

 		if ($this->form_validation->run() == FALSE) {
 			$data['title']='Formulaire de modification';
 			$data['cds']=$this->Modele->getList('cds');
 			$this->page='ihm/ASCs_Update_View';
 			$this->layout($data);
 		}else{
 			$nom=$this->input->post('nom');
 			$prenom=$this->input->post('prenom');
 			$tel1=$this->input->post('tel1');
 			$tel2=$this->input->post('tel2');
 			$email=$this->input->post('email');
 			$cds_id=$this->input->post('id_cds');

 			$data=array('ASC_NOM'=>$nom,
 				'ASC_PRENOM'=>$prenom,
 				'TELEPHONE1'=>$tel1,
 				'TELEPHONE2'=>$tel2,
 				'EMAIL'=>$email,
 				'CDS_ID'=>$cds_id
 			);
 			$sql=$this->Modele->update('ascs',array('ASC_ID'=>$id),$data);
 			if ($sql) {
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				ASC modifié avec succès ! .
 				</div>
 				<br>' ;
 				$this->session->set_flashdata($sms) ;
 				redirect('ihm/ASCs');
 			} else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produite ! .
 				</div>
 				<br>' ;
 				$this->session->set_flashdata($sms) ;
 				redirect('ihm/ASCs');
 			}

 		}
 	}



 }
