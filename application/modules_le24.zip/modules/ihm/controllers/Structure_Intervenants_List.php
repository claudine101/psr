<?php

/**
 * @author pacifique@mediabox.bi
 *le 14-04-2021
 *listing des structures des intervenants
 */
class Structure_Intervenants_List extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function index(){
	  $ptf=$this->Modele->getRequete('SELECT tp.TYPE_INTERVENANT_STRUCTURE_ID,tp.TYPE_INTERVENANT_STRUCTURE_DESCR FROM type_intervenants_structures tp WHERE 1');
	  $data=array('title'=>'Structures',
	              'ptf'=>$ptf);
	  $this->load->view('Structure_Intervenants_List_View',$data);
	}

	public function listing(){

	 $PTF_ID=$this->input->post('PTF_ID');

		  $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		  $var_search=str_replace("'", "\'", $var_search);
		  $query_principal='
			SELECT
			    st.INTERVENANT_STRUCTURE_ID,
			    st.COLLINE_ID,
			    st.SOUS_COLLINE,
			    st.TELEPHONE,
			    st.EMAIL,
			    st.INTERVENANT_STRUCTURE_DESCR,
			    p.PROVINCE_NAME,
			    c.COMMUNE_NAME
			FROM
			    intervenants_structure st
			LEFT JOIN provinces p ON
			    p.PROVINCE_ID = st.PROVINCE_ID
			LEFT JOIN communes c ON
			    c.COMMUNE_ID = st.COMMUNE_ID WHERE 1 ';

          $critaire="";
          if (!empty($PTF_ID)) {
          	$critaire=" AND TYPE_INTERVENANT_STRUCTURE_ID= ".$PTF_ID;
          }
		  $limit='LIMIT 0,10';
		  if($_POST['length'] != -1){
		    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		  }
		  $order_by='';
		  if($_POST['order']['0']['column']!=0){
		    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY PROVINCE_NAME ASC';
		  }

		  $search = !empty($_POST['search']['value']) ? (" AND (COLLINE_ID LIKE '%$var_search%' OR  INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR  SOUS_COLLINE LIKE '%$var_search%' OR  TELEPHONE LIKE '%$var_search%' OR  EMAIL LIKE '%$var_search%' OR  PROVINCE_NAME LIKE '%$var_search%' OR  COMMUNE_NAME LIKE '%$var_search%')") : '';



		  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		  $query_filter=$query_principal.'  '.$critaire.' '.$search;

		  $fetch_structures = $this->Modele->datatable($query_secondaire);
		  $u=0;
		  $data = array();
		  foreach ($fetch_structures as $row) {

		if ($row->PROVINCE_NAME==null || $row->PROVINCE_NAME=='') {
			$PROVINCE_NAME='-';
		} else {
			$PROVINCE_NAME=$row->PROVINCE_NAME;
		}

		if ($row->COMMUNE_NAME==null || $row->COMMUNE_NAME=='') {
			$COMMUNE_NAME='-';
		} else {
			$COMMUNE_NAME=$row->COMMUNE_NAME;
		}

		if ($row->COLLINE_ID==null || $row->COLLINE_ID==0) {
			$COLLINE_ID='-';
		} else {
			$COLLINE_ID=$row->COLLINE_ID;
		}

		   $u++;
		   $sub_array = array();
		   $sub_array[] =  $u;
           $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
		   $sub_array[]=$PROVINCE_NAME;
           $sub_array[]=$COMMUNE_NAME;
           $sub_array[]=$COLLINE_ID;
           $sub_array[]=$row->TELEPHONE;
           $sub_array[]=$row->EMAIL;

           $opt='<div class="dropdown" style="color:#fff;">
                       <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                       <i class="fa fa-cog"></i> Options<span class="caret">
                       </span></a>
	                   <ul class="dropdown-menu dropdown-menu-left">';

            $opt.='<li class="dropdown-item" ><a href="'.base_url().'">Modifier</a></li>';
            $opt.='<li class="dropdown-item"><a href="'.base_url().'" tagert="blanck">Supprimer</a></li>';
	        $opt.='</ul>';

          $sub_array[]=$opt;
		  $data[] = $sub_array;

		}

		$output = array(
		 "draw" => intval($_POST['draw']),
		 "recordsTotal" =>$this->Modele->all_data($query_principal),
		 "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);	
	}
}