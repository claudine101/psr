<?php 

/**
 * auteur:christa
 * date debut:02/02/2021
 * date fin:02/02/2021
 * commentaire:crud de la table ptf_intrant_district 
*/
class Ptf_Intrant_District extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		$data['error']='';
        $this->listing();
      
	}

	

	function listing()
    {

      //$intervenants=$this->Modele->getList('intervenants_structure');
      $sql="SELECT pid.PTF_MALADIE_ID,intra.INTRANT_MEDICAUX_ID,p.PTF_ID,dis.DISTRICT_ID FROM ptf_intrant_district pid JOIN intrant_medicaux intra ON pid.INTRANT_ID=intra.INTRANT_MEDICAUX_ID JOIN ptf p ON pid.PTF_ID=p.PTF_ID JOIN districts dis ON pid.DISTRICT_ID=dis.DISTRICT_ID";

      $ptf_intrant_district=$this->Modele->getRequete($sql);
     $data_pid=array(); 

     foreach ($ptf_intrant_district as $key_pid) {
       $pid_structure=array();

       $intrant_medicaux=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$key_pid['INTRANT_MEDICAUX_ID']));
      $ptf=$this->Modele->getOne('ptf', array('PTF_ID' =>$key_pid['PTF_ID']));
      $districts=$this->Modele->getOne('districts', array('DISTRICT_ID' =>$key_pid['DISTRICT_ID']));


       $pid_structure[]=$intrant_medicaux['INTRANT_MEDICAUX_DESCR'];
       $pid_structure[]=$ptf['PTF_NOM'];
       $pid_structure[]=$districts['DISTRICT_NOM'];
      
    $pid_structure['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $pid_structure['OPTIONS'] .= "<li><a hre='#' data-toggle='modal' 
     data-target='#mydelete" . $key_pid['PTF_MALADIE_ID'] . "'><font color='red'>Supprimer</font></a></li>";
     $pid_structure['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Ptf_Intrant_District/getOne/'. $key_pid['PTF_MALADIE_ID']) . "'>Modifier</a></li>";
     $pid_structure['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $key_pid['PTF_MALADIE_ID'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h5><strong>VOULEZ-VOUS SUPPRIMER UN INTERVENANT</strong> : <b style:'background-color:prink';><i style='color:green;'>" . $key_pid['INTRANT_MEDICAUX_ID']."</i></b>?</h5></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Ptf_Intrant_District/delete_pid/'. $key_pid['PTF_MALADIE_ID']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div>";

        $data_pid[]=$pid_structure;
     }

        $template = array(
            'table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed col-sm-4">',
            'table_close' => '</table>'
        );
        $this->table->set_template($template);
        $this->table->set_heading(array('Intrants medicaux','Partenaire technique financier','Districts','Options'));
        $data['donnees_pid']=$data_pid;
        $data['title'] = "Liste des intrants";
       
        $this->page = 'Ptf_Intrant_District_List_View';

     $this->layout($data);

    }

	function ajouter_pid()
	{
		$data['error']='';
        

        $data['intrant_medicaux']=$this->Modele->getListOrder('intrant_medicaux','INTRANT_MEDICAUX_DESCR');
        $data['ptf']=$this->Modele->getListOrder('ptf','PTF_NOM');
        $data['districts']=$this->Modele->getListOrder('districts','DISTRICT_NOM');

        $data['title'] = "Nouveau Intrant";
        $this->page = 'Ptf_Intrant_District_Add_View';
        $this->layout($data);
	}

	function add_pid()
	{

     $this->form_validation->set_rules('INTRANT_MEDICAUX_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

     $this->form_validation->set_rules('PTF_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

     $this->form_validation->set_rules('DISTRICT_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

     if ($this->form_validation->run() == FALSE)
        {

      $data['title'] = "Nouveau Intrant";
      $data['error']='';
     
     $this->page = 'Ptf_Intrant_District_Add_View';

     $this->layout($data);

        } else{
    	 $dataInsert=array('INTRANT_MEDICAUX_ID' => $this->input->post('INTRANT_MEDICAUX_ID'),
                 'PTF_ID'=>$this->input->post('PTF_ID'),
                 'DISTRICT_ID'=>$this->input->post('DISTRICT_ID'));

	    $table='ptf_intrant_district';
	    $this->Modele->create('ptf_intrant_district',$dataInsert);

	    $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un intrant est fait avec succès".'</div>';
	    $this->session->set_flashdata($data);
	    redirect(base_url('ihm/Ptf_Intrant_District/listing'));
	      
        }
    
	}

	function getOne()
	{

	$id=$this->uri->segment(4); 
    $data['data_pid']=$this->Modele->getOne('ptf_intrant_district',array('PTF_MALADIE_ID'=>$id));
    $data['intrant_medicaux']=$this->Modele->getList('intrant_medicaux');
    $data['ptf']=$this->Modele->getList('ptf');
    $data['districts']=$this->Modele->getList('districts');
    $data['error']='';

    $data['title'] = "Modification des intrants";
    $this->page = 'Ptf_Intrant_District_Modif_View';

     $this->layout($data);
	}

	function update_pid()
	{

     $this->form_validation->set_rules('INTRANT_MEDICAUX_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

     $this->form_validation->set_rules('PTF_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

     $this->form_validation->set_rules('DISTRICT_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


     if ($this->form_validation->run() == FALSE)
        {

        $id=$this->input->post('PTF_MALADIE_ID'); 
        
       $data['intrant_medicaux']=$this->Modele->getListOrder('intrant_medicaux',array(),'INTRANT_MEDICAUX_DESCR'); 
       $data['ptf']=$this->Modele->getListOrder('ptf',array(),'PTF_NOM');
       $data['districts']=$this->Modele->getListOrder('districts',array(),'DISTRICT_NOM');

      $data['data_pid']=$this->Modele->getOne('ptf_intrant_district ',array('PTF_MALADIE_ID'=>$id));
       $data['error']='';


      
       $this->page = 'Ptf_Intrant_District_Modif_View';

     $this->layout($data);

        }

        else
        {
        $id=$this->input->post('PTF_MALADIE_ID');
        $data=array(    
                     'INTRANT_MEDICAUX_ID'=>$this->input->post('INTRANT_MEDICAUX_ID'),
                     'PTF_ID'=>$this->input->post('PTF_ID'),
                     'DISTRICT_ID'=>$this->input->post('DISTRICT_ID')
                   );

        $this->Modele->update('ptf_intrant_district',array('PTF_MALADIE_ID'=>$id),$data);
         $datas['message']='<div class="alert alert-success text-center" id="message">La modification a été faite avec Succes</div>';
         $this->session->set_flashdata($datas);
         redirect(base_url('ihm/Ptf_Intrant_District/listing'));
        }

        }

        function delete_pid()
        {

        $table="ptf_intrant_district";
        $criteres['PTF_MALADIE_ID']=$this->uri->segment(4);
        $data['rows']= $this->Modele->getOne( $table,$criteres);
        $this->Modele->delete($table,$criteres);
        
        $data['message']='<div class="alert alert-success text-center" id="message">'."L'intrant est supprimé avec succès".'</div>';
        $this->session->set_flashdata($data);

        redirect(base_url('ihm/Ptf_Intrant_District/listing'));
        
        }
	}

 ?>