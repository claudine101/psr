<?php

/**
 * @author jules_ndihokubwayo@mediabox.bi
 *le 10-02-2021
 *ihm de processus de reception des intrants
 */
class Reception extends CI_Controller
{

	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function index($value='')
	{
		# code...
		$ptf=$this->Modele->getRequete('SELECT `PTF_ID`,`PTF_NOM` FROM `ptf` ORDER BY `PTF_NOM`');

		$rc_mode_reception=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` ORDER BY `MODE_RECEPTION_DESCR`');

		$intervenants_structure=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` ORDER BY `INTERVENANT_STRUCTURE_DESCR`');

        $intrant_medicaux=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` ORDER BY `INTRANT_MEDICAUX_DESCR`');

	    $data =array(
	    	          'ptf'=>$ptf,
	    	          'rc_mode_reception'=>$rc_mode_reception,
	    	          'intervenants_structure'=>$intervenants_structure,
	    	          'intrant_medicaux'=>$intrant_medicaux
	    	        );
	    $this->page = 'Reception_Add_View';
	    $this->layout($data);
	}
   //find structure en fonction de mode de reception
	public function get_structure($value='')
	{
		# code...
		$MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
		$htm='<option value="" selected="" disabled="">Sélectionner</option>';
		$structure=$this->Modele->getRequete("SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE `MODE_RECEPTION_ID`=".$MODE_RECEPTION_ID);
		foreach ($structure as $key ) {
			# code...
			$htm.='<option value="'.$key['INTERVENANT_STRUCTURE_ID'].'" >'.$key['INTERVENANT_STRUCTURE_DESCR'].'</option>';
		}


		echo $htm;
	}
	//find rh en fonction des structure
	public function get_structure_rh($value='')
	{
		# code...
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
		$htm='<option value="" selected="" disabled="">Sélectionner</option>';
		$structure_rh=$this->Modele->getRequete("SELECT `INTERVENANT_RH_ID`,CONCAT(NOM,' ',PRENOM) NAME FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`=".$INTERVENANT_STRUCTURE_ID." ORDER BY NAME");
		foreach ($structure_rh as $key ) {
			# code...
			$htm.='<option value="'.$key['INTERVENANT_RH_ID'].'" >'.$key['NAME'].'</option>';
		}

		echo $htm;
	}
}

?>
