<?php 

/**
 * 
 */
class Ptf_Intrant_District extends CI_Controller
{
  
  function __construct()
  {
    # code...
    parent::__construct();
  }
  function index(){

    $data['error'] = '';
    $data['title'] = 'PTF - Zones d\'intervention & package';
    //$this->listing();
    $this->load->view('Ptf_Intrant_District_List_View',$data);
  }

 //  function listing()
 //  {
 //    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
 //    $query_principal="SELECT pid.PTF_MALADIE_ID ,pid.PTF_ID AS id_ptf,pid.BDS_ID AS id_bds, i.INTRANT_MEDICAUX_DESCR,(SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_ptf ) AS ptf, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_bds) AS bds FROM `ptf_intrant_district` pid JOIN intrant_medicaux i ON pid.INTRANT_ID=i.INTRANT_MEDICAUX_ID JOIN intervenants_structure ON pid.PTF_ID=intervenants_structure.INTERVENANT_STRUCTURE_ID WHERE 1";
 // //'SELECT * from  intervenants_structure WHERE 1';

 //    $limit='LIMIT 0,10';


 //    if($_POST['length'] != -1) {
 //      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
 //    }


 //    $order_by='';
 //    if($_POST['order']['0']['column']!=0){
 //      $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY PTF_ID   ASC';
 //    }
 //    $search = !empty($_POST['search']['value']) ? (" AND  INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%'  ") : '';

 //    $critaire="";
 //    $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
 //    $query_filter=$query_principal.'  '.$critaire.' '.$search;


 //    $fetch_pid= $this->Modele->datatable($query_secondaire);

 //    $data = array();
 //    foreach ($fetch_pid as $row) {



 //      // $sql="SELECT pid.PTF_MALADIE_ID ,pid.PTF_ID AS id_ptf,pid.BDS_ID AS id_bds, intrant_medicaux.INTRANT_MEDICAUX_DESCR,(SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_ptf ) AS ptf, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_bds) AS bds FROM `ptf_intrant_district` pid JOIN intrant_medicaux ON pid.`INTRANT_ID`=intrant_medicaux.INTRANT_MEDICAUX_ID  ";

 //      // $pid=$this->Modele->getRequete($sql);

 //      // $intrant="<table class='table'><tr><th>Intrants</th></tr>";

 //      // foreach ($pid as $key) {
 //      //   # code...
 //      //   $intrant.='<tr></td>'.$key['INTRANT_MEDICAUX_DESCR'].'</td></tr>';
 //      // }
 //      // $intrant.="</table>";

 //      $sub_array = array();
      
 //      $sub_array[] = $row->ptf;
 //      $sub_array[] = $row->bds;
 //      $sub_array[] = $row->INTRANT_MEDICAUX_DESCR;
 //      // $sub_array[] = '<button type="button" class="btn btn-primary" data-toggle="modal"   data-target="#exampleModal'.$row->PTF_MALADIE_ID.'">'.count($pid).'</button>';
      
      

 //      // $point = '<div class="dropdown ">
 //      // <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
 //      // <i class="fa fa-cog"></i>
 //      // Action
 //      // <span class="caret"></span></a>
 //      // <ul class="dropdown-menu dropdown-menu-left">
 //      // ';

 //      // $point .= "<li><a hre='#' data-toggle='modal'
 //      // data-target='#mydelete" . $row->PTF_MALADIE_ID . "'><font color='red'>Supprimer</font></a></li>";
 //      // $point .= "<li><a class='btn-md' href='" . base_url('ihm/Ptf_Intrant_District/getOne/'. $row->PTF_MALADIE_ID) . "'>Modifier</a></li>";
 //      // $point .= " </ul>
 //      // </div>
 //      // <div class='modal fade' id='mydelete" . $row->PTF_MALADIE_ID . "'>
 //      // <div class='modal-dialog'>
 //      // <div class='modal-content'>

 //      // <div class='modal-body'>
 //      // <center><h5><strong>VOULEZ-VOUS SUPPRIMER UN INTERVENANT</strong> : <b style:'background-color:prink';><i style='color:green;'>" . $row->PTF_MALADIE_ID."</i></b>?</h5></center>
 //      // </div>

 //      // <div class='modal-footer'>
 //      // <a class='btn btn-danger btn-md' href='" . base_url('ihm/Ptf_Intrant_District/delete/'. $row->PTF_MALADIE_ID) . "'>Supprimer</a>
 //      // <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
 //      // </div>

 //      // </div>
 //      // </div>
 //      // </div>";



 //      // $sub_array[]=$point;

 //      $data[] = $sub_array;

 //    }

 //    $output = array(
 //      "draw" => intval($_POST['draw']),
 //      "recordsTotal" =>$this->Modele->all_data($query_principal),
 //      "recordsFiltered" => $this->Modele->filtrer($query_filter),
 //      "data" => $data
 //    );

 //    echo json_encode($output);
 //  }
  
  function listing()
  {
    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

     // $query_principal="SELECT DISTINCT pid.PTF_MALADIE_ID ,pid.PTF_ID AS id_ptf,pid.BDS_ID AS id_bds, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_ptf ) AS ptf, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_bds) AS bds FROM `ptf_intrant_district` pid JOIN intrant_medicaux i ON pid.INTRANT_ID=i.INTRANT_MEDICAUX_ID WHERE 1";

    $query_principal="SELECT DISTINCT pid.PTF_ID AS id_ptf,pid.BDS_ID AS id_bds,iss.INTERVENANT_STRUCTURE_DESCR ptf, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_bds) AS bds FROM `ptf_intrant_district` pid JOIN intrant_medicaux i ON pid.INTRANT_ID=i.INTRANT_MEDICAUX_ID JOIN intervenants_structure iss ON pid.PTF_ID=iss.INTERVENANT_STRUCTURE_ID WHERE 1 ";
    //$query_principal='SELECT * from  intervenants_structure WHERE 1';

    $limit='LIMIT 0,10';


    if($_POST['length'] != -1) {
      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
    }


    $order_by='';
    if($_POST['order']['0']['column']!=0){
      $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY PTF_ID   ASC';
    }
    $search = !empty($_POST['search']['value']) ? (" AND  INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%'  ") : '';

    $critaire="";
    $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
    $query_filter=$query_principal.'  '.$critaire.' '.$search;


    $fetch_pid= $this->Modele->datatable($query_secondaire);

    $data = array();
    foreach ($fetch_pid as $row) {



      // $sql="SELECT  pid.PTF_ID AS id_ptf,pid.BDS_ID AS id_bds, intrant_medicaux.INTRANT_MEDICAUX_DESCR,(SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_ptf ) AS ptf, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID=id_bds) AS bds FROM `ptf_intrant_district` pid JOIN intrant_medicaux ON pid.`INTRANT_ID`=intrant_medicaux.INTRANT_MEDICAUX_ID WHERE PTF_ID=".$row->id_ptf." AND BDS_ID=".$row->id_bds." "; 
  
      $sql="SELECT maladies.MALADIE_DESCR,intrant_medicaux.INTRANT_MEDICAUX_DESCR FROM `ptf_intrant_district` pid JOIN intrant_medicaux ON pid.`INTRANT_ID`=intrant_medicaux.INTRANT_MEDICAUX_ID JOIN maladies_intrant ON intrant_medicaux.INTRANT_MEDICAUX_ID=maladies_intrant.INTRANT_MEDICAUX_ID JOIN maladies ON maladies_intrant.MALADIE_ID=maladies.MALADIE_ID WHERE PTF_ID=".$row->id_ptf." AND BDS_ID=".$row->id_bds." "; 

      $intra=$this->Modele->getRequete($sql);

      $intrant='<table class="table table-striped table-bordered" style="width: 100%" >
                <tr>
                  <th>MALADIES</th>
                  <th>INTRANTS</th>
                </tr>';

      //$intrant="";

      foreach ($intra as $key) {
        # code...
        $intrant.='<tr><td>'.$key['MALADIE_DESCR'].'</td><td>'.$key['INTRANT_MEDICAUX_DESCR'].'</td></tr>';
      }
      $intrant.='</table>';
  
      $sub_array = array();
  
      $sub_array[] = $row->ptf;
      $sub_array[] = $row->bds;
      //$sub_array[] = $intrant;

      $sub_array[] = '
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#bd-example-modal-lg'.$row->id_bds.$row->id_ptf.'">'.count($intra).'</button>
  

<div id="bd-example-modal-lg'.$row->id_bds.$row->id_ptf.'" class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
 
    <div class="modal-content">
      <div class="modal-header">
      <h5><center>Pacquet</center></h5>

      </div>
      <div class="modal-body">
        '.$intrant.'
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary btn-md" data-dismiss="modal">Quitter</button>
      </div>
       
    </div>

  
  </div>
</div>


';

     //  $point = '<div class="dropdown ">
     // <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
     // <i class="fa fa-cog"></i>
     // Action
     // <span class="caret"></span></a>
     // <ul class="dropdown-menu dropdown-menu-left">
     // ';

     // $point .= "<li><a hre='#' data-toggle='modal'
     // data-target='#mydelete" . $row->PTF_MALADIE_ID . "'><font color='red'>Supprimer</font></a></li>";
     // $point .= "<li><a class='btn-md' href='" . base_url('ihm/Ptf_Intrant_District/getOne/'. $row->PTF_MALADIE_ID) . "'>Modifier</a></li>";
     // $point .= " </ul>
     // </div>
     // <div class='modal fade' id='mydelete" . $row->PTF_MALADIE_ID . "'>
     // <div class='modal-dialog'>
     // <div class='modal-content'>

     // <div class='modal-body'>
     // <center><h5><strong>VOULEZ-VOUS SUPPRIMER UN INTERVENANT</strong> : <b style:'background-color:prink';><i style='color:green;'>" . $row->PTF_MALADIE_ID."</i></b>?</h5></center>
     // </div>

     // <div class='modal-footer'>
     // <a class='btn btn-danger btn-md' href='" . base_url('ihm/Ptf_Intrant_District/delete/'. $row->PTF_MALADIE_ID) . "'>Supprimer</a>
     // <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     // </div>

     // </div>
     // </div>
     // </div>";



       // $sub_array[]=$point;

      $data[] = $sub_array;

    }

    $output = array(
      "draw" => intval($_POST['draw']),
      "recordsTotal" =>$this->Modele->all_data($query_principal),
      "recordsFiltered" => $this->Modele->filtrer($query_filter),
      "data" => $data
    );

    echo json_encode($output);
  }

  function ajouter()
  {
    $data['error']='';

    $ptf=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "PTF" ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');

    $districts=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "BDS" ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');

    $intrant_medicaux=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux`');


   $data['intrant_medicaux']=$intrant_medicaux;//$this->Modele->getListOrder('intrant_medicaux','INTRANT_MEDICAUX_DESCR');
  $data['ptf']=$ptf;//$this->Modele->getListOrder('ptf','PTF_NOM');
   $data['districts']=$districts;//$this->Modele->getListOrder('districts','DISTRICT_NOM');
   $data['exist']=array();
   $data['title'] = "Nouveau Intrant";

   $this->load->view('Ptf_Intrant_District_Add_View',$data);

 }

 function add()
 {
   
  $this->form_validation->set_rules('PTF_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  $this->form_validation->set_rules('BDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  $this->form_validation->set_rules('INTRANT_MEDICAUX_ID[]','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

  if ($this->form_validation->run() == FALSE)
  {

    $data['title'] = "Nouveau Intrant";
    $data['error']='';
    $data['exist']=array();

    $ptf=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "PTF" ');

    $districts=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "BDS" ');

    $intrant_medicaux=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux`');

    $data['intrant_medicaux']=$intrant_medicaux;
    $data['ptf']=$ptf;
    $data['districts']=$districts;

    $intrants=$this->input->post('INTRANT_MEDICAUX_ID');
    $data['exist']=$intrants;

    $this->load->view('Ptf_Intrant_District_Add_View',$data);  

  }else{

    $intrants=$this->input->post('INTRANT_MEDICAUX_ID');

    foreach ($intrants as $key) {
        # code...
      $dataInsert=array(
        'PTF_ID'=>$this->input->post('PTF_ID'),
        'BDS_ID'=>$this->input->post('BDS_ID'),
        'INTRANT_ID'=>$key
      );
      $table='ptf_intrant_district';
      $this->Modele->create('ptf_intrant_district',$dataInsert);
    }
    
    $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un intrant est fait avec succès".'</div>';
    $this->session->set_flashdata($data);
    redirect(base_url('ihm/Ptf_Intrant_District/'));

  }
}

function getOne()
{

  $id=$this->uri->segment(4);
  $data['data_pid']=$this->Modele->getOne('ptf_intrant_district',array('PTF_MALADIE_ID'=>$id));

  $data['ptf']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "PTF" ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');

  $data['districts']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "BDS" ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');

  $data['intrant_medicaux']=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux`');


  $data['error']='';

  $data['title'] = "Modification des intrants";


  $this->load->view('Ptf_Intrant_District_Modif_View',$data);
  
}

function update()
{
 $this->form_validation->set_rules('PTF_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 $this->form_validation->set_rules('BDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

 $this->form_validation->set_rules('INTRANT_MEDICAUX_ID[]','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));



 if ($this->form_validation->run() == FALSE) {
       # code...
  $id=$this->input->post('PTF_MALADIE_ID');

  $data['ptf']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "PTF" ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');

  $data['districts']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM intervenants_structure inter JOIN type_intervenants_structures typ ON inter.TYPE_INTERVENANT_STRUCTURE_ID=typ.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE "BDS" ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');

  $data['intrant_medicaux']=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux`');

      //$data['title'] = 'Modification des intrants';

  $data['data_pid']=$this->Modele->getOne('ptf_intrant_district ',array('PTF_MALADIE_ID'=>$id));
  $data['error']='';

  $this->load->view('Ptf_Intrant_District_Modif_View',$data);
  
}else{

  $id=$this->input->post('PTF_MALADIE_ID');

  $data=array(
   'INTRANT_ID'=>$this->input->post('INTRANT_MEDICAUX_ID'),
   'PTF_ID'=>$this->input->post('PTF_ID'),
   'BDS_ID'=>$this->input->post('BDS_ID')
 );

  $this->Modele->update('ptf_intrant_district',array('PTF_MALADIE_ID'=>$id),$data);
  $datas['message']='<div class="alert alert-success text-center" id="message">La modification a été faite avec Succes</div>';
  $this->session->set_flashdata($datas);
  redirect(base_url('ihm/Ptf_Intrant_District/'));
}
}


function delete()
{
  $table="ptf_intrant_district";
  $criteres['PTF_MALADIE_ID']=$this->uri->segment(4);
  $data['rows']= $this->Modele->getOne( $table,$criteres);
  $this->Modele->delete($table,$criteres);

  $data['message']='<div class="alert alert-success text-center" id="message">'."L'intrant est supprimé avec succès".'</div>';
  $this->session->set_flashdata($data);

  redirect(base_url('ihm/Ptf_Intrant_District/'));

}

}

?>