<?php

/**
 * auteur:christa
 * date debut:01/02/2021
 * date fin:01/02/2021
 * commentaire:crud de la table Partenaires technique financier
 */
class Ptf extends CI_Controller
{

	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['error']='';
		//$this->listing();

		$this->load->view('Ptf_New_List_View',$data);
	}


	public function getinfo()
{


$query_principal='SELECT inter.INTERVENANT_STRUCTURE_ID, inter.INTERVENANT_STRUCTURE_DESCR,inter.INTERVENANT_STRUCTURE_CODE, inter.TELEPHONE,inter.EMAIL, type_inter.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure inter  JOIN type_intervenants_structures type_inter ON type_inter.TYPE_INTERVENANT_STRUCTURE_ID=inter.TYPE_INTERVENANT_STRUCTURE_ID where type_inter.CODE_STRUCTURE="PTF"';

  



$var_search= !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

$limit='LIMIT 0,10';


if($_POST['length'] != -1){
  $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
}
$order_by='';



$order_column=array('INTERVENANT_STRUCTURE_DESCR','INTERVENANT_STRUCTURE_CODE','TYPE_INTERVENANT_STRUCTURE_DESCR','TELEPHONE','EMAIL');

$order_by = isset($_POST['order']) ? ' ORDER BY '.$order_column[$_POST['order']['0']['column']] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INCIDENT_ID   DESC';

$search = !empty($_POST['search']['value']) ? (" AND  (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR TYPE_INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR TELEPHONE LIKE '%$var_search%' OR EMAIL LIKE '%$var_search%') ") : '';     
      
$critaire = '';

 $query_secondaire=$query_principal.' '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
 $query_filter = $query_principal.' '.$critaire.' '.$search;


 $fetch_op = $this->Modele->datatable($query_secondaire);
 $data = array();
 foreach ($fetch_op as $row) {

$option = '<div class="dropdown ">
    <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
    <i class="fa fa-cog"></i>
    Action
    <span class="caret"></span></a>
    <ul class="dropdown-menu dropdown-menu-left">
    ';

    $option .= "<li><a hre='#' data-toggle='modal'
    data-target='#mydelete" . $row->INTERVENANT_STRUCTURE_ID . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
    $option .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenant_Structure/getOne/'.$row->INTERVENANT_STRUCTURE_ID) . "'><label class='text-info'>&nbsp;&nbsp;Modifier</label></a></li>";
    $option .= " </ul>
    </div>
    <div class='modal fade' id='mydelete" .  $row->INTERVENANT_STRUCTURE_ID . "'>
    <div class='modal-dialog'>
    <div class='modal-content'>

    <div class='modal-body'>
    <center><h5><strong>Voulez-vous supprimer?</strong> <br><b style='background-color:prink;color:green;'><i>" .$row->INTERVENANT_STRUCTURE_ID."</i></b></h5></center>
    </div>

    <div class='modal-footer'>
    <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenant_Structure/delete/'.$row->INTERVENANT_STRUCTURE_ID) . "'>Supprimer</a>
    <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
    </div>

    </div>
    </div>
    </div>";

   $sub_array = array();
   $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;  
   $sub_array[]=$row->INTERVENANT_STRUCTURE_CODE;  
   $sub_array[]=$row->TYPE_INTERVENANT_STRUCTURE_DESCR;
   $sub_array[]=$row->TELEPHONE;
   $sub_array[]=$row->EMAIL;
   $sub_array[]=$option;   


  

   $data[] = $sub_array;
 }
 $output = array(
  "draw" => intval($_POST['draw']),
  "recordsTotal" =>$this->Modele->all_data($query_principal),
  "recordsFiltered" => $this->Modele->filtrer($query_filter),
  "data" => $data
);
echo json_encode($output);

}
	function listing()
	{
		$sql="SELECT  ty.CODE_STRUCTURE,rh.INTERVENANT_RH_ID,rh.NOM,rh.PRENOM,rh.TELEPHONE1,rh.EMAIL,rh.TELEPHONE2  FROM intervenants_structure st join type_intervenants_structures ty on st.TYPE_INTERVENANT_STRUCTURE_ID=ty.TYPE_INTERVENANT_STRUCTURE_ID JOIN intervenants_rh rh ON rh.INTERVENANT_STRUCTURE_ID=st.INTERVENANT_STRUCTURE_ID WHERE ty.CODE_STRUCTURE='PTF'";
		$partenaires=$this->Modele->getRequete($sql);

		$data_ptf=array();

		foreach ($partenaires as $key_ptf) {
			$ptf_structure= array();

			$ptf_structure[]= $key_ptf['NOM'].' '.$key_ptf['PRENOM'].'<br>('.$key_ptf['CODE_STRUCTURE'].')';
			$ptf_structure[]= $key_ptf['TELEPHONE1'];
			$ptf_structure[]= $key_ptf['TELEPHONE2'];
			$ptf_structure[]= $key_ptf['EMAIL'];



			$ptf_structure["OPTIONS"]= '<div class="dropdown">
		     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
		     <i class="fa fa-cog"></i>
		     Action
		     <span class="caret"></span></a>
		     <ul class="dropdown-menu dropdown-menu-left">
		     ';

		     $ptf_structure["OPTIONS"].= "<li><a hre='#' data-toggle='modal'
		     data-target='#mydelete" . $key_ptf['INTERVENANT_RH_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
		    $ptf_structure["OPTIONS"] .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenant_Structure/getOne/'. $key_ptf['INTERVENANT_RH_ID']) . "'><label class='text-info'>&nbsp;&nbsp;Modifier</label></a></li>";
		     $ptf_structure["OPTIONS"] .= " </ul>
		     </div>
		     <div class='modal fade' id='mydelete" . $key_ptf['INTERVENANT_RH_ID'] . "'>
		     <div class='modal-dialog'>
		     <div class='modal-content'>

		     <div class='modal-body'>
		     <center><h5><strong>VOULEZ-VOUS SUPPRIMER UN PARTENAIRE</strong>?</br><b style:'background-color:prink';><i style='color:green;'>" . $key_ptf['NOM']."</i></b></h5></center>
		     </div>

		     <div class='modal-footer'>
		     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenant_Structure/delete/'. $key_ptf['INTERVENANT_RH_ID']) . "'>Supprimer</a>
		     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
		     </div>

		     </div>
		     </div>
		     </div>";


			$data_ptf[]=$ptf_structure;
		}
		$template = array(
			'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
			'table_close' => '</table>'
		);
		$this->table->set_template($template);
		$this->table->set_heading(array('Nom','Téléphone 1','Téléphone 2','Email','Actions'));

		$data['donnees_ptf']=$data_ptf;

		$data['title']="Liste des partenaires technique financier";

		$this->load->view('Ptf_List_View',$data);

		// $this->page= 'Ptf_List_View';

		// $this->layout($data);

	}

	function ajouter_ptf()
	{
		$data['error']='';
		$data['title']="Nouveau partenaire technique financier";
		//$this->page= 'Ptf_Add_View';

				$this->load->view('Ptf_Add_View',$data);

	}

	function add_ptf()
	{
		$this->form_validation->set_rules('NOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('TELEPHONE1','', 'trim|required|is_unique[ptf.TELEPHONE1]',array(
			'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>',
			'is_unique'=>'<font style="color:red;size:2px;">Le %s existe déjà</font>'
		));

		$this->form_validation->set_rules('TELEPHONE2','', 'trim|required|is_unique[ptf.TELEPHONE2]',array(
			'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>',
			'is_unique'=>'<font style="color:red;size:2px;">Le %s existe déjà</font>'
		));

		$this->form_validation->set_rules('EMAIL','', 'trim|required|is_unique[ptf.EMAIL]',array(
			'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>',
			'is_unique'=>'<font style="color:red;size:2px;">L\' %s existe déjà</font>'
		         ));



		if ($this->form_validation->run() == FALSE)
		{

			$data['title'] = "Nouveau partenaire";
			$data['error']='';

			//$this->page = 'Ptf_Add_View';

			$this->load->view('Ptf_Add_View',$data);

		}

		else
		{

			$dataInsert=array('NOM'=>$this->input->post('NOM'),
				'TELEPHONE1'=>$this->input->post('TELEPHONE1'),
				'TELEPHONE2'=>$this->input->post('TELEPHONE2'),
				'EMAIL'=>$this->input->post('EMAIL'));

			$table='ptf';
			$this->Modele->create('ptf',$dataInsert);

			$data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un partenaire <b>".' '.$this->input->post('NOM').'</b> '." est faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Ptf/listing'));


		}

	}


	function getOne()
	{

		$id=$this->uri->segment(4);
		$data['data_ptf']=$this->Modele->getOne('ptf',array('INTERVENANT_RH_ID'=>$id));
		$data['error']='';

		$data['title'] = "Modification des partenaires";
		//$this->page = 'Ptf_Modif_View';

	    $this->load->view('Ptf_Modif_View',$data);


		// $this->layout($data);

	}

	function update()
	{
		$this->form_validation->set_rules('NOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('TELEPHONE1','', 'trim|required',array(
			'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'
		));

		$this->form_validation->set_rules('TELEPHONE2','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('EMAIL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


		if ($this->form_validation->run() == FALSE)
		{

			$id=$this->input->post('INTERVENANT_RH_ID');


			$data['data_ptf']=$this->Modele->getOne('ptf',array('INTERVENANT_RH_ID'=>$id));
			$data['error']='';

			$this->load->view('Ptf_Modif_View',$data);


			// $this->page = 'Ptf_Modif_View';

			// $this->layout($data);

		}

		else
		{
			$id=$this->input->post('INTERVENANT_RH_ID');
			$data=array(
				'NOM'=>$this->input->post('NOM'),
				'TELEPHONE1'=>$this->input->post('TELEPHONE1'),
				'TELEPHONE2'=>$this->input->post('TELEPHONE2'),
				'EMAIL'=>$this->input->post('EMAIL')
			);

			$this->Modele->update('ptf',array('INTERVENANT_RH_ID'=>$id),$data);
			$datas['message']='<div class="alert alert-success text-center" id="message">La modification du  '.$this->input->post('NOM').'</b> Faite avec Succes</div>';
			$this->session->set_flashdata($datas);
			redirect(base_url('ihm/Ptf/listing'));
		}


	}
	function delete()
       {
        $table="ptf";
        $criteres['INTERVENANT_RH_ID']=$this->uri->segment(4);
        $data['rows']= $this->Modele->getOne( $table,$criteres);
        $this->Modele->delete($table,$criteres);

        $data['message']='<div class="alert alert-success text-center" id="message">'."Le partenaire technique financier <b> ".' '.$data['rows']['NOM'].' </b> '." est supprimé avec succès".'</div>';
        $this->session->set_flashdata($data);
        redirect(base_url('ihm/Ptf/listing'));


        }


}

?>
