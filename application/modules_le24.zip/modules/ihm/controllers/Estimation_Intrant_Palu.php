<?php 

/**
 * christa
 */
class Estimation_Intrant_Palu extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['error'] = '';
		$this->listing();
	}

	function listing()
	{

	$sql="SELECT ID,MOIS,TAUX FROM estimation_intrants_paludisme";
    
   $estimation=$this->Modele->getRequete($sql);

   $data=array();

   foreach ($estimation as $key) {

     $sub_array=array();

     $p='%';
     $sub_array[]=$key['MOIS'];
     $sub_array[]=$key['TAUX'].''.$p;


     $historique=$this->Modele->getRequete("SELECT `ID_ESTIMATION_INTRANT` AS id_h,`TAUX` as taux_e,`DATE_INSERTION` FROM estimation_intrants_paludisme_historique hist where ID_ESTIMATION_INTRANT=".$key['ID']);
     	$detail='<table class="table table-striped table-bordered table-responsive" width="100%" >
     						<tr>
     							<th>TAUX</th>
     							<th>DATE D\'INSERTION</th>
     						</tr>';
     foreach ($historique as $value) {
     	# code...
     	// $sub_array[]=$value['taux_e'];
     	// $sub_array[]=$value['DATE_INSERTION'];

     	$p='%';
     	$detail.='
     						<tr>
     						<td>'.$value['taux_e'].$p.'</td>
     						<td>'.$value['DATE_INSERTION'].'</td>
     						</tr>';
     
     	}
	$detail.="</table>";
     $sub_array['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydetail" . $key['ID'] . "'><font color='red'>&nbsp;&nbsp;Détail</font></a></li>";

     $sub_array['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Estimation_Intrant_Palu/getOne/'. $key['ID']) . "'><font>&nbsp;&nbsp;Modifier</font></a></li>";

     $sub_array['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydetail" . $key['ID'] . "'>

     <div class='modal-dialog modal-sm'>
      <div class='modal-content'>

      <div class='modal-body'>
      <h5><center>Historique</center> </h5>".$detail."
      </div>

     <div class='modal-footer'>
     <a href='" . base_url('ihm/Estimation_Intrant_Palu/liste_historique/'. $key['ID']) . "'></a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";

     $data[]=$sub_array;
     
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('MOIS','TAUX','ACTIONS'));
   $data['donnees_estimation']=$data;
   $data['title'] = "Taux paludisme";
   $this->load->view('Estimation_Intrant_Palu_List_View',$data);
	}

	function getOne()
	{

	$id=$this->uri->segment(4);
    $data['estimation']=$this->Modele->getOne('estimation_intrants_paludisme',array('ID'=>$id));
    $data['title']='Taux paludisme';
    $this->load->view('Estimation_Intrant_Palu_Update_View',$data);

	}

	function update()
	{
	$this->form_validation->set_rules('MOIS','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ description est obligatoire</font>'));

   $this->form_validation->set_rules('TAUX','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ description est obligatoire</font>'));

    if ($this->form_validation->run() == FALSE)
	   {
	     $id=$this->input->post('ID');
	     $data['estimation']=$this->Modele->getOne('estimation_intrants_paludisme',array('ID'=>$id));
	     $data['title']='Taux paludisme';

	     $this->load->view('Estimation_Intrant_Palu_Update_View',$data);
	   
	   }

	else
	   {
	     $id=$this->input->post('ID');
	     $data=array(
	      'MOIS'=>$this->input->post('MOIS'),
	      'TAUX'=>$this->input->post('TAUX')
	     );
	     $this->Modele->update('estimation_intrants_paludisme',array('ID'=>$id),$data);

	     $dataInsert=array(
	     	'ID_ESTIMATION_INTRANT'=>$this->input->post('ID_ESTIMATION_INTRANT'),
	     	'TAUX'=>$this->input->post('TAUX_HOSTORIQUE')
	     );
	     
		 $this->Modele->create('estimation_intrants_paludisme_historique',$dataInsert);

	     $datas['message']='<div class="alert alert-success text-center" id="message">La modification du taux est faite avec succès</div>';
	     $this->session->set_flashdata($datas);
	     redirect(base_url('ihm/Estimation_Intrant_Palu/index'));
	   }
	}


}
 ?>