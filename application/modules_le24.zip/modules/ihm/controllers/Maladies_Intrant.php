<?php
/**
*Auteur du fichier:Mutunge Ixella
Date debut:le 2/02/2021
Date fin:le 2/02/2021
commentaire: CRUD Maladies_Intrant
*/



defined('BASEPATH') OR exit('No direct script access allowed');

class Maladies_Intrant extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }
  function index()
  {
    $data['error']='';
    $this->listing();
  }

  function nouveau()
  {
    $data['title']='Nouveau intrant maladie';
    $data['type']=$this->Modele->getListOrder('maladies','MALADIE_DESCR');
    $data['types']=$this->Modele->getListOrder('intrant_medicaux','INTRANT_MEDICAUX_DESCR');

    $this->load->view('Maladies_Intrant_Add_View',$data);


  }

  function listing()
  {
    $sql="SELECT MALADIE_INTRANT_ID,maladies.MALADIE_ID,maladies.MALADIE_DESCR,intrant_medicaux.INTRANT_MEDICAUX_ID,intrant_medicaux.INTRANT_MEDICAUX_DESCR FROM maladies_intrant LEFT JOIN maladies ON maladies.MALADIE_ID = maladies_intrant.MALADIE_ID LEFT JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID = maladies_intrant.INTRANT_MEDICAUX_ID";
    $maladies_intrants=$this->Modele->getRequete($sql);
    $maladies_intrants_array=array();
    foreach ($maladies_intrants as $maladie_intrant) {
     $sub_array_maladie_intrant=array();

     $type=$this->Modele->getOne('maladies', array('MALADIE_ID' =>$maladie_intrant['MALADIE_ID']));
     $types=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$maladie_intrant['INTRANT_MEDICAUX_ID']));

     $sub_array_maladie_intrant[]=$type['MALADIE_DESCR'];
     $sub_array_maladie_intrant[]=$types['INTRANT_MEDICAUX_DESCR'];




     $sub_array_maladie_intrant['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array_maladie_intrant['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydelete" . $maladie_intrant['MALADIE_INTRANT_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
     $sub_array_maladie_intrant['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Maladies_Intrant/getOne/'. $maladie_intrant['MALADIE_INTRANT_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";
     $sub_array_maladie_intrant['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $maladie_intrant['MALADIE_INTRANT_ID'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h5><strong>Voulez-vous supprimer?</strong><br><b style:'background-color:prink';><i style='color:green;'>" . $types['INTRANT_MEDICAUX_DESCR']."</i></b></h5></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Maladies_Intrant/delete/'. $maladie_intrant['MALADIE_INTRANT_ID']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";


     $maladies_intrants_array[]=$sub_array_maladie_intrant;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('MALADIES','INTRANT MEDICAUX','ACTIONS'));
   $data['data_MaladieIntrant']=$maladies_intrants_array;
   $data['title'] = "Liste des intrants maladies";
   $this->load->view('Maladies_Intrant_List_View',$data);
   

 }
 public function add()
 {
   $this->form_validation->set_rules('MALADIE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
   $this->form_validation->set_rules('INTRANT_MEDICAUX_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


   if ($this->form_validation->run() == FALSE)
   {
     $data['title'] = "Nouveau intrant maladie";
     $data['type']=$this->Modele->getListOrder('maladies',array(),'MALADIE_DESCR');
     $data['types']=$this->Modele->getListOrder('intrant_medicaux',array(),'INTRANT_MEDICAUX_DESCR');
     $this->load->view('Maladies_Intrant_Add_View',$data);
     
   }

   else
   {
     $dataInsert=array('MALADIE_ID'=>$this->input->post('MALADIE_ID'),
       'INTRANT_MEDICAUX_ID'=>$this->input->post('INTRANT_MEDICAUX_ID'));

     $this->Modele->create('maladies_intrant',$dataInsert);
     $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un Maladie Intrant <b>".' '." est faite avec succès</b>".'</div>';
     $this->session->set_flashdata($data);
     redirect(base_url('ihm/Maladies_Intrant/listing'));
   }
 }

 public function update()
 {
   $this->form_validation->set_rules('MALADIE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
   $this->form_validation->set_rules('INTRANT_MEDICAUX_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));



   if ($this->form_validation->run() == FALSE)
   {
     $id=$this->input->post('MALADIE_INTRANT_ID');
     $data['type']=$this->Modele->getListOrder('maladies',array(),'MALADIE_DESCR');
     $data['types']=$this->Modele->getListOrder('intrant_medicaux',array(),'INTRANT_MEDICAUX_DESCR');
     $data['maladie_intrant']=$this->Modele->getOne('maladies_intrant',array('MALADIE_INTRANT_ID'=>$id));
     $data['title']='Modifier un intrant maladie';
     $this->load->view('Maladies_Intrant_Update_View',$data);
    
   }

   else
   {
     $id=$this->input->post('MALADIE_INTRANT_ID');
     $data=array('MALADIE_ID'=>$this->input->post('MALADIE_ID'),
       'INTRANT_MEDICAUX_ID'=>$this->input->post('INTRANT_MEDICAUX_ID')
     );
     $this->Modele->update('maladies_intrant',array('MALADIE_INTRANT_ID'=>$id),$data);
     $datas['message']='<div class="alert alert-success text-center" id="message">La modification du Maladie Intrant faite avec Succes</div>';
     $this->session->set_flashdata($datas);
     redirect(base_url('ihm/Maladies_Intrant/listing'));
   }

 }
 public function delete()
 {
   $table="maladies_intrant";
   $criteres['MALADIE_INTRANT_ID']=$this->uri->segment(4);
   $data['rows']= $this->Modele->getOne( $table,$criteres);
   $this->Modele->delete($table,$criteres);

   $data['message']='<div class="alert alert-success text-center" id="message">'."Maladie <b> ".' '.$data['rows']['MALADIE_ID'].' </b> '." est supprimé avec succès".'</div>';
   $this->session->set_flashdata($data);
   redirect(base_url('ihm/Maladies_Intrant/listing'));


 }
 public function getOne()
 {
   $id=$this->uri->segment(4);
   $data['type']=$this->Modele->getListOrder('maladies',array(),'MALADIE_DESCR');
   $data['types']=$this->Modele->getListOrder('intrant_medicaux',array(),'INTRANT_MEDICAUX_DESCR');
   $data['maladie_intrant']=$this->Modele->getOne('maladies_intrant',array('MALADIE_INTRANT_ID'=>$id));
   $data['title']='Modifier un intrat maladie';
   $this->load->view('Maladies_Intrant_Update_View',$data);
   

 }



}
?>
