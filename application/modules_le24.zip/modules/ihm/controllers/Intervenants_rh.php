<?php

/**
 *
 Auteur du fichier: Niyongabire Pacifique
 Date debut :Le 29/1/2021
 Date fin :Le 29/1/2021
 Commentaire: controller pour le CRUD des Intervenants
 */

 class Intervenants_rh extends CI_Controller
 {

 	public function __construct()
 	{
 		parent::__construct();
 	}

 	public function index()
 	{
 		// $data['title']='Intervenants';
   //      $crit="";
   //      if ($this->session->userdata('iccm_PROFIL_CODE')=="CAM" || $this->session->userdata('iccm_PROFIL_CODE')=="PTF" || $this->session->userdata('iccm_PROFIL_CODE')=="BDS" || $this->session->userdata('iccm_PROFIL_CODE')=="CDS" ) {
   //          # code...
   //          $crit=" and rh.INTERVENANT_STRUCTURE_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
   //      }
 		// $districts=$this->Modele->getRequete("SELECT rh.* ,st.INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh rh JOIN intervenants_structure st ON st.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID ".$crit." ORDER BY rh.INTERVENANT_RH_ID DESC");

 		// $tabledata = array();
 		// foreach ($districts as $district ) {

 		// 	$type=array();

   //          $sex=$this->Modele->getOne('sexe',array('SEXE_ID'=>$district['SEXE_ID']));
 		// 	$type[]=$district['NOM'].' '.$district['PRENOM'];
 		// 	$tel1=(!empty($district['TELEPHONE1'])) ? $district['TELEPHONE1'] : "N/A" ;
 		// 	$tel2=(!empty($district['TELEPHONE2'])) ? $district['TELEPHONE2'] : "N/A" ;
 		// 	$type[]=$tel1.'-'.$tel2;
 		// 	// $type[]=$district['PROVINCE_NOM'];
 		// 	$type[]=$district['INTERVENANT_STRUCTURE_DESCR'];
 		// 	//$type[]="";//$district['PROFIL_DESCR'];
   //          $type[]=$district['EMAIL'];
 		// 	$type[]=$sex['SEXE_DESCR'];
            
 		// 	$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
 		// 	<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog">
 		// 	</i> Options  <span class="caret"></span>
 		// 	</a>
 		// 	<ul class="dropdown-menu dropdown-menu-left">';

			// $type["OPTIONS"].= "<li><a hre='#' data-toggle='modal'
			// data-target='#mydelete" . $district['INTERVENANT_RH_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
			// $type["OPTIONS"] .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenants_rh/getOne/'. $district['INTERVENANT_RH_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";

 		// 	$type['OPTIONS'] .= " </ul>
 		// 	</div>
 		// 	<div class='modal fade' id='mydelete".$district['INTERVENANT_RH_ID']."'>
 		// 	<div class='modal-dialog'>
 		// 	<div class='modal-content'>

 		// 	<div class='modal-body'>
 		// 	<center>
 		// 	<h5><strong>Voulez-vous supprimer? </strong><br><b style='background-color:prink;color:green;'>
 		// 	<i>" . $district['NOM'].' '.$district['PRENOM']."</i></b>
 		// 	</h5>
 		// 	</center>
 		// 	</div>

 		// 	<div class='modal-footer'>
 		// 	<a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenants_rh/delete/').$district['INTERVENANT_RH_ID'] . "'>Supprimer
 		// 	</a>
 		// 	<button class='btn btn-primary btn-md' data-dismiss='modal'>
 		// 	Quitter
 		// 	</button>
 		// 	</div>

 		// 	</div>
 		// 	</div>
 		// 	</div>";


 		// 	$tabledata[]=$type;
 		// }

 		// $template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
 		// $this->table->set_template($template);
 		// $this->table->set_heading(array('INTERVENANTS','TELEPHONE','STRUCTURE','EMAIL','SEXE','ACTIONS'));
 		// $data['tableau']=$tabledata;
 		

        $this->load->view('Intervenant_Rh_New_List_View');



 	}


    public function getinfo()
{

 $crit='';
 if ($this->session->userdata('iccm_PROFIL_CODE')=="CAM" || $this->session->userdata('iccm_PROFIL_CODE')=="PTF" || $this->session->userdata('iccm_PROFIL_CODE')=="BDS" || $this->session->userdata('iccm_PROFIL_CODE')=="CDS" ) {
            # code...
 $crit=" and rh.INTERVENANT_STRUCTURE_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
 }
        

$query_principal='SELECT rh.*,(SELECT `IS_ACTIVE` FROM `admin_users` WHERE `INTERVENANT_RH_ID`=rh.INTERVENANT_RH_ID LIMIT 1) IS_ACTIVE  ,i.FONCTION_DESCR,st.INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh rh JOIN intervenants_structure st ON st.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID LEFT JOIN intervenant_fonction i ON rh.ID_FONCTION=i.ID_FONCTION WHERE 1'.$crit.'';

  



$var_search= !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

$limit='LIMIT 0,10';


if($_POST['length'] != -1){
  $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
}
$order_by='';



$order_column=array('INTERVENANT_STRUCTURE_DESCR','NOM','PRENOM');

$order_by = isset($_POST['order']) ? ' ORDER BY '.$order_column[$_POST['order']['0']['column']] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY NOM  DESC';

$search = !empty($_POST['search']['value']) ? (" AND concat(NOM,' ',PRENOM) LIKE '%$var_search%'  ") : '';     

$critaire = '';

 $query_secondaire=$query_principal.' '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
 $query_filter = $query_principal.' '.$critaire.' '.$search;


 $fetch_op = $this->Modele->datatable($query_secondaire);
 $data = array();
 foreach ($fetch_op as $row) {

  $sex=$this->Modele->getOne('sexe',array('SEXE_ID'=>$row->SEXE_ID));
  $tel1=(!empty($row->TELEPHONE1)) ? $row->TELEPHONE1 : "N/A" ;
  $tel2=(!empty($row->TELEPHONE2)) ? $row->TELEPHONE2 : "N/A" ;
            
            
            $option = '<div class="dropdown" style="color:#fff;">
            <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog">
            </i> Options  <span class="caret"></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-left">';

            $option.= "<li><a hre='#' data-toggle='modal'
            data-target='#mydelete" . $row->INTERVENANT_RH_ID . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
            $option .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenants_rh/getOne/'. $row->INTERVENANT_RH_ID) . "'>&nbsp;&nbsp;Modifier</a></li>";

            $option .= " </ul>
            </div>
            <div class='modal fade' id='mydelete".$row->INTERVENANT_RH_ID."'>
            <div class='modal-dialog'>
            <div class='modal-content'>

            <div class='modal-body'>
            <center>
            <h5><strong>Voulez-vous supprimer? </strong><br><b style='background-color:prink;color:green;'>
            <i>" . $row->NOM.' '.$row->PRENOM."</i></b>
            </h5>
            </center>
            </div>

            <div class='modal-footer'>
            <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenants_rh/delete/').$row->INTERVENANT_RH_ID . "'>Supprimer
            </a>
            <button class='btn btn-primary btn-md' data-dismiss='modal'>
            Quitter
            </button>
            </div>

            </div>
            </div>
            </div>";

   
   $sub_array = array();
   $sub_array[]=$row->NOM.' '.$row->PRENOM; 
   $sub_array[]=(!empty($row->FONCTION_DESCR)) ? $row->FONCTION_DESCR : "N/A" ;
   $sub_array[]=$tel1.'-'.$tel2;  
   $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
   $sub_array[]=$row->EMAIL;
   $sub_array[]=(!empty($sex['SEXE_DESCR'])) ? $sex['SEXE_DESCR'] : 'N/A';
   $sub_array[]=$this->get_icon($row->IS_ACTIVE); 
   $sub_array[]=$option;   


  

   $data[] = $sub_array;
 }
 $output = array(
  "draw" => intval($_POST['draw']),
  "recordsTotal" =>$this->Modele->all_data($query_principal),
  "recordsFiltered" => $this->Modele->filtrer($query_filter),
  "data" => $data
);
echo json_encode($output);

}
  function get_icon($TRAITER)
  {
    $html = ($TRAITER == 1) ? '<center><span class="fa fa-check-circle" data-toggle="tooltip" title="Activé" style="color:green;"></span></center>' : '<center><span class="fa fa-ban" data-toggle="tooltip" title="Déactivé" style="color:red;"></span></center>' ;

      return $html;
  }


 	public function nouveau(){
 		$data['title']='Création d’un nouvel  Intervenant';
        $data['sex']=$this->Modele->getRequete("SELECT `SEXE_ID`, `SEXE_DESCR` FROM `sexe` WHERE 1");

        $data['fonction']=$this->Modele->getRequete("SELECT ID_FONCTION,FONCTION_DESCR FROM `intervenant_fonction` WHERE 1");

 		$data['structure']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1 ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');
 		$data['profil']=$this->Modele->getRequete('SELECT `PROFIL_ID`, `PROFIL_DESCR` FROM `admin_profil` WHERE 1  ORDER BY PROFIL_DESCR ASC');

 		$this->load->view('Intervenants_Rh_Ajouter_View',$data);

 	}

 	function validation()
 	{
 		$this->form_validation->set_rules('nom','Nom','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champs est obligatoire</font>'));

 		$this->form_validation->set_rules('prenom','prenom','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champs est obligatoire</font>'));

    $this->form_validation->set_rules('ID_FONCTION','ID_FONCTID_FONCTIONION','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champ est obligatoire</font>'));

 		$this->form_validation->set_rules('tel','tel','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champs est obligatoire</font>'));

        if (empty($this->input->post('id'))) {
            # code...
            $this->form_validation->set_rules('email','email','valid_email|trim|required|is_unique[intervenants_rh.email]',array('valid_email'=>'<font style="color:red;size:2px;">Le email doît être valide!</font>','required'=>'<font style="color:red;size:2px;">Le champ est obligatoire</font>','is_unique'=>'<font style="color:red;size:2px;">L\'email doit être unique</font>'));
        }else{
            $this->form_validation->set_rules('email','email','valid_email|trim|required',array('valid_email'=>'<font style="color:red;size:2px;">L\' email doît être valide!</font>','required'=>'<font style="color:red;size:2px;">Le champ est obligatoire</font>'));
        }
 		
 		//$this->form_validation->set_rules('PROFIL_ID','PROFIL_ID','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champs est obligatoire</font>'));

        //$this->form_validation->set_rules('structure','structure','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champs est obligatoire</font>'));
 		$this->form_validation->set_rules('SEXE_ID','SEXE_ID','required|trim',array('required'=>'<font style="color:red;size:2px;">Le champs est obligatoire</font>'));
 		
 	}

 	public function add(){
 		
        $this->validation();
 		if ($this->form_validation->run()==FALSE) {

 			$this->nouveau();

 		} else {

 			$nom=$this->input->post('nom');
      $prenom=$this->input->post('prenom');
 			$ID_FONCTION=$this->input->post('ID_FONCTION');
 			$tel=$this->input->post('tel');
 			$autre_tel=$this->input->post('autre_tel');
 			$email=$this->input->post('email');

      // if ($this->session->userdata('iccm_CODE_STRUCTURE') == "PTF") {
      //   # code...
      //   $profil=$this->Modele->getRequeteOne('SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_DESCR` LIKE "PTF" ');
      // }elseif ($this->session->userdata('iccm_CODE_STRUCTURE') == "CAMEBU") {
      //   # code...
      //   $profil=$this->Modele->getRequeteOne('SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_DESCR` LIKE "CAMEBU" ');

      // }elseif($this->session->userdata('iccm_CODE_STRUCTURE') == "MINISANTE")
      // {
        
      //  $profil=$this->Modele->getRequeteOne('SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_DESCR` LIKE "'.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_DESCR').'" ');
      // }elseif($this->session->userdata('iccm_CODE_STRUCTURE') == "BDS")//iccm_INTERVENANT_STRUCTURE_DESCR
      // {
      //   $profil=$this->Modele->getRequeteOne('SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_DESCR` LIKE "BDS" ');
      // }elseif($this->session->userdata('iccm_CODE_STRUCTURE') == "CDS")
      // {
      //   $profil=$this->Modele->getRequeteOne('SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_DESCR`LIKE "CDS" ');
      // }else{
      //   $profil=$this->session->userdata('iccm_PROFIL_ID');

      // }
      // if (empty($profil['PROFIL_ID'])) {
      //   $profil['PROFIL_ID']=$this->session->userdata('iccm_PROFIL_ID');
      // }

      //$profil['PROFIL_ID']=$this->session->userdata('iccm_PROFIL_ID');
 			$profil=$this->input->post('PROFIL_ID');
      $structure=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
 			$SEXE_ID=$this->input->post('SEXE_ID');

 			$data=array('NOM'=>$nom,
        'PRENOM'=>$prenom,
 				'ID_FONCTION'=>$ID_FONCTION,
 				'TELEPHONE1'=>$tel,
 				'TELEPHONE2'=>$autre_tel,
                'EMAIL'=>$email,
 				'SEXE_ID'=>$SEXE_ID,
 				//'INTERVENANT_PROFIL_ID'=>$profil,
 				'INTERVENANT_STRUCTURE_ID'=>$structure
 			);
 			$INTERVENANT_RH_ID=$this->Modele->insert_last_id('intervenants_rh',$data);

 			$user_admin=array('USER_NAME'=>$nom,
 				'EMAIL'=>$email,
 				'PASSWORD'=>md5($tel),
 				'PROFIL_ID'=>$profil, //$profil['PROFIL_ID'],
 				'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID
 			);
 			$this->Modele->create('admin_users',$user_admin);
 			$data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un agent <b>".' '.$this->input->post('nom')." ".$this->input->post('prenom').'</b> '." est fait avec succès".'</div>';
    $subject="Projet ICCM - Identifiants de connexion";
    $INTERVENANT_RH_email=$this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_ID'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')));


    $cc_emails[]=$INTERVENANT_RH_email['EMAIL'];
    $message="Cher ".$prenom." ".$nom.", votre compte d’accès à ICCM est en attente d’activation. Vous recevrez très prochainement vos informations de connexion.";
    $this->notifications->send_mail($email,$subject,$cc_emails,$message,$attach=NULL);

            $this->session->set_flashdata($data);
            redirect(base_url('ihm/Intervenants_rh/index'));


 		}

 	}


 	public function delete($id){

 		$this->Modele->delete('intervenants_rh',array('INTERVENANT_RH_ID'=>$id));
 		$data['message']='<div class="alert alert-success text-center" id="message">'."La suppression est faite avec succès".'</div>';
        $this->session->set_flashdata($data);
        redirect(base_url('ihm/Intervenants_rh/index'));
 	}

 	public function getOne($id){
    if (empty($id)) {
      # code...
      $id=0;
    }
 		$data['title']='Intervenants';

        $data['sex']=$this->Modele->getRequete("SELECT `SEXE_ID`, `SEXE_DESCR` FROM `sexe` WHERE 1");
         $data['fonction']=$this->Modele->getRequete("SELECT ID_FONCTION,FONCTION_DESCR FROM `intervenant_fonction` WHERE 1");
 		$data['structure']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1 ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');
 		$data['profil']=$this->Modele->getRequete('SELECT `PROFIL_ID`, `PROFIL_DESCR` FROM `admin_profil` WHERE 1  ORDER BY PROFIL_DESCR ASC');
 		$query="SELECT rh.INTERVENANT_RH_ID,rh.NOM,rh.PRENOM,TELEPHONE1,TELEPHONE2,rh.EMAIL,rh.INTERVENANT_STRUCTURE_ID FROM intervenants_rh rh WHERE rh.INTERVENANT_RH_ID=".$id."";
    
    
 		$records=$this->Modele->getRequeteOne($query);
    $INTERVENANT_RH_PROFIL=$this->Modele->getOne('admin_users',array('INTERVENANT_RH_ID'=>$records['INTERVENANT_RH_ID']));
    $data['records']=$records;
    $data['INTERVENANT_RH_PROFIL']=$INTERVENANT_RH_PROFIL['PROFIL_ID'];

    //echo $INTERVENANT_RH_PROFIL['PROFIL_ID'];die();
 		//print_r($data['records']);die();

 		$this->load->view('Intervenants_Rh_Update_View',$data);
  //    $this->page='ihm/Intervenants_Rh_Update_View';
	 // $this->layout($data);
 	}

 	public function update($id){
 		$this->validation();

 		if ($this->form_validation->run()==FALSE) {
        // $id=$this->input->post('id') ;
 			$id=$this->uri->segment(4);
 			$data['title']='Intervenant';
 			$data['structure']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1 ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');
 		    $data['profil']=$this->Modele->getRequete('SELECT `PROFIL_ID`, `PROFIL_DESCR` FROM `admin_profil` WHERE 1  ORDER BY PROFIL_DESCR ASC');
 			$query="SELECT rh.INTERVENANT_RH_ID,rh.NOM,rh.PRENOM,TELEPHONE1,TELEPHONE2,rh.EMAIL,rh.INTERVENANT_STRUCTURE_ID FROM intervenants_rh rh WHERE rh.INTERVENANT_RH_ID=".$id."";
 			$data['records']=$this->Modele->getRequeteOne($query);
 			$data['error']='';

 			$this->load->view('Intervenants_Rh_Update_View',$data);

	  //    $this->page='ihm/Intervenants_Rh_Update_View';
		 // $this->layout($data);
 		}else{
 			$nom=$this->input->post('nom');
      $prenom=$this->input->post('prenom');
 			$ID_FONCTION=$this->input->post('ID_FONCTION');
 			$tel=$this->input->post('tel');
 			$autre_tel=$this->input->post('autre_tel');
 			$email=$this->input->post('email');
 			$profil=$this->input->post('PROFIL_ID');



 			$structure=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
      $SEXE_ID=$this->input->post('SEXE_ID');

 			$data=array('NOM'=>$nom,
        'PRENOM'=>$prenom,
 				'ID_FONCTION'=>$ID_FONCTION,
 				'TELEPHONE1'=>$tel,
 				'TELEPHONE2'=>$autre_tel,
        'EMAIL'=>$email,
 				'SEXE_ID'=>$SEXE_ID,
 				//'INTERVENANT_PROFIL_ID'=>$profil,
 				'INTERVENANT_STRUCTURE_ID'=>$structure
 			);
 			$sql=$this->Modele->update('intervenants_rh',array('INTERVENANT_RH_ID'=>$id),$data);
            $INTERVENANT_RH_ID=$id;

            if ($this->input->post('INTERVENANT_RH_PROFIL')==$this->input->post('PROFIL_ID')) 
              # code...
            {
              $user_admin=array('USER_NAME'=>$nom,
                  'EMAIL'=>$email,
                  'PASSWORD'=>md5($tel),
                  'PROFIL_ID'=>$this->input->post('PROFIL_ID'), //$profil['PROFIL_ID'],
                  
              );               
            }else{


            $user_admin=array('USER_NAME'=>$nom,
                'EMAIL'=>$email,
                'PASSWORD'=>md5($tel),
                'PROFIL_ID'=>$this->input->post('PROFIL_ID'), //$profil['PROFIL_ID'],
                'IS_ACTIVE'=>0,
                
            );

          }

      $this->Modele->update('admin_users',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID),$user_admin);

 			$data['message']='<div class="alert alert-success text-center" id="message">'."La modification est faite avec succès".'</div>';
            $this->session->set_flashdata($data);
            redirect(base_url('ihm/Intervenants_rh/index'));
 		}
 	}



 }
