<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 22/2/2021
 Date fin :Le 22/2/2021
 Commentaire: controller pour le CRUD des Intrants_Medico
 */

class Intrants_Medico_Seuil extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}


	public function index()
	{
        $data['title']='Listes des Intrants Medicaux avec leurs quantite Seuil';
        $query="SELECT seuil.INTRANT_MEDICAUX_SEUIL_ID,st.TYPE_INTERVENANT_STRUCTURE_DESCR,med.INTRANT_MEDICAUX_DESCR,seuil.QUANTITE_SEUIL FROM intrants_medicaux_seuil seuil JOIN type_intervenants_structures st ON st.TYPE_INTERVENANT_STRUCTURE_ID=seuil.TYPE_INTERVENANT_STRUCTURE_ID JOIN intrant_medicaux med ON med.INTRANT_MEDICAUX_ID=seuil.INTRANT_MEDICAUX_ID ORDER BY seuil.INTRANT_MEDICAUX_SEUIL_ID DESC";
	    $intrants_seuils=$this->Modele->getRequete($query);
	   
		$tabledata = array();
		foreach ($intrants_seuils as $intrant ) {

		$type=array();
		$type[]=$intrant['TYPE_INTERVENANT_STRUCTURE_DESCR'];
		$type[]=$intrant['INTRANT_MEDICAUX_DESCR'];
		$type[]=$intrant['QUANTITE_SEUIL'];

$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
                       <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                       <i class="fa fa-cog"></i> Options  <span class="caret">
                       </span></a> 
	                   <ul class="dropdown-menu dropdown-menu-left">';
$type['OPTIONS'] .="<li>
                       <a href='".base_url('ihm/Intrants_Medico_Seuil/update_intrant_seuil_view/').$intrant['INTRANT_MEDICAUX_SEUIL_ID'] ."'>
                       <label class='text-info'>Modifier</label>
                       </a>
                    </li>";
$type['OPTIONS'] .="<li>
                       <a href='#' data-toggle='modal' data-target='#mydelete".$intrant['INTRANT_MEDICAUX_SEUIL_ID']."'>
                       <label class='text-danger'>Supprimer</label>
                       </a>
                    </li>";



 $type['OPTIONS'] .= " </ul>
 </div>
 <div class='modal fade' id='mydelete".$intrant['INTRANT_MEDICAUX_SEUIL_ID']."'>
	 <div class='modal-dialog'>
		 <div class='modal-content'>

			 <div class='modal-body'>
				 <center><h5><strong>VOULEZ-VOUS SUPPRIMER L'INTRANT </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $intrant['INTRANT_MEDICAUX_DESCR']."</i></b>?</h5>
				 </center>
			 </div>

			 <div class='modal-footer'>
				 <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intrants_Medico_Seuil/delete_intrant_seuil/').$intrant['INTRANT_MEDICAUX_SEUIL_ID'] . "'>Supprimer
				 </a>
				 <button class='btn btn-primary btn-md' data-dismiss='modal'>
				 Quitter
				 </button>
			 </div>

		 </div>
	 </div>
 </div>";


			$tabledata[]=$type;
		}

$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
$this->table->set_template($template);
$this->table->set_heading(array('STRUCTURE DE L\'INTERVENANT','INTRANTS','QUANTITE SEUIL','ACTONS'));
$data['tableau']=$tabledata;
$this->page='ihm/Intrants_Medico_Seuil_Listing_view';
$this->layout($data);


  }


	public function add_intrant_seuil_view(){
	   $data['title']='Formulaire pour ajouter un nouveau Seuil d\'Intrant';
	   $data['intervenants_structures']=$this->Modele->getList('type_intervenants_structures');
	   $data['intrants']=$this->Modele->getList('intrant_medicaux');

	   $this->page='ihm/Intrants_Medico_Seuil_Add_View';
	   $this->layout($data);
	}

	public function insert_intrant_seuil(){

        $this->form_validation->set_rules('intervenants_structures','Structure','required');
        $this->form_validation->set_rules('intrant','Intrant','required');
        $this->form_validation->set_rules('quantite_seuil','Quantite','required');

        if ($this->form_validation->run()==FALSE) {
          $this->add_intrant_seuil_view();
        } else {
        
        $intervenant=$this->input->post('intervenants_structures');
		$intrant=$this->input->post('intrant');
		$quantite_seuil=$this->input->post('quantite_seuil');

		$data=array('TYPE_INTERVENANT_STRUCTURE_ID'=>$intervenant,
	                'INTRANT_MEDICAUX_ID'=>$intrant,
	                'QUANTITE_SEUIL'=>$quantite_seuil
	              );
		$sql=$this->Modele->create('intrants_medicaux_seuil',$data);
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Intrant ajouter avec succes ! .
			               </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Intrants_Medico_Seuil');
		} else {
			$sms['sms']='<br>
			               <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Une erreur s\'est produit ! .
			               </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Intrants_Medico_Seuil');
		}

      }		
	}


	

   public function delete_intrant_seuil($id){

   	$sql=$this->Modele->delete('intrants_medicaux_seuil',array('INTRANT_MEDICAUX_SEUIL_ID'=>$id));
   	if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Seuil de l\'intrant supprimer avec succes ! .
			               </div>
			            <br>' ;
            
		} else {
			$sms['sms']='<br>
			               <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Une erreur s\'est produit ! .
			               </div>
			            <br>' ;
		}

		$this->session->set_flashdata($sms) ;
        redirect('ihm/Intrants_Medico_Seuil/index');
   }
    
   public function update_intrant_seuil_view($id){

   	 $data['title']='Formulaire de modification';
	 $data['title']='Formulaire pour ajouter un nouveau Seuil d\'Intrant';
	 $data['intervenants_structures']=$this->Modele->getList('type_intervenants_structures');
	 $data['intrants']=$this->Modele->getList('intrant_medicaux');

	 $query="SELECT seuil.INTRANT_MEDICAUX_SEUIL_ID,st.TYPE_INTERVENANT_STRUCTURE_ID,med.INTRANT_MEDICAUX_ID,st.TYPE_INTERVENANT_STRUCTURE_DESCR,med.INTRANT_MEDICAUX_DESCR,seuil.QUANTITE_SEUIL FROM intrants_medicaux_seuil seuil JOIN type_intervenants_structures st ON st.TYPE_INTERVENANT_STRUCTURE_ID=seuil.TYPE_INTERVENANT_STRUCTURE_ID JOIN intrant_medicaux med ON med.INTRANT_MEDICAUX_ID=seuil.INTRANT_MEDICAUX_ID WHERE seuil.INTRANT_MEDICAUX_SEUIL_ID=$id";
	 $data['seuil']=$this->Modele->getRequeteOne($query);

     $this->page='ihm/Intrants_Medico_Seuil_Update_View';
	 $this->layout($data);
   }

   public function update_intrant_seuil($id){
   	
	$this->form_validation->set_rules('intervenants_structures','Structure','required');
    $this->form_validation->set_rules('intrant','Intrant','required');
    $this->form_validation->set_rules('quantite_seuil','Quantite','required');


      if ($this->form_validation->run()==FALSE) {

          $this->update_intrant_seuil_view($id);

   	    }else{
   	    
   	    $intervenant=$this->input->post('intervenants_structures');
		$intrant=$this->input->post('intrant');
		$quantite_seuil=$this->input->post('quantite_seuil');

		$data=array('TYPE_INTERVENANT_STRUCTURE_ID'=>$intervenant,
	                'INTRANT_MEDICAUX_ID'=>$intrant,
	                'QUANTITE_SEUIL'=>$quantite_seuil
	              );

$sql=$this->Modele->update('intrants_medicaux_seuil',array('INTRANT_MEDICAUX_SEUIL_ID'=>$id),$data);
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Seuil d\'intrant modifie avec succes ! .
			               </div>
			            <br>' ;
            
		} else {
			$sms['sms']='<br>
			                <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                      </a><strong> Oup! </strong> 
			                      Une erreur s\'est produit ! .
			                </div>
			            <br>' ;
		}
     }

     $this->session->set_flashdata($sms) ;
     redirect('ihm/Intrants_Medico_Seuil');
   }



}