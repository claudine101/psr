<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: NTIRAMPEBA JEAN DE DIEU
 Date debut :Le 12/02/2021
 Commentaire: controller pour Sens de Distribution
 */
 class Sens_Distribution extends CI_Controller
 {
  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {

    $sql=$this->Modele->getList('stock_demande_code_sens');

    $tabledata = array();
    $u=1;
    foreach ($sql as $distr) {

      $type=array();
      $type[]=$u++;
      $type[]=$distr['CODE_DEMANDE_SENS_DESCR'];

      $sens['demande']=$this->Modele->getOne('stock_code_sens',array('CODE_SENS_ID' => $distr['SENS_DISTRIBUTION']));

      $type[]= $sens['demande']['CODE_SENS_DESCR'];


      $type['OPTIONS'] = '<div class="dropdown">
      <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-cog"></i>
      Options <span class="caret"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-left">';
      $type['OPTIONS'] .="<li>
      <a href='".base_url('ihm/Sens_Distribution/update_sens_distribution_view/').$distr['CODE_DEMANDE_SENS_ID'] ."'>
      <label class='text-info' style='margin-left:20%;'>Modifier</label>
      </a>
      </li>";
      $type['OPTIONS'] .="<li>
      <a href='#' data-toggle='modal' data-target='#mydelete".$distr['CODE_DEMANDE_SENS_ID']."'>
      <label class='text-danger' style='margin-left:20%;'>Supprimer</label>
      </a>
      </li>";


      $type['OPTIONS'] .= " </ul>
      </div>
      <div class='modal fade' id='mydelete".$distr['CODE_DEMANDE_SENS_ID']."'>
      <div class='modal-dialog'>
      <div class='modal-content'>

      <div class='modal-body'>
      <center>
      <h5><strong>Voulez-vous supprimer ce sens de description </strong> : <b style:'background-color:prink'; >
      <i style='color:green;'>" . $distr['CODE_DEMANDE_SENS_DESCR']."</i></b> ?
      </h5>
      </center>
      </div>

      <div class='modal-footer'>
      <a class='btn btn-danger btn-md' href='" . base_url('ihm/Sens_Distribution/delete_sens_distribution/').$distr['CODE_DEMANDE_SENS_ID'] . "'>Supprimer
      </a>
      <button class='btn btn-default btn-md' data-dismiss='modal'>
      Quitter
      </button>
      </div>

      </div>
      </div>
      </div>";

      $tabledata[]=$type;
    }

    $template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
    $this->table->set_template($template);
    $this->table->set_heading(array('CODE SENS','DESCRIPTION DU DEMANDE SENS','SENS DE DISTRIBUTION','ACTION'));
    $data['title']='Liste de Sens de distribution';
    $data['sens_distr']=$tabledata;

    $this->load->view('ihm/Sens_Distribution_List_View',$data);
    // $this->page='ihm/Sens_Distribution_List_View';
    // $this->layout($data);
  }

  public function add_sens_distribution()
  {

   $data['title']='Formulaire pour ajouter le Sens de distribution';
   $data['DISTRIBUTION']=$this->input->post('DISTRIBUTION');
   $data['stock']=$this->Modele->getList('stock_code_sens');
   $data['DEMANDE_SENS']=$this->input->post('DEMANDE_SENS');

   $this->load->view('ihm/Sens_Distribution_Add_View',$data);

     // $this->page='ihm/Sens_Distribution_Add_View';
     // $this->layout($data);
 }
 public function _validation()
 {
  $this->form_validation->set_rules('DEMANDE_SENS','DEMANDE_SENS','trim|required',array('required'=>'<font style="color:red;font-size:15px;">Le champ est obligatoire</font>'));
  $this->form_validation->set_rules('DISTRIBUTION','DISTRIBUTION','trim|required',array('required'=>'<font style="color:red;font-size:15px;">Le champ est obligatoire</font>'));
}
public function insert_sens_distribution()
{
  $this->_validation();
  if ($this->form_validation->run()==FALSE)
  {
    $this->add_sens_distribution();
  }
  else
  {

    $DEMANDE_SENS=$this->input->post('DEMANDE_SENS');
    $DISTRIBUTION=$this->input->post('DISTRIBUTION');
    $data=array('CODE_DEMANDE_SENS_DESCR'=>$DEMANDE_SENS,
      'SENS_DISTRIBUTION'=>$DISTRIBUTION
    );
    $sql=$this->Modele->create('stock_demande_code_sens',$data);
    if ($sql)
    {
      $sms['sms']='<br>
      <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Demande ajouter avec succes ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Distribution/index');
    }
    else
    {
      $sms['sms']='<br>
      <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Une erreur s\'est produit ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Distribution/index');
    }

  }
}

public function update_sens_distribution_view($id){

 $data['title']='Formulaire pour éditer le Sens de demande d\'intrant';
 $data['stock']=$this->Modele->getList('stock_code_sens');
 $data['DISTR']=$this->Modele->getOne('stock_demande_code_sens' ,array('CODE_DEMANDE_SENS_ID'=>$id));

 $data['DEMANDE_SENS']=$this->input->post('DEMANDE_SENS');
 $data['DISTRIBUTION']=$this->input->post('DISTRIBUTION');

 $this->load->view('ihm/Sens_Distribution_Update_View',$data);
     // $this->page='ihm/Sens_Distribution_Update_View';
     // $this->layout($data);
}

public function update_sens_distribution($id)
{
  $this->_validation();
  if ($this->form_validation->run()==FALSE)
  {
    $this->update_sens_distribution_view($id);
  }
  else
  {

    $DISTRIBUTION=$this->input->post('DISTRIBUTION');
    $DEMANDE_SENS=$this->input->post('DEMANDE_SENS');
    $data=array('CODE_DEMANDE_SENS_DESCR'=>$DEMANDE_SENS,
      'SENS_DISTRIBUTION'=>$DISTRIBUTION
    );
    $sql=$this->Modele->update('stock_demande_code_sens',$data,array('CODE_DEMANDE_SENS_ID'=>$id));
    if ($sql)
    {
      $sms['sms']='<br>
      <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Demande ajouter avec succes ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Distribution/index');
    }
    else
    {
      $sms['sms']='<br>
      <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Une erreur s\'est produit ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Distribution/index');
    }

  }
}


public function delete_sens_distribution($id)
{
  $this->Modele->delete('stock_demande_code_sens',array('CODE_DEMANDE_SENS_ID'=>$id));
  $data['message']='<div class="alert alert-success text-center" id ="message">'."Suppression faite avec succès".'</div>';
  $this->session->set_flashdata($data);
  redirect(base_url('ihm/Sens_Distribution/index'));
}

}
