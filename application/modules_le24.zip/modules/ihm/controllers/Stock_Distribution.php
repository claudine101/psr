<?php
/**
* Author:NSHIMIRIMANA REVERIEN
DATE DEBUT:04-02-2021
DATE DEBUT:08-02-2021
COMMANTAIRE:DISTRIBUTION DES INTRATS AUX DEMANDEURS
*/
class Stock_Distribution extends CI_Controller
{
	function historique_demande($DEMANDE_ID = 1)
	{
		$demandeur=$this->Modele->getOne('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID));
		//$demandeur=$this->Modele->getOne('stock_demande');
		$data['title']='Détail des intrats demandés';
		$data['INTERVENANT_STRUCTURE_ID']=$this->input->post('INTERVENANT_STRUCTURE_ID');
    if($DEMANDE_ID > 0){
			$data['liste_demande']=$this->Modele->getRequete("SELECT stock_demande_detail.INTRANT_ID,stock_demande_detail.QUANTITE,stock_demande_detail.QUANTITE_RECU,stock_demande_detail.DEMANDE_ID,intrant_medicaux.INTRANT_MEDICAUX_DESCR,stc.QUANTITE as qte_disponible FROM `stock_demande_detail` LEFT JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID=stock_demande_detail.INTRANT_ID LEFT JOIN stock_demande ON
				stock_demande.DEMANDE_ID=stock_demande_detail.DEMANDE_ID JOIN stock_camebu stc ON stc.INTRANT_ID=stock_demande_detail.INTRANT_ID WHERE IS_DELIVERED=0 and stock_demande_detail.DEMANDE_ID=".$DEMANDE_ID);
		}
    else {
			$data['liste_demande']=$this->Modele->getRequete("SELECT stock_demande_detail.INTRANT_ID,stock_demande_detail.QUANTITE,stock_demande_detail.QUANTITE_RECU,stock_demande_detail.DEMANDE_ID,intrant_medicaux.INTRANT_MEDICAUX_DESCR,stc.QUANTITE as qte_disponible FROM `stock_demande_detail` LEFT JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID=stock_demande_detail.INTRANT_ID LEFT JOIN stock_demande ON
				stock_demande.DEMANDE_ID=stock_demande_detail.DEMANDE_ID JOIN stock_camebu stc ON stc.INTRANT_ID=stock_demande_detail.INTRANT_ID WHERE IS_DELIVERED=0");
    }
		$data['stock_demande_code_sens']=$this->Modele->getRequete('SELECT * FROM `stock_demande_code_sens`');
		//$data['intervenants_rh']=$this->Modele->getRequete("SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`,' ', `PRENOM`) AS NOM FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`=".$demandeur['INTERVENANT_STRUCTURE_ID']);
		$data['intervenants_rh']=$this->Modele->getRequete("SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`,' ', `PRENOM`) AS NOM FROM `intervenants_rh`");
		$data['structures']=$this->Modele->getRequete("SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1");
		$data['DEMANDE_ID']=$DEMANDE_ID;


		$this->page='ihm/Stock_Listing_View';
		$this->layout($data);
	}

	function add()
	{
		$DEMANDE_ID=$this->uri->segment(4);

		$demandeur=$this->Modele->getOne('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID));
		$DISTRIBUTION_DATE=$this->input->post('DISTRIBUTION_DATE');
		$COMMENT=$this->input->post('COMMENT');
		$CODE_SENS_ID=$demandeur['CODE_DEMANDE_SENS_ID'];
		$USER_ID=1;
		$INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');
		$DISTRIBUTION_CODE="DIST_".date('Ymd').$DEMANDE_ID;
		$DATE_LAST_UPDATE=date('Y-m-d');
		$INTERVENANT_STRUCTURE_ID=$demandeur['INTERVENANT_STRUCTURE_ID'];


		$this->validate();

		if ($this->form_validation->run()==FALSE)
		{

			$data['title']='Détail des intrats demandés';
			$data['INTERVENANT_STRUCTURE_ID']=$this->input->post('INTERVENANT_STRUCTURE_ID');
			$data['liste_demande']=$this->Modele->getRequete("SELECT stock_demande_detail.INTRANT_ID,stock_demande_detail.QUANTITE,stock_demande_detail.QUANTITE_RECU,stock_demande_detail.DEMANDE_ID,intrant_medicaux.INTRANT_MEDICAUX_DESCR,stc.QUANTITE as qte_disponible FROM `stock_demande_detail` LEFT JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID=stock_demande_detail.INTRANT_ID LEFT JOIN stock_demande ON
			stock_demande.DEMANDE_ID=stock_demande_detail.DEMANDE_ID JOIN stock_camebu stc ON stc.INTRANT_ID=stock_demande_detail.INTRANT_ID WHERE IS_DELIVERED=0 and stock_demande_detail.DEMANDE_ID=".$DEMANDE_ID);
			$data['stock_demande_code_sens']=$this->Modele->getRequete('SELECT * FROM `stock_demande_code_sens`');
			$data['intervenants_rh']=$this->Modele->getRequete("SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`,' ', `PRENOM`) AS NOM FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`=".$demandeur['INTERVENANT_STRUCTURE_ID']);
			$data['structures']=$this->Modele->getRequete("SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1");

			$data['DEMANDE_ID']=$DEMANDE_ID;

			$this->page='ihm/Stock_Listing_View';
			$this->layout($data);

		}
		else
		{


			$demande_detail=$this->Modele->getRequete("SELECT
				stock_demande_detail.INTRANT_ID,
				stock_demande_detail.QUANTITE,
				stock_demande_detail.QUANTITE_RECU,
				stock_demande_detail.DEMANDE_ID,
				intrant_medicaux.INTRANT_MEDICAUX_DESCR
				FROM
				`stock_demande_detail`
				LEFT JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID = stock_demande_detail.INTRANT_ID
				LEFT JOIN stock_demande ON stock_demande.DEMANDE_ID = stock_demande_detail.DEMANDE_ID
				WHERE IS_DELIVERED=0 AND
				stock_demande_detail.DEMANDE_ID =".$DEMANDE_ID);



			foreach ($demande_detail as $demand)
			{
           	  //echo "<pre>".$demand['QUANTITE']."</pre>";

				$array_distribution=array('DEMANDE_ID'=>$DEMANDE_ID,'DISTRIBUTION_CODE'=>$DISTRIBUTION_CODE,'DISTRIBUTION_DATE'=>$DISTRIBUTION_DATE,'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'CODE_SENS_ID'=>$CODE_SENS_ID,'COMMENT'=>$COMMENT,'USER_ID'=>$USER_ID);
				$DISTRIBUTION_ID=$this->Modele->insert_last_id('stock_distribution',$array_distribution);



				$getQteCamebu=$this->Modele->getList('stock_camebu',array('INTRANT_ID'=>$demand['INTRANT_ID']));

				$QTE=0;
				foreach ($getQteCamebu as $val) {
					$QTE+=$val['QUANTITE'];
				}

				//echo "<pre>".$QTE."</pre>";

				$QUANTITE_RESTANTE_STOCK_CAMEBU=0;
				if ($QTE>$demand['QUANTITE']) {
					$QUANTITE_RESTANTE_STOCK_CAMEBU=$QTE-$demand['QUANTITE'];
				}
				else
				{
				$message['sms']='<div class="alert alert-danger" role="alert" id="message"><center><b>Vous avez bien validé la demande</b></center></div>';
                $this->session->set_flashdata($message);

				redirect('ihm/Stock_Distribution/historique_demande/'.$DEMANDE_ID);
				}

				$STOCK_INTERVENANT=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$demand['INTRANT_ID']));
				$QUANTITE_A_JOUR=$STOCK_INTERVENANT['QUANTITE']+$demand['QUANTITE'];
				$this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$demand['INTRANT_ID']),array('QUANTITE'=>$QUANTITE_A_JOUR,'DATE_LAST_UPDATE'=>$DATE_LAST_UPDATE));

				$array_stock_intervenat=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'QUANTITE'=>$demand['QUANTITE'],'INTRANT_ID'=>$demand['INTRANT_ID'],'DATE_LAST_UPDATE'=>$DATE_LAST_UPDATE);
				$this->Modele->create('stock_intervenat',$array_stock_intervenat);

				$array_distribution_detail=array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID,'QUANTITE'=>$demand['QUANTITE'],'INTRANT_ID'=>$demand['INTRANT_ID']);

				$this->Modele->create('stock_distribution_intrant_detail',$array_distribution_detail);

				$this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('STATUS'=>0));
				$this->Modele->update('stock_demande_detail',array('DEMANDE_ID'=>$DEMANDE_ID),array('QUANTITE_RECU'=>$demand['QUANTITE'],'IS_DELIVERED'=>1));
				$this->Modele->update('stock_camebu',array('INTRANT_ID'=>$demand['INTRANT_ID']),array('QUANTITE'=>$QUANTITE_RESTANTE_STOCK_CAMEBU,'DATE_LAST_UPDATE'=>$DATE_LAST_UPDATE));

				$message['sms']='<div class="alert alert-success" role="alert" id="message"><center><b>Vous avez bien validé la demande</b></center></div>';
                $this->session->set_flashdata($message);

				redirect('ihm/Stock_Distribution/historique_demande/'.$DEMANDE_ID);



			}





		}

	}



	function validate()
	{
		$this->form_validation->set_rules('DISTRIBUTION_DATE','DISTRIBUTION_DATE','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));

		$this->form_validation->set_rules('COMMENT','COMMENT','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));

		$this->form_validation->set_rules('INTERVENANT_RH_ID','INTERVENANT_RH_ID','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
	}


	function changer_qte_semande($DEMANDE_ID=NULL,$INTRANT_ID=NULL)
	{
		$QUANTITE_DEMANDE=$this->input->post('QUANTITE_DEMANDE');
		$this->Modele->update('stock_demande_detail',array('DEMANDE_ID'=>$DEMANDE_ID,'INTRANT_ID'=>$INTRANT_ID),array('QUANTITE'=>$QUANTITE_DEMANDE));

		redirect('ihm/Stock_Distribution/historique_demande/'.$DEMANDE_ID);
	}

	function historique_distribution()
	{

    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
    $query_principal='SELECT
    enqueteur.NOM,
    enqueteur.PRENOM,
    enqueteur.TEL1,
    enqueteur.TEL2,
    enqueteur.EMAIL,
    enqueteur.ENQUETEUR_ID,
    enqueteur.DEVICE_ID,
    prison_prison.NOM_PRISON,
    enqueteur.IS_DOUBLON,
    niveau_instruction.DESCRIPTION AS nivo
	FROM
    `enqueteur`
	LEFT JOIN prison_prison ON prison_prison.ID_PRISON = enqueteur.ID_PRISON
	LEFT JOIN niveau_instruction ON niveau_instruction.ID_NIVEAU_INSTRUCTION = enqueteur.ID_NIVEAU_INSTRUCTION
	WHERE 1'.$critere;

      $limit='LIMIT 0,10';
      if($_POST['length'] != -1){
      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
      }
      $order_by='';
      if($_POST['order']['0']['column']!=0){
      $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY ENQUETEUR_ID   DESC';
      }

     $search = !empty($_POST['search']['value']) ? (" AND  enqueteur.TEL1 LIKE '%$var_search%' OR enqueteur.TEL2 LIKE '%$var_search%' OR  enqueteur.EMAIL LIKE '%$var_search%' OR enqueteur.DEVICE_ID LIKE '%$var_search%' OR  niveau_instruction.DESCRIPTION LIKE '%$var_search%' OR  prison_prison.NOM_PRISON LIKE '%$var_search%' OR  enqueteur.NOM LIKE '%$var_search%' OR  enqueteur.PRENOM LIKE '%$var_search%' ") : '';
     $critaire ="";


     $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
     $query_filter=$query_principal.'  '.$critaire;

     $fetch_enqueteur = $this->Model->datatable($query_secondaire);

    $data = array();
    foreach ($fetch_enqueteur as $enqueteur) {

     $sub_array = array();

       $sub_array[] =  $enqueteur->NOM." ".$enqueteur->PRENOM;
       if (empty($enqueteur->TEL2)) {
       	$sub_array[] =  $enqueteur->TEL2;
       } else {
       	$sub_array[] =  $enqueteur->TEL1.'/'.$enqueteur->TEL2;
       }

       if (empty($enqueteur->EMAIL)) {
       	$sub_array[] =  "N/A";
       } else {
       	$sub_array[] =  $enqueteur->EMAIL;
       }
       $sub_array[] =  $enqueteur->NOM_PRISON;
       $sub_array[] =  $enqueteur->nivo;

       if (empty($enqueteur->DEVICE_ID)) {
       	$sub_array[] =  "N/A";
       } else {
       	$sub_array[] =  $enqueteur->DEVICE_ID;
       }

      if ($enqueteur->IS_DOUBLON==0) {
        $sub_array[]="<a  class='btn btn-success btn-rounded tooltip1' ><center> <span class='tooltiptext1'>Non Doublon</b></span> </center> <i class='fa fa-check-circle'></i></a>" ;
       } else {
        $sub_array[]="<a  class='btn btn-danger btn-rounded tooltip1' ><center> <span class='tooltiptext1'>Doublon</b></span> </center> <i class='fa fa-times-circle'></i></a>" ;
       }
       $point="<a href='#' onclick='editer(".$enqueteur->ENQUETEUR_ID.")' class='btn btn-success btn-rounded tooltip1'><center> <span class='tooltiptext1'>Modifier</b></span> </center> <i class='fa fa-edit'></i></a>" ;

       $point.="<a href='#' data-toggle='modal'  data-target='#mydelete' class='btn btn-danger btn-rounded tooltip1' ><center> <span class='tooltiptext1'>Supprimer</b></span> </center> <i class='fa fa-trash-o'></i></a>" ;

       $point.="   </ul>
                  </div>
                  <div class='modal fade' id='mydelete'>
                   <div class='modal-dialog'>
                   <div class='modal-content'>
                  <div class='modal-body'>
                  Voulez-vous supprimer <b>  ".$enqueteur->NOM.' '.$enqueteur->PRENOM."</b>
                  ?</div>";

        $point.= "<div class='modal-footer'>
                <a class='btn btn-danger btn-md' href='".base_url('enqueteur/Enqueteurs/delete/'.$enqueteur->ENQUETEUR_ID)."'>Supprimer</a>
                                  <button class='btn btn-primary btn-md' class='close' data-dismiss='modal'>Quitter</button>
                </div>";




        $sub_array[]=$point;



        $data[] = $sub_array;

          }

          $output = array(
              "draw" => intval($_POST['draw']),
              "recordsTotal" =>$this->Model->all_data($query_principal),
              "recordsFiltered" => $this->Model->filtrer($query_filter),
              "data" => $data
          );

          echo json_encode($output);
	}





	function get_intervenant_rh($INTERVENANT_STRUCTURE_ID){
    $intervenants = $this->Modele->getRequete('SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`," ",`PRENOM`) AS NOM FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID);
     $html = '<option value="" >Intervenant RH ---</option>';
         foreach ($intervenants as $interve) {
         $html .= '<option value="'.$interve['INTERVENANT_RH_ID'].'">'.$interve['NOM'].'</option>';
         }
         echo $html;

        }



}
