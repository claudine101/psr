<?php 

/**
 * 
 */
class Intervenant_Fonction extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['error'] = '';
		
		$this->listing();
	}

	function listing()
	{
	$sql="SELECT ID_FONCTION,FONCTION_DESCR FROM `intervenant_fonction` WHERE 1";
    
   $fonction=$this->Modele->getRequete($sql);

   $data=array();

   foreach ($fonction as $key) {
     $sub_array=array();
     $sub_array[]=$key['FONCTION_DESCR'];
  

     $sub_array['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydelete" . $key['ID_FONCTION'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
     $sub_array['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Intervenant_Fonction/getOne/'. $key['ID_FONCTION']) . "'><font>&nbsp;&nbsp;Modifier</font></a></li>";
     $sub_array['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $key['ID_FONCTION'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h6><strong>Voulez-vous supprimer la facture ?</strong><br><b style:'background-color:prink';><i style='color:green;'>" . $key['FONCTION_DESCR']."</i></b></h6></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenant_Fonction/delete/'. $key['ID_FONCTION']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";


     $data[]=$sub_array;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('FONCTION','ACTIONS'));
   $data['donnees']=$data;
   $data['title'] = "Fonction";
   $this->load->view('Intervenant_Fonction_List_View',$data);
   
	}

	function ajouter()
	{
	$data['title']='Nouvelle facture';
  $this->load->view('Intervenant_Fonction_Add_View',$data);
   
	}
	function add()
  {
    $this->form_validation->set_rules('FONCTION_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   if ($this->form_validation->run() == FALSE)
   {
     $data['title'] = "Nouvelle Maladie"; 
     $this->load->view('Maladies_Add_View',$data);
   }

   else
   {
     $dataInsert=array(
               'FONCTION_DESCR'=>$this->input->post('FONCTION_DESCR')
               );


     $this->Modele->create('intervenant_fonction',$dataInsert);
     $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'une fonction <b>".' '.$this->input->post('FONCTION_DESCR').'</b> '." est faite avec succès".'</div>';
     $this->session->set_flashdata($data);
     redirect(base_url('ihm/Intervenant_Fonction/'));
   }
  }

 function getOne()
 {
 	 $id=$this->uri->segment(4);
   $data['fonc']=$this->Modele->getOne('intervenant_fonction',array('ID_FONCTION'=>$id));
   $data['title']='Fonction';
   $this->load->view('Intervenant_Fonction_Update_View',$data);

 }

 function update()
 {
 	
   $this->form_validation->set_rules('FONCTION_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   if ($this->form_validation->run() == FALSE)
   {
     $id=$this->input->post('ID_FONCTION');
     $data['fonc']=$this->Modele->getOne('intervenant_fonction',array('ID_FONCTION'=>$id));
     $data['title']='modification d\'une fonction';

     $this->load->view('Intervenant_Fonction_Update_View',$data);
   

   }else
   {
     $id=$this->input->post('ID_FONCTION');
     $data=array(
               'FONCTION_DESCR'=>$this->input->post('FONCTION_DESCR')
                );
     $this->Modele->update('intervenant_fonction',array('ID_FONCTION'=>$id),$data);
     $datas['message']='<div class="alert alert-success text-center" id="message">La modification de la fonction  '.$this->input->post('FONCTION_DESCR').'</b> faite avec succès</div>';
     $this->session->set_flashdata($datas);
     redirect(base_url('ihm/Intervenant_Fonction/index'));
   }
 }

 function delete()
 {
   $table="intervenant_fonction";
   $criteres['ID_FONCTION']=$this->uri->segment(4);
   $data['rows']= $this->Modele->getOne( $table,$criteres);
   $this->Modele->delete($table,$criteres);

   $data['message']='<div class="alert alert-success text-center" id="message">'."La fonction <b> ".' '.$data['rows']['FONCTION_DESCR'].' </b> '." est supprimée avec succès".'</div>';
   $this->session->set_flashdata($data);
   redirect(base_url('ihm/Intervenant_Fonction/index'));


 }
}
 ?>