
<?php
/**
 * auteur:EMERY
 * date debut:04/03/2021
 * date fin:04/03/2021
 * commentaire:Processus de notification des seuil et des stock
*/
class Sms_Stock_Demande extends CI_Controller
{

  function __construct()
     {
  parent::__construct();
     }

  function index()
   {
    $data['error']='';
    $this->listing();

     }

       //LISTE DES NOTIFICATION
    function listing()
            {
      //$intervenants=$this->Modele->getList('intervenants_structure');
      $sql="SELECT `TEL`,`MESSAGE_RECU`,`MESSAGE_ENVOYE`,`DATE_INSERTION` FROM `sms_demande`";

       $stock1=$this->Modele->getRequete($sql);
       $data_intervenant=array();
     foreach ($stock1 as $key) {

       $stock_seuil=array();
       $stock_seuil[]=$key['TEL'];
       $stock_seuil[]=$key['MESSAGE_RECU'];
       $stock_seuil[]=$key['MESSAGE_ENVOYE'];
       $stock_seuil[]=$key['DATE_INSERTION'];
       $data_intervenant[]=$stock_seuil;
          }
       $template = array(
            'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
            'table_close' => '</table>'
        );
        $this->table->set_template($template);
        $this->table->set_heading(array('Téléphone','Message reçu','Message envoyé','date d\'envoi'));
        $data['data']=$data_intervenant;
        $data['title'] = "LISTE DE MESSAGES";
        //$this->make_bread->add('Liste des Cultures', 'CULTURE/listing/', 1);
        // $data['breadcrumb'] = $this->make_bread->output();
      


       $this->load->view('ihm/Sms_Stock_Demande_View',$data);

       

    }


}

?>
