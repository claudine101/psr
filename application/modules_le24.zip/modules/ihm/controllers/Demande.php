<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 28/1/2021
 Date fin :Le 28/1/2021
 Commentaire: controller pour le CRUD des Demande
 */
 class Demande extends CI_Controller
 {

 	public function __construct()
 	{
 		parent::__construct();
 	}

 	public function index()
 	{

 		$query="SELECT dem.DEMANDE_ID,dem.DEMANDE_CODE,dem.DATE_INSERTION,det.QUANTITE,det.QUANTITE_RECU,med.INTRANT_MEDICAUX_DESCR,rc.NUMERO_LOT,rc.DATE_PEREMPTION FROM stock_demande dem JOIN stock_demande_detail det ON det.DEMANDE_ID=dem.DEMANDE_ID JOIN intrant_medicaux med ON med.INTRANT_MEDICAUX_ID=det.INTRANT_ID JOIN rc_reception_intrant_detail rc ON rc.INTRANT_ID=det.INTRANT_ID";
 		$demandes=$this->Modele->sql_all_query($query);

 		$tabledata = array();
 		foreach ($demandes as $demande ) {

 			$type=array();
 			$type[]=$demande['DEMANDE_CODE'];
 			$type[]=$demande['INTRANT_MEDICAUX_DESCR'];
 			$type[]=$demande['QUANTITE'];
 			$type[]=$demande['NUMERO_LOT'];
 			$type[]=$demande['DATE_INSERTION'];
 			$type[]=$demande['DATE_PEREMPTION'];


 			$type['OPTIONS'] = '<div class="dropdown">
 			<a class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
 			<i class="fa fa-cog"></i>
 			Options <span class="caret"></span>
 			</a>
 			<ul class="dropdown-menu dropdown-menu-left">';
 			$type['OPTIONS'] .="<li>
 			<a href='#'>
 			<label style='margin-left:20%;'>Approuver</label>
 			</a>
 			</li>";

 			$type['OPTIONS'] .="<li>
 			<a href='".base_url('ihm/Demande/update_demande_view/').$demande['DEMANDE_ID'] ."' class='cart_update'>
 			<label class='text-info' style='margin-left:20%;'>Modifier</label>
 			</a>
 			</li>";
 			$type['OPTIONS'] .="<li>
 			<a href='#' data-toggle='modal' data-target='#mydelete".$demande['DEMANDE_ID']."'>
 			<label class='text-danger' style='margin-left:20%;'>Supprimer</label>
 			</a>
 			</li>";


 			$type['OPTIONS'] .= " </ul>
 			</div>
 			<div class='modal fade' id='mydelete".$demande['DEMANDE_ID']."'>
 			<div class='modal-dialog'>
 			<div class='modal-content'>

 			<div class='modal-body'>
 			<center>
 			<h5><strong>VOULEZ-VOUS SUPPRIMER CE Demande </strong> : <b style:'background-color:prink';>
 			<i style='color:green;'>" . $demande['DEMANDE_CODE']."</i></b> ?
 			</h5>
 			</center>
 			</div>

 			<div class='modal-footer'>
 			<a class='btn btn-danger btn-md' href='" . base_url('ihm/Demande/delete_demande/').$demande['DEMANDE_ID'] . "'>Supprimer
 			</a>
 			<button class='btn btn-secondary btn-md' data-dismiss='modal'>
 			Quitter
 			</button>
 			</div>

 			</div>
 			</div>
 			</div>";


 			$tabledata[]=$type;
 		}

 		$template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
 		$this->table->set_template($template);
 		$this->table->set_heading(array('CODE DU DEMANDEUR','INTRANTS','QUANTITE DEMANDEE','LOT','DATE DE DEMANDE','DATE DE PEREMPTION','ACTION'));
 		$data['demandes']=$tabledata;
 		$data['title']='Listes des Demandes';
 		$this->page='ihm/Demande_Listing_View';
 		$this->layout($data);

 	}


 	public function add_demande(){
 		$this->cart->destroy();
 		$data['typ']=$this->input->post('type');
 		$data['title']='Formulaire pour les Demande';
 		$data['type_intervenants_structures']=$this->Modele->getList('type_intervenants_structures');
 		$data['intrants']=$this->Modele->getList('intrant_medicaux');
 		$data['sens_demandes']=$this->Modele->getList('stock_demande_code_sens');
 		$data['error']='';

 		$this->page='ihm/Demande_Add_View';
 		$this->layout($data);
 	}

 	public function insert_demande(){

 		$this->form_validation->set_rules('CODE_DEMANDE_SENS_ID', 'Sens', 'trim|required');
 		$this->form_validation->set_rules('PATH_JUSTIFICATION', 'Fichier', 'trim|required');
 		$this->form_validation->set_rules('USER_DEMANDEUR_ID', 'Demandeur', 'trim|required');
 		$this->form_validation->set_rules('type', 'Structure', 'trim|required');
    // $this->form_validation->set_rules('id_province', 'Province', 'trim|required');

 		if ($this->form_validation->run() == FALSE) {
 			$data['typ']=$this->input->post('type');
 			$data['title']='Formulaire pour les Demande';
 			$data['type_intervenants_structures']=$this->Modele->getList('type_intervenants_structures');
 			$data['intrants']=$this->Modele->getList('intrant_medicaux');
 			$data['sens_demandes']=$this->Modele->getList('stock_demande_code_sens');

 			$data['error']='';
 			$this->page='ihm/Demande_Add_View';
 			$this->layout($data);
 		}else{
        // if(!empty($_FILES['PATH_JUSTIFICATION']['name']))
        //    {
 			$config['upload_path']='./assets/upload/justification' ;
 			$config['allowed_types']='jpg|jpeg|png|gif' ;
 			$this->load->library('upload',$config) ;
 			$this->upload->do_upload('PATH_JUSTIFICATION') ;
 			$image=$this->upload->data() ;
 			$path=$config['upload_path'].'/'.$image['file_name'];

// }
 			$code=$this->input->post('DEMANDE_CODE');
 			$nom=$this->input->post('PATH_JUSTIFICATION');
 			$demandeur=$this->input->post('USER_DEMANDEUR_ID');
 			$is_justifie=$this->input->post('IS_JUSTIFIE');
 			$user_id=$this->session->userdata('iccm_USER_ID');
 			$structure=$this->input->post('INTERVENANT_STRUCTURE_ID');
 			$sens_demande=$this->input->post('CODE_DEMANDE_SENS_ID');

 			$data=array('DEMANDE_CODE'=>1,
 				'PATH_JUSTIFICATION'=>$path,
 				'IS_JUSTIFIE'=>$is_justifie,
 				'INTERVENANT_STRUCTURE_ID'=>$structure,
 				'USER_DEMANDEUR_ID'=>$demandeur,
 				'CODE_DEMANDE_SENS_ID'=>$sens_demande,
 				'USER_ID'=>1
 			);
 			$sql=$this->Modele->insert_last_id('stock_demande',$data);

 			if($sql >0){
 				$code_demande = "DMD-".$sens_demande.'-'.$sql;
 				$this->Modele->updateData('stock_demande',['DEMANDE_CODE'=>$code_demande],['DEMANDE_ID'=>$sql]) ;
 			}

 			$cart_contents=array();
 			foreach ($this->cart->contents() as $value) {

 				$cart_contents=array('INTRANT_ID'=>$value['id'],
 					'QUANTITE'=>$value['quantite'],
 					'DEMANDE_ID'=>$sql);
 				$this->Modele->Add_data('stock_demande_detail',$cart_contents);

 			}

 			if ($sql) {
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Demande ajouter avec succes ! .
 				</div>
 				<br>' ;
 			} else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produit ! .
 				</div>
 				<br>' ;

 			}

 		}
 		$this->session->set_flashdata($sms) ;
 		redirect('ihm/Demande');

 	}

 	public function delete_demande($id){
 		$sql=$this->Modele->deleteData('stock_demande',array('DEMANDE_ID'=>$id));
 		$sql2=$this->Modele->deleteData('stock_demande_detail',array('DEMANDE_ID'=>$id));
 		if ($sql) {
 			$sms['sms']='<br>
 			<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			District supprimer avec succes ! .
 			</div>
 			<br>' ;
 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/Demande');
 		} else {
 			$sms['sms']='<br>
 			<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			Une erreur s\'est produit ! .
 			</div>
 			<br>' ;
 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/Demande');
 		}
 	}

 	public function update_demande_view($id){
 		$data['title']='Formulaire de modification';
 		$data['type_intervenants_structures']=$this->Modele->getList('type_intervenants_structures');
 		$data['intrants']=$this->Modele->getList('intrant_medicaux');

 		$query_cart="SELECT det.DETAIL_ID,det.INTRANT_ID,det.QUANTITE,med.INTRANT_MEDICAUX_ID,med.INTRANT_MEDICAUX_DESCR FROM stock_demande_detail det JOIN intrant_medicaux med ON med.INTRANT_MEDICAUX_ID=det.INTRANT_ID WHERE det.DEMANDE_ID=$id";

 		$cart_infos=$this->Modele->sql_all_query($query_cart);
 		$total_cart=count($cart_infos);


 		foreach ($cart_infos as $cart_info) {
 			$cart_array=array('id'=>$cart_info['INTRANT_MEDICAUX_ID'],
 				'qty'     => 1,
 				'price'   => 1,
 				'name'    => 'intrant',
 				'intrant'=>$cart_info['INTRANT_MEDICAUX_DESCR'],
 				'quantite'=>$cart_info['QUANTITE']
 			);
 			$this->cart->insert($cart_array);
 		}

 		$query="SELECT dem.DEMANDE_ID,dem.DEMANDE_CODE,dem.PATH_JUSTIFICATION,dem.IS_JUSTIFIE,NOM,PRENOM,dem.USER_DEMANDEUR_ID,t.TYPE_INTERVENANT_STRUCTURE_DESCR,st.INTERVENANT_STRUCTURE_DESCR,st.INTERVENANT_STRUCTURE_ID,t.TYPE_INTERVENANT_STRUCTURE_ID,rh.INTERVENANT_RH_ID FROM stock_demande dem JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=dem.USER_DEMANDEUR_ID JOIN intervenants_structure st ON st.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID=st.TYPE_INTERVENANT_STRUCTURE_ID AND dem.DEMANDE_ID=$id";
 		$data['demande']=$this->Modele->sql_one_query($query);

 		$this->page='ihm/Demande_Update_View';
 		$this->layout($data);
 	}

 	public function update_demande($id){
 		$this->form_validation->set_rules('DEMANDE_CODE', 'Code', 'trim|required');
    // $this->form_validation->set_rules('PATH_JUSTIFICATION', 'Fichier', 'trim|required');
 		$this->form_validation->set_rules('USER_DEMANDEUR_ID', 'Demandeur', 'trim|required');
 		$this->form_validation->set_rules('type', 'Structure', 'trim|required');

 		if ($this->form_validation->run() == FALSE) {

 			$data['title']='Formulaire de modification';
 			$data['type_intervenants_structures']=$this->Modele->getList('type_intervenants_structures');
 			$query="SELECT dem.DEMANDE_ID,dem.DEMANDE_CODE,dem.PATH_JUSTIFICATION,dem.IS_JUSTIFIE,NOM,PRENOM,dem.USER_DEMANDEUR_ID,t.TYPE_INTERVENANT_STRUCTURE_DESCR,st.INTERVENANT_STRUCTURE_DESCR,st.INTERVENANT_STRUCTURE_ID,t.TYPE_INTERVENANT_STRUCTURE_ID,rh.INTERVENANT_RH_ID FROM stock_demande dem JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=dem.USER_DEMANDEUR_ID JOIN intervenants_structure st ON st.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID=st.TYPE_INTERVENANT_STRUCTURE_ID AND dem.DEMANDE_ID=$id";
 			$data['demande']=$this->Modele->sql_one_query($query);
 			$this->page='ihm/Demande_Update_View';
 			$this->layout($data);
 		}else{

 			$img=$this->Modele->sql_one_query("SELECT PATH_JUSTIFICATION FROM stock_demande WHERE DEMANDE_ID=$id") ;

 			$path_img=explode('/',$img['PATH_JUSTIFICATION']);

 			if(!empty($_FILES['PATH_JUSTIFICATION']['name']))
 			{
 				$config['upload_path']='./assets/upload/justification' ;
 				$config['allowed_types']='jpg|jpeg|png|gif' ;
 				$this->load->library('upload',$config) ;
 				$this->upload->do_upload('PATH_JUSTIFICATION') ;
 				$image=$this->upload->data() ;
 				$path=$config['upload_path'].'/'.$image['file_name'];
 			}else{
 				$path='./assets/upload/justification/'.$path_img[4];
 			}
 			$nom=$this->input->post('PATH_JUSTIFICATION');
 			$demandeur=$this->input->post('USER_DEMANDEUR_ID');
 			$is_justifie=$this->input->post('IS_JUSTIFIE');
 			$user_id=$this->session->userdata('iccm_USER_ID');

 			$data=array('PATH_JUSTIFICATION'=>$path,
 				'IS_JUSTIFIE'=>$is_justifie,
 				'USER_DEMANDEUR_ID'=>$demandeur,
 				'USER_ID'=>1
 			);
 			$sql=$this->Modele->updateData('stock_demande',$data,array('DEMANDE_ID'=>$id));


 			$cart_contents=array();
 			foreach ($this->cart->contents() as $value) {

 				$cart_contents=array('INTRANT_ID'=>$value['id'],
 					'QUANTITE'=>$value['quantite'],
 					'DEMANDE_ID'=>$id);
 				$this->Modele->updateData('stock_demande_detail',$cart_contents,array('DEMANDE_ID'=>$id));

 			}


 			if ($sql) {
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Demande modifier avec succes ! .
 				</div>
 				<br>' ;

 			} else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produit ! .
 				</div>
 				<br>' ;
 			}

 		}

 		$this->session->set_flashdata($sms) ;
 		redirect('ihm/Demande');
 	}




 	public function select_structure_intervenant(){
 		$type=$this->input->post('type');
 		if ($type) {
 			$query="SELECT * FROM intervenants_structure WHERE TYPE_INTERVENANT_STRUCTURE_ID='".$type."'";
 			$structures=$this->Modele->sql_all_query($query);
 			echo "<option selected>---selectionner la structure---</option>";
 			foreach ($structures as $structure) {
 				echo "<option value=".$structure['INTERVENANT_STRUCTURE_ID'].">".$structure['INTERVENANT_STRUCTURE_DESCR']."</option>";
 			}
 		} else {
 			echo '<option value="">No data found </option>';
 		}

 	}


 	public function select_intervenant_rh(){
 		$structure=$this->input->post('structure');
 		$query="SELECT INTERVENANT_RH_ID, NOM, PRENOM, TELEPHONE1, TELEPHONE2,rh.EMAIL,rh.INTERVENANT_PROFIL_ID,rh.INTERVENANT_STRUCTURE_ID FROM intervenants_rh rh JOIN intervenants_structure str ON str.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID AND rh.INTERVENANT_STRUCTURE_ID=$structure";
 		$intervenants_rh=$this->Modele->sql_all_query($query);
 		echo "<option selected>---selectionner l'intervenant---</option>";
 		foreach ($intervenants_rh as $intervenant) {
 			echo "<option value=".$intervenant['INTERVENANT_RH_ID'].">".$intervenant['NOM']." ".$intervenant['PRENOM']."</option>";
 		}
 	}


 	public function add_to_cart(){
 		$intrant_id=$this->input->post('intrant_id');
 		$quantite=$this->input->post('quantite');
 		$intrants=$this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$intrant_id));

 		$data=array('id'=>$intrants['INTRANT_MEDICAUX_ID'],
 			'qty'     => 1,
 			'price'   => 1,
 			'name'    => 'intrant',
 			'intrant'=>$intrants['INTRANT_MEDICAUX_DESCR'],
 			'quantite'=>$quantite
 		);
 		$this->cart->insert($data);
 		echo $this->listing_to_card();

 	}

 	public function load_cart(){
 		echo $this->listing_to_card();
 	}

 	public function listing_to_card(){
 		$output='';

 		$output.='<table class="table">
 		<thead class="thead-dark">
 		<tr>
 		<th scope="col">Intrant</th>
 		<th scope="col">Quantite</th>
 		<th scope="col">Action</th>
 		</tr>
 		</thead>
 		<tbody>';
 		$nb=0;
 		foreach ($this->cart->contents() as $value) {
 			$nb++;
 			$output.='<tr>
 			<td>'.$value['intrant'].'</td>
 			<td>'.$value['quantite'].'</td>
 			<td>
 			<button type="button" class="btn btn-danger btn-sm remove_to_cart pull-right" id="'.$value['rowid'].'">X</button>
 			</td>';
 		}
 		$output.='</tr>
 		</tbody>
 		</table>';
 		if ($nb==0) {
 			$output='';
 		}

 		return $output;

 	}


 	public function remove_to_cart(){
 		$row_id=$this->input->post('row_id');
 		$data=array('rowid'=>$row_id,'qty'=>0);
 		$this->cart->update($data);
 		echo $this->listing_to_card();
 	}








 }
