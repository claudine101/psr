<?php

/**
 * 
 Auteur du fichier: Niyongabire Pacifique
 Date debut :Le 29/1/2021
 Date fin :Le 29/1/2021
 Commentaire: controller pour le CRUD des Intervenants
 */

class Intervenants_rh extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
        $data['title']='Listes des Intervenants';
	    $districts=$this->Modele->getList('intervenants_rh');
	   
		$tabledata = array();
		foreach ($districts as $district ) {

		$type=array();
		$type[]=$district['NOM'].' '.$district['PRENOM'];
		$type[]=$district['TELEPHONE1'].' / '.$district['TELEPHONE2'];
		$type[]=$district['EMAIL'];
				

$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
                       <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog">
                           </i> Options<span class="caret"></span>
                       </a> 
				       <ul class="dropdown-menu dropdown-menu-left">';
$type['OPTIONS'] .="<li><a href='".base_url('ihm/Intervenants_rh/update_intervenant_view/').$district['INTERVENANT_RH_ID'] ."'><label class='text-info'>Modifier</label></a></li>";
$type['OPTIONS'] .="<li><a href='#' data-toggle='modal' data-target='#mydelete".$district['INTERVENANT_RH_ID']."'><label class='text-danger'>Supprimer</label></a></li>";


 $type['OPTIONS'] .= " </ul>
 </div>
 <div class='modal fade' id='mydelete".$district['INTERVENANT_RH_ID']."'>
	 <div class='modal-dialog'>
		 <div class='modal-content'>

			 <div class='modal-body'>
				 <center>
				 <h5><strong>VOULEZ-VOUS SUPPRIMER L'INTERVENANT </strong> : <b style:'background-color:prink';>
				 <i style='color:green;'>" . $district['NOM'].' '.$district['PRENOM']."</i></b> ?
				 </h5>
				 </center>
			 </div>

			 <div class='modal-footer'>
				 <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intervenants_rh/delete_intervenant/').$district['INTERVENANT_RH_ID'] . "'>Supprimer
				 </a>
				 <button class='btn btn-default btn-md' data-dismiss='modal'>
				 Quitter
				 </button>
			 </div>

		 </div>
	 </div>
 </div>";


			$tabledata[]=$type;
		}

$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
$this->table->set_template($template);
$this->table->set_heading(array('INTERVENANTS','TELEPHONE','EMAIL','ACTONS'));
$data['tableau']=$tabledata;
$this->page='ihm/Intervenants_Rh_List_View';
$this->layout($data);

  }


	public function add_intervenant_view(){
	   $data['title']='Formulaire pour ajouter un Intervenants RH';
	   $data['structure']=$this->Modele->getList('intervenants_structure');
	   $data['profil']=$this->Modele->getList('admin_profil');
	   $this->page='ihm/Intervenants_Rh_Ajouter_View';
	   $this->layout($data);
	}

	public function insert_intervenant(){

        $this->form_validation->set_rules('nom','Nom','required');
        $this->form_validation->set_rules('prenom','Prenom','required');
        $this->form_validation->set_rules('tel','Telephone','required');
        $this->form_validation->set_rules('autre_tel','Telephone','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_rules('profil','Profil','required');
        $this->form_validation->set_rules('structure','Structure','required');

    if ($this->form_validation->run()==FALSE) {

       $data['title']='Formulaire pour ajouter un Intervenants RH';
	   $data['structure']=$this->Modele->getList('intervenants_structure');
	   $data['profil']=$this->Modele->getList('admin_profil');
	   $this->page='ihm/Intervenants_Rh_Ajouter_View';
	   $this->layout($data);

        } else {
        
        $nom=$this->input->post('nom');
		$prenom=$this->input->post('prenom');
		$tel=$this->input->post('tel');
		$autre_tel=$this->input->post('autre_tel');
		$email=$this->input->post('email');
		$profil=$this->input->post('profil');
		$structure=$this->input->post('structure');

		$data=array('NOM'=>$nom,
	                'PRENOM'=>$prenom,
	                'TELEPHONE1'=>$tel,
	                'TELEPHONE2'=>$autre_tel,
	                'EMAIL'=>$email,
	                'INTERVENANT_PROFIL_ID'=>$profil,
	                'INTERVENANT_STRUCTURE_ID'=>$structure
	              );
		$sql=$this->Modele->Add_data('intervenants_rh',$data);
		if ($sql) {
			$sms['sms']='<br><div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Intervenant ajouter avec succes ! .</div><br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/intervenants_rh');
		} else {
			$sms['sms']='<br><div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Une erreur s\'est produit ! .</div><br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/intervenants_rh');
		}


     }
        
  }


   public function delete_intervenant($id){

   	$sql=$this->Modele->deleteData('intervenants_rh',array('INTERVENANT_RH_ID'=>$id));
   	if ($sql) {
			$sms['sms']='<br><div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Intervenant supprimer avec succes ! .</div><br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/intervenants_rh');
		} else {
			$sms['sms']='<br><div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Une erreur s\'est produit ! .</div><br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/intervenants_rh');
		}
   }
    
   public function update_intervenant_view($id){
   	 $data['title']='Formulaire de modification';
	 $data['structure']=$this->Modele->getList('intervenants_structure');
     $data['profil']=$this->Modele->getList('admin_profil');
	 $query="SELECT rh.INTERVENANT_RH_ID,rh.NOM,rh.PRENOM,TELEPHONE1,TELEPHONE2,rh.EMAIL,rh.INTERVENANT_PROFIL_ID,rh.INTERVENANT_STRUCTURE_ID,PROFIL_DESCR,INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh rh JOIN admin_profil p ON rh.INTERVENANT_PROFIL_ID=p.PROFIL_ID JOIN intervenants_structure s ON rh.INTERVENANT_STRUCTURE_ID=s.INTERVENANT_STRUCTURE_ID AND rh.INTERVENANT_RH_ID=$id";
	 $data['records']=$this->Modele->sql_one_query($query);

     $this->page='ihm/Intervenants_Rh_Update_View';
	 $this->layout($data);
   }

   public function update_intervenant($id){
        $this->form_validation->set_rules('nom','Nom','required');
        $this->form_validation->set_rules('prenom','Prenom','required');
        $this->form_validation->set_rules('tel','Telephone','required');
        $this->form_validation->set_rules('autre_tel','Telephone','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_rules('profil','Profil','required');
        $this->form_validation->set_rules('structure','Structure','required');

    if ($this->form_validation->run()==FALSE) {
        // $id=$this->input->post('id') ;
        $id=$this->uri->segment(4);
        $data['title']='Formulaire de modification';
		$data['structure']=$this->Modele->getList('intervenants_structure');
	    $data['profil']=$this->Modele->getList('admin_profil');
		$query="SELECT rh.INTERVENANT_RH_ID,rh.NOM,rh.PRENOM,TELEPHONE1,TELEPHONE2,rh.EMAIL,rh.INTERVENANT_PROFIL_ID,rh.INTERVENANT_STRUCTURE_ID,PROFIL_DESCR,INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh rh JOIN admin_profil p ON rh.INTERVENANT_PROFIL_ID=p.PROFIL_ID JOIN intervenants_structure s ON rh.INTERVENANT_STRUCTURE_ID=s.INTERVENANT_STRUCTURE_ID AND rh.INTERVENANT_RH_ID=$id";
		 $data['records']=$this->Modele->sql_one_query($query);
		 $data['error']='';

	     $this->page='ihm/Intervenants_Rh_Update_View';
		 $this->layout($data);
        }else{	
   	    $nom=$this->input->post('nom');
		$prenom=$this->input->post('prenom');
		$tel=$this->input->post('tel');
		$autre_tel=$this->input->post('autre_tel');
		$email=$this->input->post('email');
		$profil=$this->input->post('profil');
		$structure=$this->input->post('structure');

		$data=array('NOM'=>$nom,
	                'PRENOM'=>$prenom,
	                'TELEPHONE1'=>$tel,
	                'TELEPHONE2'=>$autre_tel,
	                'EMAIL'=>$email,
	                'INTERVENANT_PROFIL_ID'=>$profil,
	                'INTERVENANT_STRUCTURE_ID'=>$structure
	              );
$sql=$this->Modele->updateData('intervenants_rh',$data,array('INTERVENANT_RH_ID'=>$id));
		if ($sql) {
			$sms['sms']='<br><div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Intervenant modifier avec succes ! .</div><br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/intervenants_rh');
		} else {
			$sms['sms']='<br><div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Une erreur s\'est produit ! .</div><br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/intervenants_rh');
		}
     }
   }



}