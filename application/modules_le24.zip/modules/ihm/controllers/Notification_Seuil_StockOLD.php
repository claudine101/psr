
<?php
/**
 * auteur:EMERY
 * date debut:26/02/2021
 * date fin:26/02/2021
 * commentaire:Processus de notification des seuil et des stock
*/
class Notification_Seuil_Stock extends CI_Controller
    {

  // function __construct()
  //    {
  // parent::__construct();
  //    }

  function index()
   {
    $data['error']='';
    $this->listing();

     }
  function notif(){
    $diff_stocke=0;
    $sql = "SELECT st.INTERVENANT_STRUCTURE_ID, su.INTRANT_MEDICAUX_ID AS INTRANT_ID, su.QUANTITE_SEUIL,(itv.QUANTITE-itv.QUANTITE_DISTRIBUTUEE) AS QTY_DISPO FROM stock_intervenat AS itv
            JOIN intrants_medicaux_seuil AS su ON su.INTRANT_MEDICAUX_ID = itv.INTRANT_ID
            JOIN intervenants_structure AS st ON st.TYPE_INTERVENANT_STRUCTURE_ID = su.TYPE_INTERVENANT_STRUCTURE_ID AND st.INTERVENANT_STRUCTURE_ID = itv.INTERVENANT_STRUCTURE_ID
            HAVING (su.QUANTITE_SEUIL * 0.75) <= QTY_DISPO";
      $stocks=$this->Modele->getRequete($sql);

    foreach ($stocks as $key ) {
     //$diff_stocke=$key['QUANTITE']-$key['QUANTITE_DISTRIBUTUEE'];

     // if ($key['QUANTITE_SEUIL']<=$key['QTY_DISPO']) {
         $intervenant=$this->Modele->getOne('intervenants_structure', array('INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID']));
         $intrant=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID']));

         $message = "Cher(e) ".$intervenant['INTERVENANT_STRUCTURE_DESCR']." Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée, la quantité restante est de   ".$key['QTY_DISPO'].".";
         $message_mail = "Cher(e)  <b>".$intervenant['INTERVENANT_STRUCTURE_DESCR']." </b> Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée,<b>la quantité restante est de   ".$key['QTY_DISPO']." </b>";

       

          $table ='notification_seuil_stock';
          $data=array(
              'MESSAGE'=>$message,
              'INTERVENANT_STRUCTURE_ID'=>$key['INTERVENANT_STRUCTURE_ID'],
              'INTRANT_ID'=>$key['INTRANT_ID'],
              'QUANTITE_RESTANT'=>$key['QTY_DISPO']
                );
           $this->Modele->create($table,$data);
          // }
          }

      $diff_stocke_camebu=0;
      $sql1 = "SELECT st.INTERVENANT_STRUCTURE_ID, su.INTRANT_MEDICAUX_ID AS INTRANT_ID, su.QUANTITE_SEUIL,(itv.QUANTITE-itv.QUANTITE_DISTRIBUE) AS QTY_DISPO FROM stock_camebu AS itv
            JOIN intrants_medicaux_seuil AS su ON su.INTRANT_MEDICAUX_ID = itv.INTRANT_ID
            JOIN intervenants_structure AS st ON st.TYPE_INTERVENANT_STRUCTURE_ID = su.TYPE_INTERVENANT_STRUCTURE_ID 
            HAVING (su.QUANTITE_SEUIL * 0.75) <= QTY_DISPO";
      $stocks_camedu=$this->Modele->getRequete($sql);
      print_r($stocks_camedu);
      exit();



    foreach ($stocks_camedu as $key ) {
     //$diff_stocke=$key['QUANTITE']-$key['QUANTITE_DISTRIBUTUEE'];

     // if ($key['QUANTITE_SEUIL']<=$key['QTY_DISPO']) {
         $intervenant=$this->Modele->getOne('intervenants_structure', array('INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID']));
         $intrant=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID']));

         $message = "Cher(e) , Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée, la quantité restante est de   ".$key['QTY_DISPO'].".";
         $message_mail = "Cher(e) CAMEBU  </b> Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée,<b>la quantité restante est de   ".$key['QTY_DISPO']." </b>";

          $table = 'notification_seuil_stock';
          $data=array(
              'MESSAGE'=>$message,
              'INTERVENANT_STRUCTURE_ID'=>$key['INTERVENANT_STRUCTURE_ID'],
              'INTRANT_ID'=>$key['INTRANT_ID'],
              'QUANTITE_RESTANT'=>$key['QTY_DISPO']
                );

          // print_r($data);
          // exit();
           $this->Modele->create($table,$data);
          // }
          }
        }

  
  function listing()
            {
      //$intervenants=$this->Modele->getList('intervenants_structure');
      $sql="SELECT `MESSAGE`,`INTERVENANT_STRUCTURE_ID`,`INTRANT_ID`,`QUANTITE_RESTANT` FROM `notification_seuil_stock`";

       $stock1=$this->Modele->getRequete($sql);
       $data_intervenant=array();
     foreach ($stock1 as $key) {
      $intervenant=$this->Modele->getOne('intervenants_structure', array('INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID']));
      $intrant=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID']));
       $stock_seuil=array();
       $stock_seuil[]=$key['MESSAGE'];
       $stock_seuil[]=$intervenant['INTERVENANT_STRUCTURE_DESCR'];
       $stock_seuil[]=$intrant['INTRANT_MEDICAUX_DESCR'];
       //$stock_seuil[]=$key['QUANTITE_RESTANT'];
        $data_intervenant[]=$stock_seuil;
          }
       $template = array(
            'table_open' => '<table id="mytable" class="table  table-stripped table-hover table-condensed col-sm-12">',
            'table_close' => '</table>'
        );
        $this->table->set_template($template);
        $this->table->set_heading(array('MESSAGE','INTERVENANT','INTRANT'));
        $data['data']=$data_intervenant;
        $data['title'] = "LISTE DES NOTIFICATIONS";
        //$this->make_bread->add('Liste des Cultures', 'CULTURE/listing/', 1);
        // $data['breadcrumb'] = $this->make_bread->output();
        //$this->page = 'ihm/Notification_Seuil_Stock_View';

         // $this->layout($data);
         $this->load->view('Notification_Seuil_Stock_View', $data);

    }


}

?>
