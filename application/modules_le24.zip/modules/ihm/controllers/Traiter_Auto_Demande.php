<?php
/**
 * @author jules_ndihokubwayo@mediabox.bi
 *Traitement des demandes auto creer par le systeme
 */
class Traiter_Auto_Demande extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function index($value='')
	{
		# code...
		$structure=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
		$data=array('title'=>'Demandes Système','INTERVENANT_STRUCTURE_ID'=>$structure);

		$this->load->view('Traiter_Auto_Demande_View',$data);
	}

	public function get_dem_virt($value='')
	{
		# code...
		$html='';
      $sql  = 'SELECT `ID_DEMANDE_SYSTEME`,`QUANTITE`,s.`INTRANT_MEDICAUX_ID`,i.INTRANT_MEDICAUX_DESCR FROM `stock_demade_systeme` s JOIN intrant_medicaux i ON s.`INTRANT_MEDICAUX_ID`=i.INTRANT_MEDICAUX_ID  WHERE STATUT_VALIDATION=0 AND `INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
      $intr=$this->Modele->getRequete($sql);
      $i=1;
      foreach ($intr as $key) {
      	# code...
      	$html.='
      	<tr class="">
          <td>'.$i.'</td>

          <td>'.$key['INTRANT_MEDICAUX_DESCR'].'</td>
          <td><input type="number" id="QUANTITE'.$key['ID_DEMANDE_SYSTEME'].'" min="1" value="'.$key['QUANTITE'].'"></td>';
          if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS" || $this->session->userdata('iccm_PROFIL_CODE')=="CDS") {
          	# code...
          
          $html.='
          <td> <a href="#" onclick="do_demande('.$key['ID_DEMANDE_SYSTEME'].','.$key['INTRANT_MEDICAUX_ID'].')">Demander</a></td>';
         }

        $html.='</tr>';
        $i++;
      }


		echo $html."";
	}
	public function add_demande($value='')
	{
		# code...
	    $QUANTITE=$this->input->post('QUANTITE');
	    $ID_DEMANDE_SYSTEME=$this->input->post('ID_DEMANDE_SYSTEME');
	    $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
	    $mod=$this->Modele->getOne('intrant_medicaux',['INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID]);
	    $mode=$mod['MODE_RECEPTION_ID'];
	    $IS_URGENT=1;
	    $user_id=$this->session->userdata('iccm_USER_ID');
	    $observation="";

	    $demandeur=$this->session->userdata('iccm_INTERVENANT_RH_ID');

	  

	   $structure_id=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
	   $qd=$this->Modele->getOne('stock_intervenat',['INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$structure_id]);
	   $structure=$this->Modele->getOne('type_intervenants_structures',['TYPE_INTERVENANT_STRUCTURE_ID'=>$this->session->userdata('iccm_TYPE_INTERVENANT_STRUCTURE_ID')]);

	    $user_id=$this->session->userdata('iccm_USER_ID');

		$data=array('DEMANDE_CODE'=>0,
	                'IS_URGENT'=>$IS_URGENT,
	                'INTERVENANT_STRUCTURE_ID'=>$structure_id,
	                'MODE_DEMANDE_ID'=>$mode,
	                'USER_DEMANDEUR_ID'=>$demandeur,
	                'CODE_DEMANDE_SENS_ID'=>$structure['SENS_DEMANDE_ID'],
	                'USER_ID'=>$user_id,
	                'USER_APPROUVE_ID'=>$user_id,
	                'OBSERVATION'=>$observation
	              );


		$sql=$this->Modele->insert_last_id('stock_demande',$data);

		if($sql >0){
           $code_demande = "DMD-".$structure['SENS_DEMANDE_ID'].'-'.$sql;
           $this->Modele->update('stock_demande',['DEMANDE_ID'=>$sql],['DEMANDE_CODE'=>$code_demande]) ;

           $cart_contents=array();
           $structure=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');

			//foreach ($this->cart->contents() as $value) {

           $qte_restante=$this->Modele->getRequeteOne("SELECT st.QUANTITE FROM stock_intervenat st WHERE st.INTERVENANT_STRUCTURE_ID=".$structure." AND st.INTRANT_ID=".$INTRANT_MEDICAUX_ID."") ;

		   $cart_contents=array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,
			                    'QUANTITE'=>$QUANTITE,
			                    'DEMANDE_ID'=>$sql,
			                    'QUANTITE_DECLARE'=>$qd['QUANTITE']
			                   );

		   $this->Modele->create('stock_demande_detail',$cart_contents);

		   if ($qte_restante['QUANTITE']>0 && !empty($qte_restante['QUANTITE'])) {
            $QUANTITE_SEUIL=0;
            if ($this->session->userdata('iccm_CODE_STRUCTURE')=="BDS") {
            	# code...
                $QUANTITE_SEUIL=$this->mylibrary->get_valeur_mensuelle($structure,$INTRANT_MEDICAUX_ID);
            }

            if ($this->session->userdata('iccm_CODE_STRUCTURE')=="CDS") {
            	# code...
            	$BDS=$this->mylibrary->getBdsDependance($structure);
            	$QUANTITE_SEUIL=$this->mylibrary->get_valeur_mensuelle_cds($BDS,$INTRANT_MEDICAUX_ID);
            }

		   	if ( $qte_restante['QUANTITE'] >= $QUANTITE_SEUIL) {

	            if ($qte_restante['QUANTITE']>$QUANTITE_SEUIL) {
	            	# code...
	            	$commentaire='Quantité en stock supérieur au seuil de securité' ;
	            }
	            if ($qte_restante['QUANTITE']==$QUANTITE_SEUIL) {
	            	# code...
	            	$commentaire='Quantité en stock égale au seuil de securité' ;
	            }
		   //	$commentaire='Déclaration d\'une quantité différente à celle qui est stockée  ' ;
		   	$incident=array('INTERVENANT_STRUCTURE_ID'=>$structure,'TYPE_INTERVENANT_STRUCTURE_ID'=>$this->session->userdata('iccm_TYPE_INTERVENANT_STRUCTURE_ID'),
			   	            'DEMANDE_ID'=>$sql,
		                    'INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID,
		                    'QUANTITE_DECLARE'=>$qd['QUANTITE'],
		                    'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,
		                    'QUANTITE'=>$QUANTITE,
		                    'QUANTITE_RESTANTE'=>$qte_restante['QUANTITE'],
		                    'OBSERVATION'=>$commentaire
	                );
			   	$this->Modele->create('stock_incident',$incident);
			   }


		   }
		  $this->Modele->update('stock_demade_systeme',['ID_DEMANDE_SYSTEME'=>$ID_DEMANDE_SYSTEME],['STATUT_VALIDATION'=>1,'USER_ID'=>$this->session->userdata('iccm_USER_ID')]) ;

		//}
	}		
		echo "1";
	}
    public function liste($value=0)
    {


		  $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		  $var_search=str_replace("'", "\'", $var_search);
		  $query_principal='SELECT `ID_DEMANDE_SYSTEME`,`QUANTITE`,s.`INTRANT_MEDICAUX_ID`,i.INTRANT_MEDICAUX_DESCR,DATE_INSERTION FROM `stock_demade_systeme` s JOIN intrant_medicaux i ON s.`INTRANT_MEDICAUX_ID`=i.INTRANT_MEDICAUX_ID  WHERE STATUT_VALIDATION=1 AND `INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
          $critaire="";

		  $limit='LIMIT 0,10';
		  if($_POST['length'] != -1){
		    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		  }
		  $order_by='';
		  if($_POST['order']['0']['column']!=0){
		    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY DATE_INSERTION DESC';
		  }

		  $search = !empty($_POST['search']['value']) ? (" AND (DATE_INSERTION LIKE '%$var_search%' OR  INTRANT_MEDICAUX_DESCR LIKE '%$var_search%')") : '';



		  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		  $query_filter=$query_principal.'  '.$critaire.' '.$search;

		  $fetch_enqueteurs = $this->Modele->datatable($query_secondaire);
		  $u=0;
		  $data = array();
		  foreach ($fetch_enqueteurs as $row) {

		   $u++;
		   $sub_array = array();
		   $sub_array[] =  $u;
           $sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
		   $sub_array[]=$row->QUANTITE;
           $sub_array[]=$row->DATE_INSERTION;

		  $data[] = $sub_array;

		}

		$output = array(
		 "draw" => intval($_POST['draw']),
		 "recordsTotal" =>$this->Modele->all_data($query_principal),
		 "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
}
}

?>