<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 28/1/2021
 Date fin :Le 28/1/2021
 Commentaire: controller pour le CRUD des Districts
 */
class Districts extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
        $data['title']='Liste des Districts';
	    $query="SELECT DISTRICT_ID, DISTRICT_CODE, DISTRICT_NOM,dist.LATITUDE,dist.LONGITUDE, dist.PROVINCE_ID,p.PROVINCE_ID, PROVINCE_NOM FROM districts dist JOIN provinces p ON dist.PROVINCE_ID=p.PROVINCE_ID ORDER BY dist.DISTRICT_ID DESC";
 	   $districts=$this->Modele->getRequete($query);

		$tabledata = array();
		foreach ($districts as $district ) {

		$type=array();
		$type[]=$district['DISTRICT_CODE'];
	   	$type[]=$district['DISTRICT_NOM'];
	   	$type[]=$district['LATITUDE'];
	   	$type[]=$district['LONGITUDE'];
	   	$type[]=$district['PROVINCE_NOM'];


$type['OPTIONS'] = '<div class="dropdown">
                       <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
                            <i class="fa fa-cog"></i>
                            Options <span class="caret"></span>
                       </a>
	                   <ul class="dropdown-menu dropdown-menu-left">';
$type['OPTIONS'] .="<li><a href='".base_url('ihm/Districts/update_district_view/').$district['DISTRICT_ID'] ."'><label class='text-info'>Modifier</label></a></li>";
$type['OPTIONS'] .="<li><a href='#' data-toggle='modal' data-target='#mydelete".$district['DISTRICT_ID']."'><label class='text-danger'>Supprimer</label></a></li>";


 $type['OPTIONS'] .= " </ul>
 </div>
 <div class='modal fade' id='mydelete".$district['DISTRICT_ID']."'>
	 <div class='modal-dialog'>
		 <div class='modal-content'>

			 <div class='modal-body'>
				 <center>
					 <h5><strong>VOULEZ-VOUS SUPPRIMER CE DISTRICT </strong> : <b style:'background-color:prink';>
					 <i style='color:green;'>" . $district['DISTRICT_NOM']."</i></b> ?
					 </h5>
				 </center>
			 </div>

			 <div class='modal-footer'>
				 <a class='btn btn-danger btn-md' href='" . base_url('ihm/Districts/delete_district/').$district['DISTRICT_ID'] . "'>Supprimer
				 </a>
				 <button class='btn btn-primary btn-md' data-dismiss='modal'>
				    Quitter
				 </button>
			 </div>

		 </div>
	 </div>
 </div>";


			$tabledata[]=$type;
		}

$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
$this->table->set_template($template);
$this->table->set_heading(array('CODE DU DISTRICT','DISTRICT','LATITUDE','LONGITUDE','PROVINCE','ACTIONS'));
$data['districts']=$tabledata;
$this->page='ihm/Districts_Listing_View';
$this->layout($data);

  }


	public function add_district(){
	   $data['title']='Nouveau District';
	   $data['province']=$this->Modele->getList('provinces');
	   $this->page='ihm/Districts_Add_View';
	   $this->layout($data);
	}

	public function insert_district(){
    $this->form_validation->set_rules('nom', 'Nom', 'trim|required');
    $this->form_validation->set_rules('latitude', 'Latitude', 'trim|required');
    $this->form_validation->set_rules('longitude', 'Longitude', 'trim|required');
    $this->form_validation->set_rules('id_province', 'Province', 'trim|required');

    if ($this->form_validation->run() == FALSE) {
       $data['title']='Formulaire pour les Districts';
	   $data['province']=$this->Modele->getList('provinces');
	   $this->page='ihm/Districts_Add_View';
	   $this->layout($data);
     }else{
		$nom=$this->input->post('nom');
		$latitude=$this->input->post('latitude');
		$longitude=$this->input->post('longitude');
		$province_id=$this->input->post('id_province');

		$data=array('DISTRICT_NOM'=>$nom,
	                'LATITUDE'=>$latitude,
	                'LONGITUDE'=>$longitude,
	                'PROVINCE_ID'=>$province_id
	              );
		$sql=$this->Modele->insert_last_id('districts',$data);

		if($sql >0){
           $code_district = "D-".date('Y').'-'.$sql;
           $this->Modele->update('districts',['DISTRICT_ID'=>$sql],['DISTRICT_CODE'=>$code_district]) ;
           $sms['sms']='<br>
			                <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                      </a><strong> Oup! </strong>
			                      District ajouté avec succès ! .
			                </div>
			             <br>' ;
          }else {
			$sms['sms']='<br>
			               <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong>
			                     Une erreur s\'est produite ! .
			               </div>
			            <br>' ;
        }


            $this->session->set_flashdata($sms) ;
            redirect('ihm/Districts');
       }
	}

   public function delete_district($id){
   	$sql=$this->Modele->delete('districts',array('DISTRICT_ID'=>$id));
   	if ($sql) {
			$sms['sms']='<br>
			                <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                      </a><strong> Oup! </strong>
			                      District supprimé avec succès ! .
			                </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Districts');
		} else {
			$sms['sms']='<br>
			               <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong>
			                     Une erreur s\'est produite ! .
			               </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Districts');
		}
   }

   public function update_district_view($id){
   	 $data['title']='Formulaire de modification';
   	 $data['province']=$this->Modele->getList('provinces');
     $data['district']=$this->Modele->getOne('districts',array('DISTRICT_ID'=>$id));
     $data['id_province']=$this->Modele->getOne('provinces',array('PROVINCE_ID'=>$data['district']['PROVINCE_ID']));
     $this->page='ihm/Districts_Update_View';
	 $this->layout($data);
   }

   public function update_district($id){
    $this->form_validation->set_rules('nom', 'Nom', 'trim|required');
    $this->form_validation->set_rules('latitude', 'Latitude', 'trim|required');
    $this->form_validation->set_rules('longitude', 'Longitude', 'trim|required');
    $this->form_validation->set_rules('id_province', 'Province', 'trim|required');

    if ($this->form_validation->run() == FALSE) {

     $data['title']='Formulaire de modification';
   	 $data['province']=$this->Modele->getList('provinces');
     $data['district']=$this->Modele->getOne('districts',array('DISTRICT_ID'=>$id));
     $data['id_province']=$this->Modele->getOne('provinces',array('PROVINCE_ID'=>$data['district']['PROVINCE_ID']));
     $data['error']='';
     $this->page='ihm/Districts_Update_View';
	 $this->layout($data);
    }else{
		$nom=$this->input->post('nom');
		$latitude=$this->input->post('latitude');
		$longitude=$this->input->post('longitude');
		$province_id=$this->input->post('id_province');

		$data=array('DISTRICT_NOM'=>$nom,
	                'LATITUDE'=>$latitude,
	                'LONGITUDE'=>$longitude,
	                'PROVINCE_ID'=>$province_id
	              );
		$sql=$this->Modele->update('districts',array('DISTRICT_ID'=>$id),$data);
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                      </a><strong> Oup! </strong>
			                      District modifié avec succès ! .
			               </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Districts');
		} else {
			$sms['sms']='<br>
			                <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                      </a><strong> Oup! </strong>
			                      Une erreur s\'est produite ! .
			                </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Districts');
		}

	  }
   }



}
