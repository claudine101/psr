<?php
/**
* @author NSHIMIRIMANA REVERIEN
*/
class Stock_Rupture_Ticket extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['title']="Historique rupture du stock";
		$this->load->view('Stock_Rupture_Ticket_view',$data);

	}

	function getInfo()
	{

        $get_type_stru=$this->Modele->getRequeteOne('SELECT t.CODE_STRUCTURE FROM `intervenants_structure` i JOIN type_intervenants_structures t ON i.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'));

        
		$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		$var_search=str_replace("'", "\'", $var_search);  

		$query_principal="SELECT strt.ID_STOCK_RUPTURE_TICKET,strt.QUANTITE_DISPONIBLE,strt.QUANTITE_SEUIL,strt.ID_STATUT_TICKET,strt.DESCRIPTION_TICKET,intv.INTERVENANT_STRUCTURE_DESCR,intras.INTRANT_MEDICAUX_DESCR,st.DESCRIPTION,DATE_FORMAT(strt.DATE_INSERTION,'%Y-%m-%d') as DATE_INSERTION FROM stock_rupture_ticket strt JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=strt.INTERVENANT_STRUCTURE_ID JOIN intrant_medicaux intras ON intras.INTRANT_MEDICAUX_ID=strt.INTRANT_ID JOIN statut_ticket st ON st.ID_STATUT_TICKET=strt.ID_STATUT_TICKET";


		$group="";
		$critaire="";
          if ($get_type_stru['CODE_STRUCTURE']=="BDS") {
            # code...
            $critaire=" WHERE strt.`INTERVENANT_STRUCTURE_ID` IN ( SELECT bds_cds.CDS_ID FROM bds_cds WHERE bds_cds.BDS_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').") OR strt.`INTERVENANT_STRUCTURE_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')."";
          }
          if ($get_type_stru['CODE_STRUCTURE']=="CDS") {
            # code...
            $critaire=" WHERE strt.`INTERVENANT_STRUCTURE_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
          }

		$limit='LIMIT 0,10';
		if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$order_by='';
		if($_POST['order']['0']['column']!=0){
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY admin_typ.ID DESC';
		}

		$search = !empty($_POST['search']['value']) ? (" AND (strt.QUANTITE_DISPONIBLE LIKE '%$var_search%'  OR strt.QUANTITE_SEUIL LIKE '%$var_search%' OR strt.DESCRIPTION_TICKET LIKE '%$var_search%'  OR intv.INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR intras.INTRANT_MEDICAUX_DESCR LIKE '%$var_search%' OR st.DESCRIPTION LIKE '%$var_search%' OR DATE_FORMAT(strt.DATE_INSERTION,'%Y-%m-%d') LIKE '%$var_search%')") : '';


		$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
		$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

		$fetch_data = $this->Modele->datatable($query_secondaire);
		$u=0;
		$data = array();


		foreach ($fetch_data as $row) {

			$u++;
			$sub_array = array();
			// $sub_array[] =  $u;
			$sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
			$sub_array[]=$row->QUANTITE_DISPONIBLE;
			$sub_array[]=$row->QUANTITE_SEUIL;
			$sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
			$sub_array[]=$row->DESCRIPTION_TICKET;
			$sub_array[]=$row->DESCRIPTION;
			$sub_array[]=$row->DATE_INSERTION;

			
			$opt='<div class="dropdown" style="color:#fff;">
			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
			<i class="fa fa-cog"></i> Options<span class="caret">
			</span></a>
			<ul class="dropdown-menu dropdown-menu-left">';

			if ($row->ID_STATUT_TICKET==1 OR $row->ID_STATUT_TICKET==2) {
				$opt.='<li class="dropdown-item" ><a href="#" onclick="show_traiter('.$row->ID_STOCK_RUPTURE_TICKET.','.$row->ID_STATUT_TICKET.')">Traiter</a></li>';
			}
			$opt.='<li class="dropdown-item"><a href="#" onclick="show_historique('.$row->ID_STOCK_RUPTURE_TICKET.')">Historique</a></li>';
			
			$opt.="</ul>
			</div>";




			$opt.='</ul>';

			$sub_array[]=$opt;


			$data[] = $sub_array;

		}

		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
			"recordsFiltered" => $this->Modele->filtrer($query_filter),
			"data" => $data
		);
		echo json_encode($output);

	}



	public function update_statut($value='')
	{
	# code...
		$ID_STATUT_TICKET=$this->input->post('ID_STATUT_TICKET');
		$ID_STOCK_RUPTURE_TICKET=$this->input->post('ID_STOCK_RUPTURE_TICKET');
		$COMMENTAIRE=$this->input->post('COMMENTAIRE');
		$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET, 'COMMENTAIRE'=>$COMMENTAIRE, 'ID_STATUT_TICKET'=>$ID_STATUT_TICKET,'USER_ID'=>$this->session->userdata('iccm_USER_ID'));
		$this->Modele->update('stock_rupture_ticket',array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET),array('ID_STATUT_TICKET'=>$ID_STATUT_TICKET));
		$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

		echo json_encode(array('status'=>true));

	}


	public function get_statut($value='')
	{
	# code...
		$stat="";
		$ID_STATUT_TICKET=$this->input->post('ID_STATUT_TICKET');
		$statut=$this->Modele->getList('statut_ticket');
		foreach ($statut as $key ) {
		# code...
			if ($key['ID_STATUT_TICKET']==$ID_STATUT_TICKET) {
			# code...
				$stat.="<option value='".$key['ID_STATUT_TICKET']."' selected>".$key['DESCRIPTION']."</option>";
			}else{
				$stat.="<option value='".$key['ID_STATUT_TICKET']."'>".$key['DESCRIPTION']."</option>";
			}

		}
		echo $stat;
	}



	public function get_histo($value='')
	{
	# code...
		$ID_STOCK_RUPTURE_TICKET=$this->input->post('ID_STOCK_RUPTURE_TICKET');

		$table="<table class='table'><tr><th>STATUT</th><th>OBSERVATION</th><th>UTILISATEUR</th><th>DATE</th></tr>";
		$sql  = 'SELECT sth.COMMENTAIRE,sth.DATE_INSERTION,admin.USER_NAME,st.DESCRIPTION FROM stock_rupture_ticket_historique sth JOIN stock_rupture_ticket strt ON strt.ID_STOCK_RUPTURE_TICKET=sth.ID_STOCK_RUPTURE_TICKET JOIN admin_users admin ON admin.USER_ID=sth.USER_ID JOIN statut_ticket st ON st.ID_STATUT_TICKET=sth.ID_STATUT_TICKET  WHERE strt.ID_STOCK_RUPTURE_TICKET='.$ID_STOCK_RUPTURE_TICKET;
		$fetch_histo = $this->Modele->datatable($sql);
		foreach ($fetch_histo as $key ) {
   	# code...
			$table.="<tr><td>".$key->DESCRIPTION."</td><td>".$key->COMMENTAIRE."</td><td>".$key->USER_NAME."</td><td>".$key->DATE_INSERTION."</td></tr>";
		}
		echo $table."</table>";
	}







}