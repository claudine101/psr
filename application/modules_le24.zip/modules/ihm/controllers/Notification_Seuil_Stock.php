
<?php
/**
 * auteur:EMERY
 * date debut:26/02/2021
 * date fin:26/02/2021
 * commentaire:Processus de notification des seuil et des stock
 *Editer par Jules le 16052021 
*/
class Notification_Seuil_Stock extends CI_Controller
    {

  // function __construct()
  //    {
  // parent::__construct();
  //    }

  function listing()
   {

    $data['error']='';
    $data['title'] = "LISTE DES NOTIFICATIONS";

    $this->load->view('Notification_Seuil_Stock_View', $data);

   }
  // function notif(){
  //   $diff_stocke=0;
  //   $sql = "SELECT st.INTERVENANT_STRUCTURE_ID, su.INTRANT_MEDICAUX_ID AS INTRANT_ID, su.QUANTITE_SEUIL,(itv.QUANTITE-itv.QUANTITE_DISTRIBUTUEE) AS QTY_DISPO FROM stock_intervenat AS itv
  //           JOIN intrants_medicaux_seuil AS su ON su.INTRANT_MEDICAUX_ID = itv.INTRANT_ID
  //           JOIN intervenants_structure AS st ON st.TYPE_INTERVENANT_STRUCTURE_ID = su.TYPE_INTERVENANT_STRUCTURE_ID AND st.INTERVENANT_STRUCTURE_ID = itv.INTERVENANT_STRUCTURE_ID
  //           HAVING (su.QUANTITE_SEUIL * 0.75) <= QTY_DISPO";
  //     $stocks=$this->Modele->getRequete($sql);

  //   foreach ($stocks as $key ) {
  //    //$diff_stocke=$key['QUANTITE']-$key['QUANTITE_DISTRIBUTUEE'];

  //    // if ($key['QUANTITE_SEUIL']<=$key['QTY_DISPO']) {
  //        $intervenant=$this->Modele->getOne('intervenants_structure', array('INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID']));
  //        $intrant=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID']));

  //        $message = "Cher(e) ".$intervenant['INTERVENANT_STRUCTURE_DESCR']." Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée, la quantité restante est de   ".$key['QTY_DISPO'].".";
  //        $message_mail = "Cher(e)  <b>".$intervenant['INTERVENANT_STRUCTURE_DESCR']." </b> Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée,<b>la quantité restante est de   ".$key['QTY_DISPO']." </b>";

       

  //         $table ='notification_seuil_stock';
  //         $data=array(
  //             'MESSAGE'=>$message,
  //             'INTERVENANT_STRUCTURE_ID'=>$key['INTERVENANT_STRUCTURE_ID'],
  //             'INTRANT_ID'=>$key['INTRANT_ID'],
  //             'QUANTITE_RESTANT'=>$key['QTY_DISPO']
  //               );
  //          $this->Modele->create($table,$data);
  //         // }
  //         }

  //     $diff_stocke_camebu=0;
  //     $sql1 = "SELECT st.INTERVENANT_STRUCTURE_ID, su.INTRANT_MEDICAUX_ID AS INTRANT_ID, su.QUANTITE_SEUIL,(itv.QUANTITE-itv.QUANTITE_DISTRIBUE) AS QTY_DISPO FROM stock_camebu AS itv
  //           JOIN intrants_medicaux_seuil AS su ON su.INTRANT_MEDICAUX_ID = itv.INTRANT_ID
  //           JOIN intervenants_structure AS st ON st.TYPE_INTERVENANT_STRUCTURE_ID = su.TYPE_INTERVENANT_STRUCTURE_ID 
  //           HAVING (su.QUANTITE_SEUIL * 0.75) <= QTY_DISPO";
  //     $stocks_camedu=$this->Modele->getRequete($sql);
  //     print_r($stocks_camedu);
  //     exit();



  //   foreach ($stocks_camedu as $key ) {
  //    //$diff_stocke=$key['QUANTITE']-$key['QUANTITE_DISTRIBUTUEE'];

  //    // if ($key['QUANTITE_SEUIL']<=$key['QTY_DISPO']) {
  //        $intervenant=$this->Modele->getOne('intervenants_structure', array('INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID']));
  //        $intrant=$this->Modele->getOne('intrant_medicaux', array('INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID']));

  //        $message = "Cher(e) , Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée, la quantité restante est de   ".$key['QTY_DISPO'].".";
  //        $message_mail = "Cher(e) CAMEBU  </b> Votre quantité de  Seuil de l'intrant   ".$intrant['INTRANT_MEDICAUX_DESCR']." [".$key['QUANTITE_SEUIL']."] a été dépassée,<b>la quantité restante est de   ".$key['QTY_DISPO']." </b>";

  //         $table = 'notification_seuil_stock';
  //         $data=array(
  //             'MESSAGE'=>$message,
  //             'INTERVENANT_STRUCTURE_ID'=>$key['INTERVENANT_STRUCTURE_ID'],
  //             'INTRANT_ID'=>$key['INTRANT_ID'],
  //             'QUANTITE_RESTANT'=>$key['QTY_DISPO']
  //               );

  //         // print_r($data);
  //         // exit();
  //          $this->Modele->create($table,$data);
  //         // }
  //         }
  //       }



public function liste($value=0)
 {
          
      $get_type_stru=$this->Modele->getRequeteOne('SELECT t.CODE_STRUCTURE FROM `intervenants_structure` i JOIN type_intervenants_structures t ON i.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'));
      $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
      $var_search=str_replace("'", "\'", $var_search);  
      $query_principal='SELECT `MESSAGE`,i.INTERVENANT_STRUCTURE_DESCR,i.EMAIL,`QUANTITE_RESTANT`,im.INTRANT_MEDICAUX_DESCR,n.DATE_INSERTION FROM `notification_seuil_stock` n JOIN intervenants_structure i ON n.INTERVENANT_STRUCTURE_ID=i.INTERVENANT_STRUCTURE_ID JOIN intrant_medicaux im ON n.INTRANT_ID=im.INTRANT_MEDICAUX_ID';

          $group="";
          $critaire="";

          if ($get_type_stru['CODE_STRUCTURE']=="BDS") {
            # code...
            $critaire=" WHERE n.`INTERVENANT_STRUCTURE_ID` IN ( SELECT bds_cds.CDS_ID FROM bds_cds WHERE bds_cds.BDS_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').") OR n.`INTERVENANT_STRUCTURE_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')."";
          }
          if ($get_type_stru['CODE_STRUCTURE']=="CDS") {
            # code...
            $critaire=" WHERE n.`INTERVENANT_STRUCTURE_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
          }
      $limit='LIMIT 0,10';
      if($_POST['length'] != -1){
        $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
      }
      $order_by='';
      if($_POST['order']['0']['column']!=0){
        $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY DATE_INSERTION DESC';
      }

      $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR INTRANT_MEDICAUX_DESCR LIKE '%$var_search%' OR DATE_INSERTION LIKE '%$var_search%')") : '';


      
      $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
      $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

      $fetch_intrants = $this->Modele->datatable($query_secondaire);
      $u=0;
      $data = array();
  
      foreach ($fetch_intrants as $key) {

      
           $stock_seuil=array();
           $stock_seuil[]=$key->MESSAGE;
           $stock_seuil[]=$key->INTERVENANT_STRUCTURE_DESCR."<br><i>".$key->EMAIL."</i>";
           $stock_seuil[]=$key->INTRANT_MEDICAUX_DESCR;
           $stock_seuil[]=$key->QUANTITE_RESTANT;
           $stock_seuil[]=$key->DATE_INSERTION;
           $data[] = $stock_seuil;

    }
 
    $output = array(
     "draw" => intval($_POST['draw']),
     "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
     "recordsFiltered" => $this->Modele->filtrer($query_filter),
     "data" => $data
    );
    echo json_encode($output);
}
}

?>
