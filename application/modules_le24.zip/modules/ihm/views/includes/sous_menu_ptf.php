<ul class="nav nav-pills">
 <li class="nav-item">
    <a class="<?php echo $menu1 ?> btn-sm" href="<?=base_url('ihm/Ptf/index')?>">PTF</a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu2 ?> btn-sm" href="<?=base_url('ihm/Ptf_Intrant_District/index')?>">Zones d'intervention & Package</a>
  </li>

</ul><br>