<ul class="nav nav-pills">
 <li class="nav-item">
    <a class="<?php echo $menu1 ?> btn-sm" href="<?=base_url('ihm/Intervenant_Structure/index')?>">Intervenants ICCM</a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu2 ?> btn-sm" href="<?=base_url('ihm/Intervenants_rh/index')?>">Intervenants RH</a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu3 ?> btn-sm" href="<?=base_url('ihm/Type_Intervenant_Structure/index')?>">Intervenants Type</a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu4 ?> btn-sm" href="<?=base_url('ihm/Intervenant_Fonction/index')?>">Fonction</a>
  </li>
</ul><br>