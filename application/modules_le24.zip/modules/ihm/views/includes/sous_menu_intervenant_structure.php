<ul class="nav nav-pills">
 <li class="nav-item">
    <a class="<?php echo $menu1 ?> btn-sm" href="<?=base_url('ihm/Intervenant_Structure_bds')?>">BDS</a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu2 ?> btn-sm" href="<?=base_url('ihm/Bds_cds')?>">CDS</a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu3 ?> btn-sm" href="<?=base_url('ihm/Cds_asc')?>">ASC</a>
  </li>
</ul><br>