

<div>
  <legend>
    <?= $title;?>
     <div class="pull-right">
       <a class="btn btn-secondary" href="<?= base_url('ihm/Demande/index')?>">
         <i class="fa fa-list"></i> Liste
       </a>
     </div> 
  </legend>
</div>

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('ihm/Demande/insert_demande')?>" method="post" enctype="multipart/form-data">
       <div class="row">
        <div class="col-md-6">
           <label>Code du Sens :</label>
           <select name="CODE_DEMANDE_SENS_ID" class="form-control">
             <option selected="">--Selectionner le sens--</option>
<?php foreach ($sens_demandes as $sens_demande) {    
   // if ($sens==$sens_demande['CODE_DEMANDE_SENS_ID']) {  ?>
<!--      <option selected value="<?= $sens_demande['CODE_DEMANDE_SENS_ID'];?>">
      <?= $sens_demande['CODE_DEMANDE_SENS_DESCR'];?>
      </option> -->

     <option value="<?= $sens_demande['CODE_DEMANDE_SENS_ID'];?>">
      <?= $sens_demande['CODE_DEMANDE_SENS_DESCR'];?>
      </option>
<?php  }
   
             
  ?>
           </select>
           <label style="color:red;"><?php echo form_error('CODE_DEMANDE_SENS_ID'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Papier de justification :</label>
           <input type="file" class="form-control" name="PATH_JUSTIFICATION" >
           <label style="color:red;"><?php echo form_error('PATH_JUSTIFICATION'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Type Structure :</label>
           <select id="type" name="type" class="form-control">
             <option>--selectionner le type--</option>
<?php foreach ($type_intervenants_structures as $type) {   ?>
             <option value="<?= $type['TYPE_INTERVENANT_STRUCTURE_ID'];?>" <?php echo set_select('type', 'type'); ?>>
               <?= $type['TYPE_INTERVENANT_STRUCTURE_DESCR'];?>
             </option>
<?php }  ?>
           </select>
           <label style="color:red;"><?php echo form_error('type'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Structure Intervenant :</label>
           <select id="structure" name="INTERVENANT_STRUCTURE_ID" class="form-control">
             <option selected="">--selectionner le type d'abord--</option>
           </select>
           <label style="color:red;"><?php echo form_error('INTERVENANT_STRUCTURE_ID'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Demandeur :</label>
           <!-- <input type="hidden" name="dem" id="dem"> -->
           <select id="demandeur" class="form-control" name="USER_DEMANDEUR_ID" >
           	<option selected="">--selectionner la structure d'abord--</option>
           </select>
          <label style="color:red;"><?php echo form_error('USER_DEMANDEUR_ID'); ?></label>
        </div>
        <div class="col-md-6" style="margin-top:20px;">
          <label class="form-control">Justifier ?
             <label style="margin-left:20%;">Oui</label>
             <input type="radio" checked="" value="1" name="IS_JUSTIFIE">
             <label style="margin-left:20%;">Non</label>
             <input type="radio" value="0" name="IS_JUSTIFIE">
          </label>
        </div>
      </div>


    <hr>
      <div class="row">
        <div class="col-md-6">
           <label>Intrant :</label>
           <select id="intrant_medico" name="intrant" class="form-control">
             <option>--selectionner le type--</option>
<?php foreach ($intrants as $intrant) {   ?>
             <option value="<?= $intrant['INTRANT_MEDICAUX_ID'];?>">
               <?= $intrant['INTRANT_MEDICAUX_DESCR'];?>
             </option>
<?php }  ?>
           </select>
           <label id="error" style="color:red;"><?php echo form_error('intrant'); ?></label>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-10">
              <label>Quantite :</label>
              <input type="number" id="quantite" name="quantite" class="form-control">
              <label id="error2" style="color:red;"><?php echo form_error('quantite'); ?></label>
            </div>
            <div class="col-md-2" style="margin-top: 5%;">
              <a href="#" id="add_to_cart" class="btn btn-secondary add_to_cart">+</a>
            </div>
          </div>
        </div>
      </div>

      <div class="row" style="margin-top: 3%;">
       <div class="col-md-12">
         <div id="cart_detail"></div>
       </div>
      </div>

      <div class="row">
        <div class="col-md-6 offset-md-3">
          <input type="submit" class="btn btn-secondary form-control" name="submit" value="Enregistrer">
        </div>
      </div>
    </form>
  </div>
</div>