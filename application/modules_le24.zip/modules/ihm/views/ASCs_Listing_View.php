
<div class="row">
  <center>
    <?php if (!empty($this->session->flashdata('sms'))) {
      echo $this->session->flashdata('sms');
    }?>
  </center>
</div>
<div class="row">
  <legend>
  	<?= $title;?>
  	<div class="pull-right">
  	  <a href="<?= base_url('ihm/ASCs/add_ASC')?>" class="btn btn-primary">
  	  	<i class="fa fa-plus"></i> Ajouter
  	  </a>	
  	</div>
  </legend>
</div>
<div class="row">
  <div class="col-md-12">
  	<?= $this->table->generate($ASCs);?>
  </div>
</div>