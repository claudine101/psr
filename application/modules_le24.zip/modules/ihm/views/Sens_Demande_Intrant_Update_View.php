<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0"><?=$title?></h1>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">


              <span style="margin-right: 15px">

                <a class="btn btn-primary" href="<?= base_url('ihm/Sens_Demande_Intrant/index')?>">
                 <i class="fa fa-list"></i> Liste
               </a>

             </span>

           </div><!-- /.col -->
         </div><!-- /.row -->
       </div><!-- /.container-fluid -->
     </div>
     <!-- /.content-header -->
     <!-- Main content -->
     <section class="content">
      <div class="col-md-12 col-xl-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <form action="<?= base_url('ihm/Sens_Demande_Intrant/update_sens_demande_intrant/').$DESCR['CODE_SENS_ID']?>" method="post">
                  <div class="row">
                    <div class="col-md-10 col-md-push-2">
                      <label for="nom">Description:</label>
                      <input type="text" value="<?= $DESCR['CODE_SENS_DESCR'];?>" class="form-control" name="DESCRIPTION">
                      <label style="color:red;"><?php echo form_error('DESCRIPTION'); ?></label> 
                    </div> 
                    <div class="col-md-2" style="margin-top:31px;">
                      <button type="submit" class="btn btn-primary"><span class="fas fa-save"></span> Modifier</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>          
</div>
</section>


<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>


