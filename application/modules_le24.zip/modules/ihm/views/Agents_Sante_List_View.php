<div class="row">
	<legend>
		<?= $title;?>
		<div class="pull-right" style="padding-bottom:20px;">
			<a href="<?= base_url('ihm/Agents_Sante/ajouterAgent'); ?>" class="btn btn-primary"><i class="fa fa-plus"></i>
				Ajouter
			</a>
		</div>
	</legend>
</div>

<?=  $this->session->flashdata('message');?>
<?= $this->table->generate($data_Agent); ?> 