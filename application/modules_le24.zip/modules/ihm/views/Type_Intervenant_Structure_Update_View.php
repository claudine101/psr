<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Type_Intervenant_Structure/index')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>



      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">
              
              <div class="col-md-12">

                <form name="myform" method="post" class="form-horizontal" action="<?=base_url('ihm/Type_Intervenant_Structure/update'); ?>">

                  <div class="row">
                    <input type="hidden" name="TYPE_INTERVENANT_STRUCTURE_ID" value="<?=$types['TYPE_INTERVENANT_STRUCTURE_ID']?>">
                    <div class="col-md-5 col-md-push-2">
                      <label for="nom">Description:</label>
                      <input type="text" name="TYPE_INTERVENANT_STRUCTURE_DESCR" class="form-control" value="<?=$types['TYPE_INTERVENANT_STRUCTURE_DESCR']?>">
                      <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_DESCR', '<div class="text-danger">', '</div>'); ?> 
                    </div>

                    <div class="col-md-5 col-md-push-2">
                      <label for="nom">Code du structure:</label>
                      <input type="text" name="CODE_STRUCTURE" class="form-control" value="<?=$types['CODE_STRUCTURE']?>">
                      <?php echo form_error('CODE_STRUCTURE', '<div class="text-danger">', '</div>'); ?> 
                    </div>
                    
                    <div class="col-md-2" style="margin-top:31px;">
                      <button type="submit" class="btn btn-primary"><span class="fas fa-edit"></span> Modifier</button>
                      <!-- <input type="submit" name="" class="btn btn-primary" value="mmm"> -->
                    </div>

                  </div>

                  
                </form>

              </div>


              <!--  VOS CODE ICI  -->



            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</body>

<?php include VIEWPATH.'templates/footer.php'; ?>


