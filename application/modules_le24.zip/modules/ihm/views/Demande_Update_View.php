

<div>
  <legend>
    <?= $title;?>
     <div class="pull-right">
       <a class="btn btn-primary" href="<?= base_url('ihm/Demande/index')?>">
         <i class="fa fa-list"></i> Liste
       </a>
     </div> 
  </legend>
</div>

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('ihm/Demande/update_demande/').$demande['DEMANDE_ID']?>" method="post" enctype="multipart/form-data">
       <div class="row">
        <div class="col-md-6">
           <label>Code du Demandeur :</label>
           <input disabled type="text" class="form-control" value="<?= $demande['DEMANDE_CODE'];?>" name="DEMANDE_CODE">
           <label style="color:red;"><?php echo form_error('DEMANDE_CODE'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Papier de justification :</label>
           <input type="file" class="form-control" name="PATH_JUSTIFICATION" >
           <label style="color:red;"><?php echo form_error('PATH_JUSTIFICATION'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Type Structure :</label>
           <select id="type" name="type" class="form-control">
             <option selected="" value="<?= $demande['TYPE_INTERVENANT_STRUCTURE_ID'];?>">
              <?= $demande['TYPE_INTERVENANT_STRUCTURE_DESCR'];?></option>
<?php foreach ($type_intervenants_structures as $type) {   ?>
             <option value="<?= $type['TYPE_INTERVENANT_STRUCTURE_ID'];?>">
               <?= $type['TYPE_INTERVENANT_STRUCTURE_DESCR'];?>
             </option>
<?php }  ?>
           </select>
           <label style="color:red;"><?php echo form_error('type'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Structure Intervenant :</label>
           <select id="structure" name="structure" class="form-control">
             <option selected value="<?= $demande['INTERVENANT_STRUCTURE_ID'];?>">
              <?= $demande['INTERVENANT_STRUCTURE_DESCR'];?>
              </option>
           </select>
           <label style="color:red;"><?php echo form_error('structure'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Demandeur :</label>
           <select id="demandeur" class="form-control" name="USER_DEMANDEUR_ID" >
           	<option selected value="<?= $demande['INTERVENANT_RH_ID'];?>">
              <?= $demande['NOM'].' '.$demande['PRENOM'];?>
              </option>
           </select>
          <label style="color:red;"><?php echo form_error('USER_DEMANDEUR_ID'); ?></label>
        </div>
        <div class="col-md-6" style="margin-top:20px;">
          <label class="form-control">Justifier ?
             <label style="margin-left:20%;">Oui</label>
             <input type="radio" <?= $demande['IS_JUSTIFIE'] == 0 ? '' : 'checked' ?> value="1" name="IS_JUSTIFIE">
             <label style="margin-left:20%;">Non</label>
             <input type="radio" value="0" <?= $demande['IS_JUSTIFIE'] == 0 ? 'checked' : '' ?> name="IS_JUSTIFIE">
          </label>
        </div>
      </div>

          <hr>
      <div class="row">
        <div class="col-md-6">
           <label>Intrant :</label>
           <select id="intrant_medico" name="intrant" class="form-control">
             <option>--selectionner le type--</option>
<?php foreach ($intrants as $intrant) {   ?>
             <option value="<?= $intrant['INTRANT_MEDICAUX_ID'];?>">
               <?= $intrant['INTRANT_MEDICAUX_DESCR'];?>
             </option>
<?php }  ?>
           </select>
           <label id="error" style="color:red;"><?php echo form_error('intrant'); ?></label>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-10">
              <label>Quantite :</label>
              <input type="number" id="quantite" name="quantite" class="form-control">
              <label id="error2" style="color:red;"><?php echo form_error('quantite'); ?></label>
            </div>
            <div class="col-md-2" style="margin-top: 5%;">
              <a href="#" id="add_to_cart" class="btn btn-primary add_to_cart">+</a>
            </div>
          </div>
        </div>
      </div>

      <div class="row" style="margin-top: 3%;">
       <div class="col-md-12">
         <div id="cart_detail"></div>
       </div>
     </div>


      <div class="row">
        <div class="col-md-6 offset-md-3">
          <input type="submit" class="btn btn-primary form-control" name="submit" value="Enregistrer">
        </div>
      </div>
    </form>
  </div>
</div>