<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php' ?>



<style type="text/css">
.mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<!-- Navbar -->
<?php include VIEWPATH.'templates/navbar.php'; ?>

<!-- /.navbar -->

<!-- Main Sidebar Container -->
<?php include VIEWPATH.'templates/sidebar.php'; ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0"><?=$title?></h1>
        </div><!-- /.col -->
        <div class="col-sm-6 text-right">


          <span style="margin-right: 15px">

            <a href="<?= base_url('ihm/Type_Intrants/index')?>" 
             class="btn btn-primary btn-sm pull-right"><i class="fa fa-list"></i>
             Liste
           </a>

         </span>

       </div><!-- /.col -->
     </div><!-- /.row -->
   </div><!-- /.container-fluid -->
 </div>
 <!-- /.content-header -->

 <!-- Main content -->
 <section class="content">




  <div class="col-md-12 col-xl-12 grid-margin stretch-card">

    <div class="card">
      <div class="card-body">



        <div class="row">
          <div class="col-md-12">
            <form action="<?= base_url('ihm/Type_Intrants/update_type_intrant/').$type_intrants['TYPE_INTRANT_ID']?>" method="post">
             <div class="row">
              <div class="col-md-10">
               <label>Description :</label>
               <input type="text" value="<?=$type_intrants['TYPE_INTRANT_DESCR'];?>"  class="form-control" autocomplete='off' name="description">
               <label style="color:red;"><?php echo form_error('description'); ?></label>
             </div>
             <div class="col-md-2" style="margin-top:31px;">
              <button type="submit" class="btn btn-primary"><span class="fas fa-edit"></span> Modifier</button>
            </div>

          </div>
        </form>
      </div>
    </div>




  </div>
</div>
</div>

</div>

<!-- Rapport partie -->



<!-- End Rapport partie -->

</div>
</div>
</div>          
</div>


</section>


<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
