<!DOCTYPE html>
<html lang="en">
 <head>
   <title>iCCM - <?=$title?></title>
     <?php include VIEWPATH.'template/header.php';?>
 </head>
<body>

  <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="<?=base_url()?>">iCCM Projet</a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <input class="form-control form-control-dark w-100" type="text" placeholder="Trombinoscope" aria-label="Search">
    <ul class="navbar-nav px-3">
      <li class="nav-item text-nowrap">
        <a class="nav-link" href="<?= base_url('Login/do_logout')?>">
          <span data-feather="user"></span>
          Déconnection</a>
      </li>
    </ul>
  </nav>

  <div class="container-fluid">
    <div class="row">
        <?php include VIEWPATH.'template/menu_principale.php';?>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
         <!-- <?php if($page){ $this->load->view($page);}   ?> -->

<form id="myform" action="" method="post" >
  

 <div class="row" style="margin-bottom:2%;">
  <div class="col-md-3">
    <label>Justifie</label>
    <select name="is_justifie" class="form-control"  onchange="sub_fx()">
      <option>--Selectionner l'option--</option>
      <option <?php if (set_value('is_justifie')==1): ?>
        selected
      <?php endif ?> value="1">Oui</option>
      <option <?php if (set_value('is_justifie')==0): ?>
        selected
      <?php endif ?> value="0">Non</option>
    </select>
  </div>
  <div class="col-md-3">
    <label>Intrant</label>
    <select id="intrant_medico" name="intrant" class="form-control"  onchange="sub_fx()">
             <option>--selectionner le type--</option>
<?php foreach ($intrants as $intrant) {   ?>
             <option <?php if ($intrant['INTRANT_MEDICAUX_ID']==set_value('intrant')): ?>
               selected
             <?php endif ?> value="<?= $intrant['INTRANT_MEDICAUX_ID'];?>">
               <?= $intrant['INTRANT_MEDICAUX_DESCR'];?>
             </option>
<?php }  ?>
    </select>
  </div>
  <div class="col-md-3">
    <label>PTF</label>
    <select name="ptf" class="form-control"  onchange="sub_fx()">
      <option>--Selectionner l'option--</option>
      <option>PTF1</option>
      <option>PTF2</option>
      <option>PTF3</option>
      <option>PTF4</option>
    </select>
  </div>
  <div class="col-md-3">
    <label>Annee</label>
    <select name="annee" class="form-control" onchange="sub_fx()">
      <option>--Selectionner l'option--</option>
      <option>2018</option>
      <option>2019</option>
      <option>2020</option>
      <option>2021</option>
    </select>
  </div>

</div>
</form>


<div class="row">
  <div class="col-md-12">
    <div id="getTable"></div>
  </div>
</div>


       </main>
     </div>
   </div>
    <!-- jQuery -->
<?php include VIEWPATH.'template/footer.php';?>

</body>

</html>
