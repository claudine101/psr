
<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php' ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-9">
            <h1><?=$title?></h1>
          </div>
          <div class="col-sm-3 float-right">
            <a href="<?= base_url('ihm/Districts/add_district')?>" class="btn btn-outline-primary">
              <i class="fa fa-plus"></i> Ajouter
            </a>
          </div>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content ml-4">
      <div class="row">



<div class="row">
  <center>
    <?php if (!empty($this->session->flashdata('sms'))) {
      echo $this->session->flashdata('sms');
    }?>
  </center>
</div>
<!-- <div class="row">
  <legend>
  	<?= $title;?>
  	<div class="pull-right">
  	  	
  	</div>
  </legend>
</div> -->
<div class="container-fluid">
  <div class="col-md-12">
  	<?= $this->table->generate($districts);?>
  </div>
</div>


</div>
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
  
</html>




<script type="text/javascript">
  $(document).ready(function () {
       $('#mytable').DataTable({
         "processing":true,

    dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
                    language: {
                                "sProcessing":     "Traitement en cours...",
                                "sSearch":         "Rechercher&nbsp;:",
                                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                                "sInfoPostFix":    "",
                                "sLoadingRecords": "Chargement en cours...",
                                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                                "oPaginate": {
                                    "sFirst":      "Premier",
                                    "sPrevious":   "Pr&eacute;c&eacute;dent",
                                    "sNext":       "Suivant",
                                    "sLast":       "Dernier"
                                },
                                "oAria": {
                                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                                }
                        }
            });
            $(".dt-buttons").addClass("pull-left");
            $("#table_Cras_paginate").addClass("pull-right");
            $("#table_Cras_filter").addClass("pull-left");
        });  
</script>