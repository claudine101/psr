<legend><?=$title?></legend>
<form class="" action="<?=base_url()?>" method="post">
  <div class="row">
    <div class="col-md-6">
      <label for="FName">F. Name</label>
      <input type="text" name="fname" value="" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="LName">L. Name</label>
      <input type="text" name="lname" value="" class="form-control">
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <label for="province">Province</label>
      <input type="text" name="name" value="" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="commune">Commune</label>
      <input type="text" name="commune" value="" class="form-control">
    </div>
  </div>

  <div class="row">
    <div class="col-md-4" style="margin-top:15px">
      <input type="submit" value="Enregistrer" class="btn btn-primary">
    </div>
  </div>
</form>
