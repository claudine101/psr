<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <!-- <h4 class="m-0"><?=$title?></h4> -->
              <?php
              $menu1="nav-link";
              $menu2="nav-link active";
              $menu3="nav-link"; 
              VIEWPATH.include('includes/sous_menu_intervenant_structure.php'); ?>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Bds_cds/index')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>



      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">
              
              <div class="col-md-12">

                <form name="myform" method="post" class="form-horizontal" action="<?=base_url('ihm/Bds_cds/modifier'); ?>">

                  <div class="row">
                    <div class="col-md-5 col-md-push-2">
                      <input type="hidden" name="BDS_CDS_ID" value="<?=$bds_cds['BDS_CDS_ID']?>" >
                      <label for="nom">BDS</label>
                      <select class="form-control select2" name="BDS_ID" id="BDS_ID" >
                        
                        <?php foreach ($bds as $key) {
                          if ($key['INTERVENANT_STRUCTURE_ID'] == $bds_cds['BDS_ID']) {
                            echo "<option value='".$key['INTERVENANT_STRUCTURE_ID']."' selected=''>".$key['INTERVENANT_STRUCTURE_DESCR']."</option>'";
                          }else{
                            echo "<option value='".$key['INTERVENANT_STRUCTURE_ID']."' >".$key['INTERVENANT_STRUCTURE_DESCR']."</option>'";
                          }
                        }?>
                      </select>
                      <?php echo form_error('BDS_ID', '<div class="text-danger">', '</div>'); ?> 
                    </div>
                    <div class="col-md-5 col-md-push-2">
                      
                      <label for="nom">CDS</label>
                      <select class="form-control select2" name="CDS_ID" id="CDS_ID" >
                        <?php foreach ($cds as $key) {
                          if ($key['INTERVENANT_STRUCTURE_ID'] ==$bds_cds['CDS_ID']) {
                            echo "<option value='".$key['INTERVENANT_STRUCTURE_ID']."' selected=''>".$key['INTERVENANT_STRUCTURE_DESCR']."</option>'";
                          }else{
                            echo "<option value='".$key['INTERVENANT_STRUCTURE_ID']."' >".$key['INTERVENANT_STRUCTURE_DESCR']."</option>'";
                          }
                        }?>
                      </select>
                      <?php echo form_error('CDS_ID', '<div class="text-danger">', '</div>'); ?> 
                    </div>
                    
                    <div class="col-md-2" style="margin-top:31px;">
                      <button type="submit" class="btn btn-primary"><span class="fas fa-edit"></span> Modifier</button>
                      <!-- <input type="submit" name="" class="btn btn-primary" value="mmm"> -->
                    </div>

                  </div>

                  
                </form>

              </div>


              <!--  VOS CODE ICI  -->



            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</body>

<?php include VIEWPATH.'templates/footer.php'; ?>


