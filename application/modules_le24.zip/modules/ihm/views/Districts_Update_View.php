
<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php' ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-9">
            <h1><?=$title?></h1>
          </div>
          <div class="col-sm-3 float-right">
            <a class="btn btn-primary" href="<?= base_url('ihm/Districts/index')?>">
        <i class="fa fa-list"></i> Liste
      </a>
          </div>
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content ml-4">
      <div class="row">

<!-- <div class="row">
  <legend>
    <?= $title;?>
    <div class="pull-right">
      
    </div>
  </legend>
</div> -->

<div class="col-md-10">
    <form action="<?= base_url('ihm/Districts/update_district/').$district['DISTRICT_ID']?>" method="post">
      <input type="hidden" value="<?=$district['DISTRICT_ID']?>" name="id">
      <div class="row">
        <div class="col-md-6">
           <label>Province :</label>
           <select class="form-control" name="id_province" >
            <option selected="" value="<?= $id_province['PROVINCE_ID'];?>"><?= $id_province['PROVINCE_NOM'];?></option>
<?php foreach ($province as $value) {       ?>
          <option value="<?= $value['PROVINCE_ID'];?>">
            <?= $value['PROVINCE_NOM'];?> 
          </option>
<?php }  ?>
           </select>
           <label style="color:red;"><?php echo form_error('id_province'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Nom du District :</label>
           <input type="text" value="<?= $district['DISTRICT_NOM'];?>" class="form-control"  name="nom" >
           <label style="color:red;"><?php echo form_error('nom'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Latitude du District :</label>
           <input type="text" value="<?= $district['LATITUDE'];?>" class="form-control" name="latitude" >
           <label style="color:red;"><?php echo form_error('latitude'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Longitude du District :</label>
           <input type="text" value="<?= $district['LONGITUDE'];?>" class="form-control" name="longitude" >
           <label style="color:red;"><?php echo form_error('longitude'); ?></label>
        </div>
      </div>

      <!-- <div class="row"> -->
        <div class="col-sm-3 float-right">
          <input type="submit" class="btn btn-primary float-right" name="submit" value="Modifier">
        </div>
      <!-- </div> -->
    </div>
  </form>
</div>