<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Intervenants_rh/index')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>



      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">

              <div class="col-md-12">

                <form action="<?= base_url('ihm/Intervenants_rh/add')?>" method="post">
                 <div class="row">
                  <div class="col-6">
                   <label>Nom </label>
                   <input autofocus="" type="text" autocomplete="off" value="<?= set_value('nom')?>" class="form-control" name="nom" >
                   <?php echo form_error('nom', '<div class="text-danger">', '</div>'); ?> 

                 </div>
                 <div class="col-6">
                   <label>Prénom </label>
                   <input type="text" autocomplete="off" value="<?= set_value('prenom')?>" class="form-control" name="prenom">
                   <?php echo form_error('prenom', '<div class="text-danger">', '</div>'); ?> 

                 </div>
               </div>

               <div class="row">
                  <div class="col-6">
                 <label>Fonction</label>
                 <select class="form-control" name="ID_FONCTION">
                  <option value="" selected="">Sélectionner</option>
                  <?php foreach ($fonction as $value) {     
                    if (set_value('ID_FONCTION')==$value['ID_FONCTION']) { ?>
                      <option selected value="<?= $value['ID_FONCTION'];?>">
                        <?= $value['FONCTION_DESCR'];?> 
                      </option>
                      <?php } else {  ?>
                        <option value="<?= $value['ID_FONCTION'];?>">
                          <?= $value['FONCTION_DESCR'];?> 
                        </option>
                        <?php  }


                      }  ?>
                    </select>
                    <?php echo form_error('ID_FONCTION', '<div class="text-danger">', '</div>'); ?> 

                  </div>
                <div class="col-6">
                 <label>Téléphone</label>
                 <input type="number" autocomplete="off" step="any" value="<?= set_value('tel')?>" class="form-control" name="tel">
                 <?php echo form_error('tel', '<div class="text-danger">', '</div>'); ?> 

               </div>
               </div>
               <div class="row">
               <div class="col-6">
                 <label>Autre téléphone </label>
                 <input type="number" autocomplete="off" step="any" value="<?= set_value('autre_tel')?>" class="form-control" name="autre_tel">
               </div>
             

             
              <div class="col-6">
               <label>Email </label>
               <input type="text" autocomplete="off" value="<?= set_value('email')?>" class="form-control" name="email">
              
               <?php echo form_error('email', '<div class="text-danger">', '</div>'); ?> 

             </div>
             </div>

<!--              <div class="col-6">
               <label>Profil </label>
               <select class="form-control" name="PROFIL_ID">
                <option value="" selected="">--Profile--</option>
                <?php foreach ($profil as $value) {       
                  if (set_value('PROFIL_ID')==$value['PROFIL_ID']) {  ?>
                    <option  value="<?= $value['PROFIL_ID'];?>" selected=''><?= $value['PROFIL_DESCR'];?></option>
                    <?php  } else {  ?>
                      <option value="<?= $value['PROFIL_ID'];?>">
                        <?= $value['PROFIL_DESCR'];?> 
                      </option>
                      <?php  }

                    }  ?>
                  </select>
                 
                  <?php echo form_error('PROFIL_ID', '<div class="text-danger">', '</div>'); ?> 

                </div> -->
<!--               </div>

              <div class="row">
                <div class="col-6" style="display: none;" id="hidden_bps">
                 <label>BPS</label>
                 <select class="form-control select2" name="structure">
                  <option value="" selected="">--Structure--</option>
                  <?php foreach ($structure as $value) {     
                    if (set_value('structure')==$value['INTERVENANT_STRUCTURE_ID']) { ?>
                      <option selected value="<?= $value['INTERVENANT_STRUCTURE_ID'];?>">
                        <?= $value['INTERVENANT_STRUCTURE_DESCR'];?> 
                      </option>
                      <?php } else {  ?>
                        <option value="<?= $value['INTERVENANT_STRUCTURE_ID'];?>">
                          <?= $value['INTERVENANT_STRUCTURE_DESCR'];?> 
                        </option>
                        <?php  }


                      }  ?>
                    </select>
                    <?php echo form_error('structure', '<div class="text-danger">', '</div>'); ?> 

                  </div> -->
<!--                 <div class="col-6">
                 <label>Structure</label>
                 <select class="form-control select2" name="structure">
                  <option value="" selected="">--Structure--</option>
                  <?php foreach ($structure as $value) {     
                    if (set_value('structure')==$value['INTERVENANT_STRUCTURE_ID']) { ?>
                      <option selected value="<?= $value['INTERVENANT_STRUCTURE_ID'];?>">
                        <?= $value['INTERVENANT_STRUCTURE_DESCR'];?> 
                      </option>
                      <?php } else {  ?>
                        <option value="<?= $value['INTERVENANT_STRUCTURE_ID'];?>">
                          <?= $value['INTERVENANT_STRUCTURE_DESCR'];?> 
                        </option>
                        <?php  }


                      }  ?>
                    </select>
                    <?php echo form_error('structure', '<div class="text-danger">', '</div>'); ?> 

                  </div> -->
                <div class="row">
                  <div class="col-6">
                 <label>Sexe</label>
                 <select class="form-control" name="SEXE_ID">
                  <option value="" selected="">Sélectionner</option>
                  <?php foreach ($sex as $value) {     
                    if (set_value('SEXE_ID')==$value['SEXE_ID']) { ?>
                      <option selected value="<?= $value['SEXE_ID'];?>">
                        <?= $value['SEXE_DESCR'];?> 
                      </option>
                      <?php } else {  ?>
                        <option value="<?= $value['SEXE_ID'];?>">
                          <?= $value['SEXE_DESCR'];?> 
                        </option>
                        <?php  }


                      }  ?>
                    </select>
                    <?php echo form_error('SEXE_ID', '<div class="text-danger">', '</div>'); ?> 

                  </div>

                   <div class="col-6">
               <label>Profil </label>
               <select class="form-control" name="PROFIL_ID">
<!--                 <option value="" selected="">--Profile--</option>
 -->                <?php foreach ($profil as $value) {       
                  if ($this->session->userdata('iccm_PROFIL_ID')==$value['PROFIL_ID']) {  ?>
                    <option  value="<?= $value['PROFIL_ID'];?>" selected=''><?= $value['PROFIL_DESCR'];?></option>
                    <?php  } else {  ?>
                      <option value="<?= $value['PROFIL_ID'];?>">
                        <?= $value['PROFIL_DESCR'];?> 
                      </option>
                      <?php  }

                    }  ?>
                  </select>
                 
                  <?php echo form_error('PROFIL_ID', '<div class="text-danger">', '</div>'); ?> 

                </div> 
                </div>

                <div class="row">           
                  <div class="col-md-12" style="margin-top:31px;">
                <button type="submit" style="float: right;" class="btn btn-primary"><span class="fas fa-save"></span> Enregistrer</button>
              </div>
                </div>
              </form>

            </div>


            <!--  VOS CODE ICI  -->



          </div>
        </div>
      </div>
    </section>
  </div>
</div>
</body>

<?php include VIEWPATH.'templates/footer.php'; ?>


