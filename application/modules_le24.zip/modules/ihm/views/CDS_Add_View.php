

<div>
  <legend>
    <?= $title;?>
     <div class="pull-right">
       <a class="btn btn-primary" href="<?= base_url('ihm/CDS/index')?>">
         <i class="fa fa-list"></i> Liste
       </a>
     </div> 
  </legend>
</div>

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('ihm/CDS/insert_CDS')?>" method="post">
       <div class="row">
        <div class="col-md-6">
           <label>Nom CDS :</label>
           <input type="text" value="<?= set_value('cds')?>" class="form-control" name="cds" >
           <label style="color:red;"><?php echo form_error('cds'); ?></label>
        </div>
        <div class="col-md-6">
           <label>District :</label>
           <select class="form-control" name="district" >
            <option value="" selected="">--selectioner--</option>
            <?php foreach ($districts as $value) {      
              if (set_value('district')==$value['DISTRICT_ID']) {  ?>
                <option selected value="<?= $value['DISTRICT_ID'];?>">
                  <?= $value['DISTRICT_NOM'];?> 
                </option>
            <?php  } else {  ?>
                <option value="<?= $value['DISTRICT_ID'];?>">
                  <?= $value['DISTRICT_NOM'];?> 
                </option>
            <?php  }
              
                      
              } ?>
           </select>
          <label style="color:red;"><?php echo form_error('district'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Latitude :</label>
           <input type="text" value="<?= set_value('latitude')?>" class="form-control" name="latitude" >
           <label style="color:red;"><?php echo form_error('latitude'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Longitude :</label>
           <input type="text" value="<?= set_value('longitude')?>" class="form-control" name="longitude" >
           <label style="color:red;"><?php echo form_error('longitude'); ?></label>
        </div>
      </div>
      
      <div class="row">
        <div class="col-md-6 col-md-offset-3" style="margin-top:30px;">
             <input type="submit" class="btn btn-primary form-control" name="submit" value="Enregistrer">
        </div>
      </div>
    </form>
  </div>
</div>