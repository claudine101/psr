<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Intervenant_Structure/index')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">

              <div class="col-md-12">

               <form  name="myform" method="post" class="form-horizontal" action="<?= base_url('ihm/Intervenant_Structure/add'); ?>" >
                <div class="row">
                  <div class="col-md-6">
                    <label for="FName">Structure intervenant</label>
                    <input type="text" name="INTERVENANT_STRUCTURE_DESCR" autocomplete="off" id="INTERVENANT_STRUCTURE_DESCR" value="<?= set_value('INTERVENANT_STRUCTURE_DESCR') ?>"  class="form-control">
                    <?php echo form_error('INTERVENANT_STRUCTURE_DESCR', '<div class="text-danger">', '</div>'); ?> 

                  </div>

                  <div class="col-md-6">
                    <label for="LName">Code Intervenant</label>
                    <input type="text" name="INTERVENANT_STRUCTURE_CODE" autocomplete="off" value="<?=set_value('INTERVENANT_STRUCTURE_CODE') ?>"  id="INTERVENANT_STRUCTURE_CODE" class="form-control">
                    <?php echo form_error('INTERVENANT_STRUCTURE_CODE', '<div class="text-danger">', '</div>'); ?> 

                  </div>
                </div>

                <div class="row">
                  <!-- <div class="col-md-6">
                    <label for="province" >Province:</label>
                    <select class="form-control" data-live-search="true" name="PROVINCE_ID" id="PROVINCE_ID">
                      <option value="">Selectionner</option>
                      <?php 
                      foreach ($type as $key_province) 
                      {
                        if ($key_province['PROVINCE_ID']==set_value('PROVINCE_ID'))
                          {?>

                            <option value="<?= $key_province['PROVINCE_ID'] ?>" selected=''><?= $key_province['PROVINCE_NOM'] ?></option>
                            <?php }
                            ?>
                            <option value="<?= $key_province['PROVINCE_ID'] ?>"><?= $key_province['PROVINCE_NOM'] ?></option>
                            <?php
                          }

                          ?>
                        </select>
                        <?php echo form_error('PROVINCE_ID', '<div class="text-danger">', '</div>'); ?> 

                      </div> -->
                      <div class="col-md-6">
                        <label for="LName">Email</label>
                        <input type="text" autocomplete="off" name="EMAIL" id="EMAIL" value="<?= set_value('EMAIL') ?>" class="form-control">
                        <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?> 

                      </div>

                      <div class="col-md-6">
                        <label for="LName">Téléphone</label>
                        <input type="text" autocomplete="off" name="TELEPHONE" id="TELEPHONE" value="<?= set_value('TELEPHONE') ?>" class="form-control">
                        <?php echo form_error('TELEPHONE', '<div class="text-danger">', '</div>'); ?> 

                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <label for="FName">Latitude</label>
                        <input type="text" autocomplete="off" name="LATITUDE" id="LATITUDE" value="<?= set_value('LATITUDE') ?>" class="form-control">
                        <?php echo form_error('LATITUDE', '<div class="text-danger">', '</div>'); ?> 

                      </div>

                      <div class="col-md-6">
                        <label for="LName">Longitude</label>
                        <input type="text" autocomplete="off" name="LONGITUDE" id="LONGITUDE" value="<?= set_value('LONGITUDE') ?>" class="form-control">
                        <?php echo form_error('LONGITUDE', '<div class="text-danger">', '</div>'); ?> 

                      </div>
                    </div>
                    <div class="row">
                      
                      <div class="col-md-6">
                        <label for="LName">Type d'intervenant</label>
                        <select class="form-control" name="TYPE_INTERVENANT_STRUCTURE_ID" id="TYPE_INTERVENANT_STRUCTURE_ID">
                          <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 
                          <option value="">Selectionner</option>
                          <?php 
                          foreach ($types as $key_type_intervenants) 
                          {
                            if ($key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_ID']==set_value('TYPE_INTERVENANT_STRUCTURE_ID')) 
                              {?>
                                <option value="<?= $key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_ID'] ?>" selected=''><?= $key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_DESCR'] ?></option>
                                <?php } else {?>
                                  <option value="<?= $key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_ID'] ?>"><?= $key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_DESCR'] ?></option>
                                  <?php 
                                }
                              }

                              ?>

                            </select>
                            <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 

                          </div>
                          <div class="col-md-6" style="margin-top:31px;">
                            <button type="submit" style="float: right;" class="btn btn-primary"><span class="fas fa-save"></span> Enregistrer</button>
                            
                          </div>
                        </div>

                        <!-- <div class="row">
                          
                        </div> -->
                      </form>

                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </body>

      <?php include VIEWPATH.'templates/footer.php'; ?>


