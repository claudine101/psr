<div class="row">
  <legend>
    <?= $title;?>
    <a href="<?=base_url('ihm/Distribution_Stock/index')?>" 
      class="btn btn-primary btn-sm pull-right"><i class="fa fa-list"></i>
      Liste
    </a>
  </legend>
  <div class="col-md-12"><?=$this->session->flashdata('sms')?></div>
</div>
<div class="row" style="padding: 5px;">
  <div class="col-md-12">
    <form action="<?=base_url('ihm/Distribution_Stock/add/'.$DEMANDE_ID)?>" method="POST">
      <div class="row">
        <div class="col-md-6">
         <label>Date de distribution :</label>
         <input type="date" class="form-control" name="DISTRIBUTION_DATE">
         <div><?=form_error('DISTRIBUTION_DATE')?></div>
       </div>
       <div class="col-md-6">

         <label>Structures :</label>
         <select class="form-control" id="INTERVENANT_STRUCTURE_ID" onchange="get_intervenant_rh(this.value)" name="INTERVENANT_STRUCTURE_ID">
           <option>--choisir--</option>
           <?php

           foreach ($structures as $value) {
             if ($value['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')) {?>
              <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>" selected=""><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
              <?php } else {?>
                <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>"><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option>
                <?php }

              }?>

            </select>
            <div><?=form_error('INTERVENANT_STRUCTURE_ID')?></div>


          </div>

          <div class="col-md-6">

           <label>Intervenants :</label>
           <select class="form-control" id="INTERVENANT_RH_ID" name="INTERVENANT_RH_ID">
             <option>--choisir--</option>
           </select>
           <div><?=form_error('INTERVENANT_RH_ID')?></div>


         </div>

         <div class="col-md-6">
           <label>Observation :</label>
           <textarea class="form-control" name="COMMENT"><?=set_value('COMMENT')?></textarea>
           <div><?=form_error('COMMENT')?></div>
         </div>


       </div>


       <!--  <div class="row">
          <div class="col-md-12">
           <label>Observation :</label>
           <textarea class="form-control" name="COMMENT"><?=set_value('COMMENT')?></textarea>
           <div><?=form_error('COMMENT')?></div>
         </div>


       </div> -->
       <br><br>
       <?php 
       if ($liste_demande) {?> 
        <fieldset>
          <legend>Liste des intrants demandés</legend>
          <div class="row">
            <div class="col-md-12">
              <table class="table table-bordered table-stripped table-hover table-condensed">
                <thead>
                  <th>#</th>
                  <th>Intrants</th>
                  <th>Quantité demandée</th>
                  <th>Quantité reçue</th>
                  <th>Quantité disponible au stock</th>
                  <!-- <th>Options</th> -->
                </thead>
                <tbody>
                  <?php 
                  $nu=1;
                  foreach ($liste_demande as $value) {?>
                    <tr>
                      <td><?=$nu?></td>
                      <td><?=$value['INTRANT_MEDICAUX_DESCR']?></td>
                      <td><?=$value['QUANTITE']?></td>
                      <td><?=$value['QUANTITE_RECU']?></td>
                      <td><?=$value['qte_disponible']?></td>
                      <!-- <td><a href="#" data-toggle='modal' data-target='#mydelete'><span class="fa fa-edit"></span></a></td> -->
                    </tr>
                    <?php 
                    $nu++;
                  }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </fieldset>

        <div class="row">
          <div class="col-md-12">
            <button type="submit" class="btn btn-primary form-control" style="margin-top: 30px;">
              Valider
            </button>
          </div>
        </div>
        <?php } 
        ?>

        

      </form>

      <div class='modal fade' id='mydelete'>
       <div class='modal-dialog'>
         <div class='modal-content'>

           <div class='modal-body'>
            <form action="#" method="POST">
              <label>Qte livrée</label>
              <input type="number" name="QTE" class="form-control">

              <div class='modal-footer'>
               <input type="submit" class='btn btn-primary btn-md' value="Valider">
               <button style="float:right;" class='btn btn-default btn-md' data-dismiss='modal'>Quitter</button>
             </div>
           </form>

           
         </div>
       </div>
     </div>
   </div>











