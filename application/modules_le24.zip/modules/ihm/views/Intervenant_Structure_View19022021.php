
  
<div class="row">
  <legend>
    <?= $title;?>

    <div class="pull-right">
      <a href="<?= base_url('ihm/Intervenant_structure/listing'); ?>" class="btn btn-primary btn-sm pull-right">
        <i class="fa fa-list"></i>
        Liste
      </a>
    </div>
  </legend>
      
    </div>
               
    <form  name="myform" method="post" class="form-horizontal" action="<?= base_url('ihm/Intervenant_structure/add'); ?>" >
  <div class="row">
    <div class="col-md-6">
      <label for="FName">Intervenant:</label>
      <input type="text" name="INTERVENANT_STRUCTURE_DESCR" id="INTERVENANT_STRUCTURE_DESCR" value="<?= set_value('INTERVENANT_STRUCTURE_DESCR') ?>" class="form-control">
      <?php echo form_error('INTERVENANT_STRUCTURE_DESCR', '<div class="text-danger">', '</div>'); ?> 

    </div>

    <div class="col-md-6">
      <label for="LName">Code Intervenant:</label>
      <input type="text" name="INTERVENANT_STRUCTURE_CODE" value="<?=set_value('INTERVENANT_STRUCTURE_CODE') ?>"  id="INTERVENANT_STRUCTURE_CODE" class="form-control">
      <?php echo form_error('INTERVENANT_STRUCTURE_CODE', '<div class="text-danger">', '</div>'); ?> 

    </div>
  </div>

     <div class="row">
    <div class="col-md-6">
      <label for="province" >Province:</label>
      <select class="form-control" name="PROVINCE_ID" id="PROVINCE_ID"> value="<?=set_value('PROVINCE_ID') ?>">
    <option value="">Selectionner</option>
    <?php 
      foreach ($type as $key_province) 
      {
        # code...
        ?>
        <option value="<?= $key_province['PROVINCE_ID'] ?>"><?= $key_province['PROVINCE_NOM'] ?></option>
        <?php
      }

     ?>
    </select>
      <?php echo form_error('PROVINCE_ID', '<div class="text-danger">', '</div>'); ?> 

    </div>

    <div class="col-md-6">
      <label for="LName">Téléphone:</label>
      <input type="text" name="TELEPHONE" id="TELEPHONE" value="<?= set_value('TELEPHONE') ?>" class="form-control">
      <?php echo form_error('TELEPHONE', '<div class="text-danger">', '</div>'); ?> 

    </div>
  </div>
   <div class="row">
    <div class="col-md-6">
      <label for="FName">Latitude:</label>
      <input type="text" name="LATITUDE" id="LATITUDE" value="<?= set_value('LATITUDE') ?>" class="form-control">
      <?php echo form_error('LATITUDE', '<div class="text-danger">', '</div>'); ?> 

    </div>

    <div class="col-md-6">
      <label for="LName">Longitude:</label>
      <input type="text" name="LONGITUDE" id="LONGITUDE" value="<?= set_value('LONGITUDE') ?>" class="form-control">
      <?php echo form_error('LONGITUDE', '<div class="text-danger">', '</div>'); ?> 

    </div>
  </div>
   <div class="row">
    <div class="col-md-6">
      <label for="LName">Email:</label>
      <input type="email" name="EMAIL" id="EMAIL" value="<?= set_value('EMAIL') ?>" class="form-control">
      <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?> 

    </div>
    <div class="col-md-6">
      <label for="LName">Type d'intervenant:</label>
      <select class="form-control" name="TYPE_INTERVENANT_STRUCTURE_ID" id="TYPE_INTERVENANT_STRUCTURE_ID" value="<?= set_value('TYPE_INTERVENANT_STRUCTURE_ID') ?>">
      <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 

    <option value="">Selectionner</option>
    <?php 
      foreach ($types as $key_type_intervenants) 
      {
        # code...
        ?>
        <option value="<?= $key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_ID'] ?>"><?= $key_type_intervenants['TYPE_INTERVENANT_STRUCTURE_DESCR'] ?></option>
        <?php
      }

     ?>
    </select>
      <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 
    
    </div>
  </div>

  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-6 col-md-push-2">
      <button type="submit" class="btn btn-primary form-control" style="margin-top: 20px;">Enregistrer
      </button>
    </div>
  </div>
</form>


                               
      