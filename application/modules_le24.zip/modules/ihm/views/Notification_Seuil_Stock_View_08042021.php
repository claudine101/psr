
<div class="row">
  <legend>
    <?= $title;?>

   
  </legend>
      
    </div>
    <div class="panel-body">
  
      <div class="card"> 

           <?=  $this->session->flashdata('message');?>
          
             
            <?= $this->table->generate($data); ?> 
                       
                </div>
    </div>

    <div class="panel-footer">
      
    </div>
  </div>
</div>
     
