<legend>
    <?= $title ?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?= base_url('ihm/Provinces/index')?>"><i class="fa fa-list"></i>Retour</a>
    </div>

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('ihm/Provinces/Modifier/').$province['PROVINCE_ID'];?>" method="post" name="myform">
      <div class="row">
        <div class="col-md-6">
           <label>Code:</label>
           <input type="text" value="<?=$province['PROVINCE_CODE'];?>" class="form-control" name="code" >
           <span><font color="red"><?=form_error('code');?></font></span>
        </div>
        <div class="col-md-6">
           <label>Nom:</label>
           <input type="text" value="<?=$province['PROVINCE_NOM'];?>" class="form-control" name="nom" >
           <span><font color="red"><?=form_error('nom');?></font></span>
        </div>
        
        <div class="col-md-6">
           <label>Latitude :</label>
           <input type="text" value="<?=$province['LATITUDE'];?>" class="form-control" name="latitude" >
          <span><font color="red"><?=form_error('latitude');?></font></span>
        </div>
        <div class="col-md-6">
           <label>Longitude :</label>
           <input type="text" value="<?=$province['LONGITUDE'];?>" class="form-control" name="longitude" >
            <span><font color="red"><?=form_error('longitude');?></font></span>
        </div>
      	<div class="col-md-6"> 
      	  <br><input type="submit" class="btn btn-primary form-control" name="submit" value="Modifier">
       	</div>
        </div>
    </form>
  </div>
</div>