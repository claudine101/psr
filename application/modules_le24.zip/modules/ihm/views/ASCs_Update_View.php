

<div>
  <legend>
    <?= $title;?>
     <div class="pull-right">
       <a class="btn btn-primary" href="<?= base_url('ihm/ASCs/index')?>">
         <i class="fa fa-list"></i> Liste
       </a>
     </div> 
  </legend>
</div>

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('ihm/ASCs/update_ASC/').$ASCs['ASC_ID']?>" method="post">
       <div class="row">
        <div class="col-md-6">
           <label>Nom :</label>
           <input type="text" value="<?= $ASCs['ASC_NOM']?>" class="form-control" name="nom" >
           <label style="color:red;"><?php echo form_error('nom'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Prenom :</label>
           <input type="text" value="<?= $ASCs['ASC_PRENOM']?>" class="form-control" name="prenom" >
           <label style="color:red;"><?php echo form_error('prenom'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Télephone :</label>
           <input type="text" value="<?= $ASCs['TELEPHONE1']?>" class="form-control" name="tel1" >
           <label style="color:red;"><?php echo form_error('tel1'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Autre télephone :</label>
           <input type="text" value="<?= $ASCs['TELEPHONE2']?>" class="form-control" name="tel2" >
           <label style="color:red;"><?php echo form_error('tel2'); ?></label>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
           <label>Email :</label>
           <input type="text" value="<?= $ASCs['EMAIL']?>" class="form-control" name="email" >
           <label style="color:red;"><?php echo form_error('email'); ?></label>
        </div>
        <div class="col-md-6">
           <label>CDS :</label>
           <select class="form-control" name="id_cds" >
            <option value="<?=$id_cds['CDS_ID']?>" selected=""><?= $id_cds['CDS_NOM']?></option>
            <?php foreach ($cds as $value) {      
              if (set_value('id_cds')==$value['CDS_ID']) {  ?>
                <option selected value="<?= $value['CDS_ID'];?>">
                  <?= $value['CDS_NOM'];?> 
                </option>
            <?php  } else {  ?>
                <option value="<?= $value['CDS_ID'];?>">
                  <?= $value['CDS_NOM'];?> 
                </option>
            <?php  }
              
                      
              } ?>
           </select>
          <label style="color:red;"><?php echo form_error('id_cds'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6 col-md-offset-3" style="margin-top:30px;">
             <input type="submit" class="btn btn-primary form-control" name="submit" value="Modifier">
        </div>
      </div>
    </form>
  </div>
</div>