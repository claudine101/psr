<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>
<legend>RECEPTION DES INTRANTS</legend>

<div class="container-fluid">
  
  <ul class="nav nav-tabs">
    <li class="active"><a href="#">Réception</a></li>

    <li><a href="#">Intrants</a></li>
    <li><a href="#">Comité de réception</a></li>
  </ul>
  <div class="col-md-12" id="reception">
<form method="post" action="<?= base_url('ihm/Reception')?>"  >    
    <div class="form-group">
      <div class="col-md-6">
        <label>PTF</label>
        <select class="form-control" name="PTF_ID" id="PTF_ID" >
          <option value="" selected="" disabled="">Sélectionner</option>

          <?php foreach ($ptf as $key) {
            # code...
          ?>
          <option value="<?= $key['PTF_ID'] ?>" <?php if ($key['PTF_ID']==set_value('PTF_ID')): ?>
            selected
          <?php endif ?> ><?= $key['PTF_NOM'] ?></option>

          <?php } ?>
        </select>
        
      </div>
      <div class="col-md-6">
        <label>Mode réception</label>
        <select class="form-control" name="MODE_RECEPTION_ID" id="MODE_RECEPTION_ID" onchange="get_structure()" >
          <option value="" selected="" disabled="">Sélectionner</option>
          <?php foreach ($rc_mode_reception as $key) {
            # code...
          ?>
          <option value="<?= $key['MODE_RECEPTION_ID'] ?>" <?php if ($key['MODE_RECEPTION_ID']==set_value('MODE_RECEPTION_ID')): ?>
            selected
          <?php endif ?> ><?= $key['MODE_RECEPTION_DESCR'] ?></option>

          <?php } ?>          
        </select>
        
      </div>      
    </div>
    <div class="form-group">
      <div class="col-md-6">
        <label>Scan de PV de réception</label>
        <input type="file" name="PATH_SCAN_PV_RECEPTION" id="PATH_SCAN_PV_RECEPTION" class="form-control">
      </div>
      <div class="col-md-6">
        <label>Date de réception</label>
        <input type="date" name="RECEPTION_DATE" value="<?= date('Y-m-d') ?>" id="RECEPTION_DATE" class="form-control" max="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>"  >
        
      </div>      
    </div>
    <div class="form-group">
      <div class="col-md-6">
        <label>Commentaire</label>
        <textarea name="COMMENTAIRE" id="COMMENTAIRE" class="form-control"></textarea>
      </div>
      <div class="col-md-6">
        <label>Code réception</label>
        <input type="text" name="RECEPTION_CODE" id="RECEPTION_CODE" class="form-control" readonly="">
        
      </div>      
    </div>
  </form>
  </div>
  <br>
  <div class="col-md-12">

       <input style="float: right;" type="button" id="btn_suivant" value="Suivant" class="btn btn-primary">

    
  </div>
  <!-- tab2 -->
   <div class="col-md-12" id="intrant_medicaux">
    <div class="form-group">
      <div class="col-md-6">
        <label>Intrant</label>
        <select class="form-control selectpicker" name="INTRANT_MEDICAUX_ID" id="INTRANT_MEDICAUX_ID" data-live-search="true">
          <option value="" selected="" disabled="">Sélectionner</option>

          <?php foreach ($intrant_medicaux as $key) {
            # code...
          ?>
          <option value="<?= $key['INTRANT_MEDICAUX_ID'] ?>" <?php if ($key['INTRANT_MEDICAUX_ID']==set_value('INTRANT_MEDICAUX_ID')): ?>
            selected
          <?php endif ?> ><?= $key['INTRANT_MEDICAUX_DESCR'] ?></option>

          <?php } ?>
        </select>
        
      </div>
      <div class="col-md-6">
        <label>Quantité</label>
        <input type="number" name="QUANTITE" id="QUANTITE" step="any" min="0.000000001" class="form-control">
        
      </div>      
    </div>
    <div class="form-group">
      <div class="col-md-6">
        <label>Numero de lot</label>
        <input type="text" name="NUMERO_LOT" id="NUMERO_LOT" class="form-control">
      </div>
      <div class="col-md-5">
        <label>Date de péremption</label>
        <input type="date" name="DATE_PEREMPTION"  id="DATE_PEREMPTION" class="form-control"  min="<?= date('Y-m-d') ?>"  >
        
      </div>

      <div class="col-md-1">
        <label>Ajouter</label>
        <button class="btn" ><i class="fa fa-plus"></i></button>
        
      </div>              
    </div>
  <br>
  <div class="col-md-12" style="padding-top: 5px;">
       <input style="float: left;" type="button" id="btn_precedent" value="Précédent" class="btn btn-primary">
       <input style="float: right;" type="button" id="btn_suivant2" value="Suivant" class="btn btn-primary">

    
  </div>

  </div> 
<!-- tab3 -->
   <div class="col-md-12" id="comite_reception">
    <div class="form-group">
      <div class="col-md-6">
        <label>Strucure</label>
        <select class="form-control selectpicker" name="INTERVENANT_STRUCTURE_ID" id="INTERVENANT_STRUCTURE_ID" onchange="get_structure_rh()" data-live-search="true">
          <option value="" selected="" disabled="">Sélectionner</option>

          <?php foreach ($intervenants_structure as $key) {
            # code...
          ?>
          <option value="<?= $key['INTERVENANT_STRUCTURE_ID'] ?>" <?php if ($key['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')): ?>
            selected
          <?php endif ?> ><?= $key['INTERVENANT_STRUCTURE_DESCR'] ?></option>

          <?php } ?>
        </select>
        
      </div>
      <div class="col-md-6">
        <label>RH</label>
        <select class="form-control selectpicker" name="INTERVENANT_RH_ID" id="INTERVENANT_RH_ID" data-live-search="true" >
          <option value="" selected="" disabled="">Sélectionner</option>


        </select>
        
      </div>      
    </div>
    <div class="form-group">

      <div class="col-md-10">
        <label>Observation</label>
        <textarea name="OBSERVATION" id="OBSERVATION" class="form-control"></textarea>
        
      </div>

      <div class="col-md-1">
        <label>Ajouter</label>
        <button class="btn" ><i class="fa fa-plus"></i></button>
        
      </div>              
    </div>
  <br>
  <div class="col-md-12" style="padding-top: 5px;">
       <input style="float: left;" type="button" id="btn_precedent2" value="Précédent" class="btn btn-primary">
       <input style="float: right;" type="button" id="btn_enregistrer" value="Enregistrer" class="btn btn-primary">

    
  </div>

  </div> 
</div>
<script type="text/javascript">
function get_structure()
{
  var MODE_RECEPTION_ID=$('#MODE_RECEPTION_ID').val();

    $.post('<?php echo base_url();?>ihm/Reception/get_structure/',
  {
    MODE_RECEPTION_ID:MODE_RECEPTION_ID
    
    },
    function(data) 
    { 
    INTERVENANT_STRUCTURE_ID.innerHTML = data; 
    $('#INTERVENANT_STRUCTURE_ID').html(data);

    $('#INTERVENANT_STRUCTURE_ID').selectpicker('refresh');
    }); 
 
}

//find rh en fonction des structure
function get_structure_rh()
{
  var INTERVENANT_STRUCTURE_ID=$('#INTERVENANT_STRUCTURE_ID').val();

    $.post('<?php echo base_url();?>ihm/Reception/get_structure_rh/',
  {
    INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID
    
    },
    function(data) 
    { 
    INTERVENANT_RH_ID.innerHTML = data; 
    $('#INTERVENANT_RH_ID').html(data);

    $('#INTERVENANT_RH_ID').selectpicker('refresh');
    }); 
 
}
</script>