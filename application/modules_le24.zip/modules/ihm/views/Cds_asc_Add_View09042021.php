<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Cds_asc/index')?>" class='btn btn-outline-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>



      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">
              
              <div class="col-md-12">

                
          <form name="myform" method="post" class="form-horizontal" action="<?=base_url('ihm/Cds_asc/ajouter'); ?>">

            <div class="row">
              <div class="col-md-5 col-md-push-2">
                <label for="nom">CDS</label>
                <select class="form-control select2" name="CDS_ID" id="CDS_ID" >
                  <option value="" >-Séléctionner-</option>
                  <?php foreach ($cds as $key) {
                    if ($key['INTERVENANT_STRUCTURE_ID'] == set_value('CDS_ID') ) {
                      echo "<option value='".$key['INTERVENANT_STRUCTURE_ID']."' selected >".$key['INTERVENANT_STRUCTURE_DESCR']."</option>'";
                    }else{
                      echo "<option value='".$key['INTERVENANT_STRUCTURE_ID']."' >".$key['INTERVENANT_STRUCTURE_DESCR']."</option>'";
                    }
                  }?>
                </select>
                <?php echo form_error('CDS_ID', '<div class="text-danger">', '</div>'); ?> 
              </div>
              <div class="col-md-5 col-md-push-2">
                <label for="nom">ASC</label>
                <select class="form-control select2" name="INTERVENANT_RH_ID" id="INTERVENANT_RH_ID" >
                  <option value="" >-Séléctionner-</option>
                  <?php foreach ($asc as $key) {
                    if ($key['INTERVENANT_RH_ID'] == set_value('INTERVENANT_RH_ID') ) {
                      echo "<option value='".$key['INTERVENANT_RH_ID']."' selected >".$key['Nom']."</option>'";
                    }else{
                      echo "<option value='".$key['INTERVENANT_RH_ID']."' >".$key['Nom']."</option>'";
                    }
                  }?>
                </select>
                <?php echo form_error('INTERVENANT_RH_ID', '<div class="text-danger">', '</div>'); ?> 
              </div>

              <div class="col-md-2" style="margin-top:31px;">
                <button type="submit" class="btn btn-outline-primary"><span class="fas fa-save"></span> Enregistrer</button>
              </div>

            
            </div>

            
        </form>

              </div>


              <!--  VOS CODE ICI  -->



            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</body>

<?php include VIEWPATH.'templates/footer.php'; ?>


