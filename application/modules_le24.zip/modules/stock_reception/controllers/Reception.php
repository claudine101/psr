<?php

/**
 * @author jules_ndihokubwayo@mediabox.bi
 *le 10-02-2021
 *ihm de processus de reception des intrants
 */
class Reception extends CI_Controller
{

	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function index($value='')
	{
		# code...
		$this->cart->destroy();
		$ptf=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID` PTF_ID,`INTERVENANT_STRUCTURE_DESCR` PTF_NOM FROM `intervenants_structure` WHERE `TYPE_INTERVENANT_STRUCTURE_ID`=2 OR `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU" ORDER BY PTF_NOM');

		$rc_mode_reception=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` ORDER BY `MODE_RECEPTION_DESCR`');

		$intervenants_structure=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` ORDER BY `INTERVENANT_STRUCTURE_DESCR`');
        $sql  = 'SELECT `ID_FONCTION`,upper(`FONCTION_DESCR`) FONCTION_DESCR FROM `intervenant_fonction` WHERE 1 ORDER BY `FONCTION_DESCR`';
        $intervenant_fonction=$this->Modele->getRequete($sql);
		$intrant_medicaux=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` ORDER BY `INTRANT_MEDICAUX_DESCR`');
		$admin_interv_sexe=$this->Modele->getList('sexe');
		$data =array(
			'ptf'=>$ptf,
			'rc_mode_reception'=>$rc_mode_reception,
			'intervenants_structure'=>$intervenants_structure,
			'intrant_medicaux'=>$intrant_medicaux,
			'title'=>'Réception',
			'admin_interv_sexe'=>$admin_interv_sexe,
			'intervenant_fonction'=>$intervenant_fonction
		);

		$this->load->view('Reception_Add_View',$data);
	}
   //find structure en fonction de mode de reception
	public function get_structure($value='')
	{
		# code...
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
		$SQL='SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID.'  OR `TYPE_INTERVENANT_STRUCTURE_ID` IN ( SELECT type_intervenants_structures.TYPE_INTERVENANT_STRUCTURE_ID FROM type_intervenants_structures WHERE type_intervenants_structures.CODE_STRUCTURE LIKE "MINISANTE") OR `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU" ORDER BY INTERVENANT_STRUCTURE_DESCR';
		$structure=$this->Modele->getRequete($SQL);
		$htm='<option value="" selected="" disabled="">Sélectionner</option>';
		foreach ($structure as $key ) {
			# code...
			$htm.='<option value="'.$key['INTERVENANT_STRUCTURE_ID'].'" >'.$key['INTERVENANT_STRUCTURE_DESCR'].'</option>';
		}


		echo $htm;
	}
	//find rh en fonction des structure
	public function get_structure_rh($value='')
	{
		# code...

		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
		$htm='<option value="" selected="" disabled="">Sélectionner</option><option value="-1">Membre non listé</option>';
		$structure_rh=$this->Modele->getRequete("SELECT `INTERVENANT_RH_ID`,CONCAT(NOM,' ',PRENOM) NAME FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`=".$INTERVENANT_STRUCTURE_ID." ORDER BY NAME");
		foreach ($structure_rh as $key ) {
			# code...
			$htm.='<option value="'.$key['INTERVENANT_RH_ID'].'" >'.$key['NAME'].'</option>';
		}

		echo $htm;
	}
	//find intrant en fonction de ptf
	public function get_intrant_by_mode($value='')
	{
		# code...
		$PTF_ID=$this->input->post('PTF_ID');
		$MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
		$htm='<option value="" selected="" disabled="">Sélectionner</option>';
		$intrant_medicaux=$this->Modele->getRequete('SELECT DISTINCT im.INTRANT_MEDICAUX_ID,im.INTRANT_MEDICAUX_DESCR FROM `ptf_intrant_district` pi JOIN intrant_medicaux im ON pi.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID WHERE pi.`PTF_ID`='.$PTF_ID.' AND `INTRANT_ID` IN (SELECT INTRANT_MEDICAUX_ID FROM intrant_medicaux WHERE MODE_RECEPTION_ID='.$MODE_RECEPTION_ID.' ) ORDER BY im.INTRANT_MEDICAUX_DESCR');
		foreach ($intrant_medicaux as $key ) {
			# code...
			$htm.='<option value="'.$key['INTRANT_MEDICAUX_ID'].'" >'.$key['INTRANT_MEDICAUX_DESCR'].'</option>';
		}

		echo $htm;
	}
	public function add_cart_data_intrant()
	{

		$MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
		$INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
		$QUANTITE=$this->input->post('QUANTITE');
		$PRIX_TOTAL=$this->input->post('PRIX_TOTAL');
		$NUMERO_LOT=$this->input->post('NUMERO_LOT');
		$DATE_PEREMPTION=$this->input->post('DATE_PEREMPTION');
		$intrant_medicaux=$this->Modele->getRequeteOne('SELECT  `INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` WHERE intrant_medicaux.`INTRANT_MEDICAUX_ID`='.$INTRANT_MEDICAUX_ID.'');
		$rc_mode_reception=$this->Modele->getRequeteOne('SELECT  `MODE_RECEPTION_DESCR` FROM `rc_mode_reception` WHERE rc_mode_reception.`MODE_RECEPTION_ID`='.$MODE_RECEPTION_ID.'');
		$data_cart = array(
			'id'      => $NUMERO_LOT.'_'.$INTRANT_MEDICAUX_ID,
			'qty'     => 1,
			'price'   => 1,
			'name'    => 'T',
			'QUANTITE'=>$QUANTITE,
			'INTRANT_MEDICAUX_DESCR'=>$intrant_medicaux['INTRANT_MEDICAUX_DESCR'],
			'PRIX_TOTAL'=>$PRIX_TOTAL,
			'MODE_RECEPTION_ID'=>$MODE_RECEPTION_ID,
			'NUMERO_LOT'=>$NUMERO_LOT,
			'DATE_PEREMPTION'=>$DATE_PEREMPTION,
			'INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID,
			'MODE_RECEPTION_DESCR'=>$rc_mode_reception['MODE_RECEPTION_DESCR'],
			'typecartitem'  =>'INTRANT'
		);
		$this->cart->insert($data_cart);
		$html = null;
		$i = 0;
		$j=1;

		$html .='<table class="table table-bordered table-striped table-hover table-condensed table-sm">
		<tr class="">
		<th style="background:#F5F5F5">#</th>
		<th style="background:#F5F5F5">PROCESSUS</th>
		<th style="background:#F5F5F5">LOT</th>
		<th style="background:#F5F5F5">INTRANT</th>
		<th style="background:#F5F5F5">PEREMPTION</th>
		<th style="background:#F5F5F5">QUANTITE</th>

		<th style="background:#F5F5F5">C.T</th>
		<th style="background:#F5F5F5">SUPPRIMER</th>
		</tr>' ;
		foreach ($this->cart->contents() as $items):


			if(preg_match("/INTRANT/", $items['typecartitem'])){
	   // $som=$som+$items['TOTAL'];
				$html .='<tr class="">' ;
				$html .='<td><font >'.$j.'</font></td>
				<td><font >'.$items['MODE_RECEPTION_DESCR'].'</font></td>
				<td><font >'.$items['NUMERO_LOT'].'</font></td>
				<td style="width: 70px;"><font >'.$items['INTRANT_MEDICAUX_DESCR'].'</font></td>
				<td style="width: 15px;"><font >'.date('d-m-Y',strtotime($items['DATE_PEREMPTION'])).'</font></td>
				<td><font >'.$items['QUANTITE'].'</font></td>
				<td><font >'.$items['PRIX_TOTAL'].'</font></td>

				<td style="width: 5px;">
				<input type="hidden" id="rowid'.$j.'" value='.$items['rowid'].'>
				<button class="btn btn-danger btn-xs" type="button" onclick="remove_ct('.$j.')">
				x
				</button>
				</td>' ;
				$html .='</tr>' ;
				$i++;
				$j++;
			}


		endforeach;

		$html .='</table>' ;

		echo $html;

	}
	public function remove_cart(){

		$rowid = $this->input->post('rowid');
		$this->cart->remove($rowid);
		$html = null;
		$i = 0;
		$j=1;

		$html .='<table class="table table-bordered table-striped table-hover table-condensed table-sm">
		<tr class="">
		<th style="background:#F5F5F5">#</th>
		<th style="background:#F5F5F5">PROCESSUS</th>
		<th style="background:#F5F5F5">LOT</th>
		<th style="background:#F5F5F5">INTRANT</th>
		<th style="background:#F5F5F5">PEREMPTION</th>
		<th style="background:#F5F5F5">QUANTITE</th>

		<th style="background:#F5F5F5">C.T</th>
		<th style="background:#F5F5F5">SUPPRIMER</th>
		</tr>' ;
		foreach ($this->cart->contents() as $items):


			if(preg_match("/INTRANT/", $items['typecartitem'])){
	   // $som=$som+$items['TOTAL'];
				$html .='<tr class="">' ;
				$html .='<td><font >'.$j.'</font></td>
				<td><font >'.$items['MODE_RECEPTION_DESCR'].'</font></td>
				<td><font >'.$items['NUMERO_LOT'].'</font></td>
				<td style="width: 70px;"><font >'.$items['INTRANT_MEDICAUX_DESCR'].'</font></td>
				<td style="width: 15px;"><font >'.date('d-m-Y',strtotime($items['DATE_PEREMPTION'])).'</font></td>
				<td><font >'.$items['QUANTITE'].'</font></td>
				<td><font >'.$items['PRIX_TOTAL'].'</font></td>

				<td style="width: 5px;">
				<input type="hidden" id="rowid'.$j.'" value='.$items['rowid'].'>
				<button class="btn btn-danger btn-xs" type="button" onclick="remove_ct('.$j.')">x</button>
				</td>' ;
				$html .='</tr>' ;
				$i=1;
				$j++;
			}



		endforeach;

		$html .='</table>' ;


		if ($i<1) {
     	# code...
			$html="";
		}
		echo $html;

	}
	public function add_cart_data_rh()
	{
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
		$INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');
		$structure_rh=$this->Modele->getRequeteOne("SELECT `INTERVENANT_RH_ID`,CONCAT(NOM,' ',PRENOM) NAME FROM `intervenants_rh` WHERE `INTERVENANT_RH_ID`=".$INTERVENANT_RH_ID."");

		$intervenants_structure=$this->Modele->getRequeteOne('SELECT  `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE INTERVENANT_STRUCTURE_ID='.$INTERVENANT_STRUCTURE_ID.'');

		$data_cart = array(
			'id'      => $INTERVENANT_STRUCTURE_ID."_".$INTERVENANT_RH_ID,
			'qty'     => 1,
			'price'   => 1,
			'name'    => 'Y',
			'INTERVENANT_STRUCTURE_DESCR'=>$intervenants_structure['INTERVENANT_STRUCTURE_DESCR'],
			'NOM'=>$structure_rh['NAME'],
			'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,
			'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
			'typecartitem'  =>'RH'
		);
		$this->cart->insert($data_cart);
		$html = null;
		$i = 1;
		$j=1;

		$html .='<table class="table table-bordered table-striped table-hover table-condensed table-sm">
		<tr class="">
		<th style="background:#F5F5F5">#</th>
		<th style="background:#F5F5F5">INTERVENANT</th>
		<th style="background:#F5F5F5">MEMBRE</th>
		<th style="background:#F5F5F5">SUPPRIMER</th>
		</tr>' ;
		foreach ($this->cart->contents() as $items):


			if(preg_match("/RH/", $items['typecartitem'])){
	   // $som=$som+$items['TOTAL'];
				$html .='<tr class="">' ;
				$html .='<td><font >'.$j.'</font></td>
				<td><font >'.$items['INTERVENANT_STRUCTURE_DESCR'].'</font></td>
				<td><font >'.$items['NOM'].'</font></td>


				<td>
				<input type="hidden" id="rowid2'.$j.'" value='.$items['rowid'].'>
				<button class="btn btn-danger btn-xs" type="button" onclick="remove_ct_rh('.$j.')">x</button>
				</td>' ;
				$html .='</tr>' ;
				$i++;
				$j++;

			}


		endforeach;

		$html .='</table>' ;

		echo $html;

	}
	public function remove_cart_rh(){

		$rowid = $this->input->post('rowid');
		$this->cart->remove($rowid);
		$html = null;
		$i = 0;
		$j=1;
		$html .='<legend>Commission de réception</legend>';
		$html .='<table class="table table-bordered table-striped table-hover table-condensed table-sm">
		<tr class="">
		<th style="background:#F5F5F5">#</th>
		<th style="background:#F5F5F5">INTERVENANT</th>
		<th style="background:#F5F5F5">MEMBRE</th>
		<th style="background:#F5F5F5">SUPPRIMER</th>
		</tr>' ;
		foreach ($this->cart->contents() as $items):


			if(preg_match("/RH/", $items['typecartitem'])){
	   // $som=$som+$items['TOTAL'];
				$html .='<tr class="">' ;
				$html .='<td><font >'.$j.'</font></td>
				<td><font >'.$items['INTERVENANT_STRUCTURE_DESCR'].'</font></td>
				<td><font >'.$items['NOM'].'</font></td>


				<td>
				<input type="hidden" id="rowid2'.$j.'" value='.$items['rowid'].'>
				<button class="btn btn-danger btn-xs" type="button" onclick="remove_ct_rh('.$j.')">x</button>
				</td>' ;
				$html .='</tr>' ;
				$i=1;
				$j++;
			}



		endforeach;

		$html .='</table>' ;


		if ($i<1) {
     	# code...
			$html="";
		}
		echo $html;

	}
    ///fonction pour ajouter un nouveau rh
	public function add_new_rh($value='')
	{
    	# code...
		$this->form_validation->set_rules('nom','Nom','required');
		$this->form_validation->set_rules('prenom','Prenom','required');
		$this->form_validation->set_rules('tel','Telephone','required');
        //$this->form_validation->set_rules('autre_tel','Telephone','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('interv_sexe','sexe','required');
		$this->form_validation->set_rules('structure','Structure','required');
		$message="";
		if ($this->form_validation->run()==FALSE) {

			$message='<div id="_message" class="alert alert-danger text-center alert-dismissible fade in col-md-12">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			</a>

			Vérifier si l\'adresse email saisie est correcte!
			</div>'."@0";

		} else {

			$nom=$this->input->post('nom');
			$prenom=$this->input->post('prenom');
			$tel=$this->input->post('tel');
			$autre_tel=$this->input->post('autre_tel');
			$email=$this->input->post('email');
			$interv_sexe=$this->input->post('interv_sexe');
			$structure=$this->input->post('structure');
			$fonction=$this->input->post('fonction');


	        $ti=$this->Modele->getRequeteOne('SELECT t.TYPE_INTERVENANT_STRUCTURE_DESCR,CODE_STRUCTURE FROM `intervenants_structure` i JOIN type_intervenants_structures t ON i.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_STRUCTURE_ID`='.$structure);

	        $prof=$this->Modele->getRequeteOne("SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_CODE` LIKE '".$ti['TYPE_INTERVENANT_STRUCTURE_DESCR']."' OR `PROFIL_DESCR` LIKE '".$ti['TYPE_INTERVENANT_STRUCTURE_DESCR']."'");


	        if ($ti['CODE_STRUCTURE']=="MINISANTE") {
	        	# code...CAMEBU 
	        	$int=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));
	        	
	        	$prof=$this->Modele->getRequeteOne("SELECT `PROFIL_ID` FROM `admin_profil` WHERE `PROFIL_CODE` LIKE '".$int['INTERVENANT_STRUCTURE_DESCR']."' OR `PROFIL_DESCR` LIKE '".$int['INTERVENANT_STRUCTURE_DESCR']."'");

	        }
          
            $profil=$prof['PROFIL_ID'];


			$data=array('NOM'=>$nom,
				'PRENOM'=>$prenom,
				'TELEPHONE1'=>$tel,
				'TELEPHONE2'=>$tel,
				'INTERVENANT_RH_CODE'=>$tel,
				'EMAIL'=>$email,
	            'ID_FONCTION'=>$fonction,
				'SEXE_ID'=>$interv_sexe,
				'INTERVENANT_STRUCTURE_ID'=>$structure
			);
			$sql=$this->Modele->insert_last_id('intervenants_rh',$data);
			$INTERVENANT_RH_ID=$sql;
			$user_admin=array('USER_NAME'=>$nom,
				'EMAIL'=>$email,
				'PASSWORD'=>md5($tel),
 				'PROFIL_ID'=>$profil,
				'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID
			);
			$this->Modele->create('admin_users',$user_admin);
			if ($INTERVENANT_RH_ID) {
				$message='<br>
				<div id="_message" class="alert alert-success text-center">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
				</a>

				Intervenant ajouté avec succès ! .
				</div>
				<br>'."@".$sql ;

			} else {
				$message='<br>
				<div id="_message" class="alert alert-danger text-center">
				<a href="#" class="close btn btn-outline-danger btn-sm" data-dismiss="alert" aria-label="close">&times;
				</a>

				Une erreur s\'est produite ! .
				</div>
				<br>' ;

			}


		}
		echo $message;
	}
	public function add($value='')
	{
    	# code...
		$USER_ID=$this->session->userdata('iccm_USER_ID');
		if (empty($USER_ID)) {
    	    # code...
			$USER_ID='-1';
		}
		$RECEPTION_DATE=$this->input->post('RECEPTION_DATE');
		$PTF_ID=$this->input->post('PTF_ID');
		$COMMENTAIRE=$this->input->post('COMMENTAIRE');
		$RECEPTION_CODE='RC'.date('Ymdhis');

		$array_reception = array(
			'RECEPTION_DATE' => $RECEPTION_DATE,
			'RECEPTION_CODE'=>$RECEPTION_CODE,
			'PTF_ID'=>$PTF_ID,
			'COMMENTAIRE'=>$COMMENTAIRE

		);
		$RECEPTION_ID=$this->Modele->insert_last_id('rc_reception',$array_reception);

		$came=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID` FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');
		if (empty($came['INTERVENANT_STRUCTURE_ID'])) {
	       	# code...
	       	$came['INTERVENANT_STRUCTURE_ID']=-1;// pris par hasard du structure CAMEBU
	       }
	       $INTERVENANT_STRUCTURE_ID=$came['INTERVENANT_STRUCTURE_ID'];

	       foreach ($this->cart->contents() as $items):
	       	if(preg_match("/RH/", $items['typecartitem'])){
	       		$array_equipe=array(
	       			'RECEPTION_ID'=>$RECEPTION_ID,
	       			'INTERVENANT_STRUCTURE_ID'=>$items['INTERVENANT_STRUCTURE_ID'],
	       			'INTERVENANT_RH_ID'=>$items['INTERVENANT_RH_ID']);
	       		$this->Modele->create('rc_equipe_reception',$array_equipe);
	       	}
	       	if(preg_match("/INTRANT/", $items['typecartitem'])){
	       		$PRIX_UNITAIRE=$items['PRIX_TOTAL']/$items['QUANTITE'];
	       		$array_data_intrant=array(
	       			'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],
	       			'QUANTITE'=>$items['QUANTITE'],
	       			'QUANTITE_DEJA_STOCKE'=>$items['QUANTITE'],
	       			'PRIX_TOTAL'=>$items['PRIX_TOTAL'],
	       			'PRIX_UNITAIRE'=>$PRIX_UNITAIRE,
	       			'NUMERO_LOT'=>$items['NUMERO_LOT'],
	       			'MODE_RECEPTION_ID'=>$items['MODE_RECEPTION_ID'],
	       			'RECEPTION_ID'=>$RECEPTION_ID,
	       			'DATE_PEREMPTION'=>date('Y-m-d',strtotime($items['DATE_PEREMPTION']))
	       		);


	       		$this->Modele->create('rc_reception_intrant_detail',$array_data_intrant);
		      ####################################STOCK CAMEBU######################################
	       		$quantite_precedent_sock_camebu=$this->Modele->getOne('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID']));

	       		if (empty($quantite_precedent_sock_camebu['INTRANT_ID'])) {
		       	# code...
	       			$quantite_precedent_sock_camebu['QUANTITE']=0;
	       		}


	       		if ((!empty($quantite_precedent_sock_camebu['QUANTITE']) || $quantite_precedent_sock_camebu['QUANTITE']>=0) && !empty($quantite_precedent_sock_camebu['INTRANT_ID']) ) {
			   	# code...
	       			$QUANTITE_STOCK_CAMEBU=$quantite_precedent_sock_camebu['QUANTITE']+$QUANTITE_A_STOCKER;
	       			$this->Modele->update('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID']),array('QUANTITE'=>$QUANTITE_STOCK_CAMEBU,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));

	       		}else{
	       			$stock_camebu=array(
	       				'RECEPTION_CODE'=>$RECEPTION_CODE,
	       				'QUANTITE'=>$items['QUANTITE'],
	       				'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],
	       				'USER_STOCKEUR_ID'=>$USER_ID,
	       				'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),
	       				'DATE_ENTRE_STOCK'=>date('Y-m-d H:i:s'),

	       			);
	       			$this->Modele->create('stock_camebu',$stock_camebu);
	       		}
		    ##################################STOCK ITERVENANT####################################
	       		$quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));
	       		$QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']+$items['QUANTITE'];

	       		if ($quantite_precedent_sock_intervenant['QUANTITE']>=0 && !empty($quantite_precedent_sock_intervenant['INTRANT_ID'])) {
			   	# code...
	       			$this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
	       		}else{
	       			$stock_intervenat=array('INTERVENANT_STRUCTURE_ID' => $INTERVENANT_STRUCTURE_ID,
	       				'INTRANT_ID' => $items['INTRANT_MEDICAUX_ID'],
	       				'QUANTITE' =>$items['QUANTITE'] ,
	       				'DATE_LAST_UPDATE' =>date('Y-m-d H:i:s'),
	       			);
	       			$this->Modele->create('stock_intervenat',$stock_intervenat);
	       		}
			   #####################################################################################
	       	}

	       endforeach;
         $this->pv_reception($RECEPTION_ID);//send pv de reception
         $sms['message']='<br>
         <div id="message" class="alert alert-success text-center">
         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
         </a>
         Opération faite avec succès ! .
         </div>
         <br>' ;
         $this->session->set_flashdata($sms) ;
         redirect(base_url('stock/Stock_Global/index'));

     }
     public function getOne($RECEPTION_ID=1)
     {
		# code...
     	$sql = "SELECT `RECEPTION_ID`,`RECEPTION_DATE`,`COMMENTAIRE`,`PTF_ID`,PATH_SCAN_PV_RECEPTION FROM `rc_reception` WHERE `RECEPTION_ID`=".$RECEPTION_ID;

     	$rc_reception=$this->Modele->getRequeteOne($sql);
     	$ptf=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID` PTF_ID,`INTERVENANT_STRUCTURE_DESCR` PTF_NOM FROM `intervenants_structure` WHERE `TYPE_INTERVENANT_STRUCTURE_ID`=2 OR `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU" ORDER BY PTF_NOM');

     	$rc_mode_reception=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` ORDER BY `MODE_RECEPTION_DESCR`');

     	$intervenants_structure=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` ORDER BY `INTERVENANT_STRUCTURE_DESCR`');

     	$intrant_medicaux=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` ORDER BY `INTRANT_MEDICAUX_DESCR`');
     	$admin_interv_sexe=$this->Modele->getList('sexe');
        $sql  = 'SELECT `ID_FONCTION`,upper(`FONCTION_DESCR`) FONCTION_DESCR FROM `intervenant_fonction` WHERE 1 ORDER BY `FONCTION_DESCR`';
        $intervenant_fonction=$this->Modele->getRequete($sql);
     	$data =array(
     		'ptf'=>$ptf,
     		'rc_mode_reception'=>$rc_mode_reception,
     		'intervenants_structure'=>$intervenants_structure,
     		'intrant_medicaux'=>$intrant_medicaux,
     		'title'=>'Réception',
     		'admin_interv_sexe'=>$admin_interv_sexe,
     		'rc_reception'=>$rc_reception,
     		'intervenant_fonction'=>$intervenant_fonction
     	);
     	$this->load->view('Reception_Update_View',$data);

     }
     public function update($value='')
     {
    	# code...
     	$USER_ID=$this->session->userdata('iccm_USER_ID');
     	if (empty($USER_ID)) {
    	    # code...
     		$USER_ID='-1';
     	}
     	$RECEPTION_DATE=$this->input->post('RECEPTION_DATE');
     	$RECEPTION_ID=$this->input->post('RECEPTION_ID');
     	$PTF_ID=$this->input->post('PTF_ID');
     	$COMMENTAIRE=$this->input->post('COMMENTAIRE');
     	$PATH_SCAN_PV_RECEPTION_OLD=$this->input->post('PATH_SCAN_PV_RECEPTION_OLD');
     	$RECEPTION_CODE='RC'.date('Ymdhis');
     	if (empty($_FILES['PATH_SCAN_PV_RECEPTION']['tmp_name'])) {
          	# code...
     		$PATH_SCAN_PV_RECEPTION=$PATH_SCAN_PV_RECEPTION_OLD;
     	}else{
     		$PATH_SCAN_PV_RECEPTION=$this->upload_document($_FILES['PATH_SCAN_PV_RECEPTION']['tmp_name'],$_FILES['PATH_SCAN_PV_RECEPTION']['name'],$RECEPTION_ID);

          	//send uploaded file
     		$message = "Pv de réception du ".$RECEPTION_DATE." veuillez ouvrir la  pièce jointe";
     		$sql_sm = "SELECT iss.EMAIL FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE RECEPTION_ID =".$RECEPTION_ID;
     		$info_reception_ptf=$this->Modele->getRequeteOne($sql_sm);

			$came=$this->Modele->getRequeteOne('SELECT EMAIL FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');//recuperation email camebu
			$cc_emails[]=$came['EMAIL'];
			$sql_mail_togive_copy = 'SELECT iss.EMAIL FROM `rc_equipe_reception` rer JOIN intervenants_rh iss ON rer.`INTERVENANT_RH_ID`=iss.INTERVENANT_RH_ID WHERE iss.EMAIL IS NOT NULL AND `RECEPTION_ID`='.$RECEPTION_ID;
			$adresse_email=$this->Modele->getRequete($sql_mail_togive_copy);
			foreach ($adresse_email as $key_ml) {
				# code...
				$cc_emails[]=$key_ml['EMAIL'];
			}

			$EMAIL= $info_reception_ptf['EMAIL'];
			$file_to_attach[]='http://51.83.236.148/iccm_un_v1/'.$PATH_SCAN_PV_RECEPTION;
		   // print_r($file_to_attach);die();
			$this->notifications->send_mail($EMAIL,'PV de réception  du '.$RECEPTION_DATE.'',$cc_emails,$message,$file_to_attach);
		}

		$array_reception = array(
			//'RECEPTION_DATE' => $RECEPTION_DATE,
			//'RECEPTION_CODE'=>$RECEPTION_CODE,
			//'PTF_ID'=>$PTF_ID,
			//'COMMENTAIRE'=>$COMMENTAIRE,
			'PATH_SCAN_PV_RECEPTION'=>$PATH_SCAN_PV_RECEPTION

		);


       

		$this->Modele->update('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID),$array_reception);

	##je commente tout ca car on modifie seulement le pv de reception

		/*$this->Modele->delete('rc_equipe_reception',array('RECEPTION_ID'=>$RECEPTION_ID));
		$this->Modele->delete('rc_reception_intrant_detail',array('RECEPTION_ID'=>$RECEPTION_ID));
		$came=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID` FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');
		if (empty($came['INTERVENANT_STRUCTURE_ID'])) {
	       	# code...
	       	$came['INTERVENANT_STRUCTURE_ID']=-1;// pris par hasard du structure CAMEBU
	       }
	       $INTERVENANT_STRUCTURE_ID=$came['INTERVENANT_STRUCTURE_ID'];
	       foreach ($this->cart->contents() as $items):
	       	if(preg_match("/RH/", $items['typecartitem'])){
	       		$array_equipe=array(
	       			'RECEPTION_ID'=>$RECEPTION_ID,
	       			'INTERVENANT_STRUCTURE_ID'=>$items['INTERVENANT_STRUCTURE_ID'],
	       			'INTERVENANT_RH_ID'=>$items['INTERVENANT_RH_ID']);
	       		$this->Modele->create('rc_equipe_reception',$array_equipe);
	       	}
	       	if(preg_match("/INTRANT/", $items['typecartitem'])){
	       		$PRIX_UNITAIRE=$items['PRIX_TOTAL']/$items['QUANTITE'];
	       		$array_data_intrant=array(
	       			'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],
	       			'QUANTITE'=>$items['QUANTITE'],
	       			'QUANTITE_DEJA_STOCKE'=>$items['QUANTITE'],
	       			'PRIX_TOTAL'=>$items['PRIX_TOTAL'],
	       			'PRIX_UNITAIRE'=>$PRIX_UNITAIRE,
	       			'NUMERO_LOT'=>$items['NUMERO_LOT'],
	       			'MODE_RECEPTION_ID'=>$items['MODE_RECEPTION_ID'],
	       			'RECEPTION_ID'=>$RECEPTION_ID,
	       			'DATE_PEREMPTION'=>date('Y-m-d',strtotime($items['DATE_PEREMPTION']))
	       		);


	       		$this->Modele->create('rc_reception_intrant_detail',$array_data_intrant);
		      ####################################STOCK CAMEBU######################################
	       		$quantite_precedent_sock_camebu=$this->Modele->getOne('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID']));

	       		if (empty($quantite_precedent_sock_camebu['INTRANT_ID'])) {
		       	# code...
	       			$quantite_precedent_sock_camebu['QUANTITE']=0;
	       		}


	       		if ((!empty($quantite_precedent_sock_camebu['QUANTITE']) || $quantite_precedent_sock_camebu['QUANTITE']>=0) && !empty($quantite_precedent_sock_camebu['INTRANT_ID']) ) {
			   	# code...
	       			$QUANTITE_STOCK_CAMEBU=$quantite_precedent_sock_camebu['QUANTITE']+$items['QUANTITE'];
	       			$this->Modele->update('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID']),array('QUANTITE'=>$QUANTITE_STOCK_CAMEBU,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));

	       		}else{
	       			$stock_camebu=array(
	       				'RECEPTION_CODE'=>$RECEPTION_CODE,
	       				'QUANTITE'=>$items['QUANTITE'],
	       				'INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],
	       				'USER_STOCKEUR_ID'=>$USER_ID,
	       				'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),
	       				'DATE_ENTRE_STOCK'=>date('Y-m-d H:i:s'),

	       			);
	       			$this->Modele->create('stock_camebu',$stock_camebu);
	       		}
		    ##################################STOCK ITERVENANT####################################
	       		$quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));
	       		$QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']+$items['QUANTITE'];

	       		if ($quantite_precedent_sock_intervenant['QUANTITE']>=0 && !empty($quantite_precedent_sock_intervenant['INTRANT_ID'])) {
			   	# code...
	       			$this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$items['INTRANT_MEDICAUX_ID'],'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
	       		}else{
	       			$stock_intervenat=array('INTERVENANT_STRUCTURE_ID' => $INTERVENANT_STRUCTURE_ID,
	       				'INTRANT_ID' => $items['INTRANT_MEDICAUX_ID'],
	       				'QUANTITE' =>$items['QUANTITE'] ,
	       				'DATE_LAST_UPDATE' =>date('Y-m-d H:i:s'),
	       			);
	       			$this->Modele->create('stock_intervenat',$stock_intervenat);
	       		}
			   #####################################################################################
	       	}

	       endforeach;

*/

         // $this->pv_reception($RECEPTION_ID);//send pv de reception
	       $sms['message']='<br>
	       <div id="message" class="alert alert-success text-center">
	       <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
	       </a>
	       Opération faite avec succès ! .
	       </div>
	       <br>' ;
	       $this->session->set_flashdata($sms) ;
	       redirect(base_url('stock_reception/Reception/listing'));

	   }
	   public function listing($value='')
	   {
		# code...
	   	$ptf=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID` PTF_ID,`INTERVENANT_STRUCTURE_DESCR` PTF_NOM FROM `intervenants_structure` WHERE `TYPE_INTERVENANT_STRUCTURE_ID`=2 OR `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU" ORDER BY PTF_NOM');
	   	$data=array('ptf'=>$ptf,'title'=>'Réception',);
	   	$this->load->view('Reception_List_View',$data);

	   }
	   public function liste($value=0)
	   {

	   	$PTF_ID=$this->input->post('PTF_ID');

	   	$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
	   	$var_search=str_replace("'", "\'", $var_search);
	   	$query_principal='SELECT `RECEPTION_ID`,`RECEPTION_CODE`,`RECEPTION_DATE`,PATH_PDF,PATH_SCAN_PV_RECEPTION,`COMMENTAIRE`,ins.INTERVENANT_STRUCTURE_DESCR,(SELECT COUNT(*) FROM `rc_reception_intrant_detail` WHERE `RECEPTION_ID`=rr.`RECEPTION_ID`) nbr_intrant,(SELECT COUNT(*) FROM `rc_equipe_reception` WHERE `RECEPTION_ID`=rr.`RECEPTION_ID`) nbre_com FROM `rc_reception` rr JOIN intervenants_structure ins ON rr.`PTF_ID`=ins.INTERVENANT_STRUCTURE_ID';
	   	$critaire="";
	   	if (!empty($PTF_ID)) {
          	# code...
	   		$critaire=" WHERE rr.PTF_ID=".$PTF_ID;
	   	}
	   	$limit='LIMIT 0,10';
	   	if($_POST['length'] != -1){
	   		$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
	   	}
	   	$order_by='';
	   	if($_POST['order']['0']['column']!=0){
	   		$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY RECEPTION_CODE DESC';
	   	}

	   	$search = !empty($_POST['search']['value']) ? (" AND (RECEPTION_CODE LIKE '%$var_search%' OR  INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';



	   	$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
	   	$query_filter=$query_principal.'  '.$critaire.' '.$search;

	   	$fetch_enqueteurs = $this->Modele->datatable($query_secondaire);
	   	$u=0;
	   	$data = array();
	   	foreach ($fetch_enqueteurs as $row) {

	   		$u++;
	   		$sub_array = array();
	   		$sub_array[] =  $u;
	   		//$sub_array[]=$row->RECEPTION_CODE;
	   		$sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
	   		$sub_array[]=$row->RECEPTION_DATE;

	   		$sub_array[]='<center><a href="javascript:;" onclick="show_intrant('.$row->RECEPTION_ID.');show_titre('.$row->RECEPTION_ID.')" class="btn btn-info btn-sm">'.$row->nbr_intrant.'</a></center>';

	   		$sub_array[]='<center><a href="javascript:;" onclick="show_comite('.$row->RECEPTION_ID.')" class="btn btn-info btn-sm">'.$row->nbre_com.'</a></center>';


	   		$opt='<div class="dropdown" style="color:#fff;">
	   		<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
	   		<i class="fa fa-cog"></i> Options<span class="caret">
	   		</span></a>
	   		<ul class="dropdown-menu dropdown-menu-left">';

	   		$opt.='<li class="dropdown-item" ><a href="'.base_url('stock_reception/Reception/getOne/'.$row->RECEPTION_ID).'">Modifier</a></li>';
            //$opt.='<li><a href="#" onclick="show_historique('.$row->RECEPTION_ID.')">Modifier</a></li>';
	   		$opt.='<li class="dropdown-item"><a href="'.base_url('stock_reception/PV_Reception/index/'.$row->RECEPTION_ID).'" tagert="blanck">Pv de réception</a></li>';
	   		$opt.='</ul>';
	   		$sub_array[]=$row->COMMENTAIRE;
          // $PATH_PDF=$row->PATH_PDF;
          // if (!empty($PATH_PDF)) {
          // 	# code...
          // 	$sub_array[]='<a href="'.base_url($PATH_PDF).'" target="blanck" class="fa fa-eye"></a>';
          // }else{
          // 	$sub_array[]="";
          // }


	   		$sub_array[]=$opt;
	   		$data[] = $sub_array;

	   	}

	   	$output = array(
	   		"draw" => intval($_POST['draw']),
	   		"recordsTotal" =>$this->Modele->all_data($query_principal),
	   		"recordsFiltered" => $this->Modele->filtrer($query_filter),
	   		"data" => $data
	   	);
	   	echo json_encode($output);
	   }
	   public function liste_intervenant($value=0)
	   {

	   	$PTF_ID=$this->input->post('PTF_ID');

	   	$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
	   	$var_search=str_replace("'", "\'", $var_search);
	   	$query_principal='SELECT SUM(`QUANTITE`) QUANTITE_RECU,SUM(`QUANTITE_DISTRIBUTUEE`) QUANTITE_DIST,im.INTRANT_MEDICAUX_DESCR FROM `rc_reception_intrant_detail` ri JOIN rc_reception rc ON ri.`RECEPTION_ID`=rc.RECEPTION_ID JOIN intrant_medicaux im ON ri.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID';
	   	$group="GROUP BY INTRANT_MEDICAUX_DESCR";
	   	$critaire="";
	   	if (!empty($PTF_ID)) {
          	# code...
	   		$critaire=" WHERE rc.PTF_ID=".$PTF_ID;
	   	}
	   	$limit='LIMIT 0,10';
	   	if($_POST['length'] != -1){
	   		$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
	   	}
	   	$order_by='';
	   	if($_POST['order']['0']['column']!=0){
	   		$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTRANT_MEDICAUX_DESCR DESC';
	   	}

	   	$search = !empty($_POST['search']['value']) ? (" AND (INTRANT_MEDICAUX_DESCR LIKE '%$var_search%' OR  QUANTITE LIKE '%$var_search%' OR  QUANTITE_DISTRIBUTUEE LIKE '%$var_search%')") : '';



	   	$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
	   	$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

	   	$fetch_enqueteurs = $this->Modele->datatable($query_secondaire);
	   	$u=0;
	   	$data = array();
	   	foreach ($fetch_enqueteurs as $row) {

	   		$u++;
	   		$sub_array = array();
	   		$sub_array[] =  $u;
	   		$sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
	   		$sub_array[]=number_format($row->QUANTITE_RECU,0,' ',' ');
	   		$sub_array[]=number_format($row->QUANTITE_RECU-$row->QUANTITE_DIST,0,' ',' ');



	   		$data[] = $sub_array;

	   	}

	   	$output = array(
	   		"draw" => intval($_POST['draw']),
	   		"recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
	   		"recordsFiltered" => $this->Modele->filtrer($query_filter),
	   		"data" => $data
	   	);
	   	echo json_encode($output);
	   }
	   public function get_comite($value='')
	   {
	# code...
	   	$RECEPTION_ID=$this->input->post('RECEPTION_ID');
	   	$html = null;
	   	$i = 1;
	   	$j=1;
	   	$html .='<table id="TableComiteId" class="table table-bordered table-striped table-hover table-condensed ">
	   	<thead>
	   	<tr class="">
	   	<th style="background:#F5F5F5">#</th>
	   	<th style="background:#F5F5F5">INTERVENANT</th>
	   	<th style="background:#F5F5F5">MEMBRE</th>
	   	</tr>
	   	</thead>
	   	<tbody>' ;
	   	$sql = "SELECT ins.INTERVENANT_STRUCTURE_DESCR,concat(ir.NOM,\" \",ir.PRENOM) NOM FROM `rc_equipe_reception` rer JOIN intervenants_structure ins ON rer.`INTERVENANT_STRUCTURE_ID`=ins.INTERVENANT_STRUCTURE_ID JOIN intervenants_rh ir ON rer.`INTERVENANT_RH_ID`=ir.INTERVENANT_RH_ID WHERE `RECEPTION_ID`=".$RECEPTION_ID;
	   	$interevenant=$this->Modele->getRequete($sql);
	   	foreach ($interevenant as $items):



	   // $som=$som+$items['TOTAL'];
	   		$html .='<tr class="">' ;
	   		$html .='<td><font >'.$j.'</font></td>
	   		<td><font >'.$items['INTERVENANT_STRUCTURE_DESCR'].'</font></td>
	   		<td><font >'.$items['NOM'].'</font></td>';

	   		$html .='</tr>' ;
	   		$i++;
	   		$j++;




	   	endforeach;

	   	$html .='</tbody></table>' ;

	   	echo json_encode(array('datas'=>$html));
	   }
	   public function get_intrant($value='')
	   {

	   	$RECEPTION_ID=$this->input->post('RECEPTION_ID');
	   	$html = null;
	   	$i = 0;
	   	$j=1;
	   	$html .='<table id="TableReceptionId" class="table table-bordered table-striped table-hover table-condensed ">
	   	<thead>
	   	<tr class="">
	   	<th style="background:#F5F5F5">#</th>
	   	<th style="background:#F5F5F5">MODE</th>
	   	<th style="background:#F5F5F5">LOT</th>
	   	<th style="background:#F5F5F5">INTRANT</th>
	   	<th style="background:#F5F5F5">PEREMPTION</th>
	   	<th style="background:#F5F5F5">QUANTITE</th>

	   	<th style="background:#F5F5F5">C.TOTAL</th>
	   	</tr>
	   	</thead><tbody>' ;
	   	$sql = "SELECT `QUANTITE`,`PRIX_UNITAIRE`,`NUMERO_LOT`,`DATE_PEREMPTION`,`PRIX_TOTAL`,im.INTRANT_MEDICAUX_DESCR,rcr.MODE_RECEPTION_DESCR FROM `rc_reception_intrant_detail` rri JOIN intrant_medicaux im ON rri.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID JOIN rc_mode_reception rcr ON rri.`MODE_RECEPTION_ID`=rcr.MODE_RECEPTION_ID WHERE `RECEPTION_ID`=".$RECEPTION_ID;
	   	$intrants=$this->Modele->getRequete($sql);
	   	foreach ($intrants as $items):



	   		$html .='<tr class="">' ;
	   		$html .='<td><font >'.$j.'</font></td>
	   		<td><font >'.$items['MODE_RECEPTION_DESCR'].'</font></td>
	   		<td><font >'.$items['NUMERO_LOT'].'</font></td>
	   		<td><font >'.$items['INTRANT_MEDICAUX_DESCR'].'</font></td>
	   		<td><font >'.date('d-m-Y',strtotime($items['DATE_PEREMPTION'])).'</font></td>
	   		<td><font >'.$items['QUANTITE'].'</font></td>
	   		<td><font >'.$items['PRIX_TOTAL'].'</font></td>' ;
	   		$html .='</tr>' ;
	   		$i++;
	   		$j++;



	   	endforeach;

	   	$html .='</tbody></table>' ;

	   	echo json_encode(array('datas'=>$html));

	   }
	   public function upload_document($nom_file,$nom_champ,$RECEPTION_ID)
	   {
  # code...

	   	$rep_doc =FCPATH.'uploads/pv_reception/';
	   	$code=date("YmdHis");
	   	$fichier=basename($code."pv_rec".$RECEPTION_ID);
	   	$file_extension = pathinfo($nom_champ, PATHINFO_EXTENSION);
	   	$file_extension = strtolower($file_extension);
	   	$valid_ext = array('png','jpeg','jpg');

      if(!is_dir($rep_doc)) //create the folder if it does not already exists   
      {
      	mkdir($rep_doc,0777,TRUE);

      }  


      move_uploaded_file($nom_file, $rep_doc.$fichier.".".$file_extension);
      $pathfile="uploads/pv_reception/".$fichier.".".$file_extension;
      return $pathfile;


  }
/*function pv_reception($RECEPTION_ID="")
{

  include 'pdfinclude/fpdf/mc_table.php';
  include 'pdfinclude/fpdf/pdf_config.php';
  $pdf = new PDF_CONFIG('P','mm','A4');
  $pdf->addPage();
  $lien_sauvegarder = FCPATH.'uploads/pv_reception/';
  //$filename='test.pdf';
  if(!is_dir($lien_sauvegarder)){
         mkdir($lien_sauvegarder,0777,TRUE); 
  }

  //$rc=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));

  $rc_r=$this->Modele->getRequeteOne('SELECT DISTINCT rcri.MODE_RECEPTION_ID,RECEPTION_DATE,intv.INTERVENANT_STRUCTURE_DESCR PTF,rc_mode_reception.MODE_RECEPTION_DESCR MODES FROM rc_reception_intrant_detail rcri JOIN rc_reception rc  ON rcri.RECEPTION_ID=rc.RECEPTION_ID JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rc.PTF_ID JOIN rc_mode_reception ON rc_mode_reception.MODE_RECEPTION_ID=rcri.`MODE_RECEPTION_ID` WHERE rc.RECEPTION_ID='.$RECEPTION_ID.' AND rcri.`MODE_RECEPTION_ID`<>0');


  //$mode=$this->Modele->getOne('rc_mode_reception',array('MODE_RECEPTION_ID'=>$rc['MODE_RECEPTION_ID']));
  //$ptf=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID` PTF_ID,`INTERVENANT_STRUCTURE_DESCR` PTF_NOM FROM `intervenants_structure` WHERE  INTERVENANT_STRUCTURE_ID='.$rc['PTF_ID']);

  $equipe=$this->Modele->getRequete('SELECT rcm.MODE_RECEPTION_DESCR,concat(rh.NOM," ",rh.PRENOM) as NOM,rh.SEXE_ID FROM `rc_equipe_reception` JOIN rc_reception_intrant_detail rcr ON rcr.RECEPTION_ID=rc_equipe_reception.RECEPTION_ID JOIN rc_mode_reception rcm ON rcm.MODE_RECEPTION_ID=rcr.MODE_RECEPTION_ID JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=rc_equipe_reception.INTERVENANT_RH_ID WHERE  rcr.RECEPTION_ID='.$RECEPTION_ID);


  $date=$rc_r['RECEPTION_DATE'];
  //GENERER L'ANNEE LITERALE
  $annee_jour_mois=$this->mylibrary->mois_jour_litterale($date);
  $pdf->SetFont('Arial','BU',12);
  $pdf->Cell(150,5,utf8_decode('Procès-verbal de la réception des médicaments de la '.$rc_r['MODES']),0,1,'R');
  $pdf->SetFont('Arial','',12);

  $pdf->Ln(4);

  $pdf->MultiCell(189,5,utf8_decode($annee_jour_mois. ' dans l\'un des magasins de la CAMEBU s\'est tenue une réception des médicaments de la '.$rc_r['MODES'].' achetés par '.$rc_r['PTF']));//.$ptf['PTF_NOM']
  $pdf->Ln();
  
  $pdf->MultiCell(189,5,utf8_decode('L\'équipe chargée de réceptionner ces médicaments était composée par:'));
  $pdf->Ln();

  $eq=1;
  foreach ($equipe as $key => $value) {

    $sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Madame ' ;

    $pdf->MultiCell(100,5,utf8_decode($eq.'.'.$sex.' '.$value['NOM'].'  , '.$value['MODE_RECEPTION_DESCR']));

    $eq++;

  }

  $pdf->Ln();


  //$pdf->Ln(5);
  $pdf->MultiCell(189,5,utf8_decode('La méthodologie a consisté à l\'inspection qualitative et quantitative des produits par comptage physique et par la vérification carton par carton du: '));
  $pdf->Ln();

  $pdf->MultiCell(60,5,utf8_decode('
    1.Nom du produit;
    2.Numéro de lot;
    3.La date de péremption;
    4.La quantité'),0,'L',0);

  $pdf->Ln();



  $pdf->MultiCell(189,5,utf8_decode('Tableau qui montre les détails des produits ICCM achetés par '.$rc_r['PTF'].' à la CAMEBU'));//.$ptf['PTF_NOM']
  $pdf->Ln();

  $pdf->SetWidths(array('55','22','25','23','23','21','23'));
  $pdf->SetLineHeight(5);
  $pdf->SetFont('Arial','B',12);
  $pdf->Row(array(utf8_decode('Nom du produit'),utf8_decode('Unité'),utf8_decode('Lot'),utf8_decode('Exp'),utf8_decode('Quantité'),utf8_decode('P.U(USD)'),utf8_decode('P.T(USD)')),'C');
  $pdf->SetFont('Arial','',10);


  $query_principal=$this->Modele->getRequete('SELECT DISTINCT `INTRANT_ID` FROM `rc_reception_intrant_detail` WHERE RECEPTION_ID='.$RECEPTION_ID);
  $general_total=0;



  foreach ($query_principal as $key => $value) 
  {


   $total=0;
   $qte=0;

   $query_secondaire=$this->Modele->getRequete('SELECT SUM(rc.`QUANTITE`) as qte,SUM(rc.QUANTITE * PRIX_UNITAIRE) AS PT,intra.INTRANT_MEDICAUX_DESCR,(SELECT unite.INTRANT_UNITE_DESCR FROM intrant_unites unite WHERE unite.INTRANT_UNITE_ID=intra.INTRANT_UNITE_ID) as UNITE, `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` rc JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=rc.`INTRANT_ID` WHERE `RECEPTION_ID`='.$RECEPTION_ID.' AND rc.INTRANT_ID='.$value['INTRANT_ID'].' GROUP BY `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION`,intra.INTRANT_MEDICAUX_DESCR,UNITE');
   

      foreach ($query_secondaire as $value1) 
      {

        $qte_total=0;
        $montant_total=0;

        $qte_total+=$value1['qte'];
        $montant_total+=$value1['PT'];

        $pdf->Row(array(utf8_decode($value1['INTRANT_MEDICAUX_DESCR']),utf8_decode($value1['UNITE']),utf8_decode($value1['NUMERO_LOT']),utf8_decode($value1['DATE_PEREMPTION']),utf8_decode(number_format($value1['qte'],0,' ',' ')),utf8_decode($value1['PRIX_UNITAIRE']),utf8_decode(number_format($value1['PT'],0,' ',' '))));

        $pdf->SetFont('Arial','B',10);
        $pdf->Row(array(utf8_decode('Total'),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(number_format($qte_total,0,' ',' ')),utf8_decode(''),utf8_decode('')));
        $pdf->SetFont('Arial','',10);
      }


    $general_total+=$montant_total;
    }


   

    $pdf->SetFont('Arial','B',12);
    $pdf->Row(array(utf8_decode('Total général'),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(number_format($general_total,0,' ',' '))));
    $pdf->SetFont('Arial','',12);



    $pdf->Ln();
    $pdf->MultiCell(189,5,utf8_decode('Les membres de l\'équipe chargée de la réception'));
    $pdf->Ln();

    $eq=1;



    foreach ($equipe as $key => $value) {

      $sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Madame ' ;

      $pdf->MultiCell(100,5,utf8_decode($eq.'.'.$sex.' '.$value['NOM'].'  , '.$value['MODE_RECEPTION_DESCR']));

      $eq++;

    }

    $pdf->Ln();

    $pdf->MultiCell(180,5,utf8_decode('Fait à Bujumbura, le '.date('d/m/Y',strtotime($rc_r['RECEPTION_DATE']))),0,'R');

    $pdf->Output($lien_sauvegarder."Pv_de_reception".date('Y').date('m').date('d').".pdf","F");
    $message = "Pv de réception du ".date('Y-m-d')." veuillez ouvrir la  pièce jointe";

	$sql_sm = "SELECT iss.EMAIL FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE RECEPTION_ID =".$RECEPTION_ID;
	$info_reception_ptf=$this->Modele->getRequeteOne($sql_sm);


	$EMAIL= $info_reception_ptf['EMAIL'];
	$came=$this->Modele->getRequeteOne('SELECT EMAIL FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');//recuperation email camebu
	$cc_emails[]=$came['EMAIL'];
	$sql_mail_togive_copy = 'SELECT iss.EMAIL FROM `rc_equipe_reception` rer JOIN intervenants_rh iss ON rer.`INTERVENANT_RH_ID`=iss.INTERVENANT_RH_ID WHERE iss.EMAIL IS NOT NULL AND `RECEPTION_ID`='.$RECEPTION_ID;
	$adresse_email=$this->Modele->getRequete($sql_mail_togive_copy);
	foreach ($adresse_email as $key_ml) {
		# code...
		$cc_emails[]=$key_ml['EMAIL'];
	}

    $file_to_attach[]=base_url('uploads/pv_reception/'.'Pv_de_reception'.date('Y').date('m').date('d').'.pdf');
    $this->notifications->send_mail($EMAIL,'PV de réception à signer',$cc_emails,$message,$file_to_attach);



    ///$pdf->output('pv'.$RECEPTION_ID.'.pdf','D');
}*/
function pv_reception($RECEPTION_ID="")
{

	include 'pdfinclude/fpdf/mc_table.php';
	include 'pdfinclude/fpdf/pdf_config.php';
	$pdf = new PDF_CONFIG('P','mm','A4');
	$pdf->addPage();
	$lien_sauvegarder = FCPATH.'uploads/pv_reception/';
  //$filename='test.pdf';
	if(!is_dir($lien_sauvegarder)){
		mkdir($lien_sauvegarder,0777,TRUE); 
	}

	$rc_r=$this->Modele->getRequeteOne('SELECT DISTINCT rcri.MODE_RECEPTION_ID,RECEPTION_DATE,intv.INTERVENANT_STRUCTURE_DESCR PTF,rc_mode_reception.MODE_RECEPTION_DESCR MODES FROM rc_reception_intrant_detail rcri JOIN rc_reception rc  ON rcri.RECEPTION_ID=rc.RECEPTION_ID JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rc.PTF_ID JOIN rc_mode_reception ON rc_mode_reception.MODE_RECEPTION_ID=rcri.`MODE_RECEPTION_ID` WHERE rc.RECEPTION_ID='.$RECEPTION_ID.' AND rcri.`MODE_RECEPTION_ID`<>0');


  // $equipe=$this->Modele->getRequete('SELECT rcm.MODE_RECEPTION_DESCR,concat(rh.NOM," ",rh.PRENOM) as NOM,rh.SEXE_ID FROM `rc_equipe_reception` JOIN rc_reception_intrant_detail rcr ON rcr.RECEPTION_ID=rc_equipe_reception.RECEPTION_ID JOIN rc_mode_reception rcm ON rcm.MODE_RECEPTION_ID=rcr.MODE_RECEPTION_ID JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=rc_equipe_reception.INTERVENANT_RH_ID WHERE  rcr.RECEPTION_ID='.$RECEPTION_ID);

	$equipe=$this->Modele->getRequete("SELECT rh.SEXE_ID,CONCAT(rh.NOM,' ',rh.PRENOM,', ',intv.INTERVENANT_STRUCTURE_DESCR) EQUIPE FROM `rc_equipe_reception` JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rc_equipe_reception.INTERVENANT_STRUCTURE_ID JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=rc_equipe_reception.INTERVENANT_RH_ID WHERE rc_equipe_reception.RECEPTION_ID=".$RECEPTION_ID);


	$date=$rc_r['RECEPTION_DATE'];
  //GENERER L'ANNEE LITERALE
	$annee_jour_mois=$this->mylibrary->mois_jour_litterale($date);
	$pdf->SetFont('Arial','BU',12);
	$pdf->Cell(150,5,utf8_decode('Procès-verbal de la réception des médicaments de la '.$rc_r['MODES']),0,1,'R');
	$pdf->SetFont('Arial','',12);

	$pdf->Ln(4);

  $pdf->MultiCell(189,5,utf8_decode($annee_jour_mois. ' dans l\'un des magasins de la CAMEBU s\'est tenue une réception des médicaments de la '.$rc_r['MODES'].' achetés par '.$rc_r['PTF']));//.$ptf['PTF_NOM']
  $pdf->Ln();
  
  $pdf->MultiCell(189,5,utf8_decode('L\'équipe chargée de réceptionner ces médicaments était composée par:'));
  $pdf->Ln();

  $eq=1;
  foreach ($equipe as $key => $value) {

  	$sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Madame ' ;

  	$pdf->MultiCell(100,5,utf8_decode($eq.'.'.$sex.' '.$value['EQUIPE']));

  	$eq++;

  }

  $pdf->Ln();


  //$pdf->Ln(5);
  $pdf->MultiCell(189,5,utf8_decode('La méthodologie a consisté à l\'inspection qualitative et quantitative des produits par comptage physique et par la vérification carton par carton du: '));
  $pdf->Ln();

  $pdf->MultiCell(60,5,utf8_decode('
  	1.Nom du produit;
  	2.Numéro de lot;
  	3.La date de péremption;
  	4.La quantité'),0,'L',0);

  $pdf->Ln();



  $pdf->MultiCell(189,5,utf8_decode('Tableau qui montre les détails des produits ICCM achetés par '.$rc_r['PTF'].' à la CAMEBU'));//.$ptf['PTF_NOM']
  $pdf->Ln();

  $pdf->SetWidths(array('55','22','25','23','23','21','23'));
  $pdf->SetLineHeight(5);
  $pdf->SetFont('Arial','B',12);
  $pdf->Row(array(utf8_decode('Nom du produit'),utf8_decode('Unité'),utf8_decode('Lot'),utf8_decode('Exp'),utf8_decode('Quantité'),utf8_decode('P.U(USD)'),utf8_decode('P.T(USD)')),'C');
  $pdf->SetFont('Arial','',10);


  $query_principal=$this->Modele->getRequete('SELECT DISTINCT `INTRANT_ID` FROM `rc_reception_intrant_detail` WHERE RECEPTION_ID='.$RECEPTION_ID);
  $general_total=0;



  foreach ($query_principal as $key => $value) 
  {


  	$total=0;
  	$qte=0;

  	$query_secondaire=$this->Modele->getRequete('SELECT SUM(rc.`QUANTITE`) as qte,SUM(rc.QUANTITE * PRIX_UNITAIRE) AS PT,intra.INTRANT_MEDICAUX_DESCR,(SELECT unite.INTRANT_UNITE_DESCR FROM intrant_unites unite WHERE unite.INTRANT_UNITE_ID=intra.INTRANT_UNITE_ID) as UNITE, `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` rc JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=rc.`INTRANT_ID` WHERE `RECEPTION_ID`='.$RECEPTION_ID.' AND rc.INTRANT_ID='.$value['INTRANT_ID'].' GROUP BY `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION`,intra.INTRANT_MEDICAUX_DESCR,UNITE');


  	foreach ($query_secondaire as $value1) 
  	{

  		$qte_total=0;
  		$montant_total=0;

  		$qte_total+=$value1['qte'];
  		$montant_total+=$value1['PT'];

  		$pdf->Row(array(utf8_decode($value1['INTRANT_MEDICAUX_DESCR']),utf8_decode($value1['UNITE']),utf8_decode($value1['NUMERO_LOT']),utf8_decode($value1['DATE_PEREMPTION']),utf8_decode(number_format($value1['qte'],0,' ',' ')),utf8_decode($value1['PRIX_UNITAIRE']),utf8_decode(number_format($value1['PT'],0,' ',' '))));

  		$pdf->SetFont('Arial','B',10);
  		$pdf->Row(array(utf8_decode('Total'),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(number_format($qte_total,0,' ',' ')),utf8_decode(''),utf8_decode('')));
  		$pdf->SetFont('Arial','',10);
  	}


  	$general_total+=$montant_total;
  }




  $pdf->SetFont('Arial','B',12);
  $pdf->Row(array(utf8_decode('Total général'),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(number_format($general_total,0,' ',' '))));
  $pdf->SetFont('Arial','',12);



  $pdf->Ln();
  $pdf->MultiCell(189,5,utf8_decode('Les membres de l\'équipe chargée de la réception'));
  $pdf->Ln();

  $eq=1;



  foreach ($equipe as $key => $value) {

  	$sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Madame ' ;

  	$pdf->MultiCell(100,5,utf8_decode($eq.'.'.$sex.' '.$value['EQUIPE']));

  	$eq++;

  }

  $pdf->Ln();

  $pdf->MultiCell(180,5,utf8_decode('Fait à Bujumbura, le '.date('d/m/Y',strtotime($rc_r['RECEPTION_DATE']))),0,'R');

  $pdf->Output($lien_sauvegarder."Pv_de_reception".date('YmdHis').".pdf","F");
  $message = "Pv de réception du ".date('Y-m-d')." veuillez ouvrir la  pièce jointe";

  $sql_sm = "SELECT iss.EMAIL FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE RECEPTION_ID =".$RECEPTION_ID;
  $info_reception_ptf=$this->Modele->getRequeteOne($sql_sm);


  $EMAIL= $info_reception_ptf['EMAIL'];
	$came=$this->Modele->getRequeteOne('SELECT EMAIL FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');//recuperation email camebu
	$cc_emails[]=$came['EMAIL'];
	$sql_mail_togive_copy = 'SELECT iss.EMAIL FROM `rc_equipe_reception` rer JOIN intervenants_rh iss ON rer.`INTERVENANT_RH_ID`=iss.INTERVENANT_RH_ID WHERE iss.EMAIL IS NOT NULL AND `RECEPTION_ID`='.$RECEPTION_ID;
	$adresse_email=$this->Modele->getRequete($sql_mail_togive_copy);
	foreach ($adresse_email as $key_ml) {
		# code...
		$cc_emails[]=$key_ml['EMAIL'];
	}

	$file_to_attach[]='http://51.83.236.148/iccm_un_v1/uploads/pv_reception/'.'Pv_de_reception'.date('YmdHis').'.pdf';
	$this->notifications->send_mail($EMAIL,'PV de réception à signer',$cc_emails,$message,$file_to_attach);
 //$pdf->output('I');send_mail($emailTo = array(), $subjet, $cc_emails = array(), $message, $attach = array())
 //$pdf->output('pv'.$RECEPTION_ID.'.pdf','D');


}

public function show_titre($value='')
{
	# code...
	$RECEPTION_ID=$this->input->post('RECEPTION_ID');
	$result=$this->Modele->getRequeteOne("SELECT concat('Intrants ',i.INTERVENANT_STRUCTURE_DESCR,' réceptionnés en date du ',date_format(`DATE_INSERTION`,'%d-%m-%Y')) title_modale FROM `rc_reception` r JOIN intervenants_structure i ON r.`PTF_ID`=i.INTERVENANT_STRUCTURE_ID WHERE `RECEPTION_ID`=".$RECEPTION_ID);
	echo $result['title_modale'];
}

}

?>
