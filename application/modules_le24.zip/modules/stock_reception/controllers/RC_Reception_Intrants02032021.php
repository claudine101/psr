<?php

/**
* Author:NSHIMIRIMANA REVERIEN
DATE DEBUT:12-02-2021
DATE DEBUT:15-02-2021
COMMANTAIRE:RECEPTION DES INTRANTS
*/
class RC_Reception_Intrants extends My_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function etape1()
	{

		$data['title']="Réception des intrants";
		$data['mode_reception']=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` WHERE 1');
		$data['ptfs']=$this->Modele->getRequete('SELECT `PTF_ID`, `PTF_NOM` FROM `ptf` WHERE 1');
		$data['title']="Réception des intrants";
   $this->page='stock_reception/rc_reception/RC_Reception_description_add_view';
   $this->layout($data);
 }

 function etape3($RECEPTION_ID='')
 {
  $data['title']="Réception des intrants";
  $data['RECEPTION_ID']=$RECEPTION_ID;
  $data['intrants_medicaux']=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`, `INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` WHERE 1');


  $rc_reception_intrants=$this->Modele->getRequete('SELECT  RECEPTION_ID,rc_reception_intrant_detail.INTRANT_ID,intra.INTRANT_MEDICAUX_DESCR,rc_reception_intrant_detail.RECEPTION_INTRANT_ID,rc_reception_intrant_detail.QUANTITE,rc_reception_intrant_detail.PRIX_UNITAIRE,rc_reception_intrant_detail.NUMERO_LOT FROM `rc_reception_intrant_detail` JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=rc_reception_intrant_detail.INTRANT_ID WHERE RECEPTION_ID='.$RECEPTION_ID);
  $table="";
  $nu=1;
  if (!empty($rc_reception_intrants)) {
    $table.="<table class='table table-bordered table-stripped table-hover table-condensed'>";
    $table.="<thead><th>#</th><th>Intrants</th><th>Quantité</th><th>P.U</th><th>No. du lot</th><th>OPTIONS</th></thead>";
    foreach ($rc_reception_intrants as $key => $value) {
     $table.="<tr><td>".$nu."</td><td>".$value['INTRANT_MEDICAUX_DESCR']."</td><td>".$value['QUANTITE']."</td><td>".number_format($value['PRIX_UNITAIRE'],0,',',' ')."</td><td>".$value['NUMERO_LOT']."</td><td><a href='#' data-toggle='modal' data-target='#mydelete".$value['RECEPTION_INTRANT_ID']."'><center><i class='fa fa-trash' style='color:red;'></i></center></a></td></tr>";

     $table.="<div class='modal fade' id='mydelete".$value['RECEPTION_INTRANT_ID']."'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h5><strong>VOULEZ-VOUS SUPPRIMER L'INTERVENANT </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $value['INTRANT_MEDICAUX_DESCR']."</i></b>?</h5></center>

     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('stock_reception/RC_Reception_Intrants/delete_intrant/').$value['RECEPTION_INTRANT_ID'].'/'.$value['RECEPTION_ID'].'/'.$value['INTRANT_ID']."'>Supprimer</a>
     <button class='btn btn-default btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div>";

     $nu++;
   }

   $table.="</table>";
      
 }


 $data['intrants']=$table;


 $this->page='stock_reception/rc_reception/RC_Reception_Intrants_view';
 $this->layout($data);
}

function etape1_back($RECEPTION_ID='')
{
  $data['title']="Réception des intrants";
  $data['mode_reception']=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` WHERE 1');
  $data['ptfs']=$this->Modele->getRequete('SELECT `PTF_ID`, `PTF_NOM` FROM `ptf` WHERE 1');
  $data['title']="Réception des intrants";
  $data['RECEPTION_ID']=$RECEPTION_ID;
  $data['reception']=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));
  $this->page='stock_reception/rc_reception/RC_Reception_description_update_view';
  $this->layout($data);

}

function etape1_update()
{
  $this->validate();
  $RECEPTION_ID=$this->input->post('RECEPTION_ID');
  if ($this->form_validation->run()==FALSE) 
  {
    $data['title']="Réception des intrants";
    $data['mode_reception']=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` WHERE 1');
    $data['ptfs']=$this->Modele->getRequete('SELECT `PTF_ID`, `PTF_NOM` FROM `ptf` WHERE 1');
    $data['title']="Réception des intrants";
    $this->page='stock_reception/rc_reception/RC_Reception_description_add_view';
    $this->layout($data);
  } else {


    $photoreperatoire =FCPATH.'/uploads/signatures';
    $photo_avatar="SCAN_PV".date('Ymdhis');
    $PATH_SCAN_PV_RECEPTION= $_FILES['PATH_SCAN_PV_RECEPTION']['name'];
    $config['upload_path'] ='./uploads/signatures/';
    $config['allowed_types'] = '*';
    $test = explode('.', $PATH_SCAN_PV_RECEPTION);
    $ext = end($test);
    $name = $photo_avatar.'.'.$ext;

    $config['file_name'] =$name;
          if(!is_dir($photoreperatoire)) //create the folder if it does not already exists   
          {
            mkdir($photoreperatoire,0777,TRUE);

          } 

          $this->upload->initialize($config);
          $this->upload->do_upload('PATH_SCAN_PV_RECEPTION');

          if ($_FILES['PATH_SCAN_PV_RECEPTION']['name']) 
          {
            $PATH_SCAN_PV_RECEPTION=$config['file_name'];
          }else
          {
            $PATH_SCAN_PV_RECEPTION=$this->input->post('pv');
          }
          
          //$PATH_SCAN_PV_RECEPTION=$config['file_name'];
          $data_image=$this->upload->data();



          $RECEPTION_DATE=$this->input->post('RECEPTION_DATE');
          $PTF_ID=$this->input->post('PTF_ID');
          $MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
          $COMMENTAIRE=$this->input->post('COMMENTAIRE');
          $RECEPTION_CODE='RC'.date('Ymdhis');

          $array_reception = array('RECEPTION_DATE' => $RECEPTION_DATE,'RECEPTION_CODE'=>$RECEPTION_CODE,'PTF_ID'=>$PTF_ID,'PATH_SCAN_PV_RECEPTION'=>$PATH_SCAN_PV_RECEPTION,'MODE_RECEPTION_ID'=>$MODE_RECEPTION_ID,'COMMENTAIRE'=>$COMMENTAIRE );
          $this->Modele->update('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID),$array_reception);


          // $sms['sms']='<br><div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Votre enregistrement a été bien faite .</div><br>' ;
          // $this->session->set_flashdata($sms) ;

          //redirect(base_url('stock_reception/RC_Reception_Intrants/rec_intrant/'.$RECEPTION_ID));


          redirect(base_url('stock_reception/RC_Reception_Intrants/etape2/'.$RECEPTION_ID));

        }
      }

      function etape2($RECEPTION_ID='')
      {

        $data['title']="Réception des intrants";
        $mode=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));
    //$data['title']="Réception des intrants détails";
        $data['RECEPTION_ID']=$RECEPTION_ID;
        $data['structures']=$this->Modele->getList('intervenants_structure',array('MODE_RECEPTION_ID'=>$mode['MODE_RECEPTION_ID']));

        $equipe_rh=$this->Modele->getRequete('SELECT rc_equipe_reception.EQUIPE_RECEPTION_ID,CONCAT(intervenants_rh.NOM," ",intervenants_rh.PRENOM) as NOM,intervenants_rh.TELEPHONE1 FROM `rc_equipe_reception` JOIN intervenants_rh ON intervenants_rh.INTERVENANT_RH_ID=rc_equipe_reception.INTERVENANT_RH_ID WHERE RECEPTION_ID='.$RECEPTION_ID);
        $table="";
        $nu=1;
        if (!empty($equipe_rh)) {
          $table.="<table class='table table-bordered table-stripped table-hover table-condensed'>";
          $table.="<thead><th>#</th><th>INTERVENANT</th><th>TELEPHONE</th><th>OPTIONS</th></thead>";
          foreach ($equipe_rh as $key => $value) {
           $table.="<tr><td>".$nu."</td><td>".$value['NOM']."</td><td>".$value['TELEPHONE1']."</td><td><a href='#' data-toggle='modal' data-target='#mydelete".$value['EQUIPE_RECEPTION_ID']."'><center><i class='fa fa-trash' style='color:red;'></i></center></a></td></tr>";

           $table.="<div class='modal fade' id='mydelete".$value['EQUIPE_RECEPTION_ID']."'>
           <div class='modal-dialog'>
           <div class='modal-content'>

           <div class='modal-body'>
           <center><h5><strong>VOULEZ-VOUS SUPPRIMER L'INTERVENANT </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $value['NOM']."</i></b>?</h5></center>

           </div>

           <div class='modal-footer'>
           <a class='btn btn-danger btn-md' href='" . base_url('stock_reception/RC_Reception_Intrants/delete_rh/').$value['EQUIPE_RECEPTION_ID'].'/'.$RECEPTION_ID."'>Supprimer</a>
           <button class='btn btn-default btn-md' data-dismiss='modal'>Quitter</button>
           </div>

           </div>
           </div>
           </div>";

           $nu++;
         }
       }

       $table.="</table>";
       $data['table']=$table;
      
       $this->page='stock_reception/rc_reception/RC_Reception_etape2_add_view';
       $this->layout($data);
     }

     function etapa2_add($RECEPTION_ID='')
     {
      $RECEPTION_ID=$RECEPTION_ID;
      $INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');

      $this->validate_etape2();
      if ($this->form_validation->run()==FALSE) 
      {
        $data['title']="Réception des intrants";
        $mode=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));
        $data['title']="Réception des intrants détails";
        $data['RECEPTION_ID']=$RECEPTION_ID;
        $data['structures']=$this->Modele->getList('intervenants_structure',array('MODE_RECEPTION_ID'=>$mode['MODE_RECEPTION_ID']));
        $this->page='stock_reception/rc_reception/RC_Reception_etape2_add_view';
        $this->layout($data);
      } else {
       $array_equipe=array('RECEPTION_ID'=>$RECEPTION_ID,'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID);
       $this->Modele->create('rc_equipe_reception',$array_equipe);
       redirect(base_url('stock_reception/RC_Reception_Intrants/etape2/'.$RECEPTION_ID));


     }


   }



   function etape1_add()
   {
    $this->validate();
    if ($this->form_validation->run()==FALSE) 
    {
     $data['title']="Réception des intrants";
     $data['mode_reception']=$this->Modele->getRequete('SELECT * FROM `rc_mode_reception` WHERE 1');
     $data['ptfs']=$this->Modele->getRequete('SELECT `PTF_ID`, `PTF_NOM` FROM `ptf` WHERE 1');
     $data['title']="Réception des intrants";
     $this->page='stock_reception/rc_reception/RC_Reception_description_add_view';
     $this->layout($data);
   } else {


     $photoreperatoire =FCPATH.'/uploads/signatures';
     $photo_avatar="SCAN_PV".date('Ymdhis');
     $PATH_SCAN_PV_RECEPTION= $_FILES['PATH_SCAN_PV_RECEPTION']['name'];
     $config['upload_path'] ='./uploads/signatures/';
     $config['allowed_types'] = '*';
     $test = explode('.', $PATH_SCAN_PV_RECEPTION);
     $ext = end($test);
     $name = $photo_avatar.'.'.$ext;

     $config['file_name'] =$name;
          if(!is_dir($photoreperatoire)) //create the folder if it does not already exists   
          {
          	mkdir($photoreperatoire,0777,TRUE);

          } 

          $this->upload->initialize($config);
          $this->upload->do_upload('PATH_SCAN_PV_RECEPTION');
          $PATH_SCAN_PV_RECEPTION=$config['file_name'];
          $data_image=$this->upload->data();



          $RECEPTION_DATE=$this->input->post('RECEPTION_DATE');
          $PTF_ID=$this->input->post('PTF_ID');
          $MODE_RECEPTION_ID=$this->input->post('MODE_RECEPTION_ID');
          $COMMENTAIRE=$this->input->post('COMMENTAIRE');
          $RECEPTION_CODE='RC'.date('Ymdhis');

          $array_reception = array('RECEPTION_DATE' => $RECEPTION_DATE,'RECEPTION_CODE'=>$RECEPTION_CODE,'PTF_ID'=>$PTF_ID,'PATH_SCAN_PV_RECEPTION'=>$PATH_SCAN_PV_RECEPTION,'MODE_RECEPTION_ID'=>$MODE_RECEPTION_ID,'COMMENTAIRE'=>$COMMENTAIRE );
          $RECEPTION_ID=$this->Modele->insert_last_id('rc_reception',$array_reception);



          $sms['sms']='<br><div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Votre enregistrement a été bien faite .</div><br>' ;
          $this->session->set_flashdata($sms) ;

          //redirect(base_url('stock_reception/RC_Reception_Intrants/rec_intrant/'.$RECEPTION_ID));
          redirect(base_url('stock_reception/RC_Reception_Intrants/etape2/'.$RECEPTION_ID));

        }

      }



      function delete_intrant($RECEPTION_INTRANT_ID='',$RECEPTION_ID='',$INTRANT_ID='')
      {

    //print_r($INTRANT_ID);exit();
       $getvalue=$this->Modele->getOne('rc_reception_intrant_detail',array('RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,'RECEPTION_ID'=>$RECEPTION_ID));
       $getvalue_from_camebu=$this->Modele->getOne('stock_camebu',array('INTRANT_ID'=>$INTRANT_ID));
       $qte_disponible_stock_camebu=$getvalue_from_camebu['QUANTITE']-$getvalue['QUANTITE'];
       $this->Modele->update('stock_camebu',array('INTRANT_ID'=>$INTRANT_ID),array('QUANTITE'=>$qte_disponible_stock_camebu));
       $this->Modele->delete('rc_reception_intrant_detail',array('RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID));
       redirect(base_url('stock_reception/RC_Reception_Intrants/etape3/'.$RECEPTION_ID));
     }


     function delete_rh($EQUIPE_RECEPTION_ID='',$RECEPTION_ID='')
     {

    //print_r($INTRANT_ID);exit();
       $getvalue=$this->Modele->getOne('rc_equipe_reception',array('EQUIPE_RECEPTION_ID'=>$EQUIPE_RECEPTION_ID,'RECEPTION_ID'=>$RECEPTION_ID));

       $this->Modele->delete('rc_equipe_reception',array('EQUIPE_RECEPTION_ID'=>$EQUIPE_RECEPTION_ID));
       redirect(base_url('stock_reception/RC_Reception_Intrants/etape2/'.$RECEPTION_ID));
     }





     function validate()
     {

       $this->form_validation->set_rules('RECEPTION_DATE','RECEPTION_DATE','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
       $this->form_validation->set_rules('PTF_ID','PTF_ID','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
       $this->form_validation->set_rules('MODE_RECEPTION_ID','MODE_RECEPTION_ID','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
       $this->form_validation->set_rules('COMMENTAIRE','COMMENTAIRE','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
     //$this->form_validation->set_rules('INTERVENANT_RH_ID','INTERVENANT_RH_ID','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));


     }


     function etape3_add()
     {
       $RECEPTION_ID=$this->uri->segment(4);

       $this->validate1();
       if($this->form_validation->run()==FALSE) {
        $data['RECEPTION_ID']=$RECEPTION_ID;

        $mode=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));

        $data['title']="Réception des intrants détails";
        $data['RECEPTION_ID']=$RECEPTION_ID;
        $data['intrants_medicaux']=$this->Modele->getRequete('SELECT `INTRANT_MEDICAUX_ID`, `INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` WHERE 1');
        $data['structures']=$this->Modele->getList('intervenants_structure',array('MODE_RECEPTION_ID'=>$mode['MODE_RECEPTION_ID']));

        $rc_reception_intrants=$this->Modele->getRequete('SELECT  RECEPTION_ID,rc_reception_intrant_detail.INTRANT_ID,intra.INTRANT_MEDICAUX_DESCR,rc_reception_intrant_detail.RECEPTION_INTRANT_ID,rc_reception_intrant_detail.QUANTITE,rc_reception_intrant_detail.PRIX_UNITAIRE,rc_reception_intrant_detail.NUMERO_LOT FROM `rc_reception_intrant_detail` JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=rc_reception_intrant_detail.INTRANT_ID WHERE RECEPTION_ID='.$RECEPTION_ID);
        $table="";
        $nu=1;
        if (!empty($rc_reception_intrants)) {
          $table.="<table class='table table-bordered table-stripped table-hover table-condensed'>";
          $table.="<thead><th>#</th><th>Intrants</th><th>Quantité</th><th>P.U</th><th>No. du lot</th><th>OPTIONS</th></thead>";
          foreach ($rc_reception_intrants as $key => $value) {
           $table.="<tr><td>".$nu."</td><td>".$value['INTRANT_MEDICAUX_DESCR']."</td><td>".$value['QUANTITE']."</td><td>".number_format($value['PRIX_UNITAIRE'],0,',',' ')."</td><td>".$value['NUMERO_LOT']."</td><td><a href='#' data-toggle='modal' data-target='#mydelete".$value['RECEPTION_INTRANT_ID']."'><center><i class='fa fa-trash' style='color:red;'></i></center></a></td></tr>";

           $table.="<div class='modal fade' id='mydelete".$value['RECEPTION_INTRANT_ID']."'>
           <div class='modal-dialog'>
           <div class='modal-content'>

           <div class='modal-body'>
           <center><h5><strong>VOULEZ-VOUS SUPPRIMER L'INTERVENANT </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $value['INTRANT_MEDICAUX_DESCR']."</i></b>?</h5></center>

           </div>

           <div class='modal-footer'>
           <a class='btn btn-danger btn-md' href='" . base_url('stock_reception/RC_Reception_Intrants/delete_intrant/').$value['RECEPTION_INTRANT_ID'].'/'.$value['RECEPTION_ID'].'/'.$value['INTRANT_ID']."'>Supprimer</a>
           <button class='btn btn-default btn-md' data-dismiss='modal'>Quitter</button>
           </div>

           </div>
           </div>
           </div>";

           $nu++;
         }

         $table.="</table>";
       //$table.="<div class='col-md-12'><button class='btn btn-success' style='float:right;'><a style='color:white;text-decoration:none;' href='".base_url('stock_reception/RC_Reception_Intrants/listing')."'>Terminer</a></button></div>";

       }


       $data['intrants']=$table;
       $this->page='stock_reception/rc_reception/RC_Reception_Intrants_view';
       $this->layout($data);
     } else {

      $INTRANT_ID=$this->input->post('INTRANT_ID');
      $QUANTITE=$this->input->post('QUANTITE');
      $PRIX_UNITAIRE=$this->input->post('PRIX_UNITAIRE');
      $NUMERO_LOT=$this->input->post('NUMERO_LOT');
      $DATE_PEREMPTION=$this->input->post('DATE_PEREMPTION');
  		//$INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');
      $code=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));
      $RECEPTION_CODE=$code['RECEPTION_CODE'];
      $DATE_ENTRE_STOCK=date('Y-m-d');
      $USER_STOCKEUR_ID=$this->session->userdata('iccm_USER_ID');


      //$array_rc_equipe_reception = array('INTERVENANT_RH_ID' =>$INTERVENANT_RH_ID ,'RECEPTION_ID'=>$RECEPTION_ID);
      //$this->Modele->create('rc_equipe_reception',$array_rc_equipe_reception);

      $array_data_intrant=array('INTRANT_ID'=>$INTRANT_ID,'QUANTITE'=>$QUANTITE,'PRIX_UNITAIRE'=>$PRIX_UNITAIRE,'NUMERO_LOT'=>$NUMERO_LOT,'RECEPTION_ID'=>$RECEPTION_ID,'DATE_PEREMPTION'=>$DATE_PEREMPTION);

      //$verifier_intra=$this->Modele->getOne('rc_reception_intrant_detail',array('INTRANT_ID'=>$INTRANT_ID,'RECEPTION_ID'=>$RECEPTION_ID));

      $verifier_stock=$this->Modele->getOne('stock_camebu',array('INTRANT_ID'=>$INTRANT_ID));
      $this->Modele->create('rc_reception_intrant_detail',$array_data_intrant);

  		//DETAILS DES INTRANTS PROVENANT DU CAMEBU

     //  if (!empty($verifier_intra)) {
     //   $this->Modele->update('rc_reception_intrant_detail',array('INTRANT_ID'=>$INTRANT_ID,'RECEPTION_ID'=>$RECEPTION_ID),array('QUANTITE'=>$QUANTITE,'PRIX_UNITAIRE'=>$PRIX_UNITAIRE,'NUMERO_LOT'=>$NUMERO_LOT,'DATE_PEREMPTION'=>$DATE_PEREMPTION));


     // } 
     // else
     // {

     //   $this->Modele->create('rc_reception_intrant_detail',$array_data_intrant);
     // }


  		//METTRE A JOUR LE STOCK AINSI QUE L AJOUT DES NOUVEAUX INTRANS

      if (!empty($verifier_stock)) {

       $quantite_nouvelle=$verifier_stock['QUANTITE_DISTRIBUE']+$QUANTITE;
       $this->Modele->update('stock_camebu',array('INTRANT_ID'=>$INTRANT_ID),array('QUANTITE_DISTRIBUE'=>$quantite_nouvelle));
     } else {
       $this->Modele->create('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'QUANTITE'=>$QUANTITE,'DATE_ENTRE_STOCK'=>$DATE_ENTRE_STOCK,'INTRANT_ID'=>$INTRANT_ID,'USER_STOCKEUR_ID'=>$USER_STOCKEUR_ID));
     }


     redirect(base_url('stock_reception/RC_Reception_Intrants/etape3/'.$RECEPTION_ID));
   }




 }


 function listing()
 {
  $rec_reception_array=array();

  $sql=$this->Modele->getRequete('SELECT `RECEPTION_ID`, `RECEPTION_CODE`, `RECEPTION_DATE`, `PATH_SCAN_PV_RECEPTION`, `COMMENTAIRE` FROM `rc_reception` JOIN ptf ON ptf.PTF_ID=rc_reception.PTF_ID JOIN rc_mode_reception modes ON modes.MODE_RECEPTION_ID=rc_reception.MODE_RECEPTION_ID ORDER BY RECEPTION_DATE DESC');

  $nu=1;
  foreach ($sql as $key => $rc) 
  {
    $sub_array=array();


    $intrants=$this->Modele->getRequete('SELECT `RECEPTION_INTRANT_ID`,intra.INTRANT_MEDICAUX_DESCR, `QUANTITE`, `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=rc_reception_intrant_detail.INTRANT_ID WHERE `RECEPTION_ID`='.$rc['RECEPTION_ID']);

    //$table="";
    $n=1;
    $liste='<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">';
    $liste.='<thead><th>#</th><th>Intrants</th><th>Quantité</th><th>Prix unitaire</th><th>Numéro du lot</th><th>Date de péremption</th></thead>';
    $liste.='<tbody>';
    foreach ($intrants as $key => $value) {
      $liste.="<tr><td>".$n."</td><td>".$value['INTRANT_MEDICAUX_DESCR']."</td><td>".$value['QUANTITE']."</td><td>".$value['PRIX_UNITAIRE']."</td><td>".$value['NUMERO_LOT']."</td><td>".$value['DATE_PEREMPTION']."</td></tr>";

      $n++;
    }
    $liste.='</tbody>';
    $liste.='</table>';

    $sub_array[]=$nu;
    $sub_array[]=$rc['RECEPTION_CODE'];
    $sub_array[]=$rc['RECEPTION_DATE'];
    $sub_array[]="<a href='#' data-toggle='modal' data-target='#myPDF".$rc['RECEPTION_ID']."'><span class='btn btn-default'>".sizeof($intrants)."</span></a>";
    $sub_array[]=$rc['COMMENTAIRE'];
    $sub_array[]="<a href='".base_url().'/uploads/signatures/'.$rc['PATH_SCAN_PV_RECEPTION']."' target='__blanc'><i class='fa fa-file'></i></a>";

    $sub_array['OPTIONS'] = '<div class="dropdown">
    <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
    <i class="fa fa-cog"></i> 
    Options <span class="caret"></span>
    </a> 
    <ul class="dropdown-menu dropdown-menu-left">';
    $sub_array['OPTIONS'] .="<li><a target='__blanc' href='".base_url('stock_reception/RC_Reception_Intrants/pv_reception/'.$rc['RECEPTION_ID'])."'><label class='text-info'>PV de réception</label></a></li>";

    // $sub_array['OPTIONS'] .="<li><a href='#' data-toggle='modal' data-target='#myPDF".$rc['RECEPTION_ID']."'><label class='text-danger'>Supprimer</label></a></li>";


    $sub_array['OPTIONS'] .= " </ul>
    </div>
    <div class='modal fade' id='myPDF".$rc['RECEPTION_ID']."'>
    <div class='modal-dialog'>
    <div class='modal-content'>

    <div class='modal-body'>
    <center>
    <h6>INTRANTS RECUS SOUS LE CODE DE RECEPTION <strong>".$rc['RECEPTION_CODE']."</strong><br>
    </h6>
    </center>
    ".$liste."
    </div>

    <div class='modal-footer'>

    <button class='btn btn-secondary btn-md' data-dismiss='modal'>
    Fermer
    </button>
    </div>

    </div>
    </div>
    </div>";


    $rec_reception_array[]=$sub_array;

    $nu++;
  }

  $template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
  $this->table->set_template($template);
  $this->table->set_heading(array('#','CODE DE RECEPTION','DATE DE RECEPTION','NBRE D\'INTRANTS','COMMENTAIRE','PV DE RECEPTION','ACTION'));
  $data['array_reception']=$rec_reception_array;
  $data['title']='Liste des intrants réçus';
  $this->page='stock_reception/rc_reception/RC_Reception_Intrants_list_view';
  $this->layout($data);
}



function validate1()
{

 $this->form_validation->set_rules('INTRANT_ID','INTRANT_ID','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
 $this->form_validation->set_rules('QUANTITE','QUANTITE','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
 $this->form_validation->set_rules('PRIX_UNITAIRE','PRIX_UNITAIRE','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
 $this->form_validation->set_rules('NUMERO_LOT','NUMERO_LOT','trim|required|is_unique[rc_reception_intrant_detail.NUMERO_LOT]',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>','is_unique'=>'<font style="color:red;font-size:14px;">Le numéro du lot doît être unique</font>'));
 $this->form_validation->set_rules('DATE_PEREMPTION','DATE_PEREMPTION','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));


}

function validate_etape2()
{

 $this->form_validation->set_rules('INTERVENANT_STRUCTURE_ID','INTERVENANT_STRUCTURE_ID','trim|required',array('required'=>'<font style="color:red;font-size:14px;">Le champs est obligatoire</font>'));
 


}




function get_intervenant_structure($MODE_RECEPTION_ID)
{
 $sub_requete=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE `MODE_RECEPTION_ID`='.$MODE_RECEPTION_ID);
 $html="<select name='' class='form-control'>";
 $html.="<option value=''>--Structure</option>";
 foreach ($sub_requete as $inter) {
  $html.="<option value='".$inter['INTERVENANT_STRUCTURE_ID']."'>".$inter['INTERVENANT_STRUCTURE_DESCR']."</option>";	
}
echo $html;
}

function get_intervenant_RH($INTERVENANT_STRUCTURE_ID)
{
 $sub_requete=$this->Modele->getRequete('SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`," ",`PRENOM`) AS NOM FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID);
 $html="<select name='' class='form-control'>";
 $html.="<option value=''>--Structure</option>";
 foreach ($sub_requete as $rh) {
  $html.="<option value='".$rh['INTERVENANT_RH_ID']."'>".$rh['NOM']."</option>";	
}
echo $html;
}


//PV DE RECEPTION DES INTRANTS

function pv_reception($RECEPTION_ID='')
{
  include 'pdfinclude/fpdf/mc_table.php';
  include 'pdfinclude/fpdf/pdf_config.php';
  $pdf = new PDF_CONFIG('P','mm','A4');
  $pdf->addPage();

  $rc=$this->Modele->getOne('rc_reception',array('RECEPTION_ID'=>$RECEPTION_ID));
  $mode=$this->Modele->getOne('rc_mode_reception',array('MODE_RECEPTION_ID'=>$rc['MODE_RECEPTION_ID']));
  $ptf=$this->Modele->getOne('ptf',array('PTF_ID'=>$rc['PTF_ID']));

  $equipe=$this->Modele->getRequete('SELECT rmod.MODE_RECEPTION_DESCR,concat(rh.NOM," ",rh.PRENOM) as NOM,rh.SEXE_ID FROM `rc_reception` JOIN rc_mode_reception rmod ON rmod.MODE_RECEPTION_ID=rc_reception.MODE_RECEPTION_ID JOIN rc_equipe_reception rcequip ON rcequip.RECEPTION_ID=rc_reception.RECEPTION_ID JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=rcequip.INTERVENANT_RH_ID WHERE rc_reception.RECEPTION_ID='.$RECEPTION_ID);


  $date=$rc['RECEPTION_DATE'];

  $annee_jour_mois=$this->mylibrary->mois_jour_litterale($date);


  $pdf->SetFont('Arial','U',12);
  $pdf->Cell(150,5,utf8_decode('Procès-verbal de la réception des médicaments de la '.$mode['MODE_RECEPTION_DESCR']),0,1,'R');
  $pdf->SetFont('Arial','',12);

  $pdf->Ln(4);
      //$pdf->Cell(150,5,utf8_decode('L\'an deux mille vingt le vingt sixième jour du mois de '),0,1,'L');
  $pdf->Cell(150,5,utf8_decode($annee_jour_mois.'dans l\'un des magasins'),0,1,'L');
  $pdf->Cell(150,5,utf8_decode('de la CAMEBU s\'est tenue une réception des médicaments de la '.$mode['MODE_RECEPTION_DESCR'].' achetés par '.$ptf['PTF_NOM'].'.'),0,1,'L');

  $pdf->Cell(150,5,utf8_decode('L\'équipe chargée de réceptionner ces médicaments était composée par:'),0,1,'L');
  $pdf->Ln(8);



  $eq=1;
  foreach ($equipe as $key => $value) {

    $sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Mme' ;

    $pdf->Cell(70,5,utf8_decode($eq.'.'.$sex.' '.$value['NOM'].','.$value['MODE_RECEPTION_DESCR']),0,1,'L');

    $eq++;

  }



  $pdf->Ln(5);
  $pdf->Cell(150,5,utf8_decode('La méthodologie a consisté à l\'inspection qualitative et quantitative des produits '),0,1,'L');

  $pdf->Cell(150,5,utf8_decode('par comptage physique et par la vérification carton par carton du:'),0,1,'L');
  $pdf->Ln(8);
  $pdf->Cell(40,5,utf8_decode('1.Nom du produit;'),0,1,'R');
  $pdf->Cell(38,5,utf8_decode('2.Numéro de lot;'),0,1,'R');
  $pdf->Cell(53.5,5,utf8_decode('3.La date de péremption;'),0,1,'R');
  $pdf->Cell(31,5,utf8_decode('4.La quantité'),0,1,'R');

  $pdf->Ln(5);
  $pdf->Cell(150,5,utf8_decode('Tableau qui montre les détails des produits ICCM achetés par '.$ptf['PTF_NOM'].' à la CAMEBU'),0,1,'L');

  $pdf->Ln(4);

  $pdf->Cell(43,8,utf8_decode('Nom du produit'),1,0);
  $pdf->Cell(22,8,utf8_decode('Unité'),1,0);
  $pdf->Cell(25,8,utf8_decode('Lot'),1,0);
  $pdf->Cell(25,8,utf8_decode('Exp'),1,0);
  $pdf->Cell(20,8,utf8_decode('Quantité'),1,0);
  $pdf->Cell(30,8,utf8_decode('P.U en USD'),1,0);
  $pdf->Cell(30,8,utf8_decode('P.T en USD'),1,1);


  $infos_1=$this->Modele->getRequete('SELECT DISTINCT INTRANT_ID,INTRANT_UNITE_ID, intrant_medicaux.INTRANT_MEDICAUX_DESCR, rc_reception_intrant_detail.`NUMERO_LOT`, `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID=rc_reception_intrant_detail.INTRANT_ID WHERE rc_reception_intrant_detail.INTRANT_ID IN (SELECT DISTINCT INTRANT_ID FROM rc_reception_intrant_detail WHERE `RECEPTION_ID`='.$RECEPTION_ID.')');

      //echo "<pre>".$infos_1."</pre>";

      //print_r($infos_1);//exit();

  $total_general=0;
  $qte_total=0;
  $prix_unitaire=0;
  $prix_tot=0;

  foreach ($infos_1 as $key => $value) 
  {

    $total=0;
    $pt=0;
    $qte=0;
    $prix=0;


    $unite=$this->Modele->getOne('intrant_unites',array('INTRANT_UNITE_ID'=>$value['INTRANT_UNITE_ID']));

    $infos_2=$this->Modele->getRequete('SELECT INTRANT_ID,QUANTITE,PRIX_UNITAIRE FROM rc_reception_intrant_detail WHERE rc_reception_intrant_detail.INTRANT_ID='.$value['INTRANT_ID'].' AND rc_reception_intrant_detail.RECEPTION_ID='.$RECEPTION_ID);
        //print_r($infos_2)."</br>";
    foreach ($infos_2 as $key => $value1) {
      $total+=$value1['QUANTITE'];
      $prix+=$value1['PRIX_UNITAIRE'];
      $qte+=$value1['QUANTITE'];
      $pt+=$value1['QUANTITE']*$value1['PRIX_UNITAIRE'];

    }

        //echo "<pre>".$prix."</pre>";

    $total_general+=$total;
    $prix_unitaire+=$prix;
    $prix_tot+=$pt;


    $pdf->Cell(43,8,utf8_decode($value['INTRANT_MEDICAUX_DESCR']),1,0);

    if ($unite['INTRANT_UNITE_DESCR']) {
      $pdf->Cell(22,8,utf8_decode($unite['INTRANT_UNITE_DESCR']),1,0);
    } else {
      $pdf->Cell(22,8,utf8_decode('-'),1,0);
    }


    $pdf->Cell(25,8,utf8_decode($value['NUMERO_LOT']),1,0);
    $pdf->Cell(25,8,utf8_decode($value['DATE_PEREMPTION']),1,0);
    $pdf->Cell(20,8,utf8_decode(number_format($qte,0,' ',' ')),1,0);
    $pdf->Cell(30,8,utf8_decode($prix),1,0);
    $pdf->Cell(30,8,utf8_decode(number_format($pt,0,' ',' ')),1,1);
    $pdf->SetFont('Arial','B',12);
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(43,8,utf8_decode('Total'),1,0);
    $pdf->Cell(22,8,utf8_decode(''),1,0);
    $pdf->Cell(25,8,utf8_decode(''),1,0);
    $pdf->Cell(25,8,utf8_decode(''),1,0);
    $pdf->Cell(20,8,utf8_decode(number_format($total,0,' ',' ')),1,0);
    $pdf->Cell(30,8,utf8_decode(number_format($prix,0,' ',' ')),1,0);
    $pdf->Cell(30,8,utf8_decode(number_format($pt,0,' ',' ')),1,1);
    $pdf->SetFont('Arial','',12);

  }
      //exit();
      //die();
  $pdf->SetFont('Arial','B',12);
  $pdf->Cell(43,8,utf8_decode('Total général'),1,0);
  $pdf->Cell(22,8,utf8_decode(''),1,0);
  $pdf->Cell(25,8,utf8_decode(''),1,0);
  $pdf->Cell(25,8,utf8_decode(''),1,0);

  $pdf->Cell(20,8,utf8_decode(''),1,0);
  $pdf->Cell(30,8,utf8_decode(''),1,0);
  $pdf->Cell(30,8,utf8_decode(number_format($prix_tot,0,' ',' ')),1,0);
  $pdf->SetFont('Arial','',12);




  $pdf->Ln(12);
  $pdf->Cell(150,5,utf8_decode('Les membres de l\'équipe chargée de la réception '),0,1,'L');


  $eq=1;
  foreach ($equipe as $key => $value) {

    $sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Mme' ;

    $pdf->Cell(70,5,utf8_decode($eq.'.'.$sex.' '.$value['NOM'].','.$value['MODE_RECEPTION_DESCR']),0,1,'L');

    $eq++;

  }

  if (!empty($equipe)) {
    $pdf->Ln(7);
  } else {
   $pdf->Ln(7);
 }



 $pdf->Cell(177,5,utf8_decode('Fait à Bujumbura, le '.date('d/m/Y',strtotime($rc['RECEPTION_DATE']))),0,1,'R');




 $pdf->output('pv'.$RECEPTION_ID.'.pdf','D');

}











}