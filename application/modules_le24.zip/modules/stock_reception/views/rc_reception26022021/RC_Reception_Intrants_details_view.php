<br><br>
<div class="row">
  <div class="col-md-12">
    <legend>
    <?= $title;?>
      <a href="<?= base_url('stock_reception/RC_Reception_Intrants/index')?>" 
        class="btn btn-primary btn-sm pull-right"><i class="fa fa-list"></i>
        Liste
      </a>
    </legend>
  </div>
</div>
<div class="row"><?=$this->session->flashdata('sms')?></div>

<div class="col-md-12">
   <form action="<?= base_url('stock_reception/RC_Reception_Intrants/add_intrant/'.$RECEPTION_ID)?>" method="post">

    <div class="col-md-6">
           <label>Intrants</label>
           <select name="INTRANT_ID" class="form-control">
             <option value="">--Intrants</option>
             <?php
             foreach ($intrants_medicaux as $intrant) {
               if ($intrant['INTRANT_MEDICAUX_ID']==set_value('INTRANT_ID')) {?>
                <option value="<?=$intrant['INTRANT_MEDICAUX_ID']?>" selected=''><?=$intrant['INTRANT_MEDICAUX_DESCR']?></option> 
               <?php } else {?>
                <option value="<?=$intrant['INTRANT_MEDICAUX_ID']?>"><?=$intrant['INTRANT_MEDICAUX_DESCR']?></option> 
               <?php }
               
             }
             ?>

           </select>
           <label class="text-red"><?php echo form_error('INTRANT_ID'); ?></label>

           <label>Date de perremption</label>
          <input type="date" name="DATE_PEREMPTION" autocomplete="off" value="<?=set_value('DATE_PEREMPTION')?>" class="form-control">
          <div><?=form_error('DATE_PEREMPTION')?></div>
        </div>

        <div class="col-md-6">
           

           <label>Structure intervenants</label>
           <select name="INTERVENANT_STRUCTURE_ID" id='INTERVENANT_STRUCTURE_ID' class="form-control" onchange="get_intervenant_RH(this.value)">
             <option value="">--Structure</option>
             <?php
             foreach ($structures as $key => $value) {

                if ($value['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')) {?>
                 <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>" selected=''><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option> 
                <?php } else {?>
                 <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>"><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option> 
                <?php }
                
              } 
             ?>
           </select>
           <div><?=form_error('INTERVENANT_STRUCTURE_ID')?></div>

           <label>Intervenant RH</label>
           <select name="INTERVENANT_RH_ID" id='INTERVENANT_RH_ID' class="form-control">
             <option value="">--Intervenant</option>
           </select>
           <div><?=form_error('INTERVENANT_RH_ID')?></div>

        </div>
          
        <div class="col-md-6">
           <label>Quantité</label>
           <input type="number" name="QUANTITE" autocomplete="off" value="<?=set_value('QUANTITE')?>" class="form-control">
           <label class="text-red"><?php echo form_error('QUANTITE'); ?></label>

           <label>Prix unitaire</label>
           <input type="number" name="PRIX_UNITAIRE" autocomplete="off" value="<?=set_value('PRIX_UNITAIRE')?>" class="form-control">
           <div><?=form_error('PRIX_UNITAIRE')?></div>
        </div>

        <div class="col-md-6">
           <label>Numéro du lot</label>
          <input type="text" name="NUMERO_LOT" autocomplete="off" value="<?=set_value('NUMERO_LOT')?>" class="form-control">
          <div><?=form_error('NUMERO_LOT')?></div>
        </div>

        <div class="col-md-12">
            <button type="submit" class="btn btn-primary form-control" style="margin-top: 30px;">
              Enregistrer
            </button>
          </div>


   </form>

   <div class="col-md-12"><br><br>
    <?=$intrants?>
  </div>
</div>