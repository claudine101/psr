<div class="row">
<?php if($this->session->flashdata('sms')){
   echo $this->session->flashdata('sms');
} ?>
</div>
<div class="row">
  <legend>
    <?= $title;?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?=base_url('stock_reception/RC_Reception_Intrants/index')?>">
        <i class="fa fa-plus"></i>Nouveau
      </a>
    </div>
  </legend>
<div class="col-md-12">
    <?php echo $this->table->generate($array_reception); ?>
  </div>
  
</div>
<!-- <div class="row" style="padding: 5px;"> -->
  
<!-- </div> -->





