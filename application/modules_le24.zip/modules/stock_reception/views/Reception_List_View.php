<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url('assets/bootstrap/')?>bootstrap.min.js"></script>
<legend>RECEPTION DES INTRANTS</legend> -->
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h1 class="m-0"><?=$title?></h1>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('stock_reception/Reception')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-plus"></i>
                Nouvelle
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>
      <section class="container" >
        <!-- ************************************************************************************************** -->
        <div class="card" >
          <?=  $this->session->flashdata('message');?>
          <!-- modal INTRANT -->
          <div class="modal fade bd-example-modal-lg" id="modal_intant" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <center><h5 class="modal-title" id="titre_modal"></h5></center>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="SHOW_INTRANT"></div>
              </div>
            </div>
          </div>
          <!-- fin modal INTRANT -->
          <!-- modal comite -->
          <div class="modal fade bd-example-modal-lg" id="modal_commission" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">COMISSION DE RECEPTION</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="SHOW_COMISSION"></div>
              </div>
            </div>
          </div>
          <!-- fin modal comite -->
          <div class="container-fluid">
           <div class="col-5" style="padding: 5px;">
             <label for="PTF_ID">PTF</label>
             <select  class="form-control"  id="PTF_ID" onclick="get_list(this.value)">
              <option value="" selected="">sélectionner</option>
              <?php foreach ($ptf as $key) {
            # code...
                ?>
                <option value="<?= $key['PTF_ID'] ?> "><?= $key['PTF_NOM'] ?></option>

              <?php } ?>
            </select>
          </div> 
          <br>

          <div class="col-md-12 table-responsive">
            <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
              <thead>
                <tr>
                  <th>#</th>
                  <th>PTF</th>
                  <th>DATE</th>
                  <th>INTRANTS</th>
                  <th>COMMISSION</th>
                  <th>COMMENTAIRE</th>
                  <!-- <th>PV</th> -->

                  <th>OPTION</th>
                </tr>
              </thead>

            </table>


          </div>


        </div>
      </div>
      <!-- ********************************************************************************************** -->

      

      
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
  function show_intrant(RECEPTION_ID) {
    $("#modal_intant").modal();
    show_titre(RECEPTION_ID);
    $.ajax({
      url: '<?php echo base_url();?>stock_reception/Reception/get_intrant/',
      type: 'POST',
      dataType: "JSON",
      data: {RECEPTION_ID: RECEPTION_ID},
      beforeSend: function() {
        $('#SHOW_INTRANT').html("<center><font color='#73879C'><i class='fa fa-spinner fa-pulse fa-2x fa-fw'></i><span class='sr-only'>Loading...</span></font></center>");
      },
      success: function(data) {
        $('#SHOW_INTRANT').html(data.datas);
        dataTable('TableReceptionId');
      }
    })
  }
  function show_titre(RECEPTION_ID) {
    // body...

    
    $.post('<?php echo base_url();?>stock_reception/Reception/show_titre',
    {
      RECEPTION_ID:RECEPTION_ID,
      
    },
    function(data) 
    { 
      titre_modal.innerHTML = data;  
      $('#titre_modal').html(data);

    });  
  }
  function show_comite(RECEPTION_ID) {
    $("#modal_commission").modal();
    $.ajax({
      url: '<?php echo base_url();?>stock_reception/Reception/get_comite/',
      type: 'POST',
      dataType: "JSON",
      data: {RECEPTION_ID: RECEPTION_ID},
      beforeSend: function() {
        $('#SHOW_COMISSION').html("<center><font color='#73879C'><i class='fa fa-spinner fa-pulse fa-2x fa-fw'></i><span class='sr-only'>Loading...</span></font></center>");
      },
      success: function(data) {
        $('#SHOW_COMISSION').html(data.datas);
        dataTable('TableComiteId');
      }
    })
  }


  function dataTable(id_table) {
    $("#"+id_table).DataTable({
      "destroy" : true,
      lengthMenu: [[5, 10, 25, 50, 100, 500, 10000000], [5, 10, 25, 50, 100, 500, 'All']],
      pageLength: 5,
      "columnDefs":[{
        "targets":[],
        "orderable":false
      }],

      dom: 'Bfrtlip',
      buttons: ['excelHtml5', 'pdfHtml5', 'print'],
      language: {
        "sProcessing":     "<font color='#73879C'><i class='fa fa-spinner fa-pulse fa-2x fa-fw'></i><span class='sr-only'>Loading...</span></font>",
        "sSearch":         "Recherche",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "_START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Aucun &eacute;l&eacute;ment",
        "sInfoFiltered":   "",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      }
    });
  }
</script>
<script type="text/javascript">
  $(document).ready(function(){ 
   $("#message").delay("slow").fadeOut(3000);
   get_list();


 });
  function get_list(ID) {
  // body...
  var PTF_ID=ID;

  var row_count ="1000000";

  $("#mytable").DataTable({
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "oreder":[[ 0, 'desc' ]],
    "ajax":{
      url:"<?=base_url()?>stock_reception/Reception/liste/",
      type:"POST",
      data : {

        PTF_ID:PTF_ID,

      }
    },
    lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
    "columnDefs":[{
      "targets":[],
      "orderable":false
    }],

    dom: 'Bfrtlip',
    buttons: [
    'copy', 'csv', 'excel', 'pdf', 'print'
    ],
    language: {
      "sProcessing":     "Traitement en cours...",
      "sSearch":         "Rechercher&nbsp;:",
      "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
      "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
      "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
      "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
      "sInfoPostFix":    "",
      "sLoadingRecords": "Chargement en cours...",
      "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
      "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
      "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
      },
      "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
      }
    }

  });
}
</script>

