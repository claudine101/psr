<div class="row">
  <?php if($this->session->flashdata('sms')){
   echo $this->session->flashdata('sms');
 } ?>
</div>
<div class="row">
  <legend>
   <?= $title;?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?=base_url('stock_reception/RC_Reception_Intrants/etape1')?>">
        <i class="fa fa-plus"></i>Nouveau
      </a>
    </div>
  </legend>
  


    <section class="home-content-top">
    <div class="container">
      <!--our-quality-shadow-->
      <div class="clearfix"></div>
      <!-- <h1 class="heading1"> <?= $title;?></h1> -->
      <div class="tabbable-panel margin-tops4 ">
        <div class="tabbable-line">
          <ul class="nav nav-tabs tabtop  tabsetting">
            <li> <a href="#" data-toggle="tab"> Description de la distribution </a> </li>
            <li> <a href="#" data-toggle="tab"> Intervenant RH</a> </li>
            <li class="active"> <a href="#" data-toggle="tab"> Intrants réçus </a> </li>
          </ul>
          <div class="tab-content margin-tops">
           
            <div class="tab-pane fade active fade in" id="tb_2">
              <div class="col-md-12">
                <form action="<?= base_url('stock_reception/RC_Reception_Intrants/etape3_add/'.$RECEPTION_ID)?>" method="post">

                  <div class="col-md-6">
                   <label>Intrants</label>
                   <select name="INTRANT_ID" class="form-control">
                     <option value="">--Intrants</option>
                     <?php
                     foreach ($intrants_medicaux as $intrant) {
                       if ($intrant['INTRANT_MEDICAUX_ID']==set_value('INTRANT_ID')) {?>
                        <option value="<?=$intrant['INTRANT_MEDICAUX_ID']?>" selected=''><?=$intrant['INTRANT_MEDICAUX_DESCR']?></option> 
                        <?php } else {?>
                          <option value="<?=$intrant['INTRANT_MEDICAUX_ID']?>"><?=$intrant['INTRANT_MEDICAUX_DESCR']?></option> 
                          <?php }

                        }
                        ?>

                      </select>
                      <label class="text-red"><?php echo form_error('INTRANT_ID'); ?></label>

                      <label>Date de perremption</label>
                      <input type="date" name="DATE_PEREMPTION" id="DATE_PEREMPTION" autocomplete="off" value="<?=set_value('DATE_PEREMPTION')?>" class="form-control">
                      <div><?=form_error('DATE_PEREMPTION')?></div>
                    </div>
                    <div class="col-md-6">
                     <label>Quantité</label>
                     <input type="number" name="QUANTITE" autocomplete="off" value="<?=set_value('QUANTITE')?>" class="form-control">
                     <label class="text-red"><?php echo form_error('QUANTITE'); ?></label>

                     <label>Prix unitaire</label>
                     <input type="number" name="PRIX_UNITAIRE" min="0" max="10" autocomplete="off" value="<?=set_value('PRIX_UNITAIRE')?>" class="form-control">
                     <div><?=form_error('PRIX_UNITAIRE')?></div>
                   </div>

                   <div class="col-md-6">
                     <label>Numéro du lot</label>
                     <input type="text" name="NUMERO_LOT" autocomplete="off" value="<?=set_value('NUMERO_LOT')?>" class="form-control">
                     <div><?=form_error('NUMERO_LOT')?></div>

                   </div>

                   <div class="col-md-6">
                    <label></label>
                    <button type="submit" class="btn btn-primary form-control">
                      Enregistrer
                    </button>
                  </div>
                </form>

               <div class="col-md-12" style="margin-top:10px;">
                     <a style="color: white;text-decoration: none;" href="<?=base_url('stock_reception/RC_Reception_Intrants/etape2/'.$RECEPTION_ID)?>" class="btn btn-primary">Précédent</a>
                     <a style="text-decoration: none;color:white;float:right;" href="<?=base_url('stock_reception/RC_Reception_Intrants/listing')?>" class="btn btn-primary">Terminer</a>
              </div>

              
              <div class="col-md-12" style="margin-top:10px;">
                <?=$intrants?>
              </div>

              </div>





          </div>

          <!-- <div class="col-md-2"></div> -->

        </div>
      </div>
    </div>
  </div>
</section>

</div>


<script> 
 $(document).ready(function(){
  // get_liste();    
 $("#message").delay(2000).hide('slow');

 $('#DATE_PEREMPTION').datetimepicker({
      format: 'd-m-Y',
      //defaultDate:new Date(),
      startDate:'01/01/2020',
      //maxDate: new Date(),
      minDate: new Date()
    });

 // $('#DATE_FIN').datetimepicker({
 //      format: 'd-m-Y',
 //      //defaultDate:new Date(),
 //      startDate:'01/01/2020',
 //      //maxDate: new Date(),
 //      maxDate: new Date()
 //    });


}); 
 
  </script>





