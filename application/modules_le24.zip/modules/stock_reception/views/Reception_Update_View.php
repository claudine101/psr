<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script> -->
<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
<script src="<?=base_url('assets/bootstrap/')?>jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url('assets/bootstrap/')?>bootstrap.min.js"></script>
<legend>RECEPTION DES INTRANTS</legend> -->
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h1 class="m-0"><?=$title?></h1>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('stock_reception/Reception/listing')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list-ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <section class="container">
        <!-- ************************************************************************************************** -->
        <div class="card" style="padding: 10px;">
          <div class="container-fluid">

            <ul class="nav nav-tabs">
              <li  class="nav-item"><a id="rec" class="nav-link active" href="#">Réception</a></li>

              <li  class="nav-item"><a class="nav-link" id="intr" href="#">Intrants</a></li>
              <li  class="nav-item"><a class="nav-link" id="com_rec" href="#">Commission de réception</a></li>
            </ul>
            <div class="col-md-12" id="reception">
              <form id="myform" method="post" action="<?= base_url('stock_reception/Reception/update')?>" enctype="multipart/form-data"  >
                <input type="hidden" name="RECEPTION_ID" value="<?= $rc_reception['RECEPTION_ID'] ?>">
                <div class="form-group row">
                  <div class="col-md-6">
                    <label>PTF</label>
                    <select class="form-control" name="PTF_ID" id="PTF_ID" onchange="get_structure(this.value);getstok_dispo(this.value)" >
                      <option value="" selected="" disabled="">Sélectionner</option>

                      <?php foreach ($ptf as $key) {
            # code...
                        ?>
                        <option value="<?= $key['PTF_ID'] ?> " <?php if ($key['PTF_ID']==$rc_reception['PTF_ID']): ?>
                        selected
                        <?php endif ?>><?= $key['PTF_NOM'] ?></option>

                        <?php } ?>
                      </select>
                      <span class="text-danger" id="error_ptf"></span>
                    </div>
                    <div class="col-md-6">
                      <label>Date de réception</label>
                      <input type="date" name="RECEPTION_DATE" value="<?= $rc_reception['RECEPTION_DATE'] ?>" id="RECEPTION_DATE" class="form-control" max="<?= date('Y-m-d') ?>" min=""  >
                      <span class="text-danger" id="error_date_reception"></span>

                    </div>
                  </div>
                  <div class="row">
                    <div class="col-6">
                      <label>Scan de PV de réception</label>
                      <input type="hidden" name="PATH_SCAN_PV_RECEPTION_OLD" id="PATH_SCAN_PV_RECEPTION_OLD" class="form-control" value="<?= $rc_reception['PATH_SCAN_PV_RECEPTION'] ?>">
                      <input type="file" name="PATH_SCAN_PV_RECEPTION" id="PATH_SCAN_PV_RECEPTION" class="form-control">
                    </div>


                    <div class="col-6">
                      <label>Commentaire</label>
                      <textarea name="COMMENTAIRE" id="COMMENTAIRE" class="form-control"><?= $rc_reception['COMMENTAIRE'] ?></textarea>
                    </div>
<!--       <div class="col-md-6">
        <label>Code réception</label>
        <input type="text" name="RECEPTION_CODE" id="RECEPTION_CODE" class="form-control" readonly="">

      </div>    -->
    </div>
    <br>
    <div class="row">
      <div class="col-12">
        <button type="button" onclick="verify_input_page1_suivant()" id="btn_suivant" class="btn btn-primary btn-sm float-right">
          <b>Suivant</b>
          <i class="nav-icon fas fa-angle-double-right"></i>
        </button>
      </div>
    </div>
  </form>
</div>
<br>
<!--   <br>
  <div class="col-md-12">

       <input style="float: right;" onclick="verify_input_page1_suivant()" type="button" id="btn_suivant" value="Suivant" class="btn btn-primary">


     </div> -->
     <div id="stock_disponible" class="col-12" style="display: none;" >
      <table id='mytable_intv' class="table table-bordered table-striped table-hover" style="width: 100%;">
        <thead>
          <tr>
            <th>#</th>
            <th>INTRANT</th>
            <th>QTE.REÇUE</th>
            <th>QTE.DISPONIBLE</th>


          </tr>
        </thead></table>

      </div>
      <!-- tab2 -->
      <div class="col-md-12" id="intrant_medicaux" style="display: none;">
        <div class="row">
          <div class="col-6">
            <label>Mode réception</label>
            <select class="form-control" name="MODE_RECEPTION_ID" id="MODE_RECEPTION_ID" onchange="get_intrant_by_mode()" >
              <option value="" selected="" disabled="">Sélectionner</option>
              <?php foreach ($rc_mode_reception as $key) {
            # code...
                ?>
                <option value="<?= $key['MODE_RECEPTION_ID'] ?>" <?php if ($key['MODE_RECEPTION_ID']==set_value('MODE_RECEPTION_ID')): ?>
                selected
                <?php endif ?> ><?= $key['MODE_RECEPTION_DESCR'] ?></option>

                <?php } ?>
              </select>
              <span class="text-danger" id="error_mode_reception"></span>

            </div>
            <div class="col-6">
              <label>Intrant</label>
              <select class="form-control" name="INTRANT_MEDICAUX_ID" id="INTRANT_MEDICAUX_ID" data-live-search="true">
                <!-- <option value="" selected="" disabled="">Sélectionner</option> -->


              </select>
              <span class="text-danger" id="error_intrant" ></span>
            </div>

          </div>
          <div class="row">
            <div class="col-6">
              <label>Quantité</label>
              <input type="number" name="QUANTITE" id="QUANTITE" step="any" min="0.0001" class="form-control">
              <span class="text-danger" id="error_quantite" ></span>
            </div>
            <div class="col-6">
              <label>Coût total</label>
              <input type="number" name="PRIX_TOTAL" id="PRIX_TOTAL" step="any" min="0.0001" class="form-control">
              <span class="text-danger" id="error_prix_total" ></span>
            </div>
          </div>
          <div class="row">
            <div class="col-6">
              <label>Lot</label>
              <input type="text" name="NUMERO_LOT" id="NUMERO_LOT" class="form-control">
              <span class="text-danger" id="error_lot" ></span>
            </div>
            <div class="col-4">
              <label>Date de péremption</label>
              <input type="date" name="DATE_PEREMPTION"  id="DATE_PEREMPTION" class="form-control"  min="<?= date('Y-m-d') ?>"  >
              <span class="text-danger" id="error_date" ></span>
            </div>
            <div class="col-2" style="padding-top:30px;padding-left:-3000px;">
              <button class="btn btn-primary float-right" onclick="check_data()" >
                <i class="fa fa-plus"></i><b>Ajouter</b>
              </button>
            </div>
          </div>
          
          <br>
          <div class="row">
            <div class="col-md-12" id="carte">
            <!-- <div style="margin-top: 5px;" class="col-md-12" id="carte">
            </div> -->
            <?php

            $sql = "SELECT `RECEPTION_ID`, `INTRANT_ID`, `QUANTITE`, `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION`, `PRIX_TOTAL`, `MODE_RECEPTION_ID` FROM `rc_reception_intrant_detail` WHERE `RECEPTION_ID`=".$rc_reception['RECEPTION_ID'];
            $rc_reception_intrant_detail=$this->Modele->getRequete($sql);

            foreach ($rc_reception_intrant_detail as $key ) {
           # code...

              $MODE_RECEPTION_ID=$key['MODE_RECEPTION_ID'];
              $INTRANT_MEDICAUX_ID=$key['INTRANT_ID'];
              $QUANTITE=number_format($key['QUANTITE'],0,' ',' ');
              $PRIX_TOTAL=number_format($key['PRIX_TOTAL'],0,' ',' ');
              $NUMERO_LOT=$key['NUMERO_LOT'];
              $DATE_PEREMPTION=$key['DATE_PEREMPTION'];
              $intrant_medicaux=$this->Modele->getRequeteOne('SELECT  `INTRANT_MEDICAUX_DESCR` FROM `intrant_medicaux` WHERE intrant_medicaux.`INTRANT_MEDICAUX_ID`='.$INTRANT_MEDICAUX_ID.'');
              $rc_mode_reception=$this->Modele->getRequeteOne('SELECT  `MODE_RECEPTION_DESCR` FROM `rc_mode_reception` WHERE rc_mode_reception.`MODE_RECEPTION_ID`='.$MODE_RECEPTION_ID.'');
              $data_cart = array(
                'id'      => $NUMERO_LOT.'_'.$INTRANT_MEDICAUX_ID,
                'qty'     => 1,
                'price'   => 1,
                'name'    => 'T',
                'QUANTITE'=>$QUANTITE,
                'INTRANT_MEDICAUX_DESCR'=>$intrant_medicaux['INTRANT_MEDICAUX_DESCR'],
                'PRIX_TOTAL'=>$PRIX_TOTAL,
                'MODE_RECEPTION_ID'=>$MODE_RECEPTION_ID,
                'NUMERO_LOT'=>$NUMERO_LOT,
                'DATE_PEREMPTION'=>$DATE_PEREMPTION,
                'INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID,
                'MODE_RECEPTION_DESCR'=>$rc_mode_reception['MODE_RECEPTION_DESCR'],
                'typecartitem'  =>'INTRANT'
              );
              $this->cart->insert($data_cart);

            }

            $html = null;
            $i = 0;
            $j=1;
            $html .='<table class="table table-bordered table-striped table-hover table-condensed table-sm">

            <tr class="">
            <th style="background:#F5F5F5">#</th>
            <th style="background:#F5F5F5">MODE</th>
            <th style="background:#F5F5F5">LOT</th>
            <th style="background:#F5F5F5">INTRANT</th>
            <th style="background:#F5F5F5">PEREMPTION</th>
            <th style="background:#F5F5F5">QUANTITE</th>

            <th style="background:#F5F5F5">C.T</th>
            <th style="background:#F5F5F5">SUPPRIMER</th>
            </tr>' ;
            foreach ($this->cart->contents() as $items):


             if(preg_match("/INTRANT/", $items['typecartitem'])){
             // $som=$som+$items['TOTAL'];
              $html .='<tr class="">' ;
              $html .='<td><font >'.$j.'</font></td>
              <td><font >'.$items['MODE_RECEPTION_DESCR'].'</font></td>
              <td><font >'.$items['NUMERO_LOT'].'</font></td>
              <td style="width: 70px;"><font >'.$items['INTRANT_MEDICAUX_DESCR'].'</font></td>
              <td style="width: 15px;"><font >'.date('d-m-Y',strtotime($items['DATE_PEREMPTION'])).'</font></td>
              <td><font >'.$items['QUANTITE'].'</font></td>
              <td><font >'.$items['PRIX_TOTAL'].'</font></td>

              <td style="width: 5px;">
              <input type="hidden" id="rowid'.$j.'" value='.$items['rowid'].'>
              <button class="btn btn-danger btn-xs" type="button" onclick="remove_ct('.$j.')">X</button>
              </td>' ;
              $html .='</tr>' ;
              $i++;
              $j++;
            }


          endforeach;

          $html .='</table>' ;

          echo $html;


          ?></div></div>



          <div class="row" >
            <div class="col-6">
              <button type="button" onclick="return_on_page1()" id="btn_precedent" class="btn btn-primary btn-sm">
                <i class="nav-icon fas fa-angle-double-left"></i>
                <b>Précédent</b>
              </button>
            </div>
            <div class="col-6">
              <button type="button" onclick="verify_input_page2_suivant()" id="btn_suivant2" class="btn btn-primary btn-sm float-right">
                <b>Suivant</b>
                <i class="nav-icon fas fa-angle-double-right"></i>
              </button>
            </div>
          </div>
        </div>



        <!-- tab3 -->
        <div class="col-md-12" id="comite_reception" style="display: none;">
          <div class="row">
            <div class="col-6">
              <label>Intervenant</label>
              <select class="form-control selectpicker" name="INTERVENANT_STRUCTURE_ID" id="INTERVENANT_STRUCTURE_ID" onchange="get_structure_rh(this.value)" data-live-search="true">
              </select>
              <span class="text-danger" id="error_structure"></span>
            </div>

            <div class="col-6">
              <label>Membre</label>
              <select class="form-control selectpicker" name="INTERVENANT_RH_ID" id="INTERVENANT_RH_ID" data-live-search="true" onchange="check_data_rh(this.value);add_new_rh(this.value);" >
                <option value="">Sélectionner</option>
                <!-- <option value="-1">Membre non listé</option>  ntidukeneye kwongeramwo abantu kandi twarakoze kera pv bariko-->

              </select>

            </div>
          </div>
          <br>
<!--     <div class="form-group">

      <div class="col-md-10">
        <label>Observation</label>
        <textarea name="OBSERVATION" id="OBSERVATION" class="form-control"></textarea>

      </div>

      <div class="col-md-1">
        <label>Ajouter</label>
        <button class="btn" ><i class="fa fa-plus"></i></button>

      </div>
    </div> -->
    <div class="row">
      <div style="margin-top: 5px;" class="col-md-12" id="carte_rh">
        <?php

        $sq = "SELECT `INTERVENANT_RH_ID`,`INTERVENANT_STRUCTURE_ID` FROM `rc_equipe_reception` WHERE `RECEPTION_ID`=".$rc_reception['RECEPTION_ID'];

        $rc_equipe_reception=$this->Modele->getRequete($sq);
        foreach ($rc_equipe_reception as  $value) {

          $INTERVENANT_STRUCTURE_ID=$value['INTERVENANT_STRUCTURE_ID'];
          $INTERVENANT_RH_ID=$value['INTERVENANT_RH_ID'];
          $structure_rh=$this->Modele->getRequeteOne("SELECT `INTERVENANT_RH_ID`,CONCAT(NOM,' ',PRENOM) NAME FROM `intervenants_rh` WHERE `INTERVENANT_RH_ID`=".$INTERVENANT_RH_ID."");

          $intervenants_structure=$this->Modele->getRequeteOne('SELECT  `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE INTERVENANT_STRUCTURE_ID='.$INTERVENANT_STRUCTURE_ID.'');

          $data_cart = array(
            'id'      => $INTERVENANT_STRUCTURE_ID."_".$INTERVENANT_RH_ID,
            'qty'     => 1,
            'price'   => 1,
            'name'    => 'Y',
            'INTERVENANT_STRUCTURE_DESCR'=>$intervenants_structure['INTERVENANT_STRUCTURE_DESCR'],
            'NOM'=>$structure_rh['NAME'],
            'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,
            'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
            'typecartitem'  =>'RH'
          );
          $this->cart->insert($data_cart);
        }
        $html = null;
        $i = 1;
        $j=1;
        $html .='<table class="table table-bordered table-striped table-hover table-condensed table-sm">

        <tr class="">
        <th style="background:#F5F5F5">#</th>
        <th style="background:#F5F5F5">INTERVENANT</th>
        <th style="background:#F5F5F5">MEMBRE</th>
        <th style="background:#F5F5F5">Supprimer</th>
        </tr>' ;
        foreach ($this->cart->contents() as $items):


         if(preg_match("/RH/", $items['typecartitem'])){
     // $som=$som+$items['TOTAL'];
          $html .='<tr class="">' ;
          $html .='<td><font >'.$j.'</font></td>
          <td><font >'.$items['INTERVENANT_STRUCTURE_DESCR'].'</font></td>
          <td><font >'.$items['NOM'].'</font></td>


          <td>
          <input type="hidden" id="rowid2'.$j.'" value='.$items['rowid'].'>
          <button class="btn btn-danger btn-xs" type="button" onclick="remove_ct_rh('.$j.')">X</button>
          </td>' ;
          $html .='</tr>' ;
          $i++;
          $j++;

        }


      endforeach;

      $html .='</table>' ;

      echo $html;

      ?></div>

      <br>
<!--   <div class="col-md-12" style="padding-top: 5px;">
       <input style="float: left;" type="button" onclick="return_on_page2()" id="btn_precedent2" value="Précédent" class="btn btn-primary">
       <input style="float: right;display: block;" onclick="submit_form();" type="button" id="btn_enregistrer" value="Modifier" class="btn btn-primary">


     </div> -->
     <!-- <div class="row" >
      <div class="col-6">
        <button type="button" onclick="return_on_page2()" id="btn_precedent2" class="btn btn-primary btn-sm">
          <i class="nav-icon fas fa-angle-double-left"></i>
          Précédent
        </button>
      </div>
      <div class="col-6">
        <button style="display: block;" type="button" onclick="submit_form()" id="btn_enregistrer" class="btn btn-primary btn-sm float-right">
          <i class="nav-icon fas fa-save"></i>
          Enregistrer
        </button>
      </div>
    </div> -->



  </div>
  <div class="row" >
    <div class="col-6">
      <button type="button" onclick="return_on_page2()" id="btn_precedent2" class="btn btn-primary btn-sm">
        <i class="nav-icon fas fa-angle-double-left"></i>
        <b>Précédent</b>
      </button>
    </div>
    <div class="col-6">
      <button style="display: block;" type="button" onclick="submit_form()" id="btn_enregistrer" class="btn btn-primary btn-sm float-right">
        <i class="nav-icon fas fa-edit"></i>
        <b>Modifier</b>
      </button>
    </div>
  </div>
  <!--  -->
  <!-- Large modal -->


  <div class="modal fade bd-example-modal-lg" id="add_new_rh" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="add_new_rh">Nouveau RH</h4>
            <button type="button" onclick="get_structure_rh();vider_structure();" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="container-fluid" style="padding: 20px;">
            <center><span id="message_retour"></span></center>
            <div class="col-md-12">
              <form action="" method="post">
               <div class="row">
                <div class="col-md-6">
                 <label>Nom</label>
                 <input type="text" class="form-control" name="nom" id="nom" autofocus="">
                 <label class="text-danger" id="error_nom"></label>
               </div>
               <div class="col-md-6">
                 <label>Prénom</label>
                 <input type="text" class="form-control" name="prenom" id="prenom">
                 <label class="text-danger" id="error_prenom"></label>
               </div>
             </div>

             <div class="row">
           <div class="col-md-6">
             <label>Sexe</label>
             <select class="form-control" name="interv_sexe" id="interv_sexe">
              <option value="" selected="">Sélectionner</option>
              <?php foreach ($admin_interv_sexe as $value) {
                if (set_value('interv_sexe')==$value['SEXE_ID']) {  ?>
                  <option selected value="<?= $value['SEXE_ID'];?>">
                    <?= $value['SEXE_DESCR'];?>
                  </option>
                  <?php  } else {  ?>
                    <option value="<?= $value['SEXE_ID'];?>">
                      <?= $value['SEXE_DESCR'];?>
                    </option>
                    <?php  }

                  }  ?>
                </select>
                <label class="text-danger" id="error_sexe"></label>
              </div>
              <div class="col-md-6">
               <label>Tél</label>
               <input type="number"  class="form-control" name="tel" id="tel">
               <label class="text-danger" id="error_tel1"></label>
             </div>

           </div>

           <div class="row">
            <div class="col-md-6">
             <label>Email</label>
             <input type="text"  class="form-control" name="email" id="email">
             <label class="text-danger" id="error_email"></label>
           </div>

            </div>
            <input type="hidden" name="structure" id="structure">
            <div class="row">
              <div class="col-md-3">
              </div>
              <div class="col-md-6">
                <button type="button" id="btn_new_rh" class="btn btn-primary btn-block center" style="margin-top: 25px;" onclick="send_new_rh()">
                  Enregistrer
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<!-- ********************************************************************************************** -->




</section>
<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
  $(document).ready(function () {

    var PTF_ID=$('#PTF_ID').val();
    getstok_dispo(PTF_ID);
    get_structure(PTF_ID);
 // get_structure_rh();
 get_intrant_by_mode();

});
  function get_structure(STRUCTURE_ID)
  {
    var INTERVENANT_STRUCTURE_ID=STRUCTURE_ID;

    $.post('<?php echo base_url();?>stock_reception/Reception/get_structure/',
    {
      INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID

    },
    function(data)
    {
      INTERVENANT_STRUCTURE_ID.innerHTML = data;
      $('#INTERVENANT_STRUCTURE_ID').html(data);

   // $('#INTERVENANT_STRUCTURE_ID').selectpicker('refresh');
 });

  }

//find rh en fonction des structure
function get_structure_rh(id=0)
{
  var structure=$('#structure').val();
  var ID=$('#INTERVENANT_STRUCTURE_ID').val();
  var INTERVENANT_STRUCTURE_ID=0;
  if (ID!="") {
    INTERVENANT_STRUCTURE_ID=ID;
  }
  if (structure!="") {
    INTERVENANT_STRUCTURE_ID=structure;
  }
  $.post('<?php echo base_url();?>stock_reception/Reception/get_structure_rh/',
  {
    INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID

  },
  function(data)
  {
    INTERVENANT_RH_ID.innerHTML = data;
    $('#INTERVENANT_RH_ID').html(data);

    //$('#INTERVENANT_RH_ID').selectpicker('refresh');
  });

}
//find intrant en fonction de ptf
function get_intrant_by_mode()
{
  var PTF_ID=$('#PTF_ID').val();
  var MODE_RECEPTION_ID=$('#MODE_RECEPTION_ID').val();

  $.post('<?php echo base_url();?>stock_reception/Reception/get_intrant_by_mode/',
  {
    PTF_ID:PTF_ID,
    MODE_RECEPTION_ID

  },
  function(data)
  {
    INTRANT_MEDICAUX_ID.innerHTML = data;
    $('#INTRANT_MEDICAUX_ID').html(data);

    //$('#INTRANT_MEDICAUX_ID').selectpicker('refresh');
  });

}
function check_data(){

  var MODE_RECEPTION_ID=Number($('#MODE_RECEPTION_ID').val());
  var INTRANT_MEDICAUX_ID=Number($('#INTRANT_MEDICAUX_ID').val());
  var QUANTITE=$('#QUANTITE').val();
  var NUMERO_LOT=$('#NUMERO_LOT').val();

  var DATE_PEREMPTION=$('#DATE_PEREMPTION').val();
  var PRIX_TOTAL=$('#PRIX_TOTAL').val();




  if(INTRANT_MEDICAUX_ID>0 && QUANTITE>0 && PRIX_TOTAL>0 && NUMERO_LOT!='' && DATE_PEREMPTION!='' && MODE_RECEPTION_ID>0 )
  {
   $('#btn_suivant2').attr('disabled', false);
         // document.getElementById('ID_DISTRIBUTEUR').disabled=true;
         $.post('<?php echo base_url();?>stock_reception/Reception/add_cart_data_intrant',
         {
          INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
          QUANTITE:QUANTITE,
          NUMERO_LOT:NUMERO_LOT,
          DATE_PEREMPTION:DATE_PEREMPTION,
          PRIX_TOTAL:PRIX_TOTAL,
          MODE_RECEPTION_ID:MODE_RECEPTION_ID

        },
        function(data)
        {

          carte.innerHTML = data;
          $('#carte').html(data);
          $('#QUANTITE').val('');
          $('#NUMERO_LOT').val('');
          $('#PRIX_TOTAL').val('');
          $('#DATE_PEREMPTION').val('');
          $('#INTRANT_MEDICAUX_ID').val('');
          $('#error_intrant').html('');
          $('#error_quantite').html('');
          $('#error_lot').html('');
          $('#error_prix_total').html('');
          $('#error_date').html('');
          $('#btn_suivant2').show();

        }
        );

       }

       if (INTRANT_MEDICAUX_ID<0 || INTRANT_MEDICAUX_ID=='') {

        $('#error_intrant').html('Champ obligatoire');

      }else{
        $('#error_intrant').html('');
      }


      if (QUANTITE<0 || QUANTITE=='') {

        $('#error_quantite').html('Champ obligatoire');

      }else{
        $('#error_quantite').html('');
      }

      if (PRIX_TOTAL<0 || PRIX_TOTAL=='') {

        $('#error_prix_total').html('Champ obligatoire');

      }else{
        $('#error_prix_total').html('');
      }

      if (NUMERO_LOT=='') {

        $('#error_lot').html('Champ obligatoire');

      }else{
        $('#error_lot').html('');
      }

      if (DATE_PEREMPTION=='') {
        $('#error_date').html('Champ obligatoire');

      }else{
        $('#error_date').html('');
      }
      if (MODE_RECEPTION_ID<0 || MODE_RECEPTION_ID=="" ) {
        $('#error_mode_reception').html('Champ obligatoire');

      }else{
        $('#error_mode_reception').html('');
      }

    }

    function remove_ct(id_row){

      var rowid=$('#rowid'+id_row).val();
      $.post('<?php echo base_url();?>stock_reception/Reception/remove_cart',
      {
        rowid:rowid

      },
      function(data)
      {
        carte.innerHTML = data;
        $('#carte').html(data);
        if (data=='') {
          $('#btn_suivant2').hide();
        }
      });

    }
    /**************************************RH**********************************************/
    function check_data_rh(id_rh,structure=0){
      var INTERVENANT_STRUCTURE_ID=0;
      var INTERVENANT_RH_ID=Number(id_rh);
      if (Number(structure)>0) {
        INTERVENANT_STRUCTURE_ID=Number(structure);
      }else{
        INTERVENANT_STRUCTURE_ID=Number($('#INTERVENANT_STRUCTURE_ID').val());
      }


      if(INTERVENANT_RH_ID>0 && INTERVENANT_STRUCTURE_ID>0 )
      {
         // document.getElementById('ID_DISTRIBUTEUR').disabled=true;
         $.post('<?php echo base_url();?>stock_reception/Reception/add_cart_data_rh',
         {
          INTERVENANT_RH_ID:INTERVENANT_RH_ID,
          INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,

        },
        function(data)
        {

          carte_rh.innerHTML = data;
          $('#carte_rh').html(data);
          $('#btn_enregistrer').show();
          $('#INTERVENANT_STRUCTURE_ID').val('');
          $('#INTERVENANT_RH_ID').val('');
          $('#error_structure').html('');
                 // $('#MEDICAMENT_ID').selectpicker('val','');

               }
               );

       }

       if (INTERVENANT_STRUCTURE_ID<0 || INTERVENANT_STRUCTURE_ID=='') {

        $('#error_structure').html('Champ obligatoire');

      }else{
        $('#error_structure').html('');
      }

    }

    function remove_ct_rh(id_row){

      var rowid=$('#rowid2'+id_row).val();
      $.post('<?php echo base_url();?>stock_reception/Reception/remove_cart_rh',
      {
        rowid:rowid

      },
      function(data)
      {
        carte_rh.innerHTML = data;
        $('#carte_rh').html(data);
        if (data=='') {
          $('#btn_enregistrer').hide();
        }
      });
    }
    /**********************************ADD NEW RH*************************************************/
    function add_new_rh(test_id) {
  // body...
  var INTERVENANT_STRUCTURE_ID=$('#INTERVENANT_STRUCTURE_ID').val();
  if (Number(test_id)==-1 && Number(INTERVENANT_STRUCTURE_ID)>0) {
    $('#structure').val(INTERVENANT_STRUCTURE_ID);
    $('#add_new_rh').modal({backdrop:false});
    $('#nom').focus();
  }
}
function send_new_rh() {
  // body...
  var nom=$('#nom').val();
  var prenom=$('#prenom').val();
  var tel=$('#tel').val();
  var autre_tel=$('#autre_tel').val();
  var email=$('#email').val();
  var interv_sexe=$('#interv_sexe').val();
  var structure=$('#structure').val();
  if (nom=="") {
    $('#error_nom').html('Champ obligatoire');

  }else{
    $('#error_nom').html('');
  }
  if (prenom=="") {
    $('#error_prenom').html('Champ obligatoire');

  }else{
    $('#error_prenom').html('');
  }
  if (tel=="") {
    $('#error_tel1').html('Champ obligatoire');

  }else{
    $('#error_tel1').html('');
  }
  if (email=="") {
    $('#error_email').html('Champ obligatoire');

  }else{


    $('#error_email').html('');
  }
  if (interv_sexe=="") {
    $('#error_sexe').html('Champ obligatoire');

  }else{
    $('#error_sexe').html('');
  }
  if (email!="") {
   var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

   var test_email=1;

    if(!emailReg.test(email)){
      $('#error_email').html('Email invalide!');
     test_email=0
    }else{
      $('#error_email').html('');
    }
  }

  if (interv_sexe!="" && tel!="" && nom!="" && prenom!="" && email!="" && structure!="" && test_email==1) {

    $('#btn_new_rh').attr('disabled', true);

    $.post('<?php echo base_url();?>stock_reception/Reception/add_new_rh',
    {

      nom:nom,
      prenom:prenom,
      tel:tel,
      autre_tel:autre_tel,
      email:email,
      interv_sexe:interv_sexe,
      structure:structure

    },
    function(data)
    {

      var msrt=data.split("@",2);
      if (Number(msrt[1])!=0) {
        get_structure_rh();
        vider_structure();
        check_data_rh(msrt[1],structure);
        $('#nom').val("");
        $('#prenom').val("");
        $('#tel').val("");
        $('#autre_tel').val("");
        $('#email').val("");
        $('#interv_sexe').val("");
        $('#add_new_rh').modal('hide');
      }

      message_retour.innerHTML = msrt[0];
      $('#message_retour').html(msrt[0]);
      $('#btn_new_rh').attr('disabled', false);

    });

  }else{
    $('#btn_new_rh').attr('disabled', false);
  }

}
function vider_structure() {
  // body...
  $('#structure').val('');
}
/*******************************************************************/
function verify_input_page1_suivant() {
  // body...
  var PTF_ID=Number($('#PTF_ID').val());
  var MODE_RECEPTION_ID=Number($('#MODE_RECEPTION_ID').val());
  var RECEPTION_DATE=$('#RECEPTION_DATE').val();
  if (PTF_ID<0 || PTF_ID=="" ) {
    $('#error_ptf').html('Champ obligatoire');

  }else{
    $('#error_ptf').html('');
  }



  if (RECEPTION_DATE<0 || RECEPTION_DATE=="" ) {
    $('#error_date_reception').html('Champ obligatoire');

  }else{
    $('#error_date_reception').html('');
  }
  if (PTF_ID>0 &&  RECEPTION_DATE!="") {
   $('#intrant_medicaux').show();
   $('#reception').hide();
   $('#comite_reception').hide();
   $('#btn_suivant').hide();
     //$('#btn_suivant2').attr('disabled',true);
     document.getElementById("intr").className = "nav-link active";
     document.getElementById("rec").className = "nav-link";
     document.getElementById("com_rec").className = "nav-link";
     $('#stock_disponible').hide();



   }
 }
 function return_on_page1() {
  // body...
  $('#intrant_medicaux').hide();
  $('#reception').show();
  $('#comite_reception').hide();
  $('#btn_suivant').show();
  document.getElementById("intr").className = "nav-link";
  document.getElementById("rec").className = "nav-link active";
  document.getElementById("com_rec").className = "nav-link";
  $('#stock_disponible').show();

}

function verify_input_page2_suivant() {
  // body...
  $('#intrant_medicaux').hide();
  $('#reception').hide();
  $('#comite_reception').show();
  $('#btn_suivant').hide();
  document.getElementById("intr").className = "nav-link";
  document.getElementById("rec").className = "nav-link";
  document.getElementById("com_rec").className = "nav-link active";
  $('#stock_disponible').hide();


}
function return_on_page2() {
  // body...
  $('#intrant_medicaux').show();
  $('#reception').hide();
  $('#comite_reception').hide();
  $('#btn_suivant').hide();
  $('#btn_suivant2').show();
  document.getElementById("intr").className = "nav-link active";
  document.getElementById("rec").className = "nav-link";
  document.getElementById("com_rec").className = "nav-link";
  $('#stock_disponible').hide();

}
function submit_form(argument) {
  // body...
  myform.submit();
}
function getstok_dispo(ID) {
  // body...
  $('#stock_disponible').show();
  var PTF_ID=ID;
  var row_count ="1000000";
  $('#mytable_intv').DataTable( {
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "oreder":[[ 0, 'desc' ]],
    "ajax":{
      url:"<?=base_url()?>stock_reception/Reception/liste_intervenant/",
      type:"POST",
      data : {

       PTF_ID:PTF_ID,


     }
   },
   lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
   pageLength: 10,
   "columnDefs":[{
    "targets":[],
    "orderable":false
  }],
  buttons: [
  'copy', 'csv', 'excel', 'pdf', 'print'
  ],
  language: {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
      "sFirst":      "Premier",
      "sPrevious":   "Pr&eacute;c&eacute;dent",
      "sNext":       "Suivant",
      "sLast":       "Dernier"
    },
    "oAria": {
      "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
      "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    }
  }
} );
}
</script>
