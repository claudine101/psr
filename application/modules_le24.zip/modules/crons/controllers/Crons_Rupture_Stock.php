<?php
/**
* @author NSHIMIRIMANA REVERIEN

*/
class Crons_Rupture_Stock extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		


		$get_mail_minisante=$this->Modele->getRequete("SELECT intv.EMAIL FROM intervenants_structure intv JOIN type_intervenants_structures typ ON typ.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE 'MINISANTE'");

		foreach ($get_mail_minisante as $key) {
			$EMAIL_CC_DODS_PNILP[]=$key['EMAIL'];
			
		}

		// print_r($EMAIL_CC_DODS_PNILP);

		$requete_principal=$this->Modele->getRequete("SELECT sti.INTERVENANT_STRUCTURE_ID,sti.INTRANT_ID,sti.QUANTITE,intv.INTERVENANT_STRUCTURE_DESCR,intv.EMAIL,intras.INTRANT_MEDICAUX_DESCR,typi.TYPE_INTERVENANT_STRUCTURE_ID,typi.CODE_STRUCTURE FROM stock_intervenat sti JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=sti.INTERVENANT_STRUCTURE_ID JOIN type_intervenants_structures typi ON typi.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID JOIN intrant_medicaux intras ON intras.INTRANT_MEDICAUX_ID=sti.INTRANT_ID");

		if (!empty($requete_principal))
		{
			foreach ($requete_principal as $key) {


				$check_elmnt_existe=$this->Modele->getRequete("SELECT `ID_STOCK_RUPTURE_TICKET`, `INTERVENANT_STRUCTURE_ID`, `INTRANT_ID`, `QUANTITE_DISPONIBLE`, `QUANTITE_SEUIL`, `DESCRIPTION_TICKET`, `USER_ID`, `ID_STATUT_TICKET` FROM `stock_rupture_ticket` WHERE INTERVENANT_STRUCTURE_ID=".$key['INTERVENANT_STRUCTURE_ID']." AND  INTRANT_ID=".$key['INTRANT_ID']);

				// print_r($check_elmnt_existe);die();



				if ($key['CODE_STRUCTURE']=="CAMEBU") 
				{
					
					$SEUIL_QTE_CAMEBU=$this->mylibrary->get_valeur_mensuelle_camebu($key['INTRANT_ID']);
					$QTE_DISPONIBLE=$key['QUANTITE'];

					if ($QTE_DISPONIBLE==$SEUIL_QTE_CAMEBU) 
					{


						$INTRANT_ID=$key['INTRANT_ID'];

						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_CAMEBU;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="La quantité disponible est égale à la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_CAMBEBU=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est presque épuisé la quantité disponible est à la quantité disponible.<br>Quantité disponible est:<b>".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);

						// foreach ($check_elmnt_existe as $key_value) 
						// {
						// 	if ($key_value['QUANTITE_SEUIL'] != $QUANTITE_SEUIL && $key_value['INTERVENANT_STRUCTURE_ID']!=$INTERVENANT_STRUCTURE_ID && $key_value['INTRANT_ID']!=$INTRANT_ID && ($key['ID_STATUT_TICKET']!=-1 || $key['ID_STATUT_TICKET']==3) && $key_value['QUANTITE_DISPONIBLE']!=$QUANTITE_DISPONIBLE && $key_value['USER_ID']!=-1) 
						// 	{
								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_CAMBEBU,'ETAT DU STOCK CAMEBU',$EMAIL_CC,$MESSAGE,array());
						// 	}
						// }

						


					}elseif ($QTE_DISPONIBLE>$SEUIL_QTE_CAMEBU) {
						

						$INTRANT_ID=$key['INTRANT_ID'];	
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_CAMEBU;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="La quantité disponible est supérieure à la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_CAMBEBU=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est en bonne état.<br><b>La quantité disponible est :<b>".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);





						// foreach ($check_elmnt_existe as $key_value) 
						// {
						// 	if ($key_value['QUANTITE_SEUIL'] != $QUANTITE_SEUIL && $key_value['INTERVENANT_STRUCTURE_ID']!=$INTERVENANT_STRUCTURE_ID && $key_value['INTRANT_ID']!=$INTRANT_ID && ($key['ID_STATUT_TICKET']!=-1 || $key['ID_STATUT_TICKET']==3) && $key_value['QUANTITE_DISPONIBLE']!=$QUANTITE_DISPONIBLE && $key_value['USER_ID']!=-1) 
						// 	{
								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_CAMBEBU,'ETAT DU STOCK CAMEBU',$EMAIL_CC,$MESSAGE,array());
						// 	}
						// }




						// $ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
						// $this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

						// $array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
						// $this->Modele->create('stock_rupture_ticket_historique',$array_historique);
						// $this->notifications->send_mail($EMAIL_CAMBEBU,'ETAT DU STOCK CAMEBU',$EMAIL_CC,$MESSAGE,array());

					}elseif ($QTE_DISPONIBLE<$SEUIL_QTE_CAMEBU) {
						
						$INTRANT_ID=$key['INTRANT_ID'];
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_CAMEBU;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="Le stock est en dessous de la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_CAMBEBU=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est en dessous du quantité seuil,<br>.<b>La quantité disponible est :".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);


						
								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_CAMBEBU,'ETAT DU STOCK CAMEBU',$EMAIL_CC,$MESSAGE,array());


								// verification  si l'etat si est 3 creer un ticket

								$ticket_ferme_sans_reponse=$this->Modele->getRequete("SELECT `ID_STOCK_RUPTURE_TICKET`, `INTERVENANT_STRUCTURE_ID`, `INTRANT_ID`, `QUANTITE_DISPONIBLE`, `QUANTITE_SEUIL`, `DESCRIPTION_TICKET`, `USER_ID`, `ID_STATUT_TICKET` FROM `stock_rupture_ticket` WHERE INTERVENANT_STRUCTURE_ID=".$INTERVENANT_STRUCTURE_ID);

								foreach ($ticket_ferme_sans_reponse as $tci) 
								{
									if ($tci['ID_STATUT_TICKET']==3 && $QUANTITE_SEUIL==$tci['QUANTITE_SEUIL']) 
									{
										$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								        $this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								        $array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								        $this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								        $this->notifications->send_mail($EMAIL_CAMBEBU,'ETAT DU STOCK CAMEBU',$EMAIL_CC,$MESSAGE,array());
								    }
								}

								
						

					}


				}




				// *********************************************************BDS*************************************************



				if ($key['CODE_STRUCTURE']=="BDS") 
				{
					
					$SEUIL_QTE_BDS=$this->mylibrary->get_valeur_mensuelle($key['INTERVENANT_STRUCTURE_ID'],$key['INTRANT_ID']);
					$QTE_DISPONIBLE=$key['QUANTITE'];

					$EMAIL_CAMBEBU=$this->Modele->getRequeteOne("SELECT intv.EMAIL FROM intervenants_structure intv JOIN type_intervenants_structures typ ON typ.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE 'CAMEBU'");

					$EMAIL_CC_DODS_PNILP[]=$EMAIL_CAMBEBU['EMAIL'];


					if ($QTE_DISPONIBLE==$SEUIL_QTE_BDS) 
					{


						$INTRANT_ID=$key['INTRANT_ID'];

						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_BDS;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="La quantité disponible est égale à la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_BDS=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est presque épuisé la quantité disponible est à la quantité disponible.<br>Quantité disponible est:<b>".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);


						
								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_BDS,'ETAT DU STOCK BDS',$EMAIL_CC,$MESSAGE,array());

						



					}elseif ($QTE_DISPONIBLE>$SEUIL_QTE_BDS) {
						

						$INTRANT_ID=$key['INTRANT_ID'];	
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_BDS;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="La quantité disponible est supérieure à la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_BDS=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est en bonne état.<br><b>La quantité disponible est :<b>".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);


								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_BDS,'ETAT DU STOCK CAMEBU',$EMAIL_CC,$MESSAGE,array());
						

					}elseif ($QTE_DISPONIBLE<$SEUIL_QTE_BDS) {
						
						$INTRANT_ID=$key['INTRANT_ID'];
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_BDS;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="Le stock est en dessous de la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_BDS=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est en dessous du quantité seuil,<br>.<b>La quantité disponible est :".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);




								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_BDS,'ETAT DU STOCK BDS',$EMAIL_CC,$MESSAGE,array());

								// verification  si l'etat si est 3 creer un ticket

								$ticket_ferme_sans_reponse=$this->Modele->getRequete("SELECT `ID_STOCK_RUPTURE_TICKET`, `INTERVENANT_STRUCTURE_ID`, `INTRANT_ID`, `QUANTITE_DISPONIBLE`, `QUANTITE_SEUIL`, `DESCRIPTION_TICKET`, `USER_ID`, `ID_STATUT_TICKET` FROM `stock_rupture_ticket` WHERE INTERVENANT_STRUCTURE_ID=".$INTERVENANT_STRUCTURE_ID);

								foreach ($ticket_ferme_sans_reponse as $tci) 
								{
									if ($tci['ID_STATUT_TICKET']==3 && $QUANTITE_SEUIL==$tci['QUANTITE_SEUIL']) 
									{
										$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								        $this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								        $array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								        $this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								        $this->notifications->send_mail($EMAIL_BDS,'ETAT DU STOCK BDS',$EMAIL_CC,$MESSAGE,array());
								    }
								}
						


						
					}


				}









				// ********************************************************FIN BDS************************************************
				// *******************************************************CDS*****************************************************

				


				if ($key['CODE_STRUCTURE']=="CDS") 
				{
					
					$SEUIL_QTE_CDS=$this->mylibrary->get_valeur_mensuelle($key['INTERVENANT_STRUCTURE_ID'],$key['INTRANT_ID']);
					$QTE_DISPONIBLE=$key['QUANTITE'];

					$EMAIL_CAMBEBU=$this->Modele->getRequeteOne("SELECT intv.EMAIL FROM intervenants_structure intv JOIN type_intervenants_structures typ ON typ.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE 'CAMEBU'");

					$EMAIL_BDS=$this->Modele->getRequeteOne("SELECT intv.EMAIL FROM intervenants_structure intv JOIN type_intervenants_structures typ ON typ.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE 'BDS'");



					$EMAIL_CC_DODS_PNILP[]=$EMAIL_CAMBEBU['EMAIL'];
					$EMAIL_CC_DODS_PNILP[]=$EMAIL_BDS['EMAIL'];

					// print_r($key['EMAIL']);die();


					if ($QTE_DISPONIBLE==$SEUIL_QTE_CDS) 
					{

						$INTRANT_ID=$key['INTRANT_ID'];
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_CDS;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="La quantité disponible est égale à la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_CDS=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est presque épuisé la quantité disponible est à la quantité disponible.<br>Quantité disponible est:<b>".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);


								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_CDS,'ETAT DU STOCK CDS',$EMAIL_CC,$MESSAGE,array());
						
						


					}elseif ($QTE_DISPONIBLE>$SEUIL_QTE_CDS) {
						

						$INTRANT_ID=$key['INTRANT_ID'];	
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_CDS;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="La quantité disponible est supérieure à la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_CDS=$key['EMAIL'];
						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est en bonne état.<br><b>La quantité disponible est :<b>".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);


								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_CDS,'ETAT DU STOCK CDS',$EMAIL_CC,$MESSAGE,array());
						





					}elseif ($QTE_DISPONIBLE<$SEUIL_QTE_CDS) {
						
						$INTRANT_ID=$key['INTRANT_ID'];
						$QUANTITE_DISPONIBLE=$QTE_DISPONIBLE;
						$QUANTITE_SEUIL=$SEUIL_QTE_CDS;
						$INTERVENANT_STRUCTURE_ID=$key['INTERVENANT_STRUCTURE_ID'];
						$DESCRIPTION_TICKET="Le stock est en dessous de la quantité seuil";


					// NOTIFICATIONS INFOS
						$EMAIL_CDS=$key['EMAIL'];

					// print_r($EMAIL_CDS);die();

						$EMAIL_CC=$EMAIL_CC_DODS_PNILP;
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock est en dessous du quantité seuil,<br>.<b>La quantité disponible est :".$QUANTITE_DISPONIBLE."</b>";

						$array_stock_rupture_tick=array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_DISPONIBLE'=>$QUANTITE_DISPONIBLE,'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

						$array_notification_rupture_seuil=array('MESSAGE'=>$MESSAGE,'INTRANT_ID'=>$INTRANT_ID,'QUANTITE_RESTANT'=>$QUANTITE_DISPONIBLE,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID);


								$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								$this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								$this->notifications->send_mail($EMAIL_CDS,'ETAT DU STOCK CDS',$EMAIL_CC,$MESSAGE,array());

								

								// verification  si l'etat si est 3 creer un ticket

								$ticket_ferme_sans_reponse=$this->Modele->getRequete("SELECT `ID_STOCK_RUPTURE_TICKET`, `INTERVENANT_STRUCTURE_ID`, `INTRANT_ID`, `QUANTITE_DISPONIBLE`, `QUANTITE_SEUIL`, `DESCRIPTION_TICKET`, `USER_ID`, `ID_STATUT_TICKET` FROM `stock_rupture_ticket` WHERE INTERVENANT_STRUCTURE_ID=".$INTERVENANT_STRUCTURE_ID);

								foreach ($ticket_ferme_sans_reponse as $tci) 
								{
									if ($tci['ID_STATUT_TICKET']==3 && $QUANTITE_SEUIL==$tci['QUANTITE_SEUIL']) 
									{
										$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
								        $this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);

								        $array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
								        $this->Modele->create('stock_rupture_ticket_historique',$array_historique);

								        $this->notifications->send_mail($EMAIL_CDS,'ETAT DU STOCK CDS',$EMAIL_CC,$MESSAGE,array());
								    }
								}
						






					}


				}







				// ********************************************************FIN CDS*************************************************











			}

		// die();


		}
	}



}
?>