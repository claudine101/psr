<?php
/**
*
*/
class Distribution_Intrants extends My_Controller
{


			function index()
			{
				$array_stock_demande=array();
				$requete=$this->Modele->getRequete('SELECT  DISTINCT DEMANDE_CODE,`DEMANDE_ID`,USER_DEMANDEUR_ID,CODE_DEMANDE_SENS_ID,stock_demande.INTERVENANT_STRUCTURE_ID,`PATH_JUSTIFICATION`,IS_JUSTIFIE, `DATE_INSERTION`,intervena.INTERVENANT_STRUCTURE_DESCR,rh.NOM,rh.PRENOM,rh.TELEPHONE1 FROM `stock_demande`
					                                  LEFT JOIN intervenants_structure intervena on intervena.INTERVENANT_STRUCTURE_ID=stock_demande.INTERVENANT_STRUCTURE_ID AND IS_JUSTIFIE=1
					                                  LEFT JOIN intervenants_rh rh on rh.INTERVENANT_RH_ID=stock_demande.USER_DEMANDEUR_ID
																						WHERE stock_demande.APPROUVE =1 ORDER BY DATE_INSERTION DESC');
				$nu=1;

				foreach ($requete as $value)
				{
					$sub_array=array();

					$sub_array[]=$nu;
					$sub_array[]=$value['DEMANDE_CODE'];
					//$sub_array[]=$value['NOM'];
					$sub_array[]=$value['INTERVENANT_STRUCTURE_DESCR'];
					$sub_array[]=$value['NOM']." ".$value['PRENOM']."(".$value['TELEPHONE1'].")";
					$sub_array[]="<a href='#'><i style='font-size:17px;color:green;' class='fa fa-check' style='color:green;'></i></a>";


					$intervena="<option value=''>--Intervenant</option>";
					$sub_requete1=$this->Modele->getRequete('SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`," ", `PRENOM`) AS NOM, TELEPHONE1 FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`='.$value['INTERVENANT_STRUCTURE_ID']);
          if($value['CODE_DEMANDE_SENS_ID'] == 3){
						$sub_requete1=$this->Modele->getRequete('SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`," ", `PRENOM`) AS NOM,TELEPHONE1 FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`='.$value['INTERVENANT_STRUCTURE_ID'].' AND INTERVENANT_RH_ID = '.$value['USER_DEMANDEUR_ID']);
					}

					foreach ($sub_requete1 as $key)
					{
					$intervena.="<option value='".$key['INTERVENANT_RH_ID']."'>".$key['NOM']."(".$key['TELEPHONE1'].")</option>";
					}
					//echo $intervena;

					//INTRANTS A DISTRIBUER

					$sub_requete2=$this->Modele->getRequete('SELECT  `QUANTITE`,INTRANT_ID,(QUANTITE_APPROUVEE-QUANTITE_RECU) AS QUANTITE_NO_RECUPER, `QUANTITE_RECU`,intra.INTRANT_MEDICAUX_DESCR FROM `stock_demande_detail`  JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stock_demande_detail.INTRANT_ID WHERE  `DEMANDE_ID`='.$value['DEMANDE_ID']);
		      // echo "<pre>";
					// echo "DEMANDE_ID ".$value['DEMANDE_ID']."<br>";
					// print_r($sub_requete2);
					// echo "</pre>";
					$intrants_distribue='';
					$n1=1;
					if ($sub_requete2) {

						$intrants_distribue.="<table class='table table-bordered table-stripped'>";
						$intrants_distribue.="<thead><th>#</th><th>Intrants</th><th>Quantité disponible</th><th>Quantité donnée</th><th>Valider</th></thead>";
						$intrants_distribue.="<thbody>";

						foreach ($sub_requete2 as $key1)
						{
							$intrants_distribue.="
							<tr>
							<td>".$n1."</td>
							<td>".$key1['INTRANT_MEDICAUX_DESCR']."<input type='hidden' name='INTRANT_ID[".$key1['INTRANT_ID']."]'></td>
							<td><input type='hidden' value='".$key1['QUANTITE']."' name='QUANTITE_DEMANDE[".$key1['INTRANT_ID']."]'>
							    ".$key1['QUANTITE_NO_RECUPER']."</td>
							<td><input type='number' value=".$key1['QUANTITE_NO_RECUPER']." id='QUANTITE_DONNEE_".$key1['INTRANT_ID']."_".$value['DEMANDE_ID']."' class='form-control'></td>
							<td><button type='button' onClick='valide_un_intrant(this)' class='btn btn-sm btn btn-primary id' id='".$key1['INTRANT_ID']."_".$value['DEMANDE_ID']."'>+</button></td>
							</tr>";

							$n1++;
						}

						$intrants_distribue.="</tbody>";
						$intrants_distribue.="</table>";
					}




					$sub_array[]=$value['DATE_INSERTION'];

					$sub_array['OPTIONS'] = '<div class="dropdown">
					<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
					<i class="fa fa-cog"></i>
					Options <span class="caret"></span>
					</a>
					<ul class="dropdown-menu dropdown-menu-left">';
					$sub_array['OPTIONS'].="<center><a href='#' data-toggle='modal' data-target='#mydistribue".$value['DEMANDE_ID']."'><span style='color:green;text-decoration:none;'>Distribué</span></a></center>";

				   // <form method='POST' action='".base_url('stock_distribution/Distribution_Intrants/distrubue_intrant/'.$value['DEMANDE_ID'])."'>
					$sub_array['OPTIONS'] .= " </ul>
					</div>
					<div class='modal fade' data-backdrop='static' id='mydistribue".$value['DEMANDE_ID']."'>
					<div class='modal-dialog' style='width:60%'>
					<div class='modal-content'>
					<div class='modal-header'>
					<center><b>Distribution des intrants  à un demandeur du code ".$value['DEMANDE_CODE']."</b></center>
					</div>
					<div class='modal-body'>
					<p id='msg_".$value['DEMANDE_ID']."'></p>

					<input type='hidden' value='".$value['DEMANDE_ID']."' name='DEMANDE_ID' id='DEMANDE_ID'>
					<input type='hidden' value='".$value['INTERVENANT_STRUCTURE_ID']."' name='INTERVENANT_STRUCTURE_ID' id='INTERVENANT_STRUCTURE_ID_".$value['DEMANDE_ID']."'>
					<div class='col-md-12'>
						<div class='col-md-4'>
						<label>Code du demande</label>
						<input type='text' readonly='' class='form-control' id='DEMANDE_CODE' value='".$value['DEMANDE_CODE']."'></div>
						<div class='col-md-4'>
						<label>Date de distribution</label>
						<input type='date' class='form-control' readonly='' id='DISTRIBUTION_DATE_".$value['DEMANDE_ID']."' name='DISTRIBUTION_DATE' value='".date('Y-m-d')."'></div>
						<div class='col-md-4'>
						<label>Intervenant RH</label>
						<select name='INTERVENANT_RH_ID' id='INTERVENANT_RH_ID_".$value['DEMANDE_ID']."' class='form-control'>
						".$intervena."
						</select>
						</div>
						<div class='col-md-12'>
						<label>Commentaire</label>
						<textarea class='form-control' name='COMMENT' id='COMMENT_".$value['DEMANDE_ID']."'></textarea>
						</div>

						<div class='col-md-12' style='margin-top:20px;'>
						".$intrants_distribue."

						</div>

					</div>


					</div><br><br><br><br><br><br><br><br><br><br><br><br>

					<div class='modal-footer'>
					<button class='btn btn-primary' id='".$value['DEMANDE_ID']."' onClick='valider_distribution(this)'>Confirmer</button>
					<button class='btn btn-secondary btn-md' data-dismiss='modal'>
					Quitter
					</button>
					</div>

					</div>
					</div>
					</div>";


					$array_stock_demande[]=$sub_array;
					$nu++;
				}


				$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
				$this->table->set_template($template);
				$this->table->set_heading(array('#','CODE DU DEMANDE','STRUCTURE','AGENT','EST JUSTIFIE?','DATE DU DEMANDE','ACTION'));
				$data['array_stock_demande']=$array_stock_demande;
				$data['title']='Liste des demandes d\'intrants';
				$this->page='stock_distribution/Stock_Demande_list_view';
				$this->layout($data);
			}



		    public function distrubue_intrant(){
		      $DEMANDE_ID = $this->input->post('DEMANDE_ID');
					$demande = $this->Modele->getOne('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID));
		      $details = $this->Modele->getList('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$demande['DEMANDE_CODE']));

					// print_r($demande);
					// echo "<pre>";
					// print_r($details);
					// echo "</pre>";

					$INTERVENANT_RH_ID = $this->input->post('INTERVENANT_RH_ID');

					$msg = "";
					$status = 500;
		      if(!empty($demande)){
			      if(!empty($details)){
							if(empty($INTERVENANT_RH_ID)){
								$msg = "<i class='alert alert-danger'>Vous devez sélectionner une RH qui reçoit la quantité.</i>";
							}else{
								$INTERVENANT_STRUCTURE_ID = $this->input->post('INTERVENANT_STRUCTURE_ID');
								$DISTRIBUTION_DATE = $this->input->post('DISTRIBUTION_DATE');
								$COMMENT = $this->input->post('COMMENT');

								$array_distribution = array(
									'DISTRIBUTION_CODE'=>NULL,
									'DISTRIBUTION_DATE'=>$DISTRIBUTION_DATE,
									'CODE_SENS_ID'=>$demande['CODE_DEMANDE_SENS_ID'],
									'DEMANDE_ID'=>$DEMANDE_ID,
									'COMMENT'=>$COMMENT,
									'USER_ID'=>$this->session->userdata('iccm_USER_ID'),
									'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
									'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,
								);

								$DISTRIBUTION_ID = $this->Modele->insert_last_id('stock_distribution',$array_distribution);
								$DISTRIBUTION_CODE = "DSTR-".date('ymd').'-'.$DISTRIBUTION_ID;
								$this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>$DISTRIBUTION_CODE));
								$this->Modele->update('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$demande['DEMANDE_CODE']),array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID));

								$msg = "<i class='alert alert-success'> La distribution de ".sizeof($details)." intrant(s) a été faite avec succès.</i>";
			          $status = 200;

								//Creation des notifications
								$distr_details = $this->Modele->getList('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID));
								// echo "<pre>";
								// print_r($distr_details);
                // echo "</pre>";
								foreach ($distr_details as $distr_detail) {
									$cc_emails = array();
									$RECEPTION_CODE = $distr_detail['RECEPTION_CODE'];
									$INTRANT_ID = $distr_detail['INTRANT_ID'];

									//echo "RECEPTION_CODE ".$RECEPTION_CODE."<br>";

									// Recepuration du PTF
									$sql = "SELECT p.*,rc.PTF_ID,rc.MODE_RECEPTION_ID,rcdl.* FROM rc_reception AS rc
									        JOIN rc_reception_intrant_detail AS rcdl ON rc.RECEPTION_ID = rcdl.RECEPTION_ID
									        JOIN ptf AS p ON p.PTF_ID = rc.PTF_ID
													WHERE rc.RECEPTION_CODE = '$RECEPTION_CODE'
													AND rcdl.INTRANT_ID = $INTRANT_ID";

									// $sql = "SELECT p.*,rc.PTF_ID,rc.MODE_RECEPTION_ID,rcdl.* FROM rc_reception AS rc
									//         JOIN rc_reception_intrant_detail AS rcdl ON rc.RECEPTION_ID = rcdl.RECEPTION_ID
									//         JOIN intervenants_structure AS p ON p.INTERVENANT_STRUCTURE_ID = rc.PTF_ID
									// 				WHERE rc.RECEPTION_CODE = '$RECEPTION_CODE'
									// 				AND rcdl.INTRANT_ID = $INTRANT_ID";

									$info_reception_ptf = $this->Modele->getRequeteOne($sql);

									 // echo "<pre>";
									 // print_r($info_reception_ptf);
									 // echo "</pre>";

									// Recepuration de l'intrant
	                $intrant = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$INTRANT_ID));

									// Recepuration du intervant distribué
									$sql_distribution = "SELECT ints.*,dst.CODE_SENS_ID,dst.INTERVENANT_RH_ID FROM stock_distribution AS dst
									                     JOIN intervenants_structure AS ints ON ints.INTERVENANT_STRUCTURE_ID = dst.INTERVENANT_STRUCTURE_ID
																			 WHERE dst.DISTRIBUTION_ID = $DISTRIBUTION_ID";
	                $distribue = $this->Modele->getRequeteOne($sql_distribution);

									if($distribue['CODE_SENS_ID'] < 3){
										$cc_emails[] = $distribue['EMAIL'];
									}
	                //Recuperation des depences CDS et BDS
	                $recepteur_intrant = $distribue['INTERVENANT_STRUCTURE_DESCR'];
									//ASC
									if($distribue['CODE_SENS_ID'] == 2){
										$sql_bds = "SELECT ints.* FROM bds_cds AS bd JOIN intervenants_structure AS ints ON bd.BDS_ID = ints.INTERVENANT_STRUCTURE_ID WHERE bd.CDS_ID = $INTERVENANT_STRUCTURE_ID";
										$bds = $this->Modele->getRequeteOne($sql_bds);
										$recepteur_intrant .= ' de '.$bds['INTERVENANT_STRUCTURE_DESCR'];
										$cc_emails[] = $bds['EMAIL'];
									}

									if($distribue['CODE_SENS_ID'] == 3){
										$intervenant_rh = $this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_ID'=>$distribue['INTERVENANT_RH_ID']));

										$recepteur_intrant .= "(".$intervenant_rh['NOM']." ".$intervenant_rh['PRENOM'].")";
										//CDS
										$INTERVENANT_RH_ID = $distribue['INTERVENANT_RH_ID'];
										$sql_cds = "SELECT ints.* FROM cds_asc AS cds JOIN intervenants_structure AS ints ON cds.CDS_ID = ints.INTERVENANT_STRUCTURE_ID WHERE cds.INTERVENANT_RH_ID = $INTERVENANT_RH_ID";
										$cds = $this->Modele->getRequeteOne($sql_cds);
										$cc_emails[] = $cds['EMAIL'];

										//BDS
										$CDS_ID = $cds['INTERVENANT_STRUCTURE_ID'];
										$sql_bds = "SELECT ints.* FROM bds_cds AS bd JOIN intervenants_structure AS ints ON bd.BDS_ID = ints.INTERVENANT_STRUCTURE_ID WHERE bd.CDS_ID = $CDS_ID";
										$bds = $this->Modele->getRequeteOne($sql_bds);
										$cc_emails[] = $bds['EMAIL'];

										$recepteur_intrant .= " appartenant à ".$cds['INTERVENANT_STRUCTURE_DESCR']."/".$bds['INTERVENANT_STRUCTURE_DESCR'].".Merci";
									}


									$message = "Cher <b>".$info_reception_ptf['PTF_NOM']."</b>, Une quantité <b>".$distr_detail['QUANTITE']."</b> sur le lot <b>".$info_reception_ptf['NUMERO_LOT']."</b> de l'intrant <b>".$intrant['INTRANT_MEDICAUX_DESCR']."</b> a été distribuée(s) à ".$recepteur_intrant;
									$message_save = "Cher ".$info_reception_ptf['PTF_NOM'].", Une quantité ".$distr_detail['QUANTITE']." sur le lot: ".$info_reception_ptf['NUMERO_LOT']." de l'intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." a été distribuée(s) à ".$recepteur_intrant;
									$subjet = "Distribution d'un intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." du lot ".$info_reception_ptf['NUMERO_LOT'];
									$emailTo = $info_reception_ptf['EMAIL'];
									$cc_emails[] = 'camebu@mediabox.bi';

									// echo "<pre>";
									// print_r($cc_emails);
									// echo "<pre>";
									$array_notifications = array(
										'MESSAGE'=>$message_save,
										'PTF_ID'=>$info_reception_ptf['PTF_ID'],
										'EMAIL_NOTIFIE'=>$info_reception_ptf['EMAIL'],
										'INTRANT_ID'=>$INTRANT_ID,
										'INTRANT_ID'=>$distr_detail['QUANTITE'],
										'IS_DISTRIBUTION'=>1
									);
									$this->Modele->insert_last_id('sms_mouvement_stock',$array_notifications);
									$this->notifications->send_mail($emailTo, $subjet, $cc_emails, $message, array());
								}
							}
						}else{
							$msg = "<i class='alert alert-danger'> Vous devez d'abord confirmer au moins une quantité pour un intrant.</i>";
					  }
					}else{
							$msg = "<i class='alert alert-danger'>Un erreur inattandu est survenue.</i>";
					}
		      echo json_encode(array('status'=>$status,'msg'=>$msg));
		   }
		    public function valider_distribution_intrant (){

		      $DEMANDE_ID = $this->input->post('DEMANDE_ID');
		      $INTRANT_ID = $this->input->post('INTRANT_ID');
		      $QUANTITE = $this->input->post('QUANTITE');

		      $demande=$this->Modele->getOne('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID));
		      $demande_detail=$this->Modele->getOne('stock_demande_detail',array('INTRANT_ID'=>$INTRANT_ID,'DEMANDE_ID'=>$DEMANDE_ID));
		      $intrant = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$INTRANT_ID));
		      $INTERVENANT_STRUCTURE_ID = $demande['INTERVENANT_STRUCTURE_ID'];
		      $stock_intervenat = $this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));

		      $msg = "<i class='alert alert-success'> Distribution d'(e)".$intrant['INTRANT_MEDICAUX_DESCR']." pour une quantité ".$QUANTITE." a été enregistré avec succès.</i>";

		      if(!empty($demande) && !empty($demande_detail)){
		      	$quantite_disponible = $demande_detail['QUANTITE_APPROUVEE'] - $demande_detail['QUANTITE_RECU'];
		      //  if(($QUANTITE >0) && $QUANTITE <= $quantite_disponible){

		          //Update stock intrat
		            //Distribution vers un BDS

		            if($demande['CODE_DEMANDE_SENS_ID'] == 1){
		              //Update stock camebu
		               $ma_quantite = $this->input->post('QUANTITE');
		               do {
		                 $sql_camebu = "SELECT *,(QUANTITE-QUANTITE_DISTRIBUE) AS QTY_DISPO FROM stock_camebu WHERE INTRANT_ID = $INTRANT_ID HAVING QTY_DISPO > 0 ORDER BY STOCK_ID ASC";
		                 $resulat_intrant_camebu = $this->Modele->getRequeteOne($sql_camebu);

		                 $qty_distribue = ($resulat_intrant_camebu['QTY_DISPO'] >= $ma_quantite)?$ma_quantite:($ma_quantite - $resulat_intrant_camebu['QTY_DISPO']);
		                 //Mis a jour la sortie du stock camebu
		                 $this->Modele->update('stock_camebu',array('STOCK_ID'=>$resulat_intrant_camebu['STOCK_ID']),array('QUANTITE_DISTRIBUE'=>$resulat_intrant_camebu['QUANTITE_DISTRIBUE']+$qty_distribue));

		                 //La quantite restante a pres la distribution
		                 $ma_quantite = $ma_quantite - $qty_distribue;

		                 //Mise a jour de la quantie recue de l'intervenant BDS
		                 if(!empty($stock_intervenat)){
		                 	//echo 'test Update';
		                 	$nvll_qty_dist = $stock_intervenat['QUANTITE']+$qty_distribue;
		                    $this->Modele->update('stock_intervenat',
		                    	                   array('INTRANT_ID'=>$INTRANT_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID),
		                    	                   array('QUANTITE'=>$nvll_qty_dist));
		                 }else{
		                 	//echo 'test Insert';
		                 	$nvll_data = array(
		                 		            'INTERVENANT_RH_ID'=>$this->session->userdata('ICCM_INTERVENANT_RH_ID'),
		                 		            'QUANTITE'=>$qty_distribue,
		                 		            'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,
		                 		            'QUANTITE_DISTRIBUTUEE'=>0,
		                 		            'INTRANT_ID'=>$INTRANT_ID
		                 		        );
		                   $this->Modele->insert_last_id('stock_intervenat',$nvll_data);
		                 }
		                 //UDATE DEMANDE DETAIL

		                 //INSERT LIGNE DE DISTRIBUTION
		                 $my_array_distribution_detail = array(
		                 	'DISTRIBUTION_ID'=> $demande['DEMANDE_CODE'],
		                 	'RECEPTION_CODE'=> $resulat_intrant_camebu['RECEPTION_CODE'],
		                 	'INTRANT_ID'=>$INTRANT_ID,
		                 	'QUANTITE'=> $qty_distribue,
											'QUANTITE_RESTANTE'=>$qty_distribue
		                 );
		                 $this->Modele->insert_last_id('stock_distribution_intrant_detail',$my_array_distribution_detail);

		               } while ($ma_quantite > 0);

		            }

		            //Distribution vers un CDS
		            if($demande['CODE_DEMANDE_SENS_ID'] == 2){
									$ma_quantite = $this->input->post('QUANTITE');
		              //Update stock camebu
		               $INTERVENANT_STRUCTURE_BDS_ID = $this->mylibrary->getBdsDependance($demande['INTERVENANT_STRUCTURE_ID']);
		              do {
										$sql_detail_intrant_bds = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
																				JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
																				WHERE dist.INTERVENANT_STRUCTURE_ID = $INTERVENANT_STRUCTURE_BDS_ID AND dt.INTRANT_ID = '$INTRANT_ID'
																				HAVING QUANTITE_RESTANTE > 0";
										$resultat_detail_bds = $this->Modele->getRequeteOne($sql_detail_intrant_bds);

											//echo "Quantite dispo ".$ligne_intrant_intervenat_distributeur['QTE_DISPO']."<br>";

										 if(!empty($resultat_detail_bds) && $resultat_detail_bds['QUANTITE_RESTANTE'] > 0){
											 $qty_distribue = ($resultat_detail_bds['QUANTITE_RESTANTE'] >= $ma_quantite)?$ma_quantite:($ma_quantite - $resultat_detail_bds['QUANTITE_RESTANTE']);

												//MISE A JOUR DE LA QUANTIRE RESTANTE POUR UN BDS parent
												$this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$resultat_detail_bds['DETAIL_ID']), array('QUANTITE_RESTANTE'=>$resultat_detail_bds['QUANTITE_RESTANTE']-$qty_distribue));

											 //echo "Quantite dispo ".$ligne_intrant_intervenat_distributeur['QTE_DISPO']."<br>";

											 $sql_stock_intervant = "SELECT * FROM stock_intervenat WHERE INTRANT_ID = $INTRANT_ID AND INTERVENANT_STRUCTURE_ID = $INTERVENANT_STRUCTURE_BDS_ID";
											 $ligne_stock_intervenant_bds = $this->Modele->getRequeteOne($sql_stock_intervant);

			                 //Mis a jour la sortie du stock distributeur
			                 $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$ligne_stock_intervenant_bds['STOCK_INTERVENANT_ID']),array('QUANTITE_DISTRIBUTUEE'=>$ligne_stock_intervenant_bds['QUANTITE_DISTRIBUTUEE']+$qty_distribue));

											// echo "Ma Quantite1  ".$ma_quantite."<br>";
			                 //La quantite restante a pres la distribution
			                 $ma_quantite = $ma_quantite - $qty_distribue;

											  //echo "Ma Quantite2  ".$ma_quantite."<br>";
											  //echo "QT Distribue ".$qty_distribue."<br>";
			                 //Mise a jour de la quantie recue sur structure demandeur
			                 if(!empty($stock_intervenat)){
			                 	$nvll_qty_dist = $stock_intervenat['QUANTITE']+$qty_distribue;
			                    $this->Modele->update('stock_intervenat',
			                    	                   array('INTRANT_ID'=>$INTRANT_ID,'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID']),
			                    	                   array('QUANTITE'=>$nvll_qty_dist));
			                 }else{
			                 	$nvll_data = array(
			                 		            'QUANTITE'=>$qty_distribue,
			                 		            'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID'],
			                 		            'QUANTITE_DISTRIBUTUEE'=>0,
																			'INTRANT_ID'=>$INTRANT_ID,
																			'INTERVENANT_RH_ID'=>$this->session->userdata('ICCM_INTERVENANT_RH_ID')
			                 		        );
			                    $this->Modele->insert_last_id('stock_intervenat',$nvll_data);
			                 }

			                 //INSERT LIGNE DE DISTRIBUTION
			                 $my_array_distribution_detail = array(
												'RECEPTION_CODE'=> $resultat_detail_bds['RECEPTION_CODE'],
			                 	'DISTRIBUTION_ID'=> $demande['DEMANDE_CODE'],
			                 	'INTRANT_ID'=>$INTRANT_ID,
												'QUANTITE'=> $qty_distribue,
			                 	'QUANTITE_RESTANTE'=> $qty_distribue
			                 );
			                 $this->Modele->insert_last_id('stock_distribution_intrant_detail',$my_array_distribution_detail);
										 }else{
											 $ma_quantite = 0;
										 }
										 //echo "Ma Quantite ".$ma_quantite."<br>";


		              } while ($ma_quantite > 0);

		            }

		            //Distribution vers un ASC
								if($demande['CODE_DEMANDE_SENS_ID'] == 3){
									$ma_quantite = $this->input->post('QUANTITE');
		              //Update stock camebu
		               $INTERVENANT_STRUCTURE_CDS_ID = $this->mylibrary->getCdsDependance($demande['USER_DEMANDEUR_ID']);
		              do {
										$sql_detail_cds = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
																				JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
																				WHERE dist.INTERVENANT_STRUCTURE_ID = $INTERVENANT_STRUCTURE_CDS_ID AND dt.INTRANT_ID = '$INTRANT_ID'
																				HAVING QUANTITE_RESTANTE > 0";
										$ligne_intrant_cds = $this->Modele->getRequeteOne($sql_detail_cds);
											//echo "Quantite dispo ".$ligne_intrant_cds_distributeur['QTE_DISPO']."<br>";

										 if(!empty($ligne_intrant_cds) && $ligne_intrant_cds['QUANTITE_RESTANTE'] > 0){
											 $qty_distribue = ($ligne_intrant_cds['QUANTITE_RESTANTE'] >= $ma_quantite)?$ma_quantite:($ma_quantite - $ligne_intrant_cds['QUANTITE_RESTANTE']);

												//Update quantite restante du CDS
												$this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$ligne_intrant_cds['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$ligne_intrant_cds['QUANTITE_RESTANTE']-$qty_distribue));

											 //echo "Quantite dispo ".$ligne_intrant_intervenat_distributeur['QTE_DISPO']."<br>";
											 $sql_stock_intervenant_cds = "SELECT * FROM stock_intervenat WHERE INTRANT_ID = $INTRANT_ID AND INTERVENANT_STRUCTURE_ID = $INTERVENANT_STRUCTURE_CDS_ID";
	 	                   $ligne_stock_intervenant_cds = $this->Modele->getRequeteOne($sql_stock_intervenant_cds);

			                 //Mis a jour la sortie du stock distributeur
			                 $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$ligne_stock_intervenant_cds['STOCK_INTERVENANT_ID']),array('QUANTITE_DISTRIBUTUEE'=>$ligne_stock_intervenant_cds['QUANTITE_DISTRIBUTUEE']+$qty_distribue));

											// echo "Ma Quantite1  ".$ma_quantite."<br>";
			                 //La quantite restante a pres la distribution
			                 $ma_quantite = $ma_quantite - $qty_distribue;

											  //echo "Ma Quantite2  ".$ma_quantite."<br>";
											  //echo "QT Distribue ".$qty_distribue."<br>";
			                 //Mise a jour de la quantie recue sur structure demandeur
											 $stock_intervenat = $this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_ID,'INTERVENANT_RH_ID'=>$demande['USER_DEMANDEUR_ID']));

			                 if(!empty($stock_intervenat)){
			                 	$nvll_qty_dist = $stock_intervenat['QUANTITE']+$qty_distribue;
			                    $this->Modele->update('stock_intervenat',
			                    	                   array('INTRANT_ID'=>$stock_intervenat['STOCK_INTERVENANT_ID']),
			                    	                   array('QUANTITE'=>$nvll_qty_dist));
			                 }else{
			                 	$nvll_data = array(
			                 		            'QUANTITE'=>$qty_distribue,
			                 		            'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID'],
			                 		            'QUANTITE_DISTRIBUTUEE'=>0,
																			'INTRANT_ID'=>$INTRANT_ID,
																			'INTERVENANT_RH_ID'=>$demande['USER_DEMANDEUR_ID']
			                 		        );
			                    $this->Modele->insert_last_id('stock_intervenat',$nvll_data);
			                 }

			                 //INSERT LIGNE DE DISTRIBUTION
			                 $my_array_distribution_detail = array(
												 'DISTRIBUTION_ID'=> $demande['DEMANDE_CODE'],
			                 	'RECEPTION_CODE'=> $ligne_intrant_cds['RECEPTION_CODE'],
			                 	'INTRANT_ID'=>$INTRANT_ID,
												'QUANTITE'=> $qty_distribue,
			                 	'QUANTITE_RESTANTE'=> $qty_distribue
			                 );
			                 $this->Modele->insert_last_id('stock_distribution_intrant_detail',$my_array_distribution_detail);
										 }else{
											 $ma_quantite = 0;
										 }
										 //echo "Ma Quantite ".$ma_quantite."<br>";


		              } while ($ma_quantite > 0);
		            }
		           //Mise a jour de la quantite
		            $array_demande_detail = array('QUANTITE_RECU'=>$demande_detail['QUANTITE_RECU']+$this->input->post('QUANTITE'));
		            $this->Modele->update('stock_demande_detail',array('DETAIL_ID'=>$demande_detail['DETAIL_ID']),$array_demande_detail);
		        // }else{
		        //   $msg = "<i class='alert alert-danger'> Il faut que la quantité est supérieur à 0 ou inférieur à la quantité disponible</i>";
		        // }

		      }else{
		      $msg = "<i class='alert alert-danger'> Un erreur inattendu est survenu. Réessayez.</i>";
		      }

		      echo $msg;
		    }



	function historique()
	{

		$INTRANT_ID=$this->input->post('INTRANT_ID');
		$DATE_DISTRIBUTION=$this->input->post('DATE_DISTRIBUTION');
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');

		$critere="";
		if (!empty($INTRANT_ID))
		{
			$critere.=" AND stdi.INTRANT_ID=".$INTRANT_ID;
		}
		if (!empty($DATE_DISTRIBUTION)) {
			$critere.=" AND std.DISTRIBUTION_DATE='".$DATE_DISTRIBUTION."'";
		}

		if (!empty($INTERVENANT_STRUCTURE_ID)) {
			$critere.=" AND std.INTERVENANT_STRUCTURE_ID=".$INTERVENANT_STRUCTURE_ID;
		}

		$array_histo=array();
		$r=1;
		$requete=$this->Modele->getRequete("SELECT DISTINCT stde.DEMANDE_CODE,stde.INTERVENANT_STRUCTURE_ID, stdi.`RECEPTION_CODE`,stde.CODE_DEMANDE_SENS_ID,concat(intervena.INTERVENANT_STRUCTURE_DESCR, '(',intervenants_rh.NOM,' ',intervenants_rh.PRENOM,')') as STRUCTURE_RH, stdi.`QUANTITE`,std.DISTRIBUTION_DATE,intra.INTRANT_MEDICAUX_DESCR,stde.USER_DEMANDEUR_ID FROM `stock_distribution_intrant_detail` stdi JOIN stock_distribution std ON std.DISTRIBUTION_ID=stdi.`DISTRIBUTION_ID` JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stdi.INTRANT_ID JOIN stock_demande_code_sens ON stock_demande_code_sens.SENS_DISTRIBUTION=std.CODE_SENS_ID JOIN stock_demande stde ON stde.DEMANDE_ID=std.DEMANDE_ID JOIN intervenants_structure intervena ON intervena.INTERVENANT_STRUCTURE_ID=std.INTERVENANT_STRUCTURE_ID JOIN intervenants_rh ON intervenants_rh.INTERVENANT_RH_ID=std.INTERVENANT_RH_ID  WHERE 1 ".$critere);

	    foreach ($requete as $value)
		{
			$sub_array=array();

			//$GET_BDS=$this->Modele->getRequeteOne("SELECT  `BDS_ID` FROM `bds_cds` WHERE BDS_ID=".$value['INTERVENANT_STRUCTURE_ID']);
			//$VALUE_BDS=$GET_BDS['BDS_ID'];
			//$GET_BDS=$this->Modele->getOne()

			//$BDS=$this->Modele->getRequeteOne("SELECT DISTINCT TYPE_IN.TYPE_INTERVENANT_STRUCTURE_DESCR FROM `intervenants_structure` STRUCTUR JOIN type_intervenants_structures TYPE_IN ON TYPE_IN.TYPE_INTERVENANT_STRUCTURE_ID=STRUCTUR.`TYPE_INTERVENANT_STRUCTURE_ID` WHERE STRUCTUR.`INTERVENANT_STRUCTURE_ID`=".$GET_BDS['BDS_ID']);

			 //print_r($GET_BDS['BDS_ID']);die();





			// $GET_CDS=$this->Modele->getRequeteOne("SELECT  `BDS_ID` FROM `bds_cds` WHERE CDS_ID=".$value['USER_DEMANDEUR_ID']);

			$donneur='';
			if ($value['CODE_DEMANDE_SENS_ID']==1) {
				$donneur="CAMEBU";
			}

			// if ($value["CODE_DEMANDE_SENS_ID"]==2) {
			// 	$donneur=$BDS['TYPE_INTERVENANT_STRUCTURE_DESCR'];
			// }

			// else
			// {
			// 	$donneur=$value['CODE_DEMANDE_SENS_ID'];
			// }

			// if ($value['CODE_DEMANDE_SENS_ID']==1)
			// {
			// 	$donneur=$this->Modele->getOne('');
			// }

			// if ($value['CODE_DEMANDE_SENS_ID']==2)
			// {
			// 	$donneur=$this->Modele->getOne('');
			// }

			// if ($value['CODE_DEMANDE_SENS_ID']==3)
			// {
			// 	$donneur=$this->Modele->getOne('');
			// }



			$sub_array[]=$r;

			$sub_array[]=$value['DEMANDE_CODE'];
			$sub_array[]=$value['RECEPTION_CODE'];
			$sub_array[]=$value['STRUCTURE_RH'];
			//$sub_array[]=$donneur;
			//$sub_array[]="DEMANDEUR";
			$sub_array[]=$value['QUANTITE'];
			$sub_array[]=$value['INTRANT_MEDICAUX_DESCR'];
			$sub_array[]=$value['DISTRIBUTION_DATE'];



			$array_histo[]=$sub_array;
			$r++;
		}

		$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
		$this->table->set_template($template);
		$this->table->set_heading(array('#','CODE DEMANDE','CODE DE RECEPTION','STRUCTURE','QUANTITE RECU','INTRATS','DATE DE DISTRIBUTION'));
		$data['array_histo']=$array_histo;
		$data['title']='Historiques des intrants distribués';
		$data['intrants']=$this->Modele->getRequete('SELECT DISTINCT stock_distribution_intrant_detail.INTRANT_ID,intra.INTRANT_MEDICAUX_DESCR  FROM `stock_distribution_intrant_detail` JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stock_distribution_intrant_detail.INTRANT_ID WHERE 1 ORDER BY intra.INTRANT_MEDICAUX_DESCR ASC');
		$data['structures']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1 ORDER BY INTERVENANT_STRUCTURE_DESCR ASC');
		$data['DATE_DISTRIBUTION']=$DATE_DISTRIBUTION;
		$data['INTRANT_ID']=$INTRANT_ID;

		$this->page='stock_distribution/Historiques_intrants_view';
		$this->layout($data);
	}









	function listing_distribution($DEMANDE_ID='')
	{
		$data['title']="Historique des distributions";

		$critere="";
		$critere1="";

		$DISTRIBUTION_DATE=$this->input->post('DISTRIBUTION_DATE');
		$INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');




		if (!empty($INTERVENANT_STRUCTURE_ID)) {


			$critere=" AND stock_distribution.INTERVENANT_STRUCTURE_ID=".$INTERVENANT_STRUCTURE_ID;

			if (!empty($INTRANT_MEDICAUX_ID)) {
				$critere1=" AND stock_distribution_intrant_detail.INTRANT_ID=".$INTRANT_MEDICAUX_ID;
			}
			$data['intrants']=$this->Modele->getRequete('SELECT DISTINCT(stci.`INTRANT_ID`) AS INTRANT_MEDICAUX_ID,intrant_medicaux.INTRANT_MEDICAUX_DESCR FROM `stock_distribution` JOIN stock_distribution_intrant_detail as stci ON stci.DISTRIBUTION_ID=stock_distribution.DISTRIBUTION_ID JOIN intrant_medicaux ON intrant_medicaux.INTRANT_MEDICAUX_ID=stci.INTRANT_ID WHERE stock_distribution.INTERVENANT_STRUCTURE_ID='.$INTERVENANT_STRUCTURE_ID);

		}



		if (!empty($DISTRIBUTION_DATE)) {
			$critere=" AND DISTRIBUTION_DATE='".$DISTRIBUTION_DATE."'";
		}

		// if (!empty($INTRANT_MEDICAUX_ID)) {
		// 	$critere=" AND INTRANT_ID=".$INTRANT_MEDICAUX_ID;
		// }


		$requete=$this->Modele->getRequete('SELECT concat(intervena.NOM," ",intervena.PRENOM) as INTERVENA,intervena.EMAIL,intervenants_structure.INTERVENANT_STRUCTURE_DESCR,`DISTRIBUTION_ID`, `DISTRIBUTION_CODE`, `DISTRIBUTION_DATE`, `DEMANDE_ID`, `COMMENT`,intervena.TELEPHONE1,intervena.TELEPHONE2, `DATE_INSERTION` FROM `stock_distribution` LEFT JOIN intervenants_rh intervena ON intervena.INTERVENANT_RH_ID=stock_distribution.INTERVENANT_RH_ID LEFT JOIN intervenants_structure ON intervenants_structure.INTERVENANT_STRUCTURE_ID=stock_distribution.INTERVENANT_STRUCTURE_ID WHERE stock_distribution.DEMANDE_ID='.$DEMANDE_ID.$critere);
		$array_dist=array();

		$nu=1;

		foreach ($requete as $row)
		{

			$sub_requete=$this->Modele->getRequete('SELECT  `RECEPTION_CODE`, `QUANTITE`,intra.INTRANT_MEDICAUX_DESCR,intra.TEMPERATURE_MIN_CONSERVATION,intra.TEMPERATURE_MAX_CONSERVATION FROM `stock_distribution_intrant_detail` JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stock_distribution_intrant_detail.INTRANT_ID WHERE DISTRIBUTION_ID='.$row['DISTRIBUTION_ID'].$critere1);

			$intrants="<table class='table table-bordered table-stripped table-hover table-condensed'><thead><th>Code de reception</th><th>Quantité</th><th>Intrants</th><th>Température minimale</th><th>Température maximale</th></thead>";

			foreach ($sub_requete as $value) {
				$intrants.="<tbody><tr><td>".$value['RECEPTION_CODE']."</td><td>".$value['QUANTITE']."</td><td>".$value['INTRANT_MEDICAUX_DESCR']."</td><td>".$value['TEMPERATURE_MIN_CONSERVATION']."</td><td>".$value['TEMPERATURE_MAX_CONSERVATION']."</td></tr></tbody>";
			}

			$intrants.="</table>";

			$sub_array=array();

			$sub_array[]=$nu;
			$sub_array[]=$row['INTERVENA'];
			$sub_array[]=(!empty($row['INTERVENANT_STRUCTURE_DESCR'])) ? $row['INTERVENANT_STRUCTURE_DESCR'] : "N/A" ;
			$sub_array[]=$row['EMAIL'];
			$sub_array[]=$row['TELEPHONE1'];
			$sub_array[]=$row['TELEPHONE2'];
			$sub_array[]=$row['DISTRIBUTION_CODE'];
			$sub_array[]=$row['DISTRIBUTION_DATE'];

			$sub_array['INTRAT']="<a href='#' data-toggle='modal' data-target='#intrants".$row['DISTRIBUTION_ID']."'><label class='text-danger'><span>".sizeof($sub_requete)."</span></label></a>";

			$sub_array['INTRAT'].="</ul>
			</div>
			<div class='modal fade' id='intrants".$row['DISTRIBUTION_ID']."'>
			<div class='modal-dialog'>
			<div class='modal-content' style='width:500px;'>

			<div class='modal-body'>
			<center>Listes des intrants demandés</center>
			".$intrants."
			</div>

			<div class='modal-footer'>

			<button class='btn btn-danger btn-md' data-dismiss='modal'>
			Quitter
			</button>
			</div>

			</div>
			</div>
			</div>";


			$array_dist[]=$sub_array;
			$nu++;

		}
		$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
		$this->table->set_template($template);
		$this->table->set_heading(array('#','INTERVENANT','STRUCTURE INTERVENANT','EMAIL','TELEPHONE1','TELEPHONE2','CODE DE DISTRIBUTION','DATE DE DISTRIBUTION','INTRATS'));
		$data['distributions']=$array_dist;
		$data['DEMANDE_ID']=$DEMANDE_ID;


		// $data['demandeurs']=$this->Modele->getRequete('SELECT `DEMANDE_ID`, `DEMANDE_CODE`, `INTERVENANT_STRUCTURE_ID`, `CODE_DEMANDE_SENS_ID`, `USER_DEMANDEUR_ID` FROM `stock_demande` WHERE 1');

		$data['structures_intervenant']=$this->Modele->getRequete('SELECT DISTINCT intervenants_structure.`INTERVENANT_STRUCTURE_ID`,intervenants_structure.INTERVENANT_STRUCTURE_DESCR FROM `stock_distribution` JOIN intervenants_structure ON intervenants_structure.INTERVENANT_STRUCTURE_ID=stock_distribution.INTERVENANT_STRUCTURE_ID WHERE 1 AND stock_distribution.DEMANDE_ID='.$DEMANDE_ID.' ORDER BY intervenants_structure.`INTERVENANT_STRUCTURE_ID` ASC');

//print_r($data['intrants']);
		$this->page='stock_distribution/Distribution_Stock_Historique_View';
		$this->layout($data);

	}




	function get_intervenant_rh($INTERVENANT_STRUCTURE_ID){
		$intervenants = $this->Modele->getRequete('SELECT `INTERVENANT_RH_ID`,CONCAT(`NOM`," ",`PRENOM`) AS NOM FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID);
		$html = '<option value="" >Intervenant RH ---</option>';
		foreach ($intervenants as $interve) {
			$html .= '<option value="'.$interve['INTERVENANT_RH_ID'].'">'.$interve['NOM'].'</option>';
		}
		echo $html;

	}





	function delete($DETAIL_ID='',$DEMANDE_ID='')
	{
		$this->Modele->delete('stock_demande_detail',array('DETAIL_ID'=>$DETAIL_ID));
		redirect(base_url('stock_distribution/Distribution_Intrants/historique_demande/'.$DEMANDE_ID));
	}



	public function Mes_distribution($DISTRIBUTION_ID='')
	{

		$data['title']="Liste des distribution des intrants";

		$DISTRIBUTION_ID = (!empty($DISTRIBUTION_ID)) ? $DISTRIBUTION_ID : 0 ;

		$DEMANDE_ID=$this->input->post('DEMANDE_ID');
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
		$DEMANDE_ID=$this->input->post('DEMANDE_ID');
		$DATE_DISTRIBUTION=$this->input->post('DATE_DISTRIBUTION');

		$data['structures']=$this->Modele->getRequete('SELECT `INTERVENANT_STRUCTURE_ID`, `INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE 1');


		$data['code_sens']=$this->Modele->getRequete('SELECT `CODE_DEMANDE_SENS_ID`, `CODE_DEMANDE_SENS_DESCR`, `SENS_DISTRIBUTION` FROM `stock_demande_code_sens` WHERE 1');

		if (!empty($INTERVENANT_STRUCTURE_ID)) {
		$data['demandeurs']=$this->Modele->getRequete('SELECT `DEMANDE_ID`, `DEMANDE_CODE` FROM `stock_demande` WHERE INTERVENANT_STRUCTURE_ID='.$INTERVENANT_STRUCTURE_ID);
		} else {
		$data['demandeurs']=array();
		}





		$data['DISTRIBUTION_ID']=$DISTRIBUTION_ID;
	    $this->page='stock_distribution/Mes_Distribution_View';
		$this->layout_rapport($data);

	}



	public function get_Info()
   {

   	$USER_ID=$this->session->userdata('iccm_USER_ID');

   	$CODE_DEMANDE_SENS_ID=$this->input->post('CODE_DEMANDE_SENS_ID');
	$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
	$DEMANDE_ID=$this->input->post('DEMANDE_ID');
	$DATE_DISTRIBUTION=$this->input->post('DATE_DISTRIBUTION');

   	$criteres='';
   	$criteres1='';

   	if (!empty($USER_ID))
   	{
   	 $criteres.=" AND std.USER_ID=".$USER_ID;
   	}

   	if (!empty($INTERVENANT_STRUCTURE_ID))
   	{
   		$criteres1.=" AND std.INTERVENANT_STRUCTURE_ID=".$INTERVENANT_STRUCTURE_ID;

   		if (!empty($DEMANDE_ID))
   		{
   			$criteres1.=" AND std.DEMANDE_ID=".$DEMANDE_ID;
   		}
   	}
   	if (!empty($CODE_DEMANDE_SENS_ID)) {
   		$criteres1.=" AND std.CODE_SENS_ID=".$CODE_DEMANDE_SENS_ID;
   	}

   	if (!empty($DATE_DISTRIBUTION)) {
   		$criteres1.=" AND std.DISTRIBUTION_DATE='".$DATE_DISTRIBUTION."'";
   	}




    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
    $query_principal='SELECT `DISTRIBUTION_ID`,stde.DEMANDE_CODE, `DISTRIBUTION_CODE`,`DISTRIBUTION_DATE`, sts.CODE_DEMANDE_SENS_DESCR,CONCAT(rh.NOM," ",rh.PRENOM) as NOM,intervena.INTERVENANT_STRUCTURE_DESCR FROM `stock_distribution` std JOIN stock_demande_code_sens sts ON sts.SENS_DISTRIBUTION=std.`CODE_SENS_ID` JOIN stock_demande stde ON stde.DEMANDE_ID=std.`DEMANDE_ID` JOIN intervenants_structure intervena ON intervena.INTERVENANT_STRUCTURE_ID=std.`INTERVENANT_STRUCTURE_ID` JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=std.`INTERVENANT_RH_ID`  WHERE 1';


    $limit='LIMIT 0,10';
    if($_POST['length'] != -1){
      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
    }

    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY std.DISTRIBUTION_ID DESC';

     $search = !empty($_POST['search']['value']) ? (" AND (DEMANDE_CODE LIKE '%$var_search%' OR DISTRIBUTION_CODE LIKE '%$var_search%' OR  DISTRIBUTION_DATE LIKE '%$var_search%' OR CODE_DEMANDE_SENS_DESCR LIKE '%$var_search%' OR CONCAT(rh.NOM,' ',rh.PRENOM) LIKE '%$var_search%' OR INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';

     $critaire =$criteres.$criteres1;


     $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
     $query_filter=$query_principal.'  '.$critaire.' '.$search;

     $fetch_data = $this->Modele->datatable($query_secondaire);
      $u=0;
    $data = array();
    foreach ($fetch_data as $row) {
     $u++;
     $sub_array = array();

     $sub_array[] =$u;
     $sub_array[] =$row->DISTRIBUTION_CODE;
     $sub_array[] =$row->CODE_DEMANDE_SENS_DESCR;
     $sub_array[] =$row->INTERVENANT_STRUCTURE_DESCR;
     $sub_array[] =$row->NOM;
     $sub_array[] =$row->DISTRIBUTION_DATE;

     $options= '<div class="dropdown">
			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" style="color:#fff;">
			<i class="fa fa-cog"></i>
			Options <span class="caret"></span>
			</a>
			<ul class="dropdown-menu dropdown-menu-left">';
	$options.="<li><a href='#' onclick='histo_distribution(".$row->DISTRIBUTION_ID.")'><label class='text-info'>Détail</label></a></li>";

     $sub_array[]=$options;
    $data[] = $sub_array;



    }

    $output = array(
               "draw" => intval($_POST['draw']),
               "recordsTotal" =>$this->Modele->all_data($query_principal),
               "recordsFiltered" => $this->Modele->filtrer($query_filter),
               "data" => $data
          );

          echo json_encode($output);
    }


    public function get_Info1($id)
   {


    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
    $query_principal='SELECT DETAIL_ID,`RECEPTION_CODE`, `QUANTITE`, `QUANTITE_RESTANTE`,intra.INTRANT_MEDICAUX_DESCR FROM `stock_distribution_intrant_detail` stds JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stds.`INTRANT_ID` WHERE 1';


    $limit='LIMIT 0,10';
    if($_POST['length'] != -1){
      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
    }

    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY DETAIL_ID DESC';

     $search = !empty($_POST['search']['value']) ? (" AND (RECEPTION_CODE LIKE '%$var_search%' OR QUANTITE LIKE '%$var_search%' OR  QUANTITE_RESTANTE LIKE '%$var_search%' OR INTRANT_MEDICAUX_DESCR LIKE '%$var_search%')") : '';

     $critaire =" AND stds.`DISTRIBUTION_ID`=".$id;



     $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
     $query_filter=$query_principal.'  '.$critaire.' '.$search;

     $fetch_data = $this->Modele->datatable($query_secondaire);
      $u=0;
    $data = array();
    foreach ($fetch_data as $row) {
     $u++;
     $sub_array = array();

     $sub_array[] =$u;
     $sub_array[] =$row->RECEPTION_CODE;
     $sub_array[] =$row->INTRANT_MEDICAUX_DESCR;
     $sub_array[] =$row->QUANTITE;
     $sub_array[] =$row->QUANTITE_RESTANTE;

    $data[] = $sub_array;



    }

    $output = array(
               "draw" => intval($_POST['draw']),
               "recordsTotal" =>$this->Modele->all_data($query_principal),
               "recordsFiltered" => $this->Modele->filtrer($query_filter),
               "data" => $data
          );

          echo json_encode($output);
    }



}
