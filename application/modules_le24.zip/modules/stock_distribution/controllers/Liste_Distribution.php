<?php 

/**
 * christa
 */
class Liste_Distribution extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
 
	
	function index($DISTRIBUTION_ID=0)
		{

			$annee=$this->Modele->getRequete('SELECT DISTINCT date_format(`DISTRIBUTION_DATE`,"%Y")AS annee FROM stock_distribution');
			$ANNEE=$this->input->post('ANNEE');


			$data['annee'] = $annee;
			$data['ANNEE'] = $ANNEE;
			$data['title']="Distribution";
			$data['DISTRIBUTION_ID']=$DISTRIBUTION_ID;
			$this->load->view("Liste_Distribution_View",$data);
		}
	function listing($ann=0)
	{
			$criteres='';
			if ($ann>0) {
				# code...
				$criteres.=" AND date_format(`DISTRIBUTION_DATE`,'%Y')=".$ann;
			}

		$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

		if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS") {
			# code...
			$query_principal='SELECT stock_distribution.DISTRIBUTION_ID, stock_distribution.DISTRIBUTION_CODE, stock_distribution.DISTRIBUTION_DATE,stock_distribution.INTERVENANT_STRUCTURE_ID,intervenants_structure.INTERVENANT_STRUCTURE_DESCR FROM `stock_distribution` JOIN intervenants_structure ON stock_distribution.INTERVENANT_STRUCTURE_ID=intervenants_structure.INTERVENANT_STRUCTURE_ID JOIN stock_distribution_intrant_detail st ON stock_distribution.DISTRIBUTION_ID=st.DISTRIBUTION_ID  WHERE stock_distribution.`INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').' '.$criteres.' ';

		}elseif ($this->session->userdata('iccm_PROFIL_CODE')=="CDS") {
			# code...
			$query_principal='SELECT stock_distribution.DISTRIBUTION_ID, stock_distribution.DISTRIBUTION_CODE, stock_distribution.DISTRIBUTION_DATE,stock_distribution.INTERVENANT_STRUCTURE_ID,intervenants_structure.INTERVENANT_STRUCTURE_DESCR FROM `stock_distribution` JOIN intervenants_structure ON stock_distribution.INTERVENANT_STRUCTURE_ID=intervenants_structure.INTERVENANT_STRUCTURE_ID JOIN stock_distribution_intrant_detail st ON stock_distribution.DISTRIBUTION_ID=st.DISTRIBUTION_ID WHERE stock_distribution.`INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').' '.$criteres.' ';
		}else/*if ($this->session->userdata('iccm_PROFIL_CODE')=="CAM")*/ {
			# code...
			
			
			$query_principal='SELECT stock_distribution.DISTRIBUTION_ID, stock_distribution.DISTRIBUTION_CODE, stock_distribution.DISTRIBUTION_DATE,stock_distribution.INTERVENANT_STRUCTURE_ID,intervenants_structure.INTERVENANT_STRUCTURE_DESCR FROM `stock_distribution` JOIN intervenants_structure ON stock_distribution.INTERVENANT_STRUCTURE_ID=intervenants_structure.INTERVENANT_STRUCTURE_ID JOIN stock_distribution_intrant_detail st ON stock_distribution.DISTRIBUTION_ID=st.DISTRIBUTION_ID WHERE 1 '.$criteres.' ';
		}


		$limit='LIMIT 0,10';


		if($_POST['length'] != -1) {
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}


		$order_by='';
		if($_POST['order']['0']['column']!=0){
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY DISTRIBUTION_DATE   DESC';
		}

		$search = !empty($_POST['search']['value']) ? (" AND  INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%'  ") : '';

		$critaire="";
		$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		$query_filter=$query_principal.'  '.$critaire.' '.$search;


		$fetch_distribution= $this->Modele->datatable($query_secondaire);

		$data = array();
		foreach ($fetch_distribution as $row) {

      $sqli="SELECT * FROM `stock_distribution_intrant_detail` WHERE `DISTRIBUTION_ID`=".$row->DISTRIBUTION_ID; 

        $intrants=$this->Modele->getRequete($sqli);


			
			$sub_array = array();

			$sub_array[] = $row->DISTRIBUTION_CODE;
			$sub_array[] = $row->INTERVENANT_STRUCTURE_DESCR;
			$sub_array[] = $row->DISTRIBUTION_DATE;
			
			$sub_array[] = "<center><a href='#' onclick='detail_intra(".$row->DISTRIBUTION_ID.");' style='cursor:pointer;'>".sizeof($intrants)."</a></center>";

			$data[] = $sub_array;

		}
		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($query_principal),
			"recordsFiltered" => $this->Modele->filtrer($query_filter),
			"data" => $data
		);

		echo json_encode($output);

	}




   function get_Detail($id)
  {


  	$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
  	$var_search=str_replace("'", "\'", $var_search);  
  	$query_principal="SELECT
    intr.INTRANT_MEDICAUX_DESCR,
    st.QUANTITE
    FROM
    stock_distribution_intrant_detail st
    JOIN intrant_medicaux intr ON
    intr.INTRANT_MEDICAUX_ID=st.INTRANT_ID WHERE 1
    ";

  	$group="";
  	$critaire=" AND st.DISTRIBUTION_ID=".$id;

  	$limit='LIMIT 0,10';
  	if($_POST['length'] != -1){
  		$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
  	}
  	$order_by='';
  	if($_POST['order']['0']['column']!=0){
  		$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY intr.INTRANT_MEDICAUX_DESCR DESC';
  	}

  	$search = !empty($_POST['search']['value']) ? (" AND (intr.INTRANT_MEDICAUX_DESCR LIKE '%$var_search%')") : '';



  	$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
  	$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

  	$fetch_data = $this->Modele->datatable($query_secondaire);
  	$u=0;
  	$data = array();


  	foreach ($fetch_data as $row) {

  		$u++;
  		$sub_array = array();
  		$sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
  		$sub_array[]=$row->QUANTITE;
  		
  		$data[] = $sub_array;

  	}

  	$output = array(
  		"draw" => intval($_POST['draw']),
  		"recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
  		"recordsFiltered" => $this->Modele->filtrer($query_filter),
  		"data" => $data
  	);
  	echo json_encode($output);

  }
}

?>