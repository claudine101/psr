<ul class="nav nav-pills">
 <li class="nav-item">
    <a class="<?php echo $menu1 ?> btn-sm" href="<?=base_url('stock_distribution/Liste_Distribution')?>"><h6>Distribution</h6></a>
  </li>
  <li class="nav-item">
    <a class="<?php echo $menu2 ?> btn-sm" href="<?=base_url('stock_distribution/Liste_Sms_Distribution')?>"><h6> Distribution Asc - Population</h6></a>
  </li>
  <!-- <li class="nav-item">
    <a class="<?php echo $menu3 ?> btn-sm" href="<?=base_url('ihm/Cds_asc')?>">ASC</a>
  </li> -->
</ul><br>