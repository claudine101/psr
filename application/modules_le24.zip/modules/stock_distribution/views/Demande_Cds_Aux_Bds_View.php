
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h4 class="m-0">Demande</h4>
            </div><!-- /.col -->
            <div class="col-sm-12 text-right">


              <span style="margin-right: 15px">
                <div class="col-sm-12" style="float:right;">
                  <?php  if ($this->session->userdata('iccm_PROFIL_CODE')=="CDS") {
                    ?>
                    <a href="<?=base_url('demande/Demande/add_demande')?>" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Nouvelle demande</a>
                    <!-- <a href="<?=base_url('stock_distribution/Detail/index')?>" class="btn btn-primary float-left"><i class="fa fa-book"></i>Historique de distribution</a>
 -->
                    <?php } ?>
                  </div>

                </span>

              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>


        <div class="modal fade bd-example-modal-lg" id="modal_appr" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div  id="error_message"></div>

                <div id="ret_data" class="col-12"></div> 
              </div>
              <div class="modal-footer">
                <button  type="button" id="btn_approuver" class="btn btn-primary" onclick="valider_approuvation(2)">Approuver</button>
                <button  type="button" id="btn_ar" class="btn btn-primary" onclick="valider_approuvation(1)">Comfirmer</button>
              </div>     
            </div>
          </div>
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
          <div class="col-md-12 col-xl-12 grid-margin stretch-card">

            <div class="card">
              <div class="card-body">

                <div class="col-md-12">
                 <div class="card">
                  <div class="card-header d-flex p-0">
                    <h3 class="card-title p-3">Mes demandes</h3>
                    <ul class="nav nav-pills ml-auto p-3">
                      <li class="nav-item"><a class="nav-link active" href="#tab_1" onclick="tabs_verify(0)" id="ENCOURS"  data-toggle="tab">En cours</a></li>
                      <li class="nav-item"><a class="nav-link" href="#tab_2" id="RECU" onclick="tabs_verify(1)"  data-toggle="tab">Reçue</a></li>
                      <li class="nav-item"><a class="nav-link" href="#tab_3" id="SERVIR"  onclick="tabs_servir(1)"  data-toggle="tab">Servir</a></li>
                    </ul>

                    <input type="hidden" name="" id="TEST" value="1">



                  </div><!-- /.card-header -->
                  <div class="card-body">
                    <div class="tab-content">
                      <div class="tab-pane active" id="tab_1">
                        <div style="padding-top: 5px;" class="col-md-12">
                          <?php echo $this->session->flashdata('sms'); ?>
                        </div>

                        <div style="padding-top: 5px;" class="col-md-12" id="EVALUATION_TABLE">
                          <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                            <thead>
                              <tr>
                                <th>#</th>
                                <!-- <th>CODE</th> -->
                                <th>DEMANDEUR</th>
                                <th>DEMANDES</th>
                                <th>OPTION</th>
                              </tr>
                            </thead>

                          </table>


                          


                        </div>


    <!-- SERVIR TABLE -->

      <div style="padding-top: 5px;display: none;" class="row" id="SERVIR_TABLE">
        <!-- <div class="card" > -->
          <div class="container" style="padding:12px;">
            <div class="col-12 row">
              <div class="col-4">
                <label>ASC<span class="text-danger">*</span></label>
                <select class="form-control" name="INTERVENANT_RH_ID" id="INTERVENANT_RH_ID">
                  <option value="0">sélectionner</option>
                  <?php foreach ($intervenants_rh as $key) {
                # code...
                   ?>
                   <option value="<?= $key['INTERVENANT_STRUCTURE_ID']?>"><?= $key['NOM']?></option>

                   <?php  } ?>

                 </select>
               </div>

               <div class="col-4">
                <label>Pièce justificative</label>
                <input type="file" name="PIECE_JUSTIFICATIF" id="PIECE_JUSTIFICATIF" class="form-control">
              </div>
              <div class="col-4">
                <label>Commentaire</label>
                <textarea class="form-control" name="COMMENT" id="COMMENT"></textarea>
              </div>
            </div>
            <!-- <input type="hidden" id="INTERVENANT_STRUCTURE_ID" value="<?= $INTERVENANT_STRUCTURE_ID ?>"> -->
            <input type="hidden" id="CDS_PARENT_ID" value="<?= $CDS_PARENT_ID ?>">
             <input type="hidden" value="0" id="COMPTEUR">



            <ul style=" margin-top: 5px;" class="nav nav-tabs">
              <?php
              $i=0;
              foreach ($stock_distribution_detail as $key) {
                  # code...
                if ($i==0) {
                  ?>
                  <input type="hidden" id="INTRANT_MEDICAUX_ID" value="<?= $key['INTRANT_MEDICAUX_ID'] ?>">
                  <li  class="nav-item"><a class="nav-link" id="intr<?= $i ?>" href="#" title='<?=$key['INTRANT_MEDICAUX_DESCR']?>' onclick="get_intrant_dispo_by_ptf(<?= $key['INTRANT_MEDICAUX_ID'].",".$i?>);getstock_total(<?= $key['INTRANT_MEDICAUX_ID'].','.$CDS_PARENT_ID ?>);get_historique(<?= $key['INTRANT_MEDICAUX_ID'].",".$CDS_PARENT_ID ?>)"><?= $key['INTRANT_MEDICAUX_CODE'] ?></a></li>

                  <?php }else{ ?>

                    <li class="nav-item"><a class="nav-link" id="intr<?= $i ?>" href="#" title='<?=$key['INTRANT_MEDICAUX_DESCR']?>' onclick="get_intrant_dispo_by_ptf(<?= $key['INTRANT_MEDICAUX_ID'].",".$i ?>);getstock_total(<?= $key['INTRANT_MEDICAUX_ID'].','.$CDS_PARENT_ID ?>);get_historique(<?= $key['INTRANT_MEDICAUX_ID'].",".$CDS_PARENT_ID ?>)"><?= $key['INTRANT_MEDICAUX_CODE'] ?></a></li>
                    <?php
                  }
                  $i++;
                }
                ?>

              </ul>
              <input type="hidden" name="COMPTEUR" id="COMPTEUR" value="0">
              <div class="modal fade bd-example-modal-sm erreur_modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <div id="error" ></div>
                  </div>
                </div>
              </div>

              <div class="modal fade bd-example-modal-sm" id="toblock" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <i class="text-info">Opération en cours...</i>
                  </div>
                </div>
              </div>

              <div class="col-12 row">
               <div class="col-sm-6 text-info" id="qte_total"></div>

               <div class="col-12 table-responsive">
                <table id='mytable1' class="table table-bordered table-striped table-hover table-condensed table-sm" style="margin-top: 8px;" >
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>PTF</th>
                      <th>LOT</th>
                      <th>DATE PEREMPTION</th>
                      <th>QUANTITE DISPONIBLE</th>
                      <th>QUANTITE A DONNE</th>
                      <th>OPTION</th>
                    </tr>
                  </thead>

                </table>
              </div>
              <div class="col-12 table-responsive">
                <table id='mytable2' class="table table-bordered table-striped table-hover table-condensed table-sm" style="margin-top: 8px;" >
                  <thead>
                   <tr class="text-center"><th colspan="6" class="text-center"><h4>Historique</h4></th></tr>

                   <tr>
                    <th>#</th>
                    <th>PTF</th>
                    <th>LOT</th>
                    <th>QTE RECU</th>
                    <th>QTE RESTANTE</th>
                    <th>QTE DISTRIBUE</th>
                  </tr>
                </thead>

              </table>
            </div>
          </div>

        </div>
      <!-- </div>      -->
  </div>

  <!-- END -->

                      </div>

                    </div>
                    <!-- /.tab-content -->
                  </div><!-- /.card-body -->
                </div>
              </div>


              <!--  VOS CODE ICI  -->



            </div>
          </div>
        </div>
      </section>

    </div>

  </div>
  <!-- ./wrapper -->
  <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>

<script type="text/javascript">
  $(document).ready(function()
  {

   $("#message").delay("slow").fadeOut(3000);

   $( "#ENCOURS" ).on('click',function() {

     getList(0);
   });

   $( "#RECU" ).on('click',function() {


     getList(1);
   });



   getList(0);
   
 });
</script>




<script type="text/javascript">
  function valider_approuvation(type_action) {
    // body...
    let compteur=$('#counter').val();
    let DEMANDE=$('#DEMANDE').val();
    type_action= Number(type_action);
    if (type_action==1) {
      //accuse de reception


      let i=0;
      var QUANTITE_RECU=0;
      var QUANTITE_COMFIRMER_RECU=0;
      var form= new FormData();
      let u=0;
      for (let i = 0; i < compteur; i++) {


       QUANTITE_RECU=parseFloat($('#QUANTITE_RECU'+i).val());
       QUANTITE_COMFIRMER_RECU=parseFloat($('#QUANTITE_COMFIRMER_RECU'+i).val());
       DETAIL_ID=parseFloat($('#DETAIL_ID'+i).val());

       
       if (QUANTITE_RECU<QUANTITE_COMFIRMER_RECU) {
         $('#error_message').html('<div class="text-danger">Veuillez saisir la quantité inférieure ou égale à la quantité reçue</div>');
         u=5
       }else{
         form.append("QUANTITE_COMFIRMER_RECU"+i,QUANTITE_COMFIRMER_RECU);
         form.append("DETAIL_ID"+i,DETAIL_ID);
       }
       
       
     }
     form.append("compteur",compteur);
     form.append("DEMANDE_ID",DEMANDE);
     form.append("type_action",type_action);
     if (u!=5) {

       $.ajax({
        url: "<?php echo base_url('stock_distribution/DistributionCdsAsc/valider_approuvation');?>",
        type: "POST",
        data: form,
        processData: false,  
        contentType: false,
        success:function(data) 
        { 
         if (data==1) {
          $('#error_message').html('<div class="text-success">Opération faite avec succès</div>');
          $('#modal_appr').modal('hide');

        }else{
          $('#error_message').html('<div class="text-danger">Opération echouée</div>');

        }
        

      }

    });
     } 
     


   }else{
    //Approbation

    let i=0;
    var QUANTITE_APPROUVEE=0;
    var QUANTITE_DISPONIBLE=0;
    var form= new FormData();
    let u=0;
    for (let i = 0; i < compteur; i++) {


     QUANTITE_APPROUVEE=parseFloat($('#QUANTITE_APPROUVEE'+i).val());
     QUANTITE_DISPONIBLE=parseFloat($('#QUANTITE_DISPONIBLE'+i).val());
     DETAIL_ID=parseFloat($('#DETAIL_ID'+i).val());

     
     if (QUANTITE_DISPONIBLE<QUANTITE_APPROUVEE) {
       $('#error_message').html('<div class="text-danger">Veuillez saisir la quantité inférieure ou égale à la quantité disponible</div>');
       u=5
     }else{
       form.append("QUANTITE_APPROUVEE"+i,QUANTITE_APPROUVEE);
       form.append("DETAIL_ID"+i,DETAIL_ID);
     }
     
     
   }
   form.append("compteur",compteur);
   form.append("DEMANDE_ID",DEMANDE);
   form.append("type_action",type_action);
   if (u!=5) {




     $.ajax({
      url: "<?php echo base_url('stock_distribution/DistributionCdsAsc/valider_approuvation');?>",
      type: "POST",
      data: form,
      processData: false,  
      contentType: false,
      success:function(data) 
      { 
       if (data==1) {
        $('#error_message').html('<div class="text-success">Opération faite avec succès</div>');
        
        $('#modal_appr').modal('hide');

      }else{
        $('#error_message').html('<div class="text-danger">Opération echouée</div>');

      }
      

    }

  });
   }



 }

}
</script>







<script>

  function getList(idvalue)
  {

//alert(idvalue);
var INTERVENANT_STRUCTURE_ID='<?= $INTERVENANT_STRUCTURE_ID ?>';
 //var INTERVENANT_STRUCTURE_ID=219;
 var row_count ="1000000";
 $("#mytable").DataTable({
  "processing":true,
  "destroy" : true,
  "serverSide":true,
  "oreder":[[ 0, 'desc' ]],
  "ajax":{
    url:"<?=base_url()?>stock_distribution/DistributionCdsAsc/demandes_des_cds/",
    type:"POST",
    data : {
      idvalue:idvalue,
      INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID
    }
  },
  lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
  pageLength: 10,
  "columnDefs":[{
    "targets":[],
    "orderable":false
  }],

  dom: 'Bfrtlip',
  buttons: [
  'copy', 'csv', 'excel', 'pdf', 'print'
  ],
  language: {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
      "sFirst":      "Premier",
      "sPrevious":   "Pr&eacute;c&eacute;dent",
      "sNext":       "Suivant",
      "sLast":       "Dernier"
    },
    "oAria": {
      "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
      "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    }
  }

});

}





</script>





<script>
  
  $(document).ready(function(){

    $('#SERVIR').on('click',function()
    {
      // var tab=1;
      $("#EVALUATION_TABLE").hide();
      $("#SERVIR_TABLE").show();


     
    });

   
    
  });


  function tabs_verify(recu)
  {
    let recur=recu;
    $("#EVALUATION_TABLE").show();
    $("#SERVIR_TABLE").hide();
    getList(recur);


  }

  // check vlaue

  function check_qty_given(id,qty_restante)
  {
    var QTE_DONNEE=$("#QTE_DONNEE"+id).val();
    var qty=qty_restante;
    // alert(qty);
  }




  function tabs_servir(value)
  {
    let dist=value;
    // get_liste_servir(dist);
    


  }








</script>



<!-- nouvelle -->


<script type="text/javascript">
  function get_demande_for_ar(DEMANDE_ID,TEST_VALUE) {
    // body...

    // alert(DEMANDE_ID);
    if (TEST_VALUE==1) {
      $('#title').html('Accusé de réception');
      $('#btn_ar').show();
      $('#btn_approuver').hide();
    }else{
      $('#title').html('Approbation');
      $('#btn_ar').hide();
      $('#btn_approuver').show();
    }
    $('#modal_appr').modal({backdrop: false });
    $.post('<?php echo base_url();?>stock_distribution/DistributionCdsAsc/get_demande_detail',
    {
      DEMANDE_ID:DEMANDE_ID,
      TEST_VALUE:TEST_VALUE
      
    },
    function(data) 
    { 
      ret_data.innerHTML = data;  
      $('#ret_data').html(data);

    });  
  }
</script>

<script type="text/javascript">
  function get_valeur(u) {

  // body...
  var QUANTITE_APPROUVE=$('#QUANTITE_APPROUVE'+u).val();

  //alert(QUANTITE_APPROUVE);

  document.getElementById("QUANTITE_APPROUVE"+u).value=QUANTITE_APPROUVE
  var QUANTITE_APPROUVE=$('#QUANTITE_APPROUVE'+u).val();

}







function valider(INTRANT_MEDICAUX_ID,i,QUANTITE_DISPONIBLE,DETAIL_ID,QUANTITE_APPROUVEE,comteur_id=0,RECEPTION_INTRANT_ID,DEMANDE_ID,RECEPTION_CODE)
{
  // body...
  var QUANTITE_DISPO=parseFloat(QUANTITE_DISPONIBLE);
  // var QUANTITE_APPROUVE=parseFloat(QUANTITE_APPROUVEE);
   var QUANTITE_APPROUVE=parseFloat($('#QUANTITE_APPROUVE'+i).val());

  var INTERVENANT_RH_ID =Number($('#INTERVENANT_RH_ID').val());
  var PIECE_JUSTIFICATIF =$('#PIECE_JUSTIFICATIF').val();
  var COMPTEUR =Number($('#COMPTEUR').val());



  
   // alert($('#CDS_PARENT_ID').val());

  if ( QUANTITE_DISPO >= QUANTITE_APPROUVE && QUANTITE_APPROUVE>0 && INTERVENANT_RH_ID>0){


   $('#toblock').modal({ backdrop: false });
   var form= new FormData();   
   form.append("QUANTITE_DISPONIBLE",QUANTITE_DISPONIBLE);
   form.append("QUANTITE_APPROUVE",QUANTITE_APPROUVE);
   form.append("INTRANT_MEDICAUX_ID",INTRANT_MEDICAUX_ID);
   form.append("PIECE_JUSTIFICATIF",$('input[type=file]')[0].files[0]);
   form.append("RECEPTION_INTRANT_ID",RECEPTION_INTRANT_ID);
   form.append("DETAIL_ID",DETAIL_ID);
   form.append("DEMANDE_ID",DEMANDE_ID);
   form.append("RECEPTION_CODE",RECEPTION_CODE);
   form.append("INTERVENANT_RH_ID",INTERVENANT_RH_ID);
   form.append("COMMENT",$('#COMMENT').val());
   form.append("INTERVENANT_RH_ID",$('#INTERVENANT_RH_ID').val());
   form.append("CDS_PARENT_ID",$('#CDS_PARENT_ID').val());

   $.ajax({
    url: "<?php echo base_url('stock_distribution/DistributionCdsAsc/valider');?>",
    type: "POST",
    data: form,
    processData: false,  
    contentType: false,
    success:function(data) 
    { 

     // alert(data);

     if (data=='2') {


       $('#error').html('<div class="alert alert-success">Opération réussie avec succes</div>')
       $('.erreur_modal').modal();
       $('#INTERVENANT_RH_ID').attr('disabled',true);
       get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,COMPTEUR,"<?=$CDS_PARENT_ID ?>");
       getstock_total(INTRANT_MEDICAUX_ID,"<?=$CDS_PARENT_ID ?>");
       $('#toblock').modal('hide');
     }else{
       $('#error').html('<div class="alert alert-danger">Erreur de connexion!</div>')
       $('.erreur_modal').modal();


     }
   }

 });

 }else{
   $('#error').html('<div class="alert alert-danger">Veillez remplir tous les champs</div>')
   $('.erreur_modal').modal();


 }
}

$(document).ready(function () { 
  var i =0;
  var INTRANT_MEDICAUX_ID=$('#INTRANT_MEDICAUX_ID').val();
  var CDS_PARENT_ID=$('#CDS_PARENT_ID').val();
 // document.getElementById("intr"+i).className = "nav-link active";
 get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,i);
 getstock_total(INTRANT_MEDICAUX_ID,CDS_PARENT_ID);
 get_historique(INTRANT_MEDICAUX_ID,CDS_PARENT_ID);

});





function get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,i=0,CDS_PARENT_ID) {
  // body...
  var CDS_PARENT_ID=$('#CDS_PARENT_ID').val()
  //alert(CDS_PARENT_ID);
  document.getElementById("COMPTEUR").value=i
  var counter='<?= $i ?>';

  counter=Number(counter);
  j=0;
  while(j<counter){

   if (j==i) {
    document.getElementById("intr"+j).className = "nav-link active";

  }else {
    document.getElementById("intr"+j).className = "nav-link ";

  }
  j++;
}

// var DEMANDE_ID=12;

    //alert(DEMANDE_ID);
    var row_count ="1000000";
    $('#mytable1').DataTable( {
      "processing":true,
      "destroy" : true,
      "serverSide":true,
      "searching": false,
      "paging": false,
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "order":[[ 0, 'desc' ]],
      // "buttons": ["copy", "csv", "excel", "pdf", "print"],
      "ajax":{
        url:"<?=base_url()?>stock_distribution/DistributionCdsAsc/liste_intrant_quantite/",
        type:"POST",
        data : {

         INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
         // INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
         // DEMANDE_ID:DEMANDE_ID,
         CDS_PARENT_ID:CDS_PARENT_ID


       }
     },
     lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
     pageLength: 10,
     "columnDefs":[{
      "targets":[1,2,3,4,5,6],
      "orderable":false
    }],

    language: {
      "sProcessing":     "Traitement en cours...",
      "sSearch":         "Rechercher&nbsp;:",
      "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
      "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
      "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
      "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
      "sInfoPostFix":    "",
      "sLoadingRecords": "Chargement en cours...",
      "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
      "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
      "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
      },
      "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
      }
    }
  } )
  }
  function get_historique(INTRANT_MEDICAUX_ID,CDS_PARENT_ID) {
  // body...


  var row_count ="1000000";
  $('#mytable2').DataTable( {
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "searching": false,
    "paging": false,
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "order":[[ 0, 'desc' ]],
    // "buttons": ["copy", "csv", "excel", "pdf", "print"],
    "ajax":{
      url:"<?=base_url()?>stock_distribution/DistributionCdsAsc/historique/",
      type:"POST",
      data : {

       INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
       CDS_PARENT_ID:CDS_PARENT_ID


     }
   },
   lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
   pageLength: 10,
   "columnDefs":[{
    "targets":[1,2,3,4,5],
    "orderable":false
  }],

  language: {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
      "sFirst":      "Premier",
      "sPrevious":   "Pr&eacute;c&eacute;dent",
      "sNext":       "Suivant",
      "sLast":       "Dernier"
    },
    "oAria": {
      "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
      "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    }
  }
} )
}
function getstock_total(INTRANT_MEDICAUX_ID,CDS_PARENT_ID)
{
  //var INTERVENANT_STRUCTURE_ID=STRUCTURE_ID;

  $.post('<?php echo base_url();?>stock_distribution/DistributionCdsAsc/getstock_total/',
  {
    //INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
    INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
    CDS_PARENT_ID:CDS_PARENT_ID,

    
  },
  function(data) 
  { 
    qte_total.innerHTML = data; 
    $('#qte_total').html(data);

   // $('#INTERVENANT_STRUCTURE_ID').selectpicker('refresh');
 }); 

}
</script>





