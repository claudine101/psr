<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-8">
              <h6 class="m-0"><?=$title?></h6>
              <br>
            </div><!-- /.col -->

          
            <div class="col-sm-12 ">
           <?php  if ($this->session->userdata('iccm_PROFIL_CODE')) {
            ?>
           <a href="<?=base_url('demande/Demande/add_demande')?>" class="btn btn-primary float-right">Nouvelle demande</a>
           <a href="<?=base_url('stock_distribution/DistributionCdsAsc/mes_demande')?>" class="btn btn-primary float-left">Mes demandes</a>
           <?php } ?>
          </div>
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->

      <section class="content">

        <div class="card" >
          <div class="container" style="padding:12px;">
            <div class="col-12 row">
              <div class="col-4">
                <label>ASC<span class="text-danger">*</span></label>
                <select class="form-control" name="INTERVENANT_RH_ID" id="INTERVENANT_RH_ID">
                  <option value="0">sélectionner</option>
                  <?php foreach ($intervenants_rh as $key) {
                # code...
                   ?>
                   <option value="<?= $key['INTERVENANT_STRUCTURE_ID']?>"><?= $key['NOM']?></option>

                   <?php  } ?>

                 </select>
               </div>

               <div class="col-4">
                <label>Pièce justificatif</label>
                <input type="file" name="PIECE_JUSTIFICATIF" id="PIECE_JUSTIFICATIF" class="form-control">
              </div>
              <div class="col-4">
                <label>Commentaire</label>
                <textarea class="form-control" name="COMMENT" id="COMMENT"></textarea>
              </div>
            </div>
            <!-- <input type="hidden" id="INTERVENANT_STRUCTURE_ID" value="<?= $INTERVENANT_STRUCTURE_ID ?>"> -->
            <input type="hidden" id="CDS_PARENT_ID" value="<?= $CDS_PARENT_ID ?>">
            <input type="hidden" id="CODE_SENS_ID" value="<?= $CODE_SENS_ID ?>">



            <ul style=" margin-top: 5px;" class="nav nav-tabs">
              <?php
              $i=0;
              foreach ($stock_distribution_detail as $key) {
                  # code...
                if ($i==0) {
                  ?>
                  <input type="hidden" id="INTRANT_MEDICAUX_ID" value="<?= $key['INTRANT_MEDICAUX_ID'] ?>">
                  <li  class="nav-item"><a class="nav-link" id="intr<?= $i ?>" href="#" onclick="get_intrant_dispo_by_ptf(<?= $key['INTRANT_MEDICAUX_ID'].",".$i?>);getstock_total(<?= $key['INTRANT_MEDICAUX_ID'].','.$CDS_PARENT_ID ?>);get_historique(<?= $key['INTRANT_MEDICAUX_ID'].",".$CDS_PARENT_ID ?>)"><?= $key['INTRANT_MEDICAUX_CODE'] ?></a></li>

                  <?php }else{ ?>

                    <li class="nav-item"><a class="nav-link" id="intr<?= $i ?>" href="#" onclick="get_intrant_dispo_by_ptf(<?= $key['INTRANT_MEDICAUX_ID'].",".$i ?>);getstock_total(<?= $key['INTRANT_MEDICAUX_ID'].','.$CDS_PARENT_ID ?>);get_historique(<?= $key['INTRANT_MEDICAUX_ID'].",".$CDS_PARENT_ID ?>)"><?= $key['INTRANT_MEDICAUX_CODE'] ?></a></li>
                    <?php
                  }
                  $i++;
                }
                ?>

              </ul>
              <input type="hidden" name="COMPTEUR" id="COMPTEUR" value="0">
              <div class="modal fade bd-example-modal-sm erreur_modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <div id="error" ></div>
                  </div>
                </div>
              </div>

              <div class="modal fade bd-example-modal-sm" id="toblock" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <i class="text-info">Opération en cours...</i>
                  </div>
                </div>
              </div>

              <div class="col-12 row">
               <div class="col-sm-6 text-info" id="qte_total"></div>

               <div class="col-12 table-responsive">
                <table id='mytable' class="table table-bordered table-striped table-hover table-condensed table-sm" style="margin-top: 8px;" >
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>PTF</th>
                      <th>LOT</th>
                      <th>DATE PEREMPTION</th>
                      <th>QUANTITE DISPONIBLE</th>
                      <th>QUANTITE A DONNE</th>
                      <th>OPTION</th>
                    </tr>
                  </thead>

                </table>
              </div>
              <div class="col-12 table-responsive">
                <table id='mytable2' class="table table-bordered table-striped table-hover table-condensed table-sm" style="margin-top: 8px;" >
                  <thead>
                   <tr class="text-center"><th colspan="6" class="text-center"><h4>Historique</h4></th></tr>

                   <tr>
                    <th>#</th>
                    <th>PTF</th>
                    <th>LOT</th>
                    <th>QTE RECU</th>
                    <th>QTE RESTANTE</th>
                    <th>QTE DISTRIBUE</th>
                  </tr>
                </thead>

              </table>
            </div>
          </div>

        </div>
      </div>     
    </section>

    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>


<script type="text/javascript">
  function get_demande_for_ar(DEMANDE_ID,TEST_VALUE) {
    // body...
    if (TEST_VALUE==1) {
      $('#title').html('Accusé de réception');
      $('#btn_ar').show();
      $('#btn_approuver').hide();
    }else{
      $('#title').html('Approbation');
      $('#btn_ar').hide();
      $('#btn_approuver').show();
    }
    $('#modal_appr').modal({backdrop: false });
    $.post('<?php echo base_url();?>stock_distribution/DistributionCdsAsc/get_demande_detail',
    {
      DEMANDE_ID:DEMANDE_ID,
      TEST_VALUE:TEST_VALUE
      
    },
    function(data) 
    { 
      ret_data.innerHTML = data;  
      $('#ret_data').html(data);

    });  
  }
</script>

<script type="text/javascript">
  function get_valeur(u) {

  // body...
  var QUANTITE_APPROUVE=$('#QUANTITE_APPROUVE'+u).val();

  //alert(QUANTITE_APPROUVE);

  document.getElementById("QUANTITE_APPROUVE"+u).value=QUANTITE_APPROUVE
  var QUANTITE_APPROUVE=$('#QUANTITE_APPROUVE'+u).val();

}







function valider(INTRANT_MEDICAUX_ID,i,QUANTITE_DISPONIBLE,DETAIL_ID,QUANTITE_APPROUVEE,comteur_id=0,DEMANDE_ID,RECEPTION_INTRANT_ID,RECEPTION_CODE)
{
  // body...
  var QUANTITE_DISPO=parseFloat(QUANTITE_DISPONIBLE);
  // var QUANTITE_APPROUVE=parseFloat(QUANTITE_APPROUVEE);
   var QUANTITE_APPROUVE=parseFloat($('#QUANTITE_APPROUVE'+i).val());

  var INTERVENANT_RH_ID =Number($('#INTERVENANT_RH_ID').val());
  var PIECE_JUSTIFICATIF =$('#PIECE_JUSTIFICATIF').val();
  
   // alert(QUANTITE_APPROUVE);

  if ( QUANTITE_DISPO >= QUANTITE_APPROUVE && QUANTITE_APPROUVE>0 && INTERVENANT_RH_ID>0 && PIECE_JUSTIFICATIF !=0){


   $('#toblock').modal({ backdrop: false });
   var form= new FormData();   
   form.append("QUANTITE_DISPONIBLE",QUANTITE_DISPONIBLE);
   form.append("QUANTITE_APPROUVE",QUANTITE_APPROUVE);
   form.append("INTRANT_MEDICAUX_ID",INTRANT_MEDICAUX_ID);
   form.append("PIECE_JUSTIFICATIF",$('input[type=file]')[0].files[0]);
   form.append("RECEPTION_INTRANT_ID",RECEPTION_INTRANT_ID);
   form.append("DETAIL_ID",DETAIL_ID);
   form.append("DEMANDE_ID",DEMANDE_ID);
   form.append("RECEPTION_CODE",RECEPTION_CODE);
   form.append("INTERVENANT_RH_ID",INTERVENANT_RH_ID);
   form.append("COMMENT",$('#COMMENT').val());
   form.append("INTERVENANT_RH_ID",$('#INTERVENANT_RH_ID').val());
   form.append("CDS_PARENT_ID",$('#CDS_PARENT_ID').val());

   $.ajax({
    url: "<?php echo base_url('stock_distribution/DistributionCdsAsc/valider');?>",
    type: "POST",
    data: form,
    processData: false,  
    contentType: false,
    success:function(data) 
    { 

     // alert(data);

     if (data=='2') {


       $('#error').html('<div class="alert alert-success">Opération réussie avec succes</div>')
       $('.erreur_modal').modal();
       get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,comteur_id);
       getstock_total(INTRANT_MEDICAUX_ID,"<?=$CDS_PARENT_ID ?>");
       $('#toblock').modal('hide');
     }else{
       $('#error').html('<div class="alert alert-danger">Erreur de connexion!</div>')
       $('.erreur_modal').modal();


     }
   }

 });

 }else{
   $('#error').html('<div class="alert alert-danger">Veillez remplir tous les champs</div>')
   $('.erreur_modal').modal();


 }
}

$(document).ready(function () { 
  var i =0;
  var INTRANT_MEDICAUX_ID=$('#INTRANT_MEDICAUX_ID').val();
  var CDS_PARENT_ID=$('#CDS_PARENT_ID').val();
 // document.getElementById("intr"+i).className = "nav-link active";
 get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,i);
 getstock_total(INTRANT_MEDICAUX_ID,CDS_PARENT_ID);
 get_historique(INTRANT_MEDICAUX_ID,CDS_PARENT_ID);

});





function get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,i=0,CDS_PARENT_ID) {
  // body...
  var CDS_PARENT_ID=$('#CDS_PARENT_ID').val()
  //alert(CDS_PARENT_ID);
  document.getElementById("COMPTEUR").value=i
  var counter='<?= $i ?>';

  counter=Number(counter);
  j=0;
  while(j<counter){

   if (j==i) {
    document.getElementById("intr"+j).className = "nav-link active";

  }else {
    document.getElementById("intr"+j).className = "nav-link ";

  }
  j++;
}

var DEMANDE_ID='<?= $DEMANDE_ID ?>';

    //alert(DEMANDE_ID);
    var row_count ="1000000";
    $('#mytable').DataTable( {
      "processing":true,
      "destroy" : true,
      "serverSide":true,
      "searching": false,
      "paging": false,
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "order":[[ 0, 'desc' ]],
      // "buttons": ["copy", "csv", "excel", "pdf", "print"],
      "ajax":{
        url:"<?=base_url()?>stock_distribution/DistributionCdsAsc/liste_intrant_quantite/",
        type:"POST",
        data : {

         INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
         // INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
         DEMANDE_ID:DEMANDE_ID,
         CDS_PARENT_ID:CDS_PARENT_ID


       }
     },
     lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
     pageLength: 10,
     "columnDefs":[{
      "targets":[1,2,3,4,5,6],
      "orderable":false
    }],

    language: {
      "sProcessing":     "Traitement en cours...",
      "sSearch":         "Rechercher&nbsp;:",
      "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
      "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
      "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
      "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
      "sInfoPostFix":    "",
      "sLoadingRecords": "Chargement en cours...",
      "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
      "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
      "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
      },
      "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
      }
    }
  } )
  }
  function get_historique(INTRANT_MEDICAUX_ID,CDS_PARENT_ID) {
  // body...


  var row_count ="1000000";
  $('#mytable2').DataTable( {
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "searching": false,
    "paging": false,
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "order":[[ 0, 'desc' ]],
    // "buttons": ["copy", "csv", "excel", "pdf", "print"],
    "ajax":{
      url:"<?=base_url()?>stock_distribution/DistributionCdsAsc/historique/",
      type:"POST",
      data : {

       INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
       CDS_PARENT_ID:CDS_PARENT_ID


     }
   },
   lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
   pageLength: 10,
   "columnDefs":[{
    "targets":[1,2,3,4,5],
    "orderable":false
  }],

  language: {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
      "sFirst":      "Premier",
      "sPrevious":   "Pr&eacute;c&eacute;dent",
      "sNext":       "Suivant",
      "sLast":       "Dernier"
    },
    "oAria": {
      "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
      "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    }
  }
} )
}
function getstock_total(INTRANT_MEDICAUX_ID,CDS_PARENT_ID)
{
  //var INTERVENANT_STRUCTURE_ID=STRUCTURE_ID;

  $.post('<?php echo base_url();?>stock_distribution/DistributionCdsAsc/getstock_total/',
  {
    //INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
    INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
    CDS_PARENT_ID:CDS_PARENT_ID,

    
  },
  function(data) 
  { 
    qte_total.innerHTML = data; 
    $('#qte_total').html(data);

   // $('#INTERVENANT_STRUCTURE_ID').selectpicker('refresh');
 }); 

}
</script>
</html>

