<?php
/*
  Auteur : THADDEE ND.
  DESCR : Flux SMS pour la confirmation de la distribution des intrants dans la population
  DATE DEBUT : 03/03/2021
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class SmsDistribution extends MY_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function index(){
     $data = file_get_contents('php://input');
     $array = json_decode($data);

    $tel_array = $array->contact->urn;
    //$tel_array = "tel:+25769101010";
    $data = $array->input->text;
    //$data = "iccm_consomme 79802611#DMD-3-3#I1+20#I2+30";

    //Checking ASC how submitting data
    $data_array = explode(' ',$data);
    $partie_donnees = explode('#',$data_array[1]);

    $telephone_asc = $partie_donnees[0];
    $demande_code = $partie_donnees[1];
    $demande = $this->Modele->getOne('stock_demande',array('DEMANDE_CODE' =>$demande_code));
    $asc = $this->Modele->getOne('intervenants_rh',array('TELEPHONE1' =>$telephone_asc));

    $msg = "";
    $nombre_enregistrement = 0;

    if(!empty($asc)){
      $INTERVENANT_RH_ID = $asc['INTERVENANT_RH_ID'];
      $DEMANDE_ID = $demande['DEMANDE_ID'];

      $msg = "Cher ".$asc['NOM']." ".$asc['PRENOM']."(".$asc['TELEPHONE1'].")";
      for ($i=2; $i < sizeof($partie_donnees); $i++) {
        $intrant = explode('+',$partie_donnees[$i]);
        if(count($intrant) == 2){
          $intrant_medical = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$intrant[0]));
          if(!empty($intrant_medical)){
            if($intrant[1] > 0){
              $INTRANT_ID = $intrant_medical['INTRANT_MEDICAUX_ID'];
              //recuperation de la distribution précedente de l'intrant
              $sql_dist_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                                  JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                                  WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dist.DEMANDE_ID = $DEMANDE_ID AND dt.INTRANT_ID = '$INTRANT_ID'";
              $distribution_detail = $this->Modele->getRequeteOne($sql_dist_detail);

              //Enregistrement de la distribution
              $nombre_enregistrement ++;
              $array_distribution = array(
                'DISTRIBUTION_ID'=>$telephone_asc,
                'RECEPTION_CODE'=>$distribution_detail['RECEPTION_CODE'],
                'INTRANT_ID'=>$INTRANT_ID,
                'QUANTITE'=>$intrant[1],
                'QUANTITE_RESTANTE'=>$intrant[1]
              );
              $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_distribution);
              //Mise a jour la qte restante dans la table distribution
              $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>($distribution_detail['QUANTITE_RESTANTE']-$intrant[1])));
              //Mis a jour la table de stock_intervenant
              $stock_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_ID));
              $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_detail['STOCK_INTERVENANT_ID']),array('QUANTITE_DISTRIBUTUEE'=>$stock_detail['QUANTITE_DISTRIBUTUEE']+$intrant[1]));

             $msg .= " #la quantité ".$intrant[1]." pour l'intrant ".$intrant[0]." est sauvegardée ";
            }else{
              $msg .= "#quantité(".$intrant[1].") doit être > 0 ";
            }
          }else{
            $msg .= "#le code ".$intrant[0]." ne correspond à aucun intrant ";
          }
        }else{
          $msg .= "#un erreur: ".$partie_donnees[$i]." format non respecté ";
        }
      }

       if($nombre_enregistrement > 0){
         //Enregistrement de distribution et mise a jour des details
         $array_distribution = array(
           'DISTRIBUTION_CODE'=>'DSTR-4-',
           'DISTRIBUTION_DATE'=>date('Y-m-d'),
           'CODE_SENS_ID'=>4,
           'DEMANDE_ID'=>$DEMANDE_ID,
           'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
           'INTERVENANT_STRUCTURE_ID'=>$asc['INTERVENANT_STRUCTURE_ID']
         );
         $DISTRIBUTION_ID = $this->Modele->insert_last_id('stock_distribution',$array_distribution);
         $this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>'DSTR-4-'.$DISTRIBUTION_ID));
         $this->Modele->update('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$telephone_asc),array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID));
         $msg .= ". Merci";


				//Creation des notifications
				$distr_details = $this->Modele->getList('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID));
				foreach ($distr_details as $distr_detail) {
					$cc_emails = array();
					$RECEPTION_CODE = $distr_detail['RECEPTION_CODE'];
					$INTRANT_ID = $distr_detail['INTRANT_ID'];
					// Recepuration du PTF
					$sql = "SELECT p.*,rc.PTF_ID,rc.MODE_RECEPTION_ID,rcdl.* FROM rc_reception AS rc
					        JOIN rc_reception_intrant_detail AS rcdl ON rc.RECEPTION_ID = rcdl.RECEPTION_ID
					        JOIN ptf AS p ON p.PTF_ID = rc.PTF_ID
									WHERE rc.RECEPTION_CODE = '$RECEPTION_CODE'
									AND rcdl.INTRANT_ID = $INTRANT_ID";
          /*$sql = "SELECT p.*,rc.PTF_ID,rc.MODE_RECEPTION_ID,rcdl.* FROM rc_reception AS rc
                  JOIN rc_reception_intrant_detail AS rcdl ON rc.RECEPTION_ID = rcdl.RECEPTION_ID
                  JOIN intervenants_structure AS p ON p.INTERVENANT_STRUCTURE_ID = rc.PTF_ID
                  WHERE rc.RECEPTION_CODE = '$RECEPTION_CODE'
                  AND rcdl.INTRANT_ID = $INTRANT_ID";*/
          $info_reception_ptf = $this->Modele->getRequeteOne($sql);

					// Recepuration de l'intrant
         $intrant = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$INTRANT_ID));

					// Recepuration du intervant distribué
					$sql_distribution = "SELECT ints.*,dst.CODE_SENS_ID,dst.INTERVENANT_RH_ID FROM stock_distribution AS dst
					                     JOIN intervenants_structure AS ints ON ints.INTERVENANT_STRUCTURE_ID = dst.INTERVENANT_STRUCTURE_ID
															 WHERE dst.DISTRIBUTION_ID = $DISTRIBUTION_ID";
         $distribue = $this->Modele->getRequeteOne($sql_distribution);

         //Recuperation des depences CDS et BDS
         $recepteur_intrant = $distribue['INTERVENANT_STRUCTURE_DESCR'];

					$intervenant_rh = $this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_ID'=>$distribue['INTERVENANT_RH_ID']));


					$recepteur_intrant .= "(".$intervenant_rh['NOM']." ".$intervenant_rh['PRENOM'].")";
					//CDS
					$INTERVENANT_RH_ID = $distribue['INTERVENANT_RH_ID'];
					$sql_cds = "SELECT ints.* FROM cds_asc AS cds JOIN intervenants_structure AS ints ON cds.CDS_ID = ints.INTERVENANT_STRUCTURE_ID WHERE cds.INTERVENANT_RH_ID = $INTERVENANT_RH_ID";
					$cds = $this->Modele->getRequeteOne($sql_cds);
					$cc_emails[] = $cds['EMAIL'];
          $cc_emails[] = 'camebu@mediabox.bi';

          // echo "<pre>";
          // print_r($cds);
          // echo "</pre>";

					//BDS
					$CDS_ID = $cds['INTERVENANT_STRUCTURE_ID'];
					$sql_bds = "SELECT ints.* FROM bds_cds AS bd JOIN intervenants_structure AS ints ON bd.BDS_ID = ints.INTERVENANT_STRUCTURE_ID WHERE bd.CDS_ID = $CDS_ID";
					$bds = $this->Modele->getRequeteOne($sql_bds);
					$cc_emails[] = $bds['EMAIL'];

					$recepteur_intrant .= " appartenant à ".$cds['INTERVENANT_STRUCTURE_DESCR']."/".$bds['INTERVENANT_STRUCTURE_DESCR'].".Merci";

					$message = "Cher <b>".$info_reception_ptf['PTF_NOM']."</b>, Une quantité <b>".$distr_detail['QUANTITE']."</b> sur le lot <b>".$info_reception_ptf['NUMERO_LOT']."</b>  de l'intrant <b>".$intrant['INTRANT_MEDICAUX_DESCR']."</b> a été distribué(s) à la population par ".$recepteur_intrant;
					$subjet = "Confirmation de distribution d'un intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." du lot ".$info_reception_ptf['NUMERO_LOT']." à la population";
					$emailTo = $info_reception_ptf['EMAIL'];

					$array_notifications = array(
						'MESSAGE'=>$message,
						'PTF_ID'=>$info_reception_ptf['PTF_ID'],
						'EMAIL_NOTIFIE'=>$info_reception_ptf['EMAIL'],
						'INTRANT_ID'=>$INTRANT_ID,
						'INTRANT_ID'=>$distr_detail['QUANTITE'],
						'IS_DISTRIBUTION'=>1
					);
					$this->Modele->insert_last_id('sms_mouvement_stock',$array_notifications);
					$this->notifications->send_mail($emailTo, $subjet, $cc_emails, $message, array());
				}
       }

    }else{
      $msg = "Cher ASC, votre code ".$telephone_asc." n'est pas reconnu.";
    }

    //Insertion du message envoye dans la base
    $array_distribution = array('MSG_REPONSE'=>$msg,'SENT_DATA'=>$data,'TELEPHONE_USED'=>$tel_array);
    $this->Modele->insert_last_id('sms_distribution_intrant',$array_distribution);

    //Retour
    echo $msg;
  }

  public function liste(){
    $messages = $this->Modele->getList('sms_distribution_intrant');
    $i =1;
    $mes_message = array();

    foreach ($messages as $message) {
      $date_insertion = new DateTime($message['DATE_INSERTION']);

      $sub_array = NULL;
      $sub_array[] =$i;
      $sub_array[] =$message['SENT_DATA'];
      $sub_array[] =$message['TELEPHONE_USED'];
      $sub_array[] =$message['MSG_REPONSE'];
      $sub_array[] =$date_insertion->format('d/m/Y');
      $i ++;

      $mes_message[] = $sub_array;
    }

    $template = array('table_open' => '<table id="mytable" class="table  table-stripped table-hover table-condensed">', 'table_close' => '</table>');
    $this->table->set_template($template);
    $this->table->set_heading(array('#','MESSAGE','TELEPHONE','REPONSE','DATE'));
    $data['mes_messages']=$mes_message;

    $data['title']='Message sms';

    $this->load->view('SMS_Distribution_View',$data);
    // $this->page='SMS_Distribution_View';
    // $this->layout($data);
  }

}
