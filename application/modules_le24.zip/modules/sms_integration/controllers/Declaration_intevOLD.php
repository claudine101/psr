<?php




  // Auteur : Desire.


defined('BASEPATH') OR exit('No direct script access allowed');

class Declaration_intev extends MY_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }
  public function liste($value='')
  {
    $DATE_INSERTION=$this->input->post('DATE_INSERTION');
    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
    $var_search=str_replace("'", "\'", $var_search);
    $query_principal='SELECT decl.INCIDENT_ID, decl.TYPE_INCIDENT_ID,ID_STATUT_TICKET_INCIDENT,decl.TRANCHE_AGE_ID,decl.DATE_INCIDENT,decl.OBSERVATION,decl.DATE_INSERTION ,md.MALADIE_DESCR,str.INTERVENANT_STRUCTURE_DESCR,rh.NOM,rh.PRENOM,rh.TELEPHONE1,rh.INTERVENANT_RH_CODE,inc.TYPE_INCIDENT_ID,inc.DESCRIPTION as incidents,tr.TRANCHE_AGE_ID,tr.DESCRIPTION as tranche,stt.DESCRIPTION as STATUT_TICKET FROM declaration_incident decl LEFT JOIN maladies md on md.MALADIE_ID=decl.MALADIE_ID LEFT JOIN type_incident inc ON inc.TYPE_INCIDENT_ID=decl.TYPE_INCIDENT_ID LEFT JOIN tranche_age tr ON tr.TRANCHE_AGE_ID=decl.TRANCHE_AGE_ID LEFT JOIN intervenants_rh rh ON rh.INTERVENANT_RH_CODE=decl.INTERVENANT_RH_CODE LEFT JOIN cds_asc ON cds_asc.INTERVENANT_RH_ID=rh.INTERVENANT_RH_ID LEFT JOIN intervenants_structure str on str.INTERVENANT_STRUCTURE_ID=decl.INTERVENANT_STRUCTURE_ID JOIN statut_ticket stt ON stt.ID_STATUT_TICKET=decl.ID_STATUT_TICKET_INCIDENT';

    $critaire="";






    if (!empty($DATE_INSERTION)) {
      $critaire=" and DATE_FORMAT(DATE_INSERTION,'%Y-%m-%d')='".$DATE_INSERTION."'";
    }

    $limit='LIMIT 0,10';
    if($_POST['length'] != -1){
      $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
    }
    $order_by='';
    if($_POST['order']['0']['column']!=0){
      $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
    }

    $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR  tranche LIKE '%$var_search%' OR  NOM LIKE '%$var_search%' OR  MALADIE_DESCR LIKE '%$var_search% OR stt.DESCRIPTION LIKE '%$var_search')") : '';

    $group='';


    $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
    $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

    $fetch_enqueteurs = $this->Modele->datatable($query_secondaire);
    $u=0;
    $data = array();
    foreach ($fetch_enqueteurs as $row) {

     $u++;
     $sub_array = array();
     $sub_array[] =  $u;
     $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
     $sub_array[]=$row->MALADIE_DESCR;
     $sub_array[]=$row->tranche;
     $sub_array[]=$row->NOM.' '.$row->PRENOM.' ('.$row->TELEPHONE1.')';
     $sub_array[]=$row->STATUT_TICKET;
     $sub_array[]=$row->DATE_INSERTION;


     $opt='<div class="dropdown" style="color:#fff;">
      <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-cog"></i> Options<span class="caret">
      </span></a>
      <ul class="dropdown-menu dropdown-menu-left">';
      if ($row->ID_STATUT_TICKET_INCIDENT==1 OR $row->ID_STATUT_TICKET_INCIDENT==2) {
         $opt.='<li class="dropdown-item" ><a href="#" onclick="traiter_status('.$row->INCIDENT_ID.')">Traiter</a></li>';
      }
     
      $opt.="</ul>
      </div>";




      $opt.='</ul>';
      $sub_array[]=$opt;






     $data[] = $sub_array;

   }

   $output = array(
     "draw" => intval($_POST['draw']),
     "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
     "recordsFiltered" => $this->Modele->filtrer($query_filter),
     "data" => $data
   );
   echo json_encode($output);
 }

 public function index()
 {


   $data['dattes']=$this->Modele->getRequete("SELECT DISTINCT DATE_FORMAT(DATE_INSERTION,'%Y-%m-%d') as dattes FROM declaration_incident");
   $data['status']=$this->Modele->getRequete("SELECT * FROM `statut_ticket` WHERE 1");

   $this->load->view('Declaration_intev_View',$data);

 }   

 function traiter()
  {
    

    $INCIDENT_ID=$this->input->post('INCIDENT_ID');
    $ID_STATUT_TICKET=$this->input->post('ID_STATUT_TICKET');
    $USER_ID=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');

    $array_historique=array('INCIDENT_ID'=>$INCIDENT_ID,'ID_STATUT_TICKET'=>$ID_STATUT_TICKET,'USER_ID'=>$USER_ID);

    $this->Modele->create('declaration_incident_ticket_historique',$array_historique);
    $this->Modele->update('declaration_incident',array('INCIDENT_ID'=>$INCIDENT_ID),array('ID_STATUT_TICKET_INCIDENT'=>$ID_STATUT_TICKET));
    echo json_encode(array('status'=>true));
  }


}
