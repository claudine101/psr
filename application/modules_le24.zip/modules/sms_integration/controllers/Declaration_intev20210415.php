<?php




  // Auteur : ALPHONSE.
  

defined('BASEPATH') OR exit('No direct script access allowed');

class Declaration_intev extends MY_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }



  public function index(){

    $messages = $this->Modele->getRequete('SELECT decl.INCIDENT_ID, decl.TYPE_INCIDENT_ID,decl.TRANCHE_AGE_ID,decl.DATE_INCIDENT,decl.OBSERVATION,decl.DATE_INSERTION ,md.MALADIE_DESCR,str.INTERVENANT_STRUCTURE_DESCR,rh.NOM,rh.PRENOM,rh.TELEPHONE1,rh.INTERVENANT_RH_CODE FROM declaration_incident decl LEFT JOIN maladies md on md.MALADIE_ID=decl.MALADIE_ID LEFT JOIN intervenants_rh rh ON rh.INTERVENANT_RH_CODE=decl.INTERVENANT_RH_CODE LEFT JOIN cds_asc ON cds_asc.INTERVENANT_RH_ID=rh.INTERVENANT_RH_ID LEFT JOIN intervenants_structure str on str.INTERVENANT_STRUCTURE_ID=decl.INTERVENANT_STRUCTURE_ID');
    $i =1;
    $mes_message = array();

    foreach ($messages as $message) {

      $date_insertion = new DateTime($message['DATE_INSERTION']);

      $sub_array = NULL;

      $sub_array[] =$i++;

      $sub_array[] = $message['TYPE_INCIDENT'];
     
      $sub_array[] = ($message['TRANCHE_AGE']==1) ? '2 à 11 mois' : '1 à 5 ans';
      $sub_array[] = $message['OBSERVATION'];
     
      $sub_array[] =$message['INTERVENANT_STRUCTURE_DESCR'];
      $sub_array[] =$message['NOM'].' '.$message['PRENOM'].'<br>Tél :'.$message['TELEPHONE1'];

      $sub_array[] =$message['DATE_INCIDENT'];
     
      //$sub_array[] =$date_insertion->format('d/m/Y');
     
      $mes_message[] = $sub_array;
    }

    $template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
    $this->table->set_template($template);
    $this->table->set_heading(array('#','INCIDENT','AGE','OBSERVATION','STRUCTURE','INTERVENANT','DATE'));
    $data['mes_messages']=$mes_message;
    $data['title']="Déclaration des incidents";

    $this->load->view('Declaration_intev_View',$data);
    //$this->layout($data);
  }



}
