<?php
class Sms_incident extends CI_Controller
{
	public function __construct()
  {
  	parent::__construct();
  }

  function index()
  {
  	$data=file_get_contents('php://input');
  	$array=json_decode($data);
    $telephone_text = $array->contact->urn;
    $text_envoye=$array->input->text;
    $donnees=explode("#", $text_envoye);
    $array_tel=explode("+",$telephone_text);
    $tel=substr($array_tel[1],3);
    // print_r($tel);
    $message = "";
    $message_recu=$text_envoye;
    if(count($donnees)==5)
    {
      if($donnees[0]=='iccmincident')
      {
        $sexe=substr($donnees[2],0,1);
        $SEXE_ID=0;
        if($sexe=='F')
        {
          $SEXE_ID=2;
        }
        if($sexe=='H')
        {
          $SEXE_ID=1;
        }
        $tranche_text=substr($donnees[2],1);  
        $code=$donnees[1];
        $code_agent="CAMEBU";
        $structure_id=6;
        $maladie_id=-1;
        $tranche_id=-1;
        $DECLARANT_IS_INCONNU=0;
        //Test code de l'agent
        $agent=$this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_CODE'=>$code));
        if(!empty($agent))
        {
          //Existe agent
          $code_agent=$agent['INTERVENANT_RH_CODE'];
          $structure=$this->Modele->getOne('cds_asc',array('INTERVENANT_RH_ID'=>$agent['INTERVENANT_RH_ID']));
          if(!empty($structure))
          {
            $structure_id=$structure['CDS_ID'];
          }
        }
        else
        {
          $DECLARANT_IS_INCONNU=1;
        }

        //Test code de la maladie
        $maladie=$this->Modele->getOne('maladies',array('MALADIE_CODE'=>$donnees[3]));
        if(!empty($maladie))
        {
          $maladie_id=$maladie['MALADIE_ID'];
        }

        //Test code Tranche
        $tranche=$this->Modele->getOne('tranche_age',array('TRANCHE_AGE_ID'=>$tranche_text));
        if(!empty($tranche))
        {
          $tranche_id=$tranche['TRANCHE_AGE_ID'];
        }

        //Insertion d'un incident
        $datas=array(
                'INTERVENANT_RH_CODE'=>$code_agent,
                'TEL_DU_DECLARANT'=>$tel,
                'INTERVENANT_STRUCTURE_ID'=>$structure_id,
                'MALADIE_ID'=>$maladie_id,
                'TYPE_INCIDENT_ID'=>1,
                'TRANCHE_AGE_ID'=>$tranche_id,
                'SEXE_ID'=>$SEXE_ID,
                'DECLARANT_IS_INCONNU'=>$DECLARANT_IS_INCONNU
            );
        $INCIDENT_ID=$this->Modele->insert_last_id('declaration_incident',$datas);

        //Notification
        $message="Ubutumwa bwanyu ntibwashitse.";
        if($INCIDENT_ID)
        {
          $message="Ubutumwa bwanyu bwashitse neza.";
          if ($maladie_id==-1)
          {
            $message="Code yirwara mwanditse ntibaho.";
          }

          if ($tranche_id==-1)
          {
            $message="Umurwi y'imwaka mwanditse ntubaho.";
          }

          if($SEXE_ID==0)
          {
            $message="Mwihenze kwandika Code yígitsina.";
          }

          if (empty($agent))
          {
            $message="Code mwanditse ntibaho.";
          }
        }
      }
      else
      {
        $message="Mwihenze,nimusubiremwo mukoresheje ijambo 'iccmincident'.Murakoze";
      }
    }
    else
    {
      $message="Mwihenze code yanyu.";
    }
    $data_not=array('TEL'=>$tel,'MESSAGE_RECU'=>$message_recu,'MESSAGE_ENVOYE'=>$message);
    $ID=$this->Modele->insert_last_id('sms_declaration_incident',$data_not);
    echo $message;
  }
}
?>