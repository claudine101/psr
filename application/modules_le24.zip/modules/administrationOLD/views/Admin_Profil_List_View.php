          <!DOCTYPE html>
          <html lang="en">
            <?php include VIEWPATH.'templates/header.php' ?>
          <body class="hold-transition sidebar-mini layout-fixed">
          <div class="wrapper">

            <!-- Navbar -->
            <?php include VIEWPATH.'templates/navbar.php' ?>

            <?php include VIEWPATH.'templates/sidebar.php' ?>

            <div class="content-wrapper">
              <!-- Content Header (Page header) -->
              <div class="content-header">
                <div class="container-fluid">
                  <div class="row mb-2">
                    <div class="col-sm-6">
                      <h1 class="m-0"><?=$title?></h1>
                    </div>
                    <div class="col-sm-6">
                      <ol class="breadcrumb float-sm-right">
                    <a class="btn btn-primary" href="<?= base_url('administration/Admin_Profil/Add_Admin_Profil')?>"><i class="fa fa-plus"></i>Nouveau</a>
                      </ol>
                    </div>
                  </div>
                </div>
              </div>
              <section class="content">
              <?= $this->table->generate($data); ?> 
              </section>
            </div>

          </div>
           <?php include VIEWPATH.'templates/footer.php'; ?>
          </body>
          <script >
          $(document).ready(function () {
                 $('#mytable').DataTable({
                   
                              language: {
                                          "sProcessing":     "Traitement en cours...",
                                          "sSearch":         "Rechercher&nbsp;:",
                                          "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                                          "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                                          "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                                          "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                                          "sInfoPostFix":    "",
                                          "sLoadingRecords": "Chargement en cours...",
                                          "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                                          "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                                          "oPaginate": {
                                              "sFirst":      "Premier",
                                              "sPrevious":   "Pr&eacute;c&eacute;dent",
                                              "sNext":       "Suivant",
                                              "sLast":       "Dernier"
                                          },
                                          "oAria": {
                                              "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                                              "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                                          }
                                  }
                      });
                      $(".dt-buttons").addClass("pull-left");
                      $("#table_Cras_paginate").addClass("pull-right");
                      $("#table_Cras_filter").addClass("pull-left");
                  });  
          </script>
