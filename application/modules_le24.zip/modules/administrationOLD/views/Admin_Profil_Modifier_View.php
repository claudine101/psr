                        <!DOCTYPE html>
                        <html lang="en">
                          <?php include VIEWPATH.'templates/header.php' ?>
                        <body class="hold-transition sidebar-mini layout-fixed">
                        <div class="wrapper">

                          <!-- Navbar -->
                          <?php include VIEWPATH.'templates/navbar.php' ?>

                          <?php include VIEWPATH.'templates/sidebar.php' ?>

                          <div class="content-wrapper">
                            <!-- Content Header (Page header) -->
                            <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                    <h1 class="m-0"><?=$title?></h1>
                                  </div>
                                  <div class="col-sm-6">
                                    <ol class="breadcrumb float-sm-right">
                                  <a class="btn btn-primary" href="<?= base_url('administration/Admin_Profil/Add_Admin_Profil')?>"><i class="fa fa-plus"></i>Nouveau</a>

                                  <a class="btn btn-primary" href="<?= base_url('administration/Admin_Profil/index')?>"><i class="fa fa-list"></i>Retour</a>
                                    </ol>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <section class="content">
                
              <div class="row">
                <div class="col-md-10">
                  <form action="<?= base_url('administration/Admin_Profil/Modifier/').$admin_profil['PROFIL_ID'];?>" method="post" name="myform">
                    <div class="row">
                      <div class="col-md-6">
                         <label>Code:</label>
                         <input type="text" value="<?=$admin_profil['PROFIL_CODE'];?>" class="form-control" name="code" >
                         <span><font color="red"><?=form_error('code');?></font></span>

                      </div>
                      <div class="col-md-6">
                         <label>Nom:</label>
                         <input type="text" value="<?=$admin_profil['PROFIL_DESCR'];?>" class="form-control" name="descr" >
                         <span><font color="red"><?=form_error('descr');?></font></span>
                      </div>
                      
                      </div>
                      <div class="col-md-6"> 
                        <br><input type="submit" class="btn btn-primary form-control" name="submit" value="Modifier">
                      </div>
                      </div>
                  </form>
                </div>
              </div>
                            </section>
                          </div>

                        </div>
                         <?php include VIEWPATH.'templates/footer.php'; ?>
                        </body>
                       
