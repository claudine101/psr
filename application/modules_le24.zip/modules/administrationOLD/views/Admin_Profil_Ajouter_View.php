<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php' ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?=$title?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active"><a href="<?= base_url('administration/Admin_Profil/index')?>">Liste</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      
            <div class="col-md-10">
              <form action="<?= base_url('administration/Admin_Profil/Ajouter')?>" method="post" name="myform">
                <div class="row">
                  <div class="col-md-6">
                     <label>Code:</label>
                     <input type="text" class="form-control" name="code" >
                     <span><font color="red"><?=form_error('code');?></font></span>
                  </div>
                  <div class="col-md-6">
                     <label>Descr:</label>
                     <input type="text" class="form-control" name="descr" >
                     <span><font color="red"><?=form_error('descr');?></font></span>
                  </div>
                </div>
                  <div class="col-md-6">
                    <br><input type="submit" class="btn btn-primary form-control"  style="padding-top: 10px;" value="Enregistrer">
                  </div>
              </form>
            </div>
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
