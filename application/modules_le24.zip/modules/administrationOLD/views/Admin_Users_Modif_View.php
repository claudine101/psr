 <div class="row">
  <legend>
    <?= $title;?>

    <div class="pull-right">
      <a href="<?= base_url('administration/Admin_Users/listing'); ?>" class="btn btn-primary btn-sm pull-right">
        <i class="fa fa-list"></i>
        Liste
      </a>
    </div>
  </legend>
      
</div>

<form name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Admin_Users/update'); ?>">
  <div class="row">
      <input type="hidden" class="form-control" name="INTERVENANT_RH_ID" value="<?=$data_interv['INTERVENANT_RH_ID']?>" >
    <div class="col-md-6">
      <label for="FName">Nom:</label>
      <input type="text" name="NOM" value="<?=$data_interv['NOM']?>" class="form-control" id="NOM" >
  <?php echo form_error('NOM', '<div class="text-danger">', '</div>'); ?> 
    </div>

    <div class="col-md-6">
      <label for="LName">Prénom:</label>
      <input type="text" name="PRENOM" value="<?=$data_interv['PRENOM']?>" class="form-control" id="PRENOM">
       <?php echo form_error('PRENOM', '<div class="text-danger">', '</div>'); ?>
    </div>
  </div>
  <div class="row">
      

    <div class="col-md-6">
      <label for="FName">Téléphone 1:</label>
      <input type="text" name="TELEPHONE1" value="<?=$data_interv['TELEPHONE1']?>" class="form-control" id="TELEPHONE1" >
      <?php echo form_error('TELEPHONE1', '<div class="text-danger">', '</div>'); ?> 
    </div>

    <div class="col-md-6">
      <label for="LName">Téléphone 2:</label>
      <input type="text" name="TELEPHONE2" value="<?=$data_interv['TELEPHONE2']?>" class="form-control" id="TELEPHONE2">
       <?php echo form_error('TELEPHONE2', '<div class="text-danger">', '</div>'); ?>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <label for="LName">Email:</label>
      <input type="email" name="EMAIL" value="<?=$data_interv['EMAIL']?>" class="form-control" id="EMAIL">
       <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?>
    </div>
    <div class="col-md-6">
      <label for="FName">Intervenant:</label>
      <select class="form-control selectpicker" data-live-search="true"  name="INTERVENANT_STRUCTURE_ID" >
        <?php 
          foreach($intervenants_structure as $key_intervenant) 
           { 
              if ($key_intervenant['INTERVENANT_STRUCTURE_ID'] ==$data_interv['INTERVENANT_STRUCTURE_ID']) { 
              echo "<option value='".$key_intervenant['INTERVENANT_STRUCTURE_ID']."' selected>".$key_intervenant['INTERVENANT_STRUCTURE_DESCR']."</option>";
           } 
             else
            {
             echo "<option value='".$key_intervenant['INTERVENANT_STRUCTURE_ID']."' >".$key_intervenant['INTERVENANT_STRUCTURE_DESCR']."</option>"; 
            } 
            }
        ?>
            </select>

    <?php echo form_error('INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 
    </div>
    
  </div>
  <div class="col-md-6">
    <button type="submit" class="btn btn-primary form-control" style="margin-top: 20px;">Modifier
    </button>
  </div>
  
</form>