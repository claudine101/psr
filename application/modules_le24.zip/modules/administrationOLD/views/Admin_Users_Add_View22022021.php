<div class="row">
  <legend>
    <?= $title;?>

    <div class="pull-right">
      <a href="<?= base_url('administration/Admin_Users/listing'); ?>" class="btn btn-primary btn-sm pull-right">
        <i class="fa fa-list"></i>
        Liste
      </a>
    </div>
  </legend>
      
</div>

<form  name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Admin_Users/add_user'); ?>" >

<div class="row">
  <input type="hidden" class="form-control" name="INTERVENANT_RH_ID" value="<?=$data_users['INTERVENANT_RH_ID']?>" >

    <div class="col-md-6">
      <label for="FName">Nom d'utilisateur:</label>
      <input type="text" name="USER_NAME" id="USER_NAME" value="<?= set_value('USER_NAME') ?>" class="form-control">
      <?php echo form_error('USER_NAME', '<div class="text-danger">', '</div>'); ?> 

    </div>

    <div class="col-md-6">
      <label for="FName">Email:</label>
      <input type="text" class="form-control" name="EMAIL" value="<?=$data_users['EMAIL']?>" >
      <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?> 

    </div>
  </div>
  <div class="row">
  
    <div class="col-md-6">
      <label for="FName">Profil:</label>
      <select class="form-control" name="INTERVENANT_PROFIL_ID" id="INTERVENANT_PROFIL_ID"> value="<?=set_value('PROFIL_ID') ?>">
        <option value="">Selectionner</option>
        <?php 
          foreach ($intervenants_profil as $key_profil) 
          {
        
            ?>
            <option value="<?= $key_profil['INTERVENANT_PROFIL_ID'] ?>"><?= $key_profil['INTERVENANT_PROFIL_DESCR'] ?></option>
            <?php
          }

         ?>
      </select>
      <?php echo form_error('USER_NAME', '<div class="text-danger">', '</div>'); ?> 

    </div>

    <div class="col-md-6">
      <button type="submit" class="btn btn-primary form-control" style="margin-top: 30px;">Enregistrer
      </button>
    </div>
  </div>
  
  </div>
 

</form>