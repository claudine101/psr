 <div class="row">
  <legend>
    Nouveau Fonctionnalite
    <div class="pull-right" style="padding-bottom:20px;">
      <a href="<?= base_url('administration/Fonctionnalites/listing'); ?>" class="btn btn-secondary"><i class="fa fa-list"></i>
        Liste
      </a>
    </div>
  </legend>
</div>
<form  name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Fonctionnalites/addFonctionnalite'); ?>">
  <div class="row">

    <div class="col-md-6 col-sm-6 col-xs-6">
      <label>Description du Fonctionnalite</label>
      <input type="text" name="FONCTIONNALITE_DESCR" value="<?=set_value('FONCTIONNALITE_DESCR')?>" class="form-control" id="FONCTIONNALITE_DESCR">
      <?php echo form_error('FONCTIONNALITE_DESCR', '<div class="text-danger">', '</div>'); ?>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6">
      <label>Code Fonctionnalite</label>
      <input type="text" name="FONCTIONNALITE_CODE" value="<?=set_value('FONCTIONNALITE_CODE')?>" class="form-control" id="FONCTIONNALITE_CODE">
      <?php echo form_error('FONCTIONNALITE_CODE', '<div class="text-danger">', '</div>'); ?>
    </div>
  </div>
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-6 offset-md-3">
    <button type="submit" class="btn btn-secondary btn-block" style="margin-top: 20px">Enregistrer</button>
  </div>
</div>
</form> 
<!--                </div>
    <div class="panel-footer">
      
    </div>
  </div>
</div> -->

     <!--  <div class="col-md-12 col-xl-12 grid-margin stretch-card">
       <div class="card"> 
         <div class="card-body"> 

          
          <div style="margin-left:200px">
           
            <form  name="myform" method="post" class="form-horizontal" action="<?= base_url('ihm/Maladies/add'); ?>">
              <div class="row form-group">
                <label for="" class="col-md-3 col-sm-6 col-xs-6 control-label" style="text-align: right;">Description du Maladie</label>
                <div class="col-md-6 col-sm-6 col-xs-6">
                 <input type="text" name="MALADIE_DESCR" value="<?=set_value('MALADIE_DESCR')?>" class="form-control" id="MALADIE_DESCR">
                 <?php echo form_error('MALADIE_DESCR', '<div class="text-danger">', '</div>'); ?>
                 
               </div>
               
             </div>
             <div class="row form-group">
               <label for="" class="col-md-3 col-sm-6 col-xs-6 control-label" style="text-align: right;">Code Maladie</label>
               <div class="col-md-6 col-sm-6 col-xs-6">
                 <input type="text" name="MALADIE_CODE" value="<?=set_value('MALADIE_CODE')?>" class="form-control" id="MALADIE_CODE">
                 <?php echo form_error('MALADIE_CODE', '<div class="text-danger">', '</div>'); ?>
                 
               </div>
               
             </div>

             <div class="form-group">
               <label class="col-md-12 col-sm-12 col-xs-12 control-label"></label>
               <div class="col-md-6 col-sm-6 col-xs-6 col-md-push-2" >
                <input type="submit" class="btn btn-primary btn-block "  value="Enregistrer"/>
                
              </div>
              
              
            </div>
          </form> 
          
        </div>
        
      </div>
    </div>
  </div>

</div> 
-->



<!-- partial -->



<!-- End custom js for this page-->


