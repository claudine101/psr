<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url('assets/bootstrap/')?>bootstrap.min.js"></script>
<legend>RECEPTION DES INTRANTS</legend> -->
<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php'; ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php'; ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-9">
            <h1 class="m-0"><?=$title?></h1>
          </div><!-- /.col -->
          <div class="col-sm-3">
<!--             <a href="<?=base_url('demande/Demande/add_demande')?>" class='btn btn-primary float-right'>
              <i class="nav-icon fas fa-plus"></i>
              Nouvelle demande
            </a> -->
          </div><!-- /.col -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
<section class="container" >
<!-- ************************************************************************************************** -->
<div class="card" >

<!-- fin modal comite -->
<div class="container-fluid">

 
  <div class="col-md-12 table-responsive">



      
  </div>
  
    
</div>
</div>
<!-- ********************************************************************************************** -->

      

      
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
  function show_intrant() {
    // body...
  $.post('<?php echo base_url();?>ihm/Traiter_Auto_Demande/get_dem_virt/',
  {
    
    
    },
    function(data) 
    { 
    dem_intant.innerHTML = data; 
    $('#dem_intant').html(data);

    }); 
  }
function do_demande(ID_DEMANDE_SYSTEME,INTRANT_MEDICAUX_ID) {
  // body...
  var QUANTITE=parseFloat($('#QUANTITE'+ID_DEMANDE_SYSTEME).val());
  if (QUANTITE>0) {
   $('#message_ret').html('<div class="alert alert-info">Opération en cours...</div>')
   $('#modal').modal({ backdrop: false });
   $('#modal').modal()
  $.post('<?php echo base_url();?>ihm/Traiter_Auto_Demande/add_demande/',
  {
    QUANTITE:QUANTITE,
    ID_DEMANDE_SYSTEME:ID_DEMANDE_SYSTEME,
    INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID
    
    },
    function(data) 
    { 
     show_intrant()
    //dem_intant.innerHTML = data;
    $('#message_ret').html('<div class="alert alert-success">Opération réussi avec succes</div>')
    //$('#dem_intant').html(data);
    $('#modal').modal({ backdrop: true });
    $('#modal').modal();
    $('#modal').modal('hide');

    });
}else{
       show_intrant();
       $('#message_ret').html('<div class="alert alert-danger">Veillez saisir la quantité valide</div>')
       $('#modal').modal();
}

}
</script>
<script type="text/javascript">
  $(document).ready(function(){ 
     $("#message").delay("slow").fadeOut(3000);
   show_intrant();
   get_list();


  });
  function get_list() {
  // body...
    

    var row_count ="1000000";

   $("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
       "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
            url:"<?=base_url()?>stock/Suspiscion_Malv_Stock/liste/",
            type:"POST",
            data : {
               


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[],
            "orderable":false
        }],

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });
}
</script>

