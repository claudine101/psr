<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>

 

<style type="text/css">
   .mapbox-improve-map{
    display: none;
  }
  
      .leaflet-control-attribution{
    display: none !important;
}
.leaflet-control-attribution{
    display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php'; ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php'; ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
              <?php
              // $menu_cam_1="nav-link";
              // $menu_cam_2="nav-link";
              // $menu_cam_3="nav-link active"; 
              // $menu_cam_4="nav-link"; 

              $menu_bds_1="nav-link active";
              $menu_bds_2="nav-link";
              $menu_bds_3="nav-link";
              
              $menu_cds_1="nav-link active";
              $menu_cds_2="nav-link";


              include VIEWPATH.'sousmenu/sous_menu_stock_intervenant.php'; ?>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">




            <div class="col-md-12 col-xl-12 grid-margin stretch-card">

              <div class="card">

                <div class="card-body">




    <table id='mytable_intv' class="table  table-striped table-hover " style="width: 100%;">
      <thead>
        <tr>
          
          <th>INTRANT</th>
          <th><center>UNITE</center></th>
          <!-- <th>PRIX UNITAIRE</th> -->
          <th><center>QUANTITE DISPONIBLE</center></th>
          <!-- <th>MONTANT</th> -->
          

        </tr>
      </thead><tbody>

<?php 
if (empty($INTERVENANT_STRUCTURE_ID)) {
  # code...
  $INTERVENANT_STRUCTURE_ID=-1;
}

foreach ($intrant as $key ) {

  $total=0;
  $qte=0;
  # code...

  $query_principal=$this->Modele->getRequete('SELECT i.INTRANT_MEDICAUX_DESCR ,`QUANTITE` QUANTITE_DISPONIBLE,(SELECT iu.INTRANT_UNITE_DESCR FROM intrant_unites iu WHERE iu.INTRANT_UNITE_ID=i.INTRANT_UNITE_ID) UNITE FROM `stock_intervenat` si JOIN intrant_medicaux i ON si.`INTRANT_ID`=i.INTRANT_MEDICAUX_ID  WHERE `INTRANT_ID`='.$key['INTRANT_ID'].' AND  `INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID.'');
  // echo "<pre>";
  // print_r($query_principal);
  $i=0;
  foreach ($query_principal as  $value) {
    # code...
    if (empty($value['QUANTITE_DISPONIBLE'])) {
      # code...
      $value['QUANTITE_DISPONIBLE']=0;
    }
 
   // $qte+=$value['QUANTITE_DISPONIBLE'] ;
  ?>
  <tr>
    <td><?= $value['INTRANT_MEDICAUX_DESCR'] ?></td>
    <td><center><?= $value['UNITE'] ?></center></td>
    <!-- <td><?= $value['PRIX_UNITAIRE'] ?></td> -->
    <td><center><?= $value['QUANTITE_DISPONIBLE'] ?></center></td>
    <!-- <td><?= $montant ?></td> -->
    
  </tr>


<?php $i++; } }
  # code...
 ?> 


</tbody>
</table>

    

      
  </div>
  
    
</div>




      </div>
              </div>
            </div>
           
          </div>
        
        <!-- Rapport partie -->

     

        <!-- End Rapport partie -->
          
        </div>
          </div>
            </div>          
          </div>

     
    </section>


    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>




<script type="text/javascript">
   $(document).ready(function () {
    $('#app_title').html('Stock du <?= date('d-m-Y').' '.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_DESCR')?>');
     var row_count ="1000000";
            $("#mytable_intv").DataTable({

               "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
              "columns": [

    { "width": "43%" },
    { "width": "20%" },
    { "width": "37%" },
    

  ],
              lengthMenu: [[5,10,50, 100, row_count], [5,10,50, 100, "All"]],
                    pageLength: 5,
                        "columnDefs":[{
                            "targets":[],
                            "orderable":false
                        }],

        dom: 'Bfrtlip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
                language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }


            });
        });

</script>
