<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <!-- <h1 class="m-0"><?=$title?></h1> -->
              <?php
              $menu_cam_1="nav-link active";
              $menu_cam_2="nav-link";
              $menu_cam_3="nav-link"; 
              $menu_cam_4="nav-link"; 
              include VIEWPATH.'sousmenu/sous_menu_stock_intervenant.php'; ?>
            </div><!-- /.col -->
<?php
if ($this->session->userdata('iccm_PROFIL_CODE')=="CAM") {
  # code...


?>            
          <div class="col-sm-3">
            <a href="<?=base_url('stock_reception/Reception')?>" class='btn btn-primary float-right'>
              <i class="nav-icon fas fa-plus"></i>
              Nouvelle Réception
            </a>
          </div><!-- /.col -->
<?php
}
?>

         </div><!-- /.row -->
       </div><!-- /.container-fluid -->
     </div>
     <!-- /.content-header -->

     <!-- Main content -->
     <section class="content">




      <div class="col-md-12 col-xl-12 grid-margin stretch-card">

        <div class="card">
          <div class="card-body">
            <?=  $this->session->flashdata('message');?>
            <table id='mytable' class="table  table-striped table-hover table-condensed table-sm" style="width: 100%;">
              <thead>
                <!-- <tr><th colspan="4"><center>Stock du <?= date('d-m-Y') ?></center></th></tr> -->
                <tr>

                  <th>INTRANT</th>
                  <th><center>UNITE</center></th>
                  <!-- <th style="width: 40px;">P.U</th> -->
                  <th style="width: 40px;"><center>QUANTITE</center></th>
                  <!-- <th style="width: 40px;">MONTANT</th> -->
                  <th style="width: 40px;"><center>RECEPTION</center></th>

                </tr>
              </thead><tbody>

                <?php 
                $filter_by_ptf_conected="";
                if ($this->session->userdata('iccm_PROFIL_CODE')=="PTF") {
                  # code...
                  if (!empty($this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'))) {
                    # code...
                    $filter_by_ptf_conected=" AND rr.PTF_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
                  }
                  

                }


                foreach ($intrant as $key ) {

                  $total=0;
                  $qte=0;
  # code...
                  
                  $query_principal=$this->Modele->getRequete('SELECT im.INTRANT_MEDICAUX_DESCR ,(SELECT iu.INTRANT_UNITE_DESCR FROM intrant_unites iu WHERE iu.INTRANT_UNITE_ID=im.INTRANT_UNITE_ID) UNITE, SUM((SELECT `QUANTITE` FROM `stock_camebu` WHERE `INTRANT_ID`=rri.`INTRANT_ID` AND `RECEPTION_CODE`=rr.RECEPTION_CODE)) QUANTITE_DISPONIBLE, ( CASE WHEN rri.MODE_RECEPTION_ID=1 THEN "DODS" WHEN rri.MODE_RECEPTION_ID=2 THEN "PNLIP" END) MODE_RECEPTION FROM `rc_reception_intrant_detail` rri JOIN intrant_medicaux im ON rri.`INTRANT_ID` = im.INTRANT_MEDICAUX_ID JOIN rc_reception rr ON rri.`RECEPTION_ID` = rr.RECEPTION_ID WHERE rri.INTRANT_ID='.$key['INTRANT_ID'].' '.$filter_by_ptf_conected.' GROUP BY im.INTRANT_MEDICAUX_DESCR,UNITE,MODE_RECEPTION');
  // echo "<pre>";
  // print_r($query_principal);
                  $i=0;
                  foreach ($query_principal as  $value) {
    # code...
                    if (empty($value['QUANTITE_DISPONIBLE'])) {
      # code...
                      $value['QUANTITE_DISPONIBLE']=0;
                    }
                    // $montant=$value['QUANTITE_DISPONIBLE']*$value['PRIX_UNITAIRE'];
                    // $total+=$montant;
                   // $qte+=$value['QUANTITE_DISPONIBLE'] ;
                    ?>
                    <tr>
                      <td ><?= $value['INTRANT_MEDICAUX_DESCR'] ?></td>

                      <td><center><?= $value['UNITE'] ?></center></td>
                      <!-- <td style="width: 40px;"><?= number_format($value['PRIX_UNITAIRE'],0,',',' ') ?></td> -->
                      <td style="width: 40px;"><center><?= number_format($value['QUANTITE_DISPONIBLE'],0,' ',' ') ?></center></td>
                      <!-- <td style="width: 40px;"><?= number_format($montant,0,',',' ') ?></td> -->
                      <td><center><?= $value['MODE_RECEPTION'] ?></center></td>
                    </tr>


                    <?php $i++; } }
                  

                      

                     ?> 


                  
                  </tbody>
                </table>


              </div>
            </div>
          </div>

        </div>
        
        <!-- Rapport partie -->



        <!-- End Rapport partie -->

      </div>
    </div>
  </div>          
</div>


</section>


<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>




<script type="text/javascript">


  $(document).ready(function(){ 
     $("#message").delay("slow").fadeOut(3000);
   
$('#app_title').html('Stock du <?= date('d-m-Y') ?>');

  });
 $(document).ready(function () {
   var row_count ="1000000";
   $("#mytable").DataTable({

     "paging": true,
     "lengthChange": true,
     "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": true,
      "responsive": true,
      "pagingType": "simple_numbers",
  "columns": [

    { "width": "40%" },
    { "width": "15%" },
    { "width": "35%" },
    { "width": "10%" }

  ],
      "lengthMenu": [[50, 100, row_count], [50, 100, "All"]],
      pageLength: 50,
      "columnDefs":[{

        "targets":[],
        "orderable":false

      }],

      dom: 'Bfrtlip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
      language: {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      }


    });
 });

</script>
