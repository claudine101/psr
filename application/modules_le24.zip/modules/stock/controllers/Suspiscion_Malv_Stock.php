<?php
/**
 * @author jules_ndihokubwayo@mediabox.bi
 *Traitement (changement des statut de malversation de stock)
 */
class Suspiscion_Malv_Stock extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function index($value='')
	{
		# code...
        $data=array('title'=>"");
		$this->load->view('Suspiscion_Malv_Stock_View',$data);
	}

    public function liste($value=0)
    {
    	

          $get_type_stru=$this->Modele->getRequeteOne('SELECT t.CODE_STRUCTURE FROM `intervenants_structure` i JOIN type_intervenants_structures t ON i.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'));

		  $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		  $var_search=str_replace("'", "\'", $var_search);
		  $query_principal='SELECT INCIDENT_ID, i.INTERVENANT_STRUCTURE_DESCR,`QUANTITE_RESTANTE`,s.`QUANTITE_SEUIL`,`QUANTITE_DECLARE`,`QUANTITE`,`OBSERVATION`,t.TYPE_INTERVENANT_STRUCTURE_DESCR,im.INTRANT_MEDICAUX_DESCR,st.DESCRIPTION,DATE_INSERTION,s.ID_STATUT_TICKET FROM `stock_incident` s JOIN intervenants_structure i ON s.`INTERVENANT_STRUCTURE_ID`=i.INTERVENANT_STRUCTURE_ID JOIN type_intervenants_structures t ON s.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID JOIN intrant_medicaux im ON s.`INTRANT_MEDICAUX_ID`=im.INTRANT_MEDICAUX_ID JOIN statut_ticket st ON s.`ID_STATUT_TICKET`=st.ID_STATUT_TICKET';

          $critaire="";
          if ($get_type_stru['CODE_STRUCTURE']=="CAMEBU") {
          	# code...
          	$critaire=" WHERE t.TYPE_INTERVENANT_STRUCTURE_DESCR LIKE 'BDS'";
          }
          if ($get_type_stru['CODE_STRUCTURE']=="BDS") {
          	# code...
          	$critaire=" WHERE s.`INTERVENANT_STRUCTURE_ID` IN ( SELECT bds_cds.CDS_ID FROM bds_cds WHERE bds_cds.BDS_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').")";
          }
		  $limit='LIMIT 0,10';
		  if($_POST['length'] != -1){
		    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		  }
		  $order_by='';
		  if($_POST['order']['0']['column']!=0){
		    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY DATE_INSERTION DESC';
		  }

		  $search = !empty($_POST['search']['value']) ? (" AND (DATE_INSERTION LIKE '%$var_search%' OR  INTRANT_MEDICAUX_DESCR LIKE '%$var_search%' OR  INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR  DESCRIPTION LIKE '%$var_search%')") : '';



		  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		  $query_filter=$query_principal.'  '.$critaire.' '.$search;

		  $fetch_enqueteurs = $this->Modele->datatable($query_secondaire);
		  $u=0;
		  $data = array();
		  foreach ($fetch_enqueteurs as $row) {

		   $u++;
		   $sub_array = array();
		   $sub_array[] =  $u;
		   
		   $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
           $sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
		   $sub_array[]=$row->QUANTITE_RESTANTE;
		   $sub_array[]=$row->QUANTITE_SEUIL;
		   $sub_array[]=$row->QUANTITE;
		   $sub_array[]=$row->DESCRIPTION;
           $sub_array[]=$row->DATE_INSERTION;
           $opt='<div class="dropdown" style="color:#fff;">
                       <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                       <i class="fa fa-cog"></i> Options<span class="caret">
                       </span></a>
	                   <ul class="dropdown-menu dropdown-menu-left">';
            if ($row->ID_STATUT_TICKET==1 ||$row->ID_STATUT_TICKET==2) {
            	# code...
            
            $opt.='<li class="dropdown-item" ><a href="#" onclick="show_traiter('.$row->INCIDENT_ID.','.$row->ID_STATUT_TICKET.')">Traiter</a></li>';
            }
            //$opt.='<li><a href="#" onclick="show_historique('.$row->RECEPTION_ID.')">Modifier</a></li>';
            $opt.='<li class="dropdown-item"><a href="#" onclick="show_historique('.$row->INCIDENT_ID.')">Historique</a></li>';
	        $opt.='</ul></div>';
           $sub_array[]=$opt;

		  $data[] = $sub_array;

		}

		$output = array(
		 "draw" => intval($_POST['draw']),
		 "recordsTotal" =>$this->Modele->all_data($query_principal),
		 "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
}
public function get_statut($value='')
{
	# code...
	$stat="";
	$ID_STATUT_TICKET=$this->input->post('ID_STATUT_TICKET');
	$statut=$this->Modele->getList('statut_ticket');
	foreach ($statut as $key ) {
		# code...
		if ($key['ID_STATUT_TICKET']==$ID_STATUT_TICKET) {
			# code...
			$stat.="<option value='".$key['ID_STATUT_TICKET']."' selected>".$key['DESCRIPTION']."</option>";
		}else{
			$stat.="<option value='".$key['ID_STATUT_TICKET']."'>".$key['DESCRIPTION']."</option>";
		}
        
	}
	echo $stat;
}
public function update_statut($value='')
{
	# code...
	$ID_STATUT_TICKET=$this->input->post('ID_STATUT_TICKET');
	$INCIDENT_ID=$this->input->post('INCIDENT_ID');
	$OBSERVATION=$this->input->post('OBSERVATION');
	$stock_incident=array('INCIDENT_ID'=>$INCIDENT_ID, 'OBSERVATION'=>$OBSERVATION, 'ID_STATUT_TICKET'=>$ID_STATUT_TICKET,'USER_ID'=>$this->session->userdata('iccm_USER_ID'));
	$this->Modele->update('stock_incident',array('INCIDENT_ID'=>$INCIDENT_ID),$stock_incident);
	$this->Modele->create('stock_incident_historique',$stock_incident);
	echo "1";

}
public function get_histo($value='')
{
	# code...
	$INCIDENT_ID=$this->input->post('INCIDENT_ID');
	$table="<table class='table'><tr><th>STATUT</th><th>OBSERVATION</th><th>UTILISATEUR</th><th>DATE</th></tr>";
	$sql  = 'SELECT `DATE_INSERTION`,`OBSERVATION`,st.DESCRIPTION,a.USER_NAME FROM `stock_incident_historique` si JOIN statut_ticket st ON si.`ID_STATUT_TICKET`=st.ID_STATUT_TICKET JOIN admin_users a ON si.`USER_ID`=a.USER_ID WHERE `INCIDENT_ID`='.$INCIDENT_ID;
   $fetch_histo = $this->Modele->datatable($sql);
   foreach ($fetch_histo as $key ) {
   	# code...
   	$table.="<tr><td>".$key->DESCRIPTION."</td><td>".$key->OBSERVATION."</td><td>".$key->USER_NAME."</td><td>".$key->DATE_INSERTION."</td></tr>";
   }
   echo $table."</table>";
}

}

?>