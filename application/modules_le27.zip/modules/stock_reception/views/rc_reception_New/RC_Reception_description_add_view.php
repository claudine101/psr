
<div class="row">
 <legend>
   <?= $title;?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?=base_url('stock_reception/RC_Reception_Intrants/listing')?>">
        <i class="fa fa-plus"></i>Liste
      </a>
    </div>
  </legend>
  <!-- <div class="col-md-12"> -->
<div class="col-md-12">
  <?php
{
   echo $this->session->flashdata('sms');
 } ?>
</div>
   <section class="home-content-top">
    <div class="container">
      <!--our-quality-shadow-->
      <div class="clearfix"></div>
      <!-- <h1 class="heading1"> <?= $title;?></h1> -->
      <div class="tabbable-panel margin-tops4 ">
        <div class="tabbable-line">
          <ul class="nav nav-tabs tabtop  tabsetting">
            <li class="active"> <a href="#tb_1" data-toggle="tab"> Réception </a> </li>
            <li> <a href="#" data-toggle="tab"> Commissions de réception</a> </li>
            <li> <a href="#" data-toggle="tab"> Intrants reçus </a> </li>
          </ul>
          <div class="tab-content margin-tops">
            <div class="tab-pane active fade in" id="tb_1">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-12">
                    <form action="<?= base_url('stock_reception/RC_Reception_Intrants/etape1_add')?>" method="post" enctype="multipart/form-data">
                     <div class="row">
                      <div class="col-md-6">
                       <label>Mode de réception</label>
                       <select name="MODE_RECEPTION_ID" class="form-control" id="MODE_RECEPTION_ID" onchange="get_intervenant_structure(this.value)">
                         <option value="">--Mode de reception</option>
                         <?php
                         foreach ($mode_reception as $mod) {
                           if ($mod['MODE_RECEPTION_ID']==set_value('MODE_RECEPTION_ID')) {?>
                            <option value="<?=$mod['MODE_RECEPTION_ID']?>" selected=''><?=$mod['MODE_RECEPTION_DESCR']?></option> 
                            <?php } else {?>
                              <option value="<?=$mod['MODE_RECEPTION_ID']?>"><?=$mod['MODE_RECEPTION_DESCR']?></option> 
                              <?php }

                            }
                            ?>

                          </select>


                          <label class="text-red"><?php echo form_error('MODE_RECEPTION_ID'); ?></label>
                          <label>Date de reception</label>
                          <input type="date" name="RECEPTION_DATE" value="<?php if(!empty(set_value('RECEPTION_DATE'))){ echo set_value('RECEPTION_DATE'); }else{ echo date('Y-m-d'); }   ?>" class="form-control" max="<?= date('Y-m-d') ?>">
                          <div><?=form_error('RECEPTION_DATE')?></div>

                        </div>

                        <div class="col-md-6">
                         <label>PTF</label>
                         <select name="PTF_ID" class="form-control">
                           <option value="">--Intervenant</option>
                           <?php
                           foreach ($ptfs as $ptf) 
                           {
                             if ($ptf['PTF_ID']==set_value('PTF_ID')) {?>
                               <option value="<?=$ptf['PTF_ID']?>" selected=''><?=$ptf['PTF_NOM']?></option>
                               <?php } else {?>
                                 <option value="<?=$ptf['PTF_ID']?>"><?=$ptf['PTF_NOM']?></option>
                                 <?php }

                               }
                               ?>

                             </select>
                             <div><?=form_error('PTF_ID')?></div>

                           </div>

                          <!--  <div class="col-md-6">
                            <label>Document scané pour la réception</label>
                            <input type="file" name="PATH_SCAN_PV_RECEPTION" class="form-control">
                          </div> -->

                          <div class="col-md-6">
                            <label>Commentaire</label>
                            <textarea class="form-control" name="COMMENTAIRE"><?=set_value('COMMENTAIRE')?></textarea>
                            <div><?=form_error('COMMENTAIRE')?></div>
                          </div>


                          <div class="col-md-12">
                            <button type="submit" class="btn btn-primary form-control" style="margin-top: 30px;">
                              Enregistrer
                            </button>
                          </div>


                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>

                </div>
              </div>
            </div>
          </div>
        </section>


      <!-- </div> -->

    </div>
    






