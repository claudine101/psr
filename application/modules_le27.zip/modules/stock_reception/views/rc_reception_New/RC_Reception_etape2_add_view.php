<div class="row">
  <?php if($this->session->flashdata('sms')){
   echo $this->session->flashdata('sms');
 } ?>
</div>
<div class="row">
  <legend>
   <?= $title;?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?=base_url('stock_reception/RC_Reception_Intrants/etape1')?>">
        <i class="fa fa-plus"></i>Nouveau
      </a>
    </div>
  </legend>
  <!-- <div class="col-md-12"> -->
   <section class="home-content-top">
    <div class="container">
      <!--our-quality-shadow-->
      <div class="clearfix"></div>
      <!-- <h1 class="heading1"> <?= $title;?></h1> -->
      <div class="tabbable-panel margin-tops4 ">
        <div class="tabbable-line">
          <ul class="nav nav-tabs tabtop  tabsetting">
            <li> <a href="#" data-toggle="tab"> Réception </a> </li>
            <li class="active"> <a href="#tb_2" data-toggle="tab"> Commissions de réception</a> </li>
            <li> <a href="#" data-toggle="tab"> Intrants reçus </a> </li>
          </ul>
          <div class="tab-content margin-tops">
            <div class="tab-pane" id="tb_1">

              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-12">

                  </div>
                </div>
              </div>
            </div>
            <div class="tab-pane fade active fade in" id="tb_2">
              <div class="col-md-12">
                <form action="<?= base_url('stock_reception/RC_Reception_Intrants/etapa2_add/'.$RECEPTION_ID)?>" method="post">
                  <div class="col-md-4">
                    <label>Structure</label>
                    <select name="INTERVENANT_STRUCTURE_ID" id='INTERVENANT_STRUCTURE_ID' class="form-control" onchange="get_intervenant_RH(this.value)">
                     <option value="">--Structure</option>
                     <?php
                     foreach ($structures as $key => $value) {

                      if ($value['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')) {?>
                       <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>" selected=''><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option> 
                       <?php } else {?>
                         <option value="<?=$value['INTERVENANT_STRUCTURE_ID']?>"><?=$value['INTERVENANT_STRUCTURE_DESCR']?></option> 
                         <?php }

                       } 
                       ?>
                     </select>
                   </div>

                   <div class="col-md-4">
                     <label>Intervenant</label>
                     <select name="INTERVENANT_RH_ID" id='INTERVENANT_RH_ID' class="form-control">
                       <option value="">--Intervenant</option>
                     </select>
                     <div><?=form_error('INTERVENANT_RH_ID')?></div>

                   </div><br>
                   <div class="col-md-1">
                    <label></label>
                    <label> </label>
                    <button type="submit" class="btn btn-primary fa fa-plus">                      
                    </button>
                  </div>


                </form>

                <div class="col-sm-12" style="margin-top:10px;text-decoration: none;color: white;">
               <a href="<?=base_url('stock_reception/RC_Reception_Intrants/etape1_back/'.$RECEPTION_ID)?>" class="btn btn-primary">Précédent</a>
               <a href="<?=base_url('stock_reception/RC_Reception_Intrants/etape3/'.$RECEPTION_ID)?>" class="btn btn-primary" style="float:right;text-decoration:none;color: white;">Suivant</a>
             </div>

             <div class="col-md-12" style="margin-top:30px;">
              <?=$table;?>
            </div>

              </div>





          </div>

          <!-- <div class="col-md-2"></div> -->

        </div>
      </div>
    </div>
  </div>
</section>


<!-- </div> -->

</div>





