<?php
/**
* NSHIMIRIMANA REVERIEN
COMMENTAIRE:PV DE RECEPTION DES INTRANTS
*/
class PV_Reception extends CI_Controller
{



function index($RECEPTION_ID="")
{

  include 'pdfinclude/fpdf/mc_table.php';
  include 'pdfinclude/fpdf/pdf_config.php';
  $pdf = new PDF_CONFIG('P','mm','A4');
  $pdf->addPage();


  $rc_r=$this->Modele->getRequeteOne('SELECT DISTINCT rcri.MODE_RECEPTION_ID,RECEPTION_DATE,intv.INTERVENANT_STRUCTURE_DESCR PTF,rc_mode_reception.MODE_RECEPTION_DESCR MODES FROM rc_reception_intrant_detail rcri JOIN rc_reception rc  ON rcri.RECEPTION_ID=rc.RECEPTION_ID JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rc.PTF_ID JOIN rc_mode_reception ON rc_mode_reception.MODE_RECEPTION_ID=rcri.`MODE_RECEPTION_ID` WHERE rc.RECEPTION_ID='.$RECEPTION_ID.' AND rcri.`MODE_RECEPTION_ID`<>0');


  // $equipe=$this->Modele->getRequete('SELECT rcm.MODE_RECEPTION_DESCR,concat(rh.NOM," ",rh.PRENOM) as NOM,rh.SEXE_ID FROM `rc_equipe_reception` JOIN rc_reception_intrant_detail rcr ON rcr.RECEPTION_ID=rc_equipe_reception.RECEPTION_ID JOIN rc_mode_reception rcm ON rcm.MODE_RECEPTION_ID=rcr.MODE_RECEPTION_ID JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=rc_equipe_reception.INTERVENANT_RH_ID WHERE  rcr.RECEPTION_ID='.$RECEPTION_ID);

  $equipe=$this->Modele->getRequete("SELECT rh.SEXE_ID,CONCAT(rh.NOM,' ',rh.PRENOM,', ',intv.INTERVENANT_STRUCTURE_DESCR) EQUIPE FROM `rc_equipe_reception` JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rc_equipe_reception.INTERVENANT_STRUCTURE_ID JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=rc_equipe_reception.INTERVENANT_RH_ID WHERE rc_equipe_reception.RECEPTION_ID=".$RECEPTION_ID);


  $date=$rc_r['RECEPTION_DATE'];
  //GENERER L'ANNEE LITERALE
  $annee_jour_mois=$this->mylibrary->mois_jour_litterale($date);
  $pdf->SetFont('Arial','BU',12);
  $pdf->Cell(150,5,utf8_decode('Procès-verbal de la réception des médicaments de la '.$rc_r['MODES']),0,1,'R');
  $pdf->SetFont('Arial','',12);

  $pdf->Ln(4);

  $pdf->MultiCell(189,5,utf8_decode($annee_jour_mois. ' dans l\'un des magasins de la CAMEBU s\'est tenue une réception des médicaments de la '.$rc_r['MODES'].' achetés par '.$rc_r['PTF']));//.$ptf['PTF_NOM']
  $pdf->Ln();
  
  $pdf->MultiCell(189,5,utf8_decode('L\'équipe chargée de réceptionner ces médicaments était composée par:'));
  $pdf->Ln();

  $eq=1;
  foreach ($equipe as $key => $value) {

    $sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Madame ' ;

    $pdf->MultiCell(100,5,utf8_decode($eq.'.'.$sex.' '.$value['EQUIPE']));

    $eq++;

  }

  $pdf->Ln();


  //$pdf->Ln(5);
  $pdf->MultiCell(189,5,utf8_decode('La méthodologie a consisté à l\'inspection qualitative et quantitative des produits par comptage physique et par la vérification carton par carton du: '));
  $pdf->Ln();

  $pdf->MultiCell(60,5,utf8_decode('
    1.Nom du produit;
    2.Numéro de lot;
    3.La date de péremption;
    4.La quantité'),0,'L',0);

  $pdf->Ln();



  $pdf->MultiCell(189,5,utf8_decode('Tableau qui montre les détails des produits ICCM achetés par '.$rc_r['PTF'].' à la CAMEBU'));//.$ptf['PTF_NOM']
  $pdf->Ln();

  $pdf->SetWidths(array('55','22','25','23','23','21','23'));
  $pdf->SetLineHeight(5);
  $pdf->SetFont('Arial','B',12);
  $pdf->Row(array(utf8_decode('Nom du produit'),utf8_decode('Unité'),utf8_decode('Lot'),utf8_decode('Exp'),utf8_decode('Quantité'),utf8_decode('P.U(USD)'),utf8_decode('P.T(USD)')),'C');
  $pdf->SetFont('Arial','',10);


  $query_principal=$this->Modele->getRequete('SELECT DISTINCT `INTRANT_ID` FROM `rc_reception_intrant_detail` WHERE RECEPTION_ID='.$RECEPTION_ID);
  $general_total=0;



  foreach ($query_principal as $key => $value) 
  {


   $total=0;
   $qte=0;

   $query_secondaire=$this->Modele->getRequete('SELECT SUM(rc.`QUANTITE`) as qte,SUM(rc.QUANTITE * PRIX_UNITAIRE) AS PT,intra.INTRANT_MEDICAUX_DESCR,(SELECT unite.INTRANT_UNITE_DESCR FROM intrant_unites unite WHERE unite.INTRANT_UNITE_ID=intra.INTRANT_UNITE_ID) as UNITE, `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` rc JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=rc.`INTRANT_ID` WHERE `RECEPTION_ID`='.$RECEPTION_ID.' AND rc.INTRANT_ID='.$value['INTRANT_ID'].' GROUP BY `PRIX_UNITAIRE`, `NUMERO_LOT`, `DATE_PEREMPTION`,intra.INTRANT_MEDICAUX_DESCR,UNITE');
   

      foreach ($query_secondaire as $value1) 
      {

        $qte_total=0;
        $montant_total=0;

        $qte_total+=$value1['qte'];
        $montant_total+=$value1['PT'];

        $pdf->Row(array(utf8_decode($value1['INTRANT_MEDICAUX_DESCR']),utf8_decode($value1['UNITE']),utf8_decode($value1['NUMERO_LOT']),utf8_decode($value1['DATE_PEREMPTION']),utf8_decode(number_format($value1['qte'],0,' ',' ')),utf8_decode($value1['PRIX_UNITAIRE']),utf8_decode(number_format($value1['PT'],0,' ',' '))));

        $pdf->SetFont('Arial','B',10);
        $pdf->Row(array(utf8_decode('Total'),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(number_format($qte_total,0,' ',' ')),utf8_decode(''),utf8_decode('')));
        $pdf->SetFont('Arial','',10);
      }


    $general_total+=$montant_total;
    }


   

    $pdf->SetFont('Arial','B',12);
    $pdf->Row(array(utf8_decode('Total général'),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(''),utf8_decode(number_format($general_total,0,' ',' '))));
    $pdf->SetFont('Arial','',12);



    $pdf->Ln();
    $pdf->MultiCell(189,5,utf8_decode('Les membres de l\'équipe chargée de la réception'));
    $pdf->Ln();

    $eq=1;



    foreach ($equipe as $key => $value) {

      $sex = ($value['SEXE_ID']==1) ? 'Mr' : 'Madame ' ;

      $pdf->MultiCell(100,5,utf8_decode($eq.'.'.$sex.' '.$value['EQUIPE']));

      $eq++;

    }

    $pdf->Ln();

    $pdf->MultiCell(180,5,utf8_decode('Fait à Bujumbura, le '.date('d/m/Y',strtotime($rc_r['RECEPTION_DATE']))),0,'R');

 //$pdf->output('I');
 $pdf->output('pv'.$RECEPTION_ID.'.pdf','D');


}



}



