<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url('assets/bootstrap/')?>bootstrap.min.js"></script>
<legend>RECEPTION DES INTRANTS</legend> -->
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-12">
              <!-- <h1 class="m-0">Liste des Incidents</h1> -->
              <?php
              $menu1="nav-link active";
              $menu2="nav-link";
              $menu3="nav-link"; 
              $menu4="nav-link"; 
              $menu5="nav-link"; 
              $menu6="nav-link"; 
              include VIEWPATH.'sousmenu/sous_menu_deces.php'; ?>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>
      <section class="container" >
        <!-- ************************************************************************************************** -->
        <div class="card" >


          <div class="container-fluid">

            <div class="col-12" id="message"></div>

            <div class="col-5" style="padding: 5px;">
             <label for="DATE_INSERTION">DATE DECES</label>
             <select  class="form-control"  id="DATE_INSERTION" onclick="get_list(this.value)">
              <option value="" selected="">sélectionner</option>
              <?php foreach ($dattes as $key) {
            # code...
                ?>
                <option value="<?= $key['dattes'] ?> "><?= $key['dattes'] ?></option>

              <?php } ?>
            </select>
          </div> 
          <br>
          <div class="col-md-12 table-responsive">
            <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
              <thead>
                <tr>
                  <th>#</th>
                  <th>STRUCTURE</th>
                  <th>MALADIE</th>
                  <th>AGE</th>
                  <th>INTERVENANT</th>
                  <th>STATUT</th>
                  <th>DATE</th>
                  <th>OPTION</th>
                </tr>
              </thead>

            </table>


          </div>


        </div>
      </div>
      <!-- ********************************************************************************************** -->




    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
  function show_intrant(RECEPTION_ID) {
    // body...
    $("#modal_intant").modal();
    $.post('<?php echo base_url();?>stock_reception/Reception/get_intrant/',
    {
      RECEPTION_ID:RECEPTION_ID

    },
    function(data) 
    { 
      SHOW_INTRANT.innerHTML = data; 
      $('#SHOW_INTRANT').html(data);

    }); 
  }
  function show_comite(RECEPTION_ID) {
    // body...
    $("#modal_commission").modal();
    $.post('<?php echo base_url();?>stock_reception/Reception/get_comite/',
    {
      RECEPTION_ID:RECEPTION_ID

    },
    function(data) 
    { 
      SHOW_COMISSION.innerHTML = data; 
      $('#SHOW_COMISSION').html(data);

    }); 
  }
</script>
<script type="text/javascript">

  var table;
  $(document).ready(function(){ 
     //$("#message").delay("slow").fadeOut(3000);
     get_list();
   });



  function get_list(ID=null) {
  // body...
  var DATE_INSERTION=ID;

  var row_count ="1000000";

  table=$("#mytable").DataTable({
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "oreder":[[ 0, 'desc' ]],
    "ajax":{
      url:"<?=base_url()?>sms_integration/Declaration_intev/liste/",
      type:"POST",
      data : {

       DATE_INSERTION:DATE_INSERTION,


     }
   },
   lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
   pageLength: 10,
   "columnDefs":[{
    "targets":[],
    "orderable":false
  }],

  dom: 'Bfrtlip',
  buttons: [
  'copy', 'csv', 'excel', 'pdf', 'print'
  ],
  language: {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
      "sFirst":      "Premier",
      "sPrevious":   "Pr&eacute;c&eacute;dent",
      "sNext":       "Suivant",
      "sLast":       "Dernier"
    },
    "oAria": {
      "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
      "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    }
  }

});
}
</script>


<script>

  function show_traiter(INCIDENT_ID,ID_STATUT_TICKET) {
    // body...
  $('#INCIDENT_ID').val(INCIDENT_ID);
  $.post('<?php echo base_url();?>sms_integration/Declaration_intev/get_statut/',
  {
    ID_STATUT_TICKET:ID_STATUT_TICKET
    
    },
    function(data) 
    { 

    if (data) {
       ID_STATUT_TICKET.innerHTML = data; 
      $('#ID_STATUT_TICKET').html(data);
      $('#traiter_modal').modal();
    }


    }); 
  }




  function traiter() {
  // body...
  var INCIDENT_ID=$('#INCIDENT_ID').val();
  // document.getElementById("COMPTEUR1").value=i;
  var ID_STATUT_TICKET=$('#ID_STATUT_TICKET').val();
  var OBSERVATION=$('#OBSERVATION').val().trim();
  if (Number(ID_STATUT_TICKET)>1 && OBSERVATION!="") {
    $('#traiter_modal').modal({ backdrop: false });
   $('#message_ret').html('<div class="alert alert-info">Opération en cours...</div>')
   
   $('#do_act').attr('disabled', true);
   
  $.post('<?php echo base_url();?>sms_integration/Declaration_intev/update_statut/',
  {
    INCIDENT_ID:INCIDENT_ID,
    ID_STATUT_TICKET:ID_STATUT_TICKET,
    OBSERVATION:OBSERVATION
    
    },
    function(data) 
    { 
      if (data) {
     $('#message_ret').html('<div id="message" class="alert alert-success">Opération réussi avec succes</div>')
     // get_list();
     // get_stock_rupture(ID_STATUT_TICKET);
     table.ajax.reload(null,false);
     setTimeout(function(){ 
      $('#traiter_modal').modal({ backdrop: true });
      $('#traiter_modal').modal('hide');
      $('#do_act').attr('disabled', false);
      $("#message").delay("slow").fadeOut(3000);
      }, 3000);
}

    });
}

if (Number(ID_STATUT_TICKET)==1) {
$('#message_ret').html('<div id="message" class="alert alert-danger">Veillez changer le statut</div>');
}

if(OBSERVATION==""){
      // show_intrant();
       $('#message_ret').html('<div id="message" class="alert alert-danger">Tous les champs sont requis</div>');
       //$('#traiterticket').modal();
}

}


  // HISTORIQUE
  function show_historique(INCIDENT_ID) {
    // body...
  
  $.post('<?php echo base_url();?>sms_integration/Declaration_intev/get_histo/',
  {
    INCIDENT_ID:INCIDENT_ID
    
    },
    function(data) 
    { 

    if (data) {
       HISTO.innerHTML = data; 
      $('#HISTO').html(data);
      $('#histo_modal').modal();
    }


    }); 
  }

</script>




<div class="col-md-12 table-responsive" style="padding: 30px;">
<div class="modal fade" id="traiter_modal" tabindex="-1" role="dialog" aria-labelledby="traiterticketLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="traiterticketLabel">Traitement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
       
      </div>
     
      <div class="modal-body">
        <div class="row" id="message_ret"></div>
        <form>
          <div class="form-group">
            <input type="hidden" id="INCIDENT_ID">
            <label for="ID_STATUT_TICKET" class="col-form-label">Statut</label>
            <select class="form-control" id="ID_STATUT_TICKET"></select>
          </div>
          <div class="form-group">
            <label for="OBSERVATION" class="col-form-label">Observation</label>
            <textarea class="form-control" id="OBSERVATION"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
<!--         <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
 -->        <button type="button" id="do_act" class="btn btn-primary" onclick="traiter()">Traiter</button>
      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="histo_modal" tabindex="-1" role="dialog" aria-labelledby="histo_modalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="histo_modalTitle">Historique de Traitement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="HISTO">
              
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
      </div>
    </div>
  </div>
</div>
  

</div>











<!-- 
<div class="modal fade bd-example-modal-lg" id="traiter_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="statut"></h4>
          <button type="button"  class="close btn btn-outline-danger btn-sm" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="container-fluid" style="padding: 20px;">
          <center><span id="message_retour"></span></center>
          <div class="col-md-12">
            <form id="form_traiter">
             <div class="row">

               <div class="col-md-12">
                <input type="hidden" name="INCIDENT_ID" id="INCIDENT_ID">
                <label>Statut</label>
                <select class="form-control" id="ID_STATUT_TICKET" name="ID_STATUT_TICKET">
                 <option value="" selected="" disabled="">--Statut</option>
                 <?php
                 foreach ($status as $key)
                   {?>

                    <option value="<?=$key['ID_STATUT_TICKET']?>"><?=$key['DESCRIPTION']?></option>

                  <?php }
                  ?>
                </select>
                <label class="text-danger" id="error_status"></label>
              </div>
               
             </div>

            
             <div class="row">

              <div class="col-md-6">
                <button type="button" id="btn_status" onclick="changer_statut()" class="btn btn-primary btn-sm" style="margin-top: 25px;">
                  <i class="nav-icon fas fa-edit"></i>
                  <b>Changer</b>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div> -->

