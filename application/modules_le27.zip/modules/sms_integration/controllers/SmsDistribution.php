<?php


/*

  Auteur : THADDEE ND.
  
  DESCR : Flux SMS pour la confirmation de la distribution des intrants dans la population
  DATE DEBUT : 03/03/2021
  @Editeur jules_ndihokubwayo@mediabox.bi
  le 23/03/2021-25/03/2021 with God help
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class SmsDistribution extends MY_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  public function index()
  {
    // code...
    $data = file_get_contents('php://input');
    $array = json_decode($data);



    $TELEPHONE_USED = $array->contact->urn;

    $selections_value = $array->results->selections->value;
    // echo "<pre>";
    // print_r($selections_value);
    // echo "</pre>";
    //recuperation du code d'un ASC
    $code_asc = $array->results->code_asc->value;
    $un_asc = $this->Modele->getOne('intervenants_rh',array('TELEPHONE1'=>$code_asc));

    $message = "";
    if(!empty($un_asc)){
      $INTERVENANT_RH_ID = $un_asc['INTERVENANT_RH_ID'];

      //Recuperation de son centre de sante
      $CDS_ID = $this->mylibrary->getCdsDependance($un_asc['INTERVENANT_RH_ID']);
      $cds = $this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$CDS_ID));

      //Recuperation du BDS
      $BDS_ID = $this->mylibrary->getBdsDependance($CDS_ID);
      $bds = $this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$BDS_ID));

      //Si un individu a sélectionné TDR
      if($selections_value == 1){
        
        $maladie = $this->Modele->getOne('maladies',array('MALADIE_CODE'=>"PALU"));

        //Enregistrement d'une intervention
        $array_intervention_paludisme = array(
          'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
          'MALADIE_ID'=>$maladie['MALADIE_ID'],
          'TELEPHONE'=>$TELEPHONE_USED
        );
        $INTERVENTION_ID = $this->Modele->insert_last_id('sms_distribution_intervention',$array_intervention_paludisme);

        /*TDR*/
        //Gestion de sortie des TDRs
        $TDR_CODE = 'TDR';
        $intrant_tdr = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$TDR_CODE));

        //Derniere distribution des TRDs vers les ASCs
        $INTRANT_TDR_ID = $intrant_tdr['INTRANT_MEDICAUX_ID'];
        //recuperation de la distribution précedente de l'intrant
        $sql_tdr_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                            JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                            WHERE dist.INTERVENANT_RH_ID = ".$INTERVENANT_RH_ID." AND dt.INTRANT_ID = ".$INTRANT_TDR_ID." AND dist.CODE_SENS_ID =3
                            HAVING dt.QUANTITE_RESTANTE > 0";

        $distribution_tdr_detail = $this->Modele->getRequeteOne($sql_tdr_detail);
        //Mise de la derniere distribution
        $qte_tdr_utilise = $intrant_tdr['NOMBRE_DOSE'];
        $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_tdr_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_tdr_detail['QUANTITE_RESTANTE']-$qte_tdr_utilise));
        //Mise a jour de stock intervenant
        $stock_tdr_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_TDR_ID));
        $tdr_rest=0;
        $tdr_rest=$stock_tdr_detail['QUANTITE']-$qte_tdr_utilise;
        $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_tdr_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$tdr_rest));

        //Insertion dans la table des distribution
         $array_tdr_detail = array(
           'DISTRIBUTION_ID'=>$code_asc,
           'RECEPTION_CODE'=>$distribution_tdr_detail['RECEPTION_CODE'],
           'INTRANT_ID'=>$INTRANT_TDR_ID,
           'QUANTITE'=>$qte_tdr_utilise,
           'QUANTITE_RESTANTE'=>$qte_tdr_utilise
         );
         $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_tdr_detail);
         //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
         $array_intervention_tdr = array(
           'INTRANT_ID'=>$INTRANT_TDR_ID,
           'QUANTITE'=>$qte_tdr_utilise,
           'INTERVENTION_ID'=>$INTERVENTION_ID
         );
         $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_tdr);

         //Notification
         $this->send_notification($distribution_tdr_detail['RECEPTION_CODE'],$bds,$cds,$qte_tdr_utilise,$un_asc,$intrant_tdr);
         $message=$this->ret_message($intrant_tdr['INTRANT_MEDICAUX_DESCR'],$qte_tdr_utilise)."\n";
         $comp_mess_det_i[]=$intrant_tdr['INTRANT_MEDICAUX_DESCR'];
         $comp_mess_det_q[]=$qte_tdr_utilise;
        /*GANT*/
        //Gestion de sortie des gants
        $GANT_CODE = 'GANT';
        $intrant_gant = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$GANT_CODE));

        //Derniere distribution des TRDs vers les ASCs
        $INTRANT_GANT_ID = $intrant_gant['INTRANT_MEDICAUX_ID'];
        //recuperation de la distribution précedente de l'intrant
        $sql_gant_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                            JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                            WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_GANT_ID' AND dist.CODE_SENS_ID =3
                            HAVING dt.QUANTITE_RESTANTE > 0";
        $distribution_gant_detail = $this->Modele->getRequeteOne($sql_gant_detail);
        //Mise de la derniere distribution
        $qte_gant_utilise = $intrant_gant['NOMBRE_DOSE'];
        $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_gant_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_gant_detail['QUANTITE_RESTANTE']-$qte_gant_utilise));
        //Mise a jour de stock intervenant
        $stock_gant_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_GANT_ID));

        $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_gant_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_gant_detail['QUANTITE']-$qte_gant_utilise));

        //Insertion dans la table des distribution
         $array_gant_detail = array(
           'DISTRIBUTION_ID'=>$code_asc,
           'RECEPTION_CODE'=>$distribution_tdr_detail['RECEPTION_CODE'],
           'INTRANT_ID'=>$INTRANT_GANT_ID,
           'QUANTITE'=>$qte_gant_utilise,
           'QUANTITE_RESTANTE'=>$qte_gant_utilise
         );
         $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_gant_detail);
         //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
         $array_intervention_gant = array(
           'INTRANT_ID'=>$INTRANT_GANT_ID,
           'QUANTITE'=>$qte_gant_utilise,
           'INTERVENTION_ID'=>$INTERVENTION_ID
         );
         $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_gant);

         $message.=$qte_gant_utilise." ".$intrant_gant['INTRANT_MEDICAUX_DESCR']."\n";
         $comp_mess_det_i[]=$intrant_gant['INTRANT_MEDICAUX_DESCR'];
         $comp_mess_det_q[]=$qte_gant_utilise;
         //Notification
         $this->send_notification($distribution_gant_detail['RECEPTION_CODE'],$bds,$cds,$qte_gant_utilise,$un_asc,$intrant_gant);

       $resultat_test = $array->results->trd_tst->value;
        //$test = 0;

        if($resultat_test == 1){

          $CA_TRAITE = $array->results->traitement->value;
          if ($CA_TRAITE==1) {
            # code...
            $CAS_MAL_TRAITE=0;
          }

          if ($CA_TRAITE==2) {
            $CAS_MAL_TRAITE=1;
          }
          $array_update_interv = array(
            'TEST'=>1,
            'CAS_MAL_TRAITE'=>$CAS_MAL_TRAITE,
          );
          $this->Modele->update('sms_distribution_intervention',array('INTERVENTION_ID'=>$INTERVENTION_ID),$array_update_interv);

          //echo "Positif <br>";
          $medicament = $array->results->medicaments->value;
          if($medicament == 1){
            $ACT1 = 'ART-2';
            //echo "Artesunate ".$medicament;
            $intrant_act1 = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$ACT1));

            //Derniere distribution des TRDs vers les ASCs
            $INTRANT_ACT1_ID = $intrant_act1['INTRANT_MEDICAUX_ID'];
            //recuperation de la distribution précedente de l'intrant
            $sql_act1_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                                JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                                WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_ACT1_ID' AND dist.CODE_SENS_ID =3
                                HAVING dt.QUANTITE_RESTANTE > 0";
            $distribution_act1_detail = $this->Modele->getRequeteOne($sql_act1_detail);
            //Mise de la derniere distribution
            $qte_act1_utilise = $intrant_act1['NOMBRE_DOSE'];
            $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_act1_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_act1_detail['QUANTITE_RESTANTE']-$qte_act1_utilise));
            //Mise a jour de stock intervenant
            $stock_act1_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_ACT1_ID));
            $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_act1_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_act1_detail['QUANTITE']-$qte_act1_utilise));

            //Insertion dans la table des distribution
             $array_act1_detail = array(
               'DISTRIBUTION_ID'=>$code_asc,
               'RECEPTION_CODE'=>$distribution_act1_detail['RECEPTION_CODE'],
               'INTRANT_ID'=>$INTRANT_ACT1_ID,
               'QUANTITE'=>$qte_act1_utilise,
               'QUANTITE_RESTANTE'=>$qte_act1_utilise
             );
             $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_act1_detail);

             //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
             $array_intervention_act1 = array(
               'INTRANT_ID'=>$INTRANT_ACT1_ID,
               'QUANTITE'=>$qte_act1_utilise,
               'INTERVENTION_ID'=>$INTERVENTION_ID
             );
             $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_act1);

             // UPDATE DES INTERVENENTION
             $array_update_interv = array(
               'TRANCHE_AGE'=>'2-11'
             );
             $this->Modele->update('sms_distribution_intervention',array('INTERVENTION_ID'=>$INTERVENTION_ID),$array_update_interv);

             $message.=$qte_act1_utilise." ".$intrant_act1['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_i[]=$intrant_act1['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_act1_utilise;
             //Notification
             $this->send_notification($distribution_act1_detail['RECEPTION_CODE'],$bds,$cds,$qte_act1_utilise,$un_asc,$intrant_act1);
          }else if($medicament == 2){
            $ACT2 = 'ART-5';
          //  echo "Artesunate ".$medicament;
          $intrant_act2 = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$ACT2));

          //Derniere distribution des TRDs vers les ASCs
          $INTRANT_ACT2_ID = $intrant_act2['INTRANT_MEDICAUX_ID'];
          //recuperation de la distribution précedente de l'intrant
          $sql_act2_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                              JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                              WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_ACT2_ID' AND dist.CODE_SENS_ID =3
                              HAVING dt.QUANTITE_RESTANTE > 0";
          $distribution_act2_detail = $this->Modele->getRequeteOne($sql_act2_detail);
          //Mise de la derniere distribution
          $qte_act2_utilise = $intrant_act2['NOMBRE_DOSE'];
          $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_act2_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_act2_detail['QUANTITE_RESTANTE']-$qte_act2_utilise));
          //Mise a jour de stock intervenant
          $stock_act2_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_ACT2_ID));
          $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_act2_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_act2_detail['QUANTITE']-$qte_act2_utilise));

          //Insertion dans la table des distribution
           $array_act2_detail = array(
             'DISTRIBUTION_ID'=>$code_asc,
             'RECEPTION_CODE'=>$distribution_act2_detail['RECEPTION_CODE'],
             'INTRANT_ID'=>$INTRANT_ACT2_ID,
             'QUANTITE'=>$qte_act2_utilise,
             'QUANTITE_RESTANTE'=>$qte_act2_utilise
           );
           $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_act2_detail);
           //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
           $array_intervention_act2 = array(
             'INTRANT_ID'=>$INTRANT_ACT2_ID,
             'QUANTITE'=>$qte_act2_utilise,
             'INTERVENTION_ID'=>$INTERVENTION_ID
           );
           $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_act2);

           // UPDATE DES INTERVENENTION
           $array_update_interv = array(
             'TRANCHE_AGE'=>'1-5'
           );
           $this->Modele->update('sms_distribution_intervention',array('INTERVENTION_ID'=>$INTERVENTION_ID),$array_update_interv);
          $message.=$qte_act2_utilise." ".$intrant_act2['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_i[]=$intrant_act2['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_act2_utilise;
           //Notification
           $this->send_notification($distribution_act2_detail['RECEPTION_CODE'],$bds,$cds,$qte_act2_utilise,$un_asc,$intrant_act2);
         }
          else if ($medicament == 4) {
                  # code..
                 // 5. Arthemeter Lumefantrine,.
                  /*ARL*/
                    $ARL = 'ARL';
                    $intrant_arl = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$ARL));

                    $INTRANT_ARL_ID = $intrant_arl['INTRANT_MEDICAUX_ID'];

                    $maladie = $this->Modele->getOne('maladies_intrant',array('INTRANT_MEDICAUX_ID'=>$INTRANT_ARL_ID));
                    //insert intervention
                    $array_intervention= array(
                      'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
                      'MALADIE_ID'=>$maladie['MALADIE_ID'],
                      'TELEPHONE'=>$TELEPHONE_USED
                    );
                    $INTERVENTION_ID = $this->Modele->insert_last_id('sms_distribution_intervention',$array_intervention);


                    //recuperation de la distribution précedente de l'intrant
                    $sql_arl_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                                        JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                                        WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_ARL_ID' AND dist.CODE_SENS_ID =3
                                        HAVING dt.QUANTITE_RESTANTE > 0";
                    $distribution_arl_detail = $this->Modele->getRequeteOne($sql_arl_detail);
                    //Mise de la derniere distribution
                    $qte_arl_utilise = $intrant_arl['NOMBRE_DOSE'];
                    $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_arl_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_arl_detail['QUANTITE_RESTANTE']-$qte_arl_utilise));
                    //Mise a jour de stock intervenant
                    $stock_arl_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_ARL_ID));
                    $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_arl_detail['STOCK_INTERVENANT_ID']),array('QUANTITE'=>$stock_arl_detail['QUANTITE']-$qte_arl_utilise));

                    //Insertion dans la table des distribution
                     $array_arl_detail = array(
                       'DISTRIBUTION_ID'=>$code_asc,
                       'RECEPTION_CODE'=>$distribution_arl_detail['RECEPTION_CODE'],
                       'INTRANT_ID'=>$INTRANT_ARL_ID,
                       'QUANTITE'=>$qte_arl_utilise,
                       'QUANTITE_RESTANTE'=>$qte_arl_utilise
                     );
                     $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_arl_detail);
                       //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
                     $array_intervention_detail = array(
                         'INTRANT_ID'=>$INTRANT_ARL_ID,
                         'QUANTITE'=>$qte_arl_utilise,
                         'INTERVENTION_ID'=>$INTERVENTION_ID
                       );
                     $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_detail);
                     //$message=$this->ret_message($intrant_arl['INTRANT_MEDICAUX_DESCR'],$qte_arl_utilise);
                       $message.=$qte_arl_utilise." ".$intrant_arl['INTRANT_MEDICAUX_DESCR'];
                       $comp_mess_det_i[]=$intrant_arl['INTRANT_MEDICAUX_DESCR'];
                       $comp_mess_det_q[]=$qte_arl_utilise;
                     //Notification
                     $this->send_notification($distribution_arl_detail['RECEPTION_CODE'],$bds,$cds,$qte_arl_utilise,$un_asc,$intrant_arl);

                }



         else{

             $ACT3 = 'ART-S';
           //  echo "Artesunate ".$medicament;
           $intrant_act3 = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$ACT3));

           //Derniere distribution des ACT vers les ASCs
           $INTRANT_ACT3_ID = $intrant_act3['INTRANT_MEDICAUX_ID'];
           //recuperation de la distribution précedente de l'intrant
           $sql_act3_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                               JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                               WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_ACT3_ID' AND dist.CODE_SENS_ID =3
                               HAVING dt.QUANTITE_RESTANTE > 0";
           $distribution_act3_detail = $this->Modele->getRequeteOne($sql_act3_detail);
           //Mise de la derniere distribution
           $qte_act3_utilise = $intrant_act3['NOMBRE_DOSE'];
           $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_act3_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_act3_detail['QUANTITE_RESTANTE']-$qte_act3_utilise));
           //Mise a jour de stock intervenant
           $stock_act3_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_ACT3_ID));
           $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_act3_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_act3_detail['QUANTITE']-$qte_act3_utilise));

           //Insertion dans la table des distribution
            $array_act3_detail = array(
              'DISTRIBUTION_ID'=>$code_asc,
              'RECEPTION_CODE'=>$distribution_act3_detail['RECEPTION_CODE'],
              'INTRANT_ID'=>$INTRANT_ACT3_ID,
              'QUANTITE'=>$qte_act3_utilise,
              'QUANTITE_RESTANTE'=>$qte_act3_utilise
            );
            $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_act3_detail);
            //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
            $array_intervention_act3 = array(
              'INTRANT_ID'=>$INTRANT_ACT3_ID,
              'QUANTITE'=>$qte_act3_utilise,
              'INTERVENTION_ID'=>$INTERVENTION_ID
            );
            $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_act3);
            $message.=$qte_act3_utilise." ".$intrant_act3['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_i[]=$intrant_act3['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_act3_utilise;
            //Notification
            $this->send_notification($distribution_act3_detail['RECEPTION_CODE'],$bds,$cds,$qte_act3_utilise,$un_asc,$intrant_act3);

         }
       }
      /* $array_distribution = array(
         'DISTRIBUTION_CODE'=>'DSTR-4-',
         'DISTRIBUTION_DATE'=>date('Y-m-d'),
         'CODE_SENS_ID'=>4,
         'DEMANDE_ID'=>NULL,
         'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
         'INTERVENANT_STRUCTURE_ID'=>$un_asc['INTERVENANT_STRUCTURE_ID']
       );
       $DISTRIBUTION_ID = $this->Modele->insert_last_id('stock_distribution',$array_distribution);
       $this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>'DSTR-4-'.$DISTRIBUTION_ID));
       $this->Modele->update('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$code_asc),array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID));*/


      }else if($selections_value == 3){
        /*SRO*/
          $SRO = 'SRO';
          $intrant_sro = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$SRO));

          $INTRANT_SRO_ID = $intrant_sro['INTRANT_MEDICAUX_ID'];
          $maladie = $this->Modele->getOne('maladies_intrant',array('INTRANT_MEDICAUX_ID'=>$INTRANT_SRO_ID));
          //insert intervention
          $array_intervention= array(
            'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
            'MALADIE_ID'=>$maladie['MALADIE_ID'],
            'TELEPHONE'=>$TELEPHONE_USED
          );
          $INTERVENTION_ID = $this->Modele->insert_last_id('sms_distribution_intervention',$array_intervention);
          //recuperation de la distribution précedente de l'intrant
          $sql_sro_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                              JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                              WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_SRO_ID' AND dist.CODE_SENS_ID =3
                              HAVING dt.QUANTITE_RESTANTE > 0";
          $distribution_sro_detail = $this->Modele->getRequeteOne($sql_sro_detail);
          //Mise de la derniere distribution
          $qte_sro_utilise = $intrant_sro['NOMBRE_DOSE'];
          $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_sro_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_sro_detail['QUANTITE_RESTANTE']-$qte_sro_utilise));
          //Mise a jour de stock intervenant
          $stock_sro_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_SRO_ID));
          $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_sro_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_sro_detail['QUANTITE']-$qte_sro_utilise));

          //Insertion dans la table des distribution
           $array_sro_detail = array(
             'DISTRIBUTION_ID'=>$code_asc,
             'RECEPTION_CODE'=>$distribution_sro_detail['RECEPTION_CODE'],
             'INTRANT_ID'=>$INTRANT_SRO_ID,
             'QUANTITE'=>$qte_sro_utilise,
             'QUANTITE_RESTANTE'=>$qte_sro_utilise
           );
           $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_sro_detail);
             //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
           $array_intervention_detail = array(
               'INTRANT_ID'=>$INTRANT_SRO_ID,
               'QUANTITE'=>$qte_sro_utilise,
               'INTERVENTION_ID'=>$INTERVENTION_ID
             );
           $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_detail);
           $message=$this->ret_message($intrant_sro['INTRANT_MEDICAUX_DESCR'],$qte_sro_utilise);
             $comp_mess_det_i[]=$intrant_sro['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_sro_utilise;
           //Notification
           $this->send_notification($distribution_sro_detail['RECEPTION_CODE'],$bds,$cds,$qte_sro_utilise,$un_asc,$intrant_sro);

      }else if($selections_value == 2){

        
        $formegalemic_of_amox=$array->results->traitement_amox->value;
        if ($formegalemic_of_amox==1) {
          /*AMOX*/
          $AMOX = 'AMOX-S';
        }else if ($formegalemic_of_amox==2) {
            /*AMOX*/
            $AMOX = 'AMOX-D';
        }
            $intrant_amox = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$AMOX));

          $INTRANT_AMOX_ID = $intrant_amox['INTRANT_MEDICAUX_ID'];
          $maladie = $this->Modele->getOne('maladies_intrant',array('INTRANT_MEDICAUX_ID'=>$INTRANT_AMOX_ID));
          //insert intervention
          $array_intervention= array(
            'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
            'MALADIE_ID'=>$maladie['MALADIE_ID'],
            'TELEPHONE'=>$TELEPHONE_USED
          );
          $INTERVENTION_ID = $this->Modele->insert_last_id('sms_distribution_intervention',$array_intervention);
          //recuperation de la distribution précedente de l'intrant
          $sql_amox_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                              JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                              WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_AMOX_ID' AND dist.CODE_SENS_ID =3
                              HAVING dt.QUANTITE_RESTANTE > 0";
          $distribution_amox_detail = $this->Modele->getRequeteOne($sql_amox_detail);
          //Mise de la derniere distribution
          $qte_amox_utilise = $intrant_amox['NOMBRE_DOSE'];
          $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_amox_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_amox_detail['QUANTITE_RESTANTE']-$qte_amox_utilise));
          //Mise a jour de stock intervenant
          $stock_amox_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_AMOX_ID));
          $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_amox_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_amox_detail['QUANTITE']-$qte_amox_utilise));

          //Insertion dans la table des distribution
           $array_amox_detail = array(
             'DISTRIBUTION_ID'=>$code_asc,
             'RECEPTION_CODE'=>$distribution_amox_detail['RECEPTION_CODE'],
             'INTRANT_ID'=>$INTRANT_AMOX_ID,
             'QUANTITE'=>$qte_amox_utilise,
             'QUANTITE_RESTANTE'=>$qte_amox_utilise
           );
           $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_amox_detail);
             //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
           $array_intervention_detail = array(
               'INTRANT_ID'=>$INTRANT_AMOX_ID,
               'QUANTITE'=>$qte_amox_utilise,
               'INTERVENTION_ID'=>$INTERVENTION_ID
             );
           $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_detail);

           $message=$this->ret_message($intrant_amox['INTRANT_MEDICAUX_DESCR'],$qte_amox_utilise);
             $comp_mess_det_i[]=$intrant_amox['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_amox_utilise;
           //Notification
           $this->send_notification($distribution_amox_detail['RECEPTION_CODE'],$bds,$cds,$qte_amox_utilise,$un_asc,$intrant_amox);

         

      }else if ($selections_value==4) {
        # code...
        //echo "Ikinini ZInc";
        //print_r($array->results->traitement_zinc->value);
          $medicament = $array->results->medicaments->value;


          if ($medicament == 1) {
            # code...
            $ZINC = 'ZINC-5';
          }else if ($medicament == 2) {
            # code...
            $ZINC = 'ZINC-10';
          }elseif ($medicament == 3) {
            # code...
            $ZINC = 'ZINC-20';
          }
          $intrant_zinc = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$ZINC));

          $INTRANT_ZINC_ID = $intrant_zinc['INTRANT_MEDICAUX_ID'];
          $maladie = $this->Modele->getOne('maladies_intrant',array('INTRANT_MEDICAUX_ID'=>$INTRANT_ZINC_ID));

          $array_intervention= array(
            'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
            'MALADIE_ID'=>$maladie['MALADIE_ID'],
            'TELEPHONE'=>$TELEPHONE_USED
          );
          $INTERVENTION_ID = $this->Modele->insert_last_id('sms_distribution_intervention',$array_intervention);

               
           if ($medicament == 1 || $medicament == 2) {
      # code...
            $CA_TRAITE = $array->results->traitement_zinc->value;
            if ($CA_TRAITE==1) {
              # code...
              $CAS_MAL_TRAITE==0;
            }
            if ($CA_TRAITE==2) {
              # code...
              $CAS_MAL_TRAITE==1;
            }
              $array_update_interv = array(
                
                'CAS_MAL_TRAITE'=>$CAS_MAL_TRAITE,
              );
              $this->Modele->update('sms_distribution_intervention',array('INTERVENTION_ID'=>$INTERVENTION_ID),$array_update_interv);
            }


            //recuperation de la distribution précedente de l'intrant
            $sql_zinc_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                                JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                                WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_ZINC_ID' AND dist.CODE_SENS_ID =3
                                HAVING dt.QUANTITE_RESTANTE > 0";
            $distribution_zinc_detail = $this->Modele->getRequeteOne($sql_zinc_detail);
            //Mise de la derniere distribution
            $qte_zinc_utilise = $intrant_zinc['NOMBRE_DOSE'];
            $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_zinc_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_zinc_detail['QUANTITE_RESTANTE']-$qte_zinc_utilise));
            //Mise a jour de stock intervenant
            $stock_zinc_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_ZINC_ID));
            $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_zinc_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_zinc_detail['QUANTITE']-$qte_zinc_utilise));

            //Insertion dans la table des distribution
             $array_zinc_detail = array(
               'DISTRIBUTION_ID'=>$code_asc,
               'RECEPTION_CODE'=>$distribution_zinc_detail['RECEPTION_CODE'],
               'INTRANT_ID'=>$INTRANT_ZINC_ID,
               'QUANTITE'=>$qte_zinc_utilise,
               'QUANTITE_RESTANTE'=>$qte_zinc_utilise
             );
             $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_zinc_detail);

             //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
             $array_intervention_zinc = array(
               'INTRANT_ID'=>$INTRANT_ZINC_ID,
               'QUANTITE'=>$qte_zinc_utilise,
               'INTERVENTION_ID'=>$INTERVENTION_ID
             );
             $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_zinc);

             $message=$this->ret_message($intrant_zinc['INTRANT_MEDICAUX_DESCR'],$qte_zinc_utilise);
             $comp_mess_det_i[]=$intrant_zinc['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_zinc_utilise;
             //Notification
             $this->send_notification($distribution_zinc_detail['RECEPTION_CODE'],$bds,$cds,$qte_zinc_utilise,$un_asc,$intrant_zinc);
    

      }else if ($selections_value==6) {
        //6. Boites de securité
        /*SEC*/
          $SEC = 'SEC';
          $intrant_sec = $this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_CODE'=>$SEC));

          $INTRANT_SEC_ID = $intrant_sec['INTRANT_MEDICAUX_ID'];
          $maladie = $this->Modele->getOne('maladies_intrant',array('INTRANT_MEDICAUX_ID'=>$INTRANT_SEC_ID));
          //insert intervention
          $array_intervention= array(
            'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
            'MALADIE_ID'=>$maladie['MALADIE_ID'],
            'TELEPHONE'=>$TELEPHONE_USED
          );
          $INTERVENTION_ID = $this->Modele->insert_last_id('sms_distribution_intervention',$array_intervention);
          //recuperation de la distribution précedente de l'intrant
          $sql_sec_detail = "SELECT dt.* FROM stock_distribution_intrant_detail AS dt
                              JOIN stock_distribution AS dist ON dist.DISTRIBUTION_ID = dt.DISTRIBUTION_ID
                              WHERE dist.INTERVENANT_RH_ID = $INTERVENANT_RH_ID AND dt.INTRANT_ID = '$INTRANT_SEC_ID' AND dist.CODE_SENS_ID =3
                              HAVING dt.QUANTITE_RESTANTE > 0";
          $distribution_sec_detail = $this->Modele->getRequeteOne($sql_sec_detail);
          //Mise de la derniere distribution
          $qte_sec_utilise = $intrant_sec['NOMBRE_DOSE'];
          $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$distribution_sec_detail['DETAIL_ID']),array('QUANTITE_RESTANTE'=>$distribution_sec_detail['QUANTITE_RESTANTE']-$qte_sec_utilise));
          //Mise a jour de stock intervenant
          $stock_sec_detail = $this->Modele->getOne('stock_intervenat',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,'INTRANT_ID'=>$INTRANT_SEC_ID));

          $this->Modele->update('stock_intervenat',array('STOCK_INTERVENANT_ID'=>$stock_sec_detail['STOCK_INTERVENANT_ID']),array('DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),'QUANTITE'=>$stock_sec_detail['QUANTITE']-$qte_sec_utilise));

          //Insertion dans la table des distribution
           $array_sec_detail = array(
             'DISTRIBUTION_ID'=>$code_asc,
             'RECEPTION_CODE'=>$distribution_sec_detail['RECEPTION_CODE'],
             'INTRANT_ID'=>$INTRANT_SEC_ID,
             'QUANTITE'=>$qte_sec_utilise,
             'QUANTITE_RESTANTE'=>$qte_sec_utilise
           );
           $this->Modele->insert_last_id('stock_distribution_intrant_detail',$array_sec_detail);
             //ENREGISTREMENT DES DETAILS DE L'INTERVENTION
           $array_intervention_detail = array(
               'INTRANT_ID'=>$INTRANT_SEC_ID,
               'QUANTITE'=>$qte_sec_utilise,
               'INTERVENTION_ID'=>$INTERVENTION_ID
             );
           $this->Modele->insert_last_id('sms_distribution_intervention_detail',$array_intervention_detail);
           $message=$this->ret_message($intrant_sec['INTRANT_MEDICAUX_DESCR'],$qte_sec_utilise);
             $comp_mess_det_i[]=$intrant_sec['INTRANT_MEDICAUX_DESCR'];
             $comp_mess_det_q[]=$qte_sec_utilise;
           //Notification
          $this->send_notification($distribution_sec_detail['RECEPTION_CODE'],$bds,$cds,$qte_sec_utilise,$un_asc,$intrant_sec);
        
      }

      //Inserttion dans la table distribution et mise a jour distribution_detail
      $array_distribution = array(
        'DISTRIBUTION_CODE'=>'DSTR-4-',
        'DISTRIBUTION_DATE'=>date('Y-m-d'),
        'CODE_SENS_ID'=>4,
        'DEMANDE_ID'=>NULL,
        'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID,
        'INTERVENANT_STRUCTURE_ID'=>$un_asc['INTERVENANT_STRUCTURE_ID']
      );
      $DISTRIBUTION_ID = $this->Modele->insert_last_id('stock_distribution',$array_distribution);
      $this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>'DSTR-4-'.$DISTRIBUTION_ID));

      $this->Modele->update('stock_distribution_intrant_detail',array('DISTRIBUTION_ID'=>$code_asc),array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID));

    }else{
     $message = "Muradutunga kode <<".$code_asc.">> ntibaho!";
    }
    $tabl_comp_mes="<table><tr><th>INTRANT</th><th>QUANTITE</th></tr>";
    foreach ($comp_mess_det_i as $key1 => $value1) {
      # code...
      foreach ($comp_mess_det_q as $key2 => $value2) {
        # code...
        $tabl_comp_mes.="<tr><td>".$value1."</td><td>".$value2."</td></tr>";
      }
    }
    $tabl_comp_mes."</table>";

      $get_asc_cds_yiwe=$this->Modele->getOne('cds_asc',array('INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID));
      $sms_distribution_intrant = array(
        
        'MSG_REPONSE' => $message,
        'SENT_DATA' =>$array->results->selections->value ,
        'TELEPHONE_USED' => $TELEPHONE_USED,
        'COMPO_MESSAGE'=>$tabl_comp_mes,
        'CODE_ASC'=>$code_asc,
        'INTERVENANT_STRUCTURE_ID'=>$get_asc_cds_yiwe['CDS_ID']
        
      );
      $this->Modele->create('sms_distribution_intrant',$sms_distribution_intrant);
    echo $message;
  }

  public function send_notification($RECEPTION_CODE,$bds,$cds,$QUANTITE,$un_asc,$intrant){
     $camebu=$this->Modele->getRequeteOne('SELECT EMAIL FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');
    $INTRANT_ID = $intrant['INTRANT_MEDICAUX_ID'];
    $recepteur_intrant= "(".$un_asc['NOM']." ".$un_asc['PRENOM'].")";

    $cc_emails[] = $cds['EMAIL'];
    $cc_emails[] = $bds['EMAIL'];
    $cc_emails[] = $camebu['EMAIL'];//email camebu

    $sql = "SELECT p.*,rc.PTF_ID,rcdl.MODE_RECEPTION_ID,rcdl.* FROM rc_reception AS rc
            JOIN rc_reception_intrant_detail AS rcdl ON rc.RECEPTION_ID = rcdl.RECEPTION_ID
            JOIN intervenants_structure AS p ON p.INTERVENANT_STRUCTURE_ID = rc.PTF_ID
            WHERE rc.RECEPTION_CODE = '$RECEPTION_CODE'
            AND rcdl.INTRANT_ID = $INTRANT_ID";
    $info_reception_ptf = $this->Modele->getRequeteOne($sql);
    //$cc_emails[] = $bds['EMAIL'];

    $recepteur_intrant .= " appartenant à ".$cds['INTERVENANT_STRUCTURE_DESCR']."/".$bds['INTERVENANT_STRUCTURE_DESCR'].".Merci";
    $message = "Cher <b>".$info_reception_ptf['INTERVENANT_STRUCTURE_DESCR']."</b>, Une quantité <b>".$QUANTITE."</b> sur le lot <b>".$info_reception_ptf['NUMERO_LOT']."</b>  de l'intrant <b>".$intrant['INTRANT_MEDICAUX_DESCR']."</b> a été distribué(s) à la population par ".$recepteur_intrant;
    $subjet = "Confirmation de distribution d'un intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." du lot ".$info_reception_ptf['NUMERO_LOT']." à la population";
    $emailTo = $info_reception_ptf['EMAIL'];

    $array_notifications = array(
      'MESSAGE'=>$message,
      'PTF_ID'=>$info_reception_ptf['PTF_ID'],
      'EMAIL_NOTIFIE'=>$info_reception_ptf['EMAIL'],
      'INTRANT_ID'=>$INTRANT_ID,
      //'INTRANT_ID'=>$QUANTITE
      'IS_DISTRIBUTION'=>1
    );
    $this->Modele->insert_last_id('sms_mouvement_stock',$array_notifications);
  $this->notifications->send_mail($emailTo, $subjet, $cc_emails, $message, array());
  }
  public function ret_message($intrant_nom='',$quantite="",$intervenants_rh_id="")
  {
    # code...
    $message="Vous venez de distribuer ".$quantite." ".$intrant_nom;
    return $message;
  }



  public function liste(){

    $data['title']="Intrans - distribution ASC";
    $this->load->view('SMS_Distribution_View',$data);
    //$this->layout($data);
  }

public function listing()
 {
          
      $get_type_stru=$this->Modele->getRequeteOne('SELECT t.CODE_STRUCTURE FROM `intervenants_structure` i  JOIN type_intervenants_structures t ON i.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_STRUCTURE_ID`='.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'));
      $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
      $var_search=str_replace("'", "\'", $var_search);  
      $query_principal='SELECT `MSG_REPONSE`,`TELEPHONE_USED`,`DATE_INSERTION`,`COMPO_MESSAGE`,`CODE_ASC` FROM `sms_distribution_intrant` s LEFT JOIN intervenants_structure i ON s.`INTERVENANT_STRUCTURE_ID`=i.INTERVENANT_STRUCTURE_ID';
   // echo $query_principal;
          $group="";
          $critaire="";

          if ($get_type_stru['CODE_STRUCTURE']=="BDS") {
            # code...
            $critaire=" WHERE s.`INTERVENANT_STRUCTURE_ID` IN ( SELECT bds_cds.CDS_ID FROM bds_cds WHERE bds_cds.BDS_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').") OR s.`INTERVENANT_STRUCTURE_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')."";
          }
          if ($get_type_stru['CODE_STRUCTURE']=="CDS") {
            # code...get_type_stru
            $critaire=" WHERE s.`INTERVENANT_STRUCTURE_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
          }
      $limit='LIMIT 0,10';
      if($_POST['length'] != -1){
        $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
      }
      $order_by='';
      if($_POST['order']['0']['column']!=0){
        $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY DATE_INSERTION DESC';
      }

      $search = !empty($_POST['search']['value']) ? (" AND (MSG_REPONSE LIKE '%$var_search%' OR TELEPHONE_USED LIKE '%$var_search%' OR DATE_INSERTION LIKE '%$var_search%')") : '';


      
      $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
      $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

      $fetch_intrants = $this->Modele->datatable($query_secondaire);
      //print_r($fetch_intrants);
      $u=0;
      $data = array();
  
      foreach ($fetch_intrants as $key) {
         $asc="";
          if (!empty($key->CODE_ASC)) {
            # code...
          
           $get_asc=$this->Modele->getRequeteOne("SELECT `NOM` nom FROM `intervenants_rh` WHERE `TELEPHONE1` LIKE '".$key->CODE_ASC."' OR `TELEPHONE2` LIKE '".$key->CODE_ASC."' OR `INTERVENANT_RH_CODE` LIKE '".$key->CODE_ASC."'");
           $asc=$get_asc['nom']."(".$key->CODE_ASC.")";
         }
           $stock_seuil=array();
           $stock_seuil[]=$asc;
           $stock_seuil[]=$key->TELEPHONE_USED;
           $stock_seuil[]=$key->MSG_REPONSE;
           $stock_seuil[]=$key->COMPO_MESSAGE;
           $stock_seuil[]=$key->DATE_INSERTION;
           $data[] = $stock_seuil;

    }
 
    $output = array(
     "draw" => intval($_POST['draw']),
     "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
     "recordsFiltered" => $this->Modele->filtrer($query_filter),
     "data" => $data
    );

     echo json_encode($output);
 }  

}
