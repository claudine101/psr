<div class="row">
  <legend>
    <?= $title;?>

    <div class="pull-right">
      <a href="<?= base_url('administration/Users/ajouter'); ?>" class="btn btn-primary btn-sm pull-right">
        <i class="fa fa-plus"></i>
        Ajouter
      </a>
    </div>
  </legend>
      
    </div>
    <div class="panel-body">
  
      <div class="card"> 

           <?=  $this->session->flashdata('message');?>
          
             
            <?= $this->table->generate($donnees_users); ?> 
                       
                </div>
    </div>

    <div class="panel-footer">
      
    </div>
  </div>
</div>
     