<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}
.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">


              <span style="margin-right: 15px">
                <div class="col-sm-3" style="float:right;">
                  <a href="<?=base_url('administration/Intervenants/')?>" class='btn btn-outline-primary float-right'>
                    <i class="nav-icon fas fa-list"></i>
                    Liste
                  </a>
                </div>

              </span>

            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">

              <form name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Users/update'); ?>">
                <div class="row">
                  <input type="hidden" class="form-control" name="USER_ID" value="<?=$get_user['USER_ID']?>" >
                  <input type="hidden" class="form-control" name="INTERVENANT_RH_ID" value="<?=$get_user['INTERVENANT_RH_ID']?>" >
                  <div class="col-md-6 offset-md-3">
                    <label for="USER_NAME">Username:</label>
                    <input type="text" name="USER_NAME" value="<?=$get_user['USER_NAME']?>" class="form-control" id="USER_NAME" >
                    <?php echo form_error('USER_NAME', '<div class="text-danger">', '</div>'); ?> 
                  </div>
                  <div class="col-md-6 offset-md-3">
                    <label for="LName">Email:</label>
                    <input type="text" name="EMAIL" value="<?=$get_user['EMAIL']?>" class="form-control" id="EMAIL">
                    <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6 offset-md-3">
                    <label for="IS_ACTIVE">Active:</label>
                    <select class="form-control selectpicker" data-live-search="true"  name="IS_ACTIVE" >

                      <option value=''>Séléctionner</option>
                      <?php 

                      if ($get_user['IS_ACTIVE'] ==1) 
                        { ?>
                          <option value='1' selected>Oui</option>
                          <option value='0'>Non</option>
                          <?php } 
                          else if ($get_user['IS_ACTIVE'] ==0)
                           {  ?>

                             <option value='1'>Oui</option>
                             <option value='0' selected>Non</option>              
                             <?php } 
                             else 
                               {  ?>

                                <option value='1'>Oui</option>
                                <option value='0'>Non</option>  

                                <?php }?>
                              </select>
                              <?php echo form_error('IS_ACTIVE', '<div class="text-danger">', '</div>'); ?> 
                            </div>

                            <div class="col-md-6 offset-md-3">
                              <label for="PROFIL_ID">Profil:</label>
                              <select class="form-control selectpicker" data-live-search="true"  name="PROFIL_ID" >
                                <?php 
                                foreach($profils as $key_profil)
                                { 
                                  if ($key_profil['PROFIL_ID'] == $get_user['PROFIL_ID']) 
                                  { 
                                   echo "<option value='".$key_profil['PROFIL_ID']."' selected>".$key_profil['PROFIL_DESCR']."</option>";
                                 } 
                                 else
                                 {
                                  echo "<option value='".$key_profil['PROFIL_ID']."' >".$key_profil['PROFIL_DESCR']."</option>"; 
                                }
                              }
                              ?>
                            </select>
                            <?php echo form_error('PROFIL_ID', '<div class="text-danger">', '</div>'); ?>
                          </div>
                        </div>
                        <div>
                         <div class="col-md-6 col-sm-6 col-xs-6 offset-md-3">
                          <button type="submit" class="btn btn-primary form-control" style="margin-top: 20px;">Modifier
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </section>
            <!-- /.content -->
          </div>

        </div>
        <!-- ./wrapper -->
        <?php include VIEWPATH.'templates/footer.php'; ?>
      </body>
      </html>