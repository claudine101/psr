<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">


              <!-- <span style="margin-right: 15px">
                <div class="col-sm-6" style="float:right;">
                  <a href="<?=base_url('administration/Affectation_Users/index')?>" class='btn btn-primary float-right'>
                    <i class="nav-icon fas fa-plus"></i>
                    Nouveau
                  </a>
                </div>

              </span> -->

            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body" style="overflow-x: auto;" >
              <div style="padding-top: 5px;" class="col-md-12">
                <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                  <thead>
                    <tr>
                      <!-- <th>#</th> -->
                      <th>UTILISATEUR</th>
                      <th>IDENTIFIANT</th>
                      <th>STRUCTURE</th>
                      <th>PROFIL</th>
                      <th>DATE</th>
                      <th>STATUS</th>
                      <th>OPTION</th>
                    </tr>
                  </thead>

                </table>


              </div>
              

            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>

  </div>
  <!-- ./wrapper -->
  <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>

<script>

  var table;

  $(document).ready(function(){
    getList();
  });
  function getList()
  {

   var row_count ="1000000";
   table=$("#mytable").DataTable({
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "oreder":[[ 0, 'desc' ]],
    "ajax":{
      url:"<?=base_url()?>administration/Liste_Activation_Compte/getInfo",
      type:"POST"
    },
    lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
    "columnDefs":[{
      "targets":[],
      "orderable":false
    }],

    dom: 'Bfrtlip',
    buttons: [
    'copy', 'csv', 'excel', 'pdf', 'print'
    ],
    language: {
      "sProcessing":     "Traitement en cours...",
      "sSearch":         "Rechercher&nbsp;:",
      "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
      "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
      "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
      "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
      "sInfoPostFix":    "",
      "sLoadingRecords": "Chargement en cours...",
      "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
      "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
      "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
      },
      "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
      }
    }

  });

 }


 function traiter_status(USER_ID,IS_ACTIVE)
 {
  // alert(USER_ID+'/'+IS_ACTIVE);
  $('#compte_modal').modal('show');
  document.getElementById('USER_ID').value=USER_ID;
  document.getElementById('IS_ACTIVE').value=IS_ACTIVE;
  if (IS_ACTIVE==1) 
  {
    $('#statut').text('Voulez-vous activer le compte?');
     $('.modal-title').text('Activation du compte');
     $('#btn_status').text('Activer');

  }
  if (IS_ACTIVE==0) 
  {
    $('#statut').text('Voulez-vous désactiver le compte?');
     $('.modal-title').text('Désactivation du compte');
     $('#btn_status').text('Désactiver');
  }
  
 
  
}

function traiter()
{
  var USER_ID=$('#USER_ID').val();
  var IS_ACTIVE=$('#IS_ACTIVE').val();

  // if (USER_ID>0) 
  // {
    $.post("<?=base_url('administration/Liste_Activation_Compte/traiter_user')?>",
    {
      USER_ID:USER_ID,
      IS_ACTIVE:IS_ACTIVE
    },
    function(data)
    {
      if (data) 
      {
      
        setTimeout(function(){ 
          
            $('#compte_modal').modal('hide');
          table.ajax.reload(null,false);
          alert_notify('success','Traitement du compte','Le traitement a été fait avec succès','1');
          }, 500);
      }

    });
  // }
}



</script>



<div class="modal fade" id="compte_modal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"></h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="traiter_st">
          <input type="hidden" id="USER_ID">
          <input type="hidden" id="IS_ACTIVE">
          <center><label id="statut"></label></center>
        </form>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Quitter</button>
        <button type="button" id="btn_status" onclick="traiter()" class="btn btn-primary">Confirmer</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
