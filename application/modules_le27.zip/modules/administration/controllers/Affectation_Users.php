<?php
/**
* NSHIMIRIMANA REVERIEN
DATE :14.04.2021
DATE FIN:15.04.2021
*/
class Affectation_Users extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function  index()
	{
		$data['title']="Nouveau utilisateur";

		$data['types']=$this->Modele->getRequete('SELECT `TYPE_INTERVENANT_STRUCTURE_ID`, `TYPE_INTERVENANT_STRUCTURE_DESCR`,`CODE_STRUCTURE` FROM `type_intervenants_structures` WHERE `CODE_STRUCTURE` <>"ASC" ');

		$data['profile']=$this->Modele->getRequete("SELECT `PROFIL_ID`, `PROFIL_DESCR` FROM `admin_profil` WHERE 1 ORDER BY PROFIL_DESCR ASC");


		$data['admin_interv_sexe']=$this->Modele->getList('sexe');
		$this->load->view('Affectation_Users_view',$data);
	}

	

	




	



	








	function liste($USER_ID=0)
	{
		$data['title']="Liste des utilisateurs";
		$data['USER_ID']=$USER_ID;
		$this->load->view('Affectation_Users_liste_view',$data);

	}

	function getInfo()
	{


		$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		$var_search=str_replace("'", "\'", $var_search);  

		$query_principal="SELECT admin.USER_ID,admin.EMAIL,CONCAT(rh.NOM,' ',rh.PRENOM,' [',rh.TELEPHONE1,']') INTERVENA,intv.INTERVENANT_STRUCTURE_DESCR,admin.IS_ACTIVE,profil.PROFIL_DESCR FROM admin_users admin JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=admin.INTERVENANT_RH_ID JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=rh.INTERVENANT_STRUCTURE_ID JOIN admin_profil profil ON profil.PROFIL_ID=admin.PROFIL_ID WHERE admin.IS_ACTIVE=1";


		$group="";
		$critaire="";

		$limit='LIMIT 0,10';
		if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$order_by='';
		if($_POST['order']['0']['column']!=0){
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY admin.USER_ID DESC';
		}

		
		$search = !empty($_POST['search']['value']) ? (" AND (CONCAT(rh.NOM,' ',rh.PRENOM,' [',rh.TELEPHONE1,']') LIKE '%$var_search%' OR admin.EMAIL LIKE '%$var_search%' OR intv.INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR profil.PROFIL_DESCR LIKE '%$var_search%' )") : '';



		$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
		$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

		$fetch_data = $this->Modele->datatable($query_secondaire);
		$u=0;
		$data = array();


		foreach ($fetch_data as $row) {

			$u++;
			$sub_array = array();
			$sub_array[] =  $u;
			$sub_array[]=$row->INTERVENA;
			$sub_array[]=$row->EMAIL;
			// $sub_array[]=$row->USER_NAME;
			$sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
			$sub_array[]=$row->PROFIL_DESCR;


			$data[] = $sub_array;

		}

		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
			"recordsFiltered" => $this->Modele->filtrer($query_filter),
			"data" => $data
		);
		echo json_encode($output);

	}


	function changer()
	{
		$USER_ID=$this->input->post('USER_ID');
		$IS_ACTIVE=$this->input->post('IS_ACTIVE');

		$this->Modele->update('admin_users',array('USER_ID'=>$USER_ID),array('IS_ACTIVE'=>$IS_ACTIVE));
		echo json_encode(array('status'=>true));
		
	}




	

}