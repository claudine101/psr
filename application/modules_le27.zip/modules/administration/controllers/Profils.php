<?php
/**
* NIZIGIYIMANA Cédric
* début : 17/03/2021
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Profils extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
  }
  function index()
  {
    $data['error']='';
    $this->listing();
  }
  function nouveau()
  {
    $data['error']='';
    $data['title'] = 'Nouveau profil';
    $this->load->view('Profils_add_view',$data);
  }

  function listing()
  {
    $sql="SELECT * FROM admin_profil";
    // $table="maladies";
    $get = $this->Modele->getRequete($sql);
    $data_array = array();
    foreach ($get as $key) {
      $sub_array = array();
      $sub_array[] = $key['PROFIL_DESCR'];
      // $sub_array[] = $key['PROFIL_CODE'];
      $sub_array[] = $this->get_icon($key['DASHBOARD']);
      $sub_array[] = $this->get_icon($key['DB_INTRANT']);
      $sub_array[] = $this->get_icon($key['DB_DECES']);
      $sub_array[] = $this->get_icon($key['DB_DEMANDE']);
      $sub_array[] = $this->get_icon($key['DB_DOSAGE']);
      $sub_array[] = $this->get_icon($key['DB_MALADIE']);
      $sub_array[] = $this->get_icon($key['DB_STOCK']);
      $sub_array[] = $this->get_icon($key['RAPPORT']);
      $sub_array[] = $this->get_icon($key['RA_STOCK']);
      $sub_array[] = $this->get_icon($key['RA_CONSOMMATION']);
      $sub_array[] = $this->get_icon($key['RA_DISTRIBUTION']);
      $sub_array[] = $this->get_icon($key['SIG']);
      $sub_array[] = $this->get_icon($key['SIG_CENTRE_SITUATION']);
      $sub_array[] = $this->get_icon($key['SIG_INTERVENANT_STUCTURE']);
      $sub_array[] = $this->get_icon($key['SIG_ALERTE']);
      $sub_array[] = $this->get_icon($key['DONNEES']);
      $sub_array[] = $this->get_icon($key['DON_STOCK']);
      $sub_array[] = $this->get_icon($key['DON_DEMANDES']);
      $sub_array[] = $this->get_icon($key['DON_DISTRIBUTION']);
      $sub_array[] = $this->get_icon($key['IHM']);
      $sub_array[] = $this->get_icon($key['IHM_DEMANDE']);
      $sub_array[] = $this->get_icon($key['IHM_DISTRIBUTION']);
      $sub_array[] = $this->get_icon($key['IHM_INTRANTS_ICCM']);
      $sub_array[] = $this->get_icon($key['IHM_PTF']);
      $sub_array[] = $this->get_icon($key['IHM_MALADIE']);
      $sub_array[] = $this->get_icon($key['IHM_INTERVENANT']);
      $sub_array[] = $this->get_icon($key['IHM_STUCTURE_SANITAIRE']);
      $sub_array[] = $this->get_icon($key['RECEPTION']);
      $sub_array[] = $this->get_icon($key['DEMANDES']);
      $sub_array[] = $this->get_icon($key['ADMINISTRATION']);
      $sub_array[] = $this->get_icon($key['PARAMETRAGE']);

      $sub_array['OPTIONS'] = '<div class="dropdown ">
      <a class="btn btn-outline-primary btn-sm dropdown-toggle" data-toggle="dropdown" >
      <i class="fa fa-cog"></i>
      Action
      <span class="caret"></span></a>
      <ul class="dropdown-menu dropdown-menu-left">
      ';
      $sub_array['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
      data-target='#mydelete" . $key['PROFIL_ID'] . "'>&nbsp;&nbsp;<font color='red'>Supprimer</font></a></li>";
      $sub_array['OPTIONS'] .= "<li>&nbsp;&nbsp;<a class='btn-md' href='" . base_url('administration/Profils/getOne/'. $key['PROFIL_ID']) . "'>Modifier</a></li>";
      $sub_array['OPTIONS'] .= " </ul>
      </div>
      <div class='modal fade' id='mydelete" . $key['PROFIL_ID'] . "'>
      <div class='modal-dialog'>
      <div class='modal-content'>

      <div class='modal-body'>
      <center><h5><strong>Voulez-vous supprimer ce profil</strong> : <b style:'background-color:prink';><i style='color:green;'>" . $key['PROFIL_DESCR']."</i></b>?</h5></center>
      </div>

      <div class='modal-footer'>
      <a class='btn btn-danger btn-md' href='" . base_url('administration/Profils/delete/'. $key['PROFIL_ID']) . "'>Supprimer</a>
      <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
      </div>

      </div>
      </div>
      </div></form>";


      $data_array[] = $sub_array;
    }

    $template = array(
      'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
      'table_close' => '</table>'
    );
    $this->table->set_template($template);
    $this->table->set_heading(array('Description','Tableau de bord','TB Intrants','TB Décès','TB Demandes','TB Dosages incohérants','TB Maladies','TB Stock','Rapport','Stock (Rapport)','Consommantion (Rapport)','Distribution (Rapport)','SIG','Centre de situation (SIG)','BDS-CDS-ASC (SIG)','SIG Alertes','Données','Stock (Données)','Demandes (Données)','Distributions (Données)','IHM',' Demandes (IHM)',' Distributions (IHM)','Intrants ICCM (IHM)','PTF (IHM)','Maladies (IHM)','Intervenants (IHM)','Structures sanitaires (IHM)','Réception','Demandes','Administration','Paramétrages','ACTIONS'));
    $data['data']=$data_array;
    $data['title'] = "Matrice des droits";
    $this->load->view('Profils_list_view',$data);

  }
  public function add(){
    $this->form_validation->set_rules('PROFIL_CODE', ' Code ', 'trim|required|is_unique[admin_profil.PROFIL_CODE]',array('required'=>'Ce champs est obligatoire','is_unique'=>'Ce code est déjà utilisé'));
    $this->form_validation->set_rules('PROFIL_DESCR','', 'trim|required|is_unique[admin_profil.PROFIL_DESCR]',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>','is_unique'=>'Cette fonctionnalité existe déjà'));
    if ($this->form_validation->run() == FALSE)
    {
      $this->nouveau();
    } else {
      $DASHBOARD = ($this->input->post('DASHBOARD')) ? 1 : 0 ;
      $DB_INTRANT = ($this->input->post('DB_INTRANT')) ? 1 : 0 ;
      $DB_DECES = ($this->input->post('DB_DECES')) ? 1 : 0 ;
      $DB_MALADIE = ($this->input->post('DB_MALADIE')) ? 1 : 0 ;
      $DB_STOCK = ($this->input->post('DB_STOCK')) ? 1 : 0 ;
      $DB_DEMANDE = ($this->input->post('DB_DEMANDE')) ? 1 : 0 ;
      $DB_DOSAGE = ($this->input->post('DB_DOSAGE')) ? 1 : 0 ;
      $RAPPORT = ($this->input->post('RAPPORT')) ? 1 : 0 ;
      $RA_STOCK = ($this->input->post('RA_STOCK')) ? 1 : 0 ;
      $RA_CONSOMMATION = ($this->input->post('RA_CONSOMMATION')) ? 1 : 0 ;
      $RA_DISTRIBUTION = ($this->input->post('RA_DISTRIBUTION')) ? 1 : 0 ;
      $SIG = ($this->input->post('SIG')) ? 1 : 0 ;
      $SIG_CENTRE_SITUATION = ($this->input->post('SIG_CENTRE_SITUATION')) ? 1 : 0 ;
      $SIG_INTERVENANT_STUCTURE = ($this->input->post('SIG_INTERVENANT_STUCTURE')) ? 1 : 0 ;
      $SIG_ALERTE = ($this->input->post('SIG_ALERTE')) ? 1 : 0 ;
      $DONNEES = ($this->input->post('DONNEES')) ? 1 : 0 ;
      $DON_STOCK = ($this->input->post('DON_STOCK')) ? 1 : 0 ;
      $DON_DEMANDES = ($this->input->post('DON_DEMANDES')) ? 1 : 0 ;
      $DON_DISTRIBUTION = ($this->input->post('DON_DISTRIBUTION')) ? 1 : 0 ;
      $IHM = ($this->input->post('IHM')) ? 1 : 0 ;
      $IHM_DEMANDE = ($this->input->post('IHM_DEMANDE')) ? 1 : 0 ;
      $IHM_DISTRIBUTION = ($this->input->post('IHM_DISTRIBUTION')) ? 1 : 0 ;
      $IHM_INTRANTS_ICCM = ($this->input->post('IHM_INTRANTS_ICCM')) ? 1 : 0 ;
      $IHM_PTF = ($this->input->post('IHM_PTF')) ? 1 : 0 ;
      $IHM_MALADIE = ($this->input->post('IHM_MALADIE')) ? 1 : 0 ;
      $IHM_INTERVENANT = ($this->input->post('IHM_INTERVENANT')) ? 1 : 0 ;
      $IHM_STUCTURE_SANITAIRE = ($this->input->post('IHM_STUCTURE_SANITAIRE')) ? 1 : 0 ;
      $RECEPTION = ($this->input->post('RECEPTION')) ? 1 : 0 ;
      $ADMINISTRATION = ($this->input->post('ADMINISTRATION')) ? 1 : 0 ;
      $PARAMETRAGE = ($this->input->post('PARAMETRAGE')) ? 1 : 0 ;
      $DEMANDES = ($this->input->post('DEMANDES')) ? 1 : 0 ;
      $data = array(
        'PROFIL_CODE'=>$this->input->post('PROFIL_CODE'),
        'PROFIL_DESCR'=>$this->input->post('PROFIL_DESCR'),
        'DASHBOARD'=>$DASHBOARD,
        'DB_INTRANT'=>$DB_INTRANT,
        'DB_DECES'=>$DB_DECES,
        'DB_DEMANDE'=>$DB_DEMANDE,
        'DB_DOSAGE'=>$DB_DOSAGE,
        'DB_MALADIE'=>$DB_MALADIE,
        'DB_STOCK'=>$DB_STOCK,
        'RAPPORT'=>$RAPPORT,
        'RA_STOCK'=>$RA_STOCK,
        'RA_CONSOMMATION'=>$RA_CONSOMMATION,
        'RA_DISTRIBUTION'=>$RA_DISTRIBUTION,
        'SIG'=>$SIG,
        'SIG_CENTRE_SITUATION'=>$SIG_CENTRE_SITUATION,
        'SIG_INTERVENANT_STUCTURE'=>$SIG_INTERVENANT_STUCTURE,
        'SIG_ALERTE'=>$SIG_ALERTE,
        'DONNEES'=>$DONNEES,
        'DON_STOCK'=>$DON_STOCK,
        'DON_DEMANDES'=>$DON_DEMANDES,
        'DON_DISTRIBUTION'=>$DON_DISTRIBUTION,
        'IHM' => $IHM,
        'IHM_DEMANDE' => $IHM_DEMANDE,
        'IHM_DISTRIBUTION' => $IHM_DISTRIBUTION,
        'IHM_DISTRIBUTION' => $IHM_DISTRIBUTION,
        'IHM_PTF' => $IHM_PTF,
        'IHM_MALADIE' => $IHM_MALADIE,
        'IHM_INTERVENANT' => $IHM_INTERVENANT,
        'IHM_STUCTURE_SANITAIRE' => $IHM_STUCTURE_SANITAIRE,
        'RECEPTION' => $RECEPTION,
        'DEMANDES' => $DEMANDES,
        'ADMINISTRATION' => $ADMINISTRATION,
        'PARAMETRAGE' => $PARAMETRAGE,
      );
      $this->Modele->create('admin_profil',$data);
      $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement est fait avec succès".'</div>';
      $this->session->set_flashdata($data);
      redirect(base_url('administration/Profils/listing'));
    }
  }
  public function check_code()
  {
    $id = $this->input->post('PROFIL_ID');
    $code = $this->input->post('PROFIL_CODE');
    if (empty($code))
    {
      $this->form_validation->set_message('check_code', 'Ce champ est obligatoire');
      return FALSE;
    } else {
      $get = $this->Modele->getRequeteOne('SELECT PROFIL_ID FROM admin_profil WHERE PROFIL_CODE = "'.$code.'" AND PROFIL_ID != '.$id.' ');
      if (!empty($get)) {
        $this->form_validation->set_message('check_code', "Ce code existe déjà");
        return FALSE;
      }else{
        return TRUE;
      }  
    }
  }
  public function check_fonc()
  {
    $id = $this->input->post('PROFIL_ID');
    $fonc = $this->input->post('PROFIL_DESCR');
    if (empty($fonc))
    {
      $this->form_validation->set_message('check_fonc', 'Ce champ est obligatoire');
      return FALSE;
    } else {
      $get = $this->Modele->getRequeteOne('SELECT PROFIL_ID FROM admin_profil WHERE PROFIL_DESCR = "'.$fonc.'" AND PROFIL_ID != '.$id.' ');
      if (!empty($get)) {
        $this->form_validation->set_message('check_fonc', "Cette fonctionnalité existe déjà");
        return FALSE;
      }else{
        return TRUE;
      }  
    }
  }

  public function update()
  {
    $id=$this->input->post('PROFIL_ID');
    $this->form_validation->set_rules('PROFIL_CODE','', 'callback_check_code');
    $this->form_validation->set_rules('PROFIL_DESCR','', 'callback_check_fonc');

    if ($this->form_validation->run() == FALSE){
      $data['data']=$this->Modele->getOne('admin_profil',array('PROFIL_ID'=>$id));
      $this->getOne($id);
    } else {
      $DASHBOARD = ($this->input->post('DASHBOARD')) ? 1 : 0 ;
      $DB_INTRANT = ($this->input->post('DB_INTRANT')) ? 1 : 0 ;
      $DB_DECES = ($this->input->post('DB_DECES')) ? 1 : 0 ;
      $DB_MALADIE = ($this->input->post('DB_MALADIE')) ? 1 : 0 ;
      $DB_STOCK = ($this->input->post('DB_STOCK')) ? 1 : 0 ;
      $DB_DEMANDE = ($this->input->post('DB_DEMANDE')) ? 1 : 0 ;
      $DB_DOSAGE = ($this->input->post('DB_DOSAGE')) ? 1 : 0 ;
      $RAPPORT = ($this->input->post('RAPPORT')) ? 1 : 0 ;
      $RA_STOCK = ($this->input->post('RA_STOCK')) ? 1 : 0 ;
      $RA_CONSOMMATION = ($this->input->post('RA_CONSOMMATION')) ? 1 : 0 ;
      $RA_DISTRIBUTION = ($this->input->post('RA_DISTRIBUTION')) ? 1 : 0 ;
      $SIG = ($this->input->post('SIG')) ? 1 : 0 ;
      $SIG_CENTRE_SITUATION = ($this->input->post('SIG_CENTRE_SITUATION')) ? 1 : 0 ;
      $SIG_INTERVENANT_STUCTURE = ($this->input->post('SIG_INTERVENANT_STUCTURE')) ? 1 : 0 ;
      $SIG_ALERTE = ($this->input->post('SIG_ALERTE')) ? 1 : 0 ;
      $DONNEES = ($this->input->post('DONNEES')) ? 1 : 0 ;
      $DON_STOCK = ($this->input->post('DON_STOCK')) ? 1 : 0 ;
      $DON_DEMANDES = ($this->input->post('DON_DEMANDES')) ? 1 : 0 ;
      $DON_DISTRIBUTION = ($this->input->post('DON_DISTRIBUTION')) ? 1 : 0 ;
      $IHM = ($this->input->post('IHM')) ? 1 : 0 ;
      $IHM_DEMANDE = ($this->input->post('IHM_DEMANDE')) ? 1 : 0 ;
      $IHM_DISTRIBUTION = ($this->input->post('IHM_DISTRIBUTION')) ? 1 : 0 ;
      $IHM_INTRANTS_ICCM = ($this->input->post('IHM_INTRANTS_ICCM')) ? 1 : 0 ;
      $IHM_PTF = ($this->input->post('IHM_PTF')) ? 1 : 0 ;
      $IHM_MALADIE = ($this->input->post('IHM_MALADIE')) ? 1 : 0 ;
      $IHM_INTERVENANT = ($this->input->post('IHM_INTERVENANT')) ? 1 : 0 ;
      $IHM_STUCTURE_SANITAIRE = ($this->input->post('IHM_STUCTURE_SANITAIRE')) ? 1 : 0 ;
      $RECEPTION = ($this->input->post('RECEPTION')) ? 1 : 0 ;
      $ADMINISTRATION = ($this->input->post('ADMINISTRATION')) ? 1 : 0 ;
      $PARAMETRAGE = ($this->input->post('PARAMETRAGE')) ? 1 : 0 ;
      $DEMANDES = ($this->input->post('DEMANDES')) ? 1 : 0 ;
      $data = array(
        'PROFIL_CODE'=>$this->input->post('PROFIL_CODE'),
        'PROFIL_DESCR'=>$this->input->post('PROFIL_DESCR'),
        'DASHBOARD'=>$DASHBOARD,
        'DB_INTRANT'=>$DB_INTRANT,
        'DB_DECES'=>$DB_DECES,
        'DB_DEMANDE'=>$DB_DEMANDE,
        'DB_DOSAGE'=>$DB_DOSAGE,
        'DB_MALADIE'=>$DB_MALADIE,
        'DB_STOCK'=>$DB_STOCK,
        'RAPPORT'=>$RAPPORT,
        'RA_STOCK'=>$RA_STOCK,
        'RA_CONSOMMATION'=>$RA_CONSOMMATION,
        'RA_DISTRIBUTION'=>$RA_DISTRIBUTION,
        'SIG'=>$SIG,
        'SIG_CENTRE_SITUATION'=>$SIG_CENTRE_SITUATION,
        'SIG_INTERVENANT_STUCTURE'=>$SIG_INTERVENANT_STUCTURE,
        'SIG_ALERTE'=>$SIG_ALERTE,
        'DONNEES'=>$DONNEES,
        'DON_STOCK'=>$DON_STOCK,
        'DON_DEMANDES'=>$DON_DEMANDES,
        'DON_DISTRIBUTION'=>$DON_DISTRIBUTION,
        'IHM' => $IHM,
        'IHM_DISTRIBUTION' => $IHM_DISTRIBUTION,
        'IHM_INTRANTS_ICCM' => $IHM_INTRANTS_ICCM,
        'IHM_DEMANDE' => $IHM_DEMANDE,
        'IHM_PTF' => $IHM_PTF,
        'IHM_MALADIE' => $IHM_MALADIE,
        'IHM_INTERVENANT' => $IHM_INTERVENANT,
        'IHM_STUCTURE_SANITAIRE' => $IHM_STUCTURE_SANITAIRE,
        'RECEPTION' => $RECEPTION,
        'DEMANDES' => $DEMANDES,
        'ADMINISTRATION' => $ADMINISTRATION,
        'PARAMETRAGE' => $PARAMETRAGE,
      );
      $this->Modele->update('admin_profil',array('PROFIL_ID'=>$id),$data);
      $datas['message']='<div class="alert alert-success text-center" id="message">La modification est faite avec succès</div>';
      $this->session->set_flashdata($datas);
      redirect(base_url('administration/Profils/listing'));
    }
  }
  public function delete()
  {
    $table="admin_profil";
    $criteres['PROFIL_ID']=$this->uri->segment(4);
    $data['rows']= $this->Modele->getOne( $table,$criteres);
    $this->Modele->delete($table,$criteres);
    $data['message']='<div class="alert alert-success text-center" id="message">'."Le profil est supprimée avec succès".'</div>';
    $this->session->set_flashdata($data);
    redirect(base_url('administration/Profils/listing'));
  }
  public function getOne($id)
  {
    $data['data']=$this->Modele->getOne('admin_profil',array('PROFIL_ID'=>$id));
    $data['error']='';
    $data['title'] = "Modifier un profil";
    $this->load->view('Profils_mod_view',$data);
  }

  public function get_form()
  {

  }

  public function get_icon($droit)
  {
    $html = ($droit == 1) ? '<a class = "btn btn-success btn-sm" ><span class = "fa fa-check" ></span></a>' : '<a class = "btn btn-danger btn-sm" ><span class = "fas fa-ban" ></span></a>' ;
    return $html;
  }
}
?>