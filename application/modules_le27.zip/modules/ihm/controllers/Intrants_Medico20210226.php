<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 01/2/2021
 Date fin :Le 01/2/2021
 Commentaire: controller pour le CRUD des Intrants_Medico
 */

class Intrants_Medico extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}


	public function index()
	{
        $data['title']='Listes des Intrants Medico';
        $query="SELECT INTRANT_MEDICAUX_ID,DEGRE_HUMIDITE,INTRANT_MEDICAUX_DESCR,t.TYPE_INTRANT_DESCR,unit.INTRANT_UNITE_DESCR, INTRANT_MEDICAUX_CODE,intr.TYPE_INTRANT_ID,intr.INTRANT_UNITE_ID, QUANTITE_SEUIL, QUANTITE_NATIONALE_DISPO, TEMPERATURE_MIN_CONSERVATION, TEMPERATURE_MAX_CONSERVATION FROM intrant_medicaux intr JOIN type_intrants t ON t.TYPE_INTRANT_ID=intr.TYPE_INTRANT_ID JOIN intrant_unites unit ON unit.INTRANT_UNITE_ID=intr.INTRANT_UNITE_ID";
	    $intrants=$this->Modele->sql_all_query($query);
	   
		$tabledata = array();
		foreach ($intrants as $intrant ) {

		$type=array();
		$type[]=$intrant['INTRANT_MEDICAUX_CODE'];
		$type[]=$intrant['INTRANT_MEDICAUX_DESCR'];
		$type[]=$intrant['INTRANT_UNITE_DESCR'];
		$type[]=$intrant['TYPE_INTRANT_DESCR'];
		$type[]=$intrant['QUANTITE_SEUIL'];
		$type[]=$intrant['QUANTITE_NATIONALE_DISPO'];
		$type[]=$intrant['DEGRE_HUMIDITE'];
		$type[]=$intrant['TEMPERATURE_MIN_CONSERVATION'];
		$type[]=$intrant['TEMPERATURE_MAX_CONSERVATION'];
		
				

$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
                       <a class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown">
                       <i class="fa fa-cog"></i> Options<span class="caret">
                       </span></a> 
	                   <ul class="dropdown-menu dropdown-menu-left">';
$type['OPTIONS'] .="<li>
                       <a href='".base_url('ihm/Intrants_Medico/update_intrant_view/').$intrant['INTRANT_MEDICAUX_ID'] ."'>
                       <label class='text-info'>Modifier</label>
                       </a>
                    </li>";
$type['OPTIONS'] .="<li>
                       <a href='#' data-toggle='modal' data-target='#mydelete".$intrant['INTRANT_MEDICAUX_ID']."'>
                       <label class='text-danger'>Supprimer</label>
                       </a>
                    </li>";



 $type['OPTIONS'] .= " </ul>
 </div>
 <div class='modal fade' id='mydelete".$intrant['INTRANT_MEDICAUX_ID']."'>
	 <div class='modal-dialog'>
		 <div class='modal-content'>

			 <div class='modal-body'>
				 <center><h5><strong>VOULEZ-VOUS SUPPRIMER L'INTRANT </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $intrant['TYPE_INTRANT_DESCR']."</i></b>?</h5>
				 </center>
			 </div>

			 <div class='modal-footer'>
				 <a class='btn btn-danger btn-md' href='" . base_url('ihm/Intrants_Medico/delete_intrant/').$intrant['INTRANT_MEDICAUX_ID'] . "'>Supprimer
				 </a>
				 <button class='btn btn-secondary btn-md' data-dismiss='modal'>
				 Quitter
				 </button>
			 </div>

		 </div>
	 </div>
 </div>";


			$tabledata[]=$type;
		}

$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
$this->table->set_template($template);
$this->table->set_heading(array('CODE D\'INTRANT','INTRANT','UNITE','TYPE D\'INTRANT','QUANTITE SEUIL','QUANTITE NATIONALE','DEGRE D\'HUMIDITE','TEMPERATURE MINIMALE','TEMPERATURE MAX','ACTONS'));
$data['tableau']=$tabledata;
$this->page='ihm/Intrants_Medico_Listing_view';
$this->layout($data);


  }


	public function add_intrant_view(){
	   $data['title']='Formulaire pour ajouter un nouveau Intrant';
	   $data['type_intrants']=$this->Modele->getList('type_intrants');
	   $data['unite_intrants']=$this->Modele->getList('intrant_unites');
	   $this->page='ihm/Intrants_Medico_Add_View';
	   $this->layout($data);
	}

	public function insert_intrant(){

        $this->form_validation->set_rules('code_intrant','Code','required');
        $this->form_validation->set_rules('description','Description','required');
        $this->form_validation->set_rules('type','Type','required');
        $this->form_validation->set_rules('unite','Unite','required');
        $this->form_validation->set_rules('seuil','Seuil','required');
        $this->form_validation->set_rules('quantite','Quantite','required');
        $this->form_validation->set_rules('min','Min','required');
        $this->form_validation->set_rules('min','Min','required');
        $this->form_validation->set_rules('max','Max','required');
        $this->form_validation->set_rules('degre','Degre','required');

        if ($this->form_validation->run()==FALSE) {
        $data['title']='Formulaire pour ajouter un nouveau Intrant';
	    $data['type_intrants']=$this->Modele->getList('type_intrants');
	    $data['unite_intrants']=$this->Modele->getList('intrant_unites');
	    $this->page='ihm/Intrants_Medico_Add_View';
	    $this->layout($data);
        } else {
        
        $code_intrant=$this->input->post('code_intrant');
		$description=$this->input->post('description');
		$type=$this->input->post('type');
		$unite=$this->input->post('unite');

		$seuil=$this->input->post('seuil');
		$quantite=$this->input->post('quantite');
		$min=$this->input->post('min');
		$max=$this->input->post('max');
		$degre=$this->input->post('degre');

		$data=array('INTRANT_MEDICAUX_CODE'=>$code_intrant,
	                'INTRANT_MEDICAUX_DESCR'=>$description,
	                'TYPE_INTRANT_ID'=>$type,
	                'INTRANT_UNITE_ID'=>$unite,
	                'QUANTITE_SEUIL'=>$seuil,
	                'QUANTITE_NATIONALE_DISPO'=>$quantite,
	                'TEMPERATURE_MIN_CONSERVATION'=>$min,
	                'TEMPERATURE_MAX_CONSERVATION'=>$max,
	                'DEGRE_HUMIDITE'=>$degre
	              );
		$sql=$this->Modele->Add_data('intrant_medicaux',$data);
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Intrant ajouter avec succes ! .
			               </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Intrants_Medico');
		} else {
			$sms['sms']='<br>
			               <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Une erreur s\'est produit ! .
			               </div>
			            <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Intrants_Medico');
		}

      }		
	}


	

   public function delete_intrant($id){

   	$sql=$this->Modele->deleteData('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$id));
   	if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Intervenant supprimer avec succes ! .
			               </div>
			            <br>' ;
            
		} else {
			$sms['sms']='<br>
			               <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Une erreur s\'est produit ! .
			               </div>
			            <br>' ;
		}

		$this->session->set_flashdata($sms) ;
        redirect('ihm/Intrants_Medico/index');
   }
    
   public function update_intrant_view($id){

   	 $data['title']='Formulaire de modification';
	 $data['type_intrants']=$this->Modele->getList('type_intrants');
     $data['unite_intrants']=$this->Modele->getList('intrant_unites');
	 $query="SELECT INTRANT_MEDICAUX_ID,DEGRE_HUMIDITE,INTRANT_MEDICAUX_DESCR,t.TYPE_INTRANT_DESCR,unit.INTRANT_UNITE_DESCR, INTRANT_MEDICAUX_CODE,intr.TYPE_INTRANT_ID,intr.INTRANT_UNITE_ID, QUANTITE_SEUIL, QUANTITE_NATIONALE_DISPO, TEMPERATURE_MIN_CONSERVATION, TEMPERATURE_MAX_CONSERVATION FROM intrant_medicaux intr JOIN type_intrants t ON t.TYPE_INTRANT_ID=intr.TYPE_INTRANT_ID JOIN intrant_unites unit ON unit.INTRANT_UNITE_ID=intr.INTRANT_UNITE_ID AND INTRANT_MEDICAUX_ID=$id";
	 $data['intrants']=$this->Modele->sql_one_query($query);

     $this->page='ihm/Intrants_Medico_Update_View';
	 $this->layout($data);
   }

   public function update_intrant($id){
   	
   	    $this->form_validation->set_rules('code_intrant','Code','required');
        $this->form_validation->set_rules('description','Description','required');
        $this->form_validation->set_rules('type','Type','required');
        $this->form_validation->set_rules('unite','Unite','required');
        $this->form_validation->set_rules('seuil','Seuil','required');
        $this->form_validation->set_rules('quantite','Quantite','required');
        $this->form_validation->set_rules('min','Min','required');
        $this->form_validation->set_rules('min','Min','required');
        $this->form_validation->set_rules('max','Max','required');
        $this->form_validation->set_rules('degre','Degre','required');

        if ($this->form_validation->run()==FALSE) {

         $data['title']='Formulaire de modification';
		 $data['type_intrants']=$this->Modele->getList('type_intrants');
	     $data['unite_intrants']=$this->Modele->getList('intrant_unites');
		 $query="SELECT INTRANT_MEDICAUX_ID,DEGRE_HUMIDITE,INTRANT_MEDICAUX_DESCR,t.TYPE_INTRANT_DESCR,unit.INTRANT_UNITE_DESCR, INTRANT_MEDICAUX_CODE,intr.TYPE_INTRANT_ID,intr.INTRANT_UNITE_ID, QUANTITE_SEUIL, QUANTITE_NATIONALE_DISPO, TEMPERATURE_MIN_CONSERVATION, TEMPERATURE_MAX_CONSERVATION FROM intrant_medicaux intr JOIN type_intrants t ON t.TYPE_INTRANT_ID=intr.TYPE_INTRANT_ID JOIN intrant_unites unit ON unit.INTRANT_UNITE_ID=intr.INTRANT_UNITE_ID AND INTRANT_MEDICAUX_ID=$id";
		 $data['intrants']=$this->Modele->sql_one_query($query);
		 $data['error']='';

	     $this->page='ihm/Intrants_Medico_Update_View';
		 $this->layout($data);
   	    }else{
   	    $code_intrant=$this->input->post('code_intrant');
		$description=$this->input->post('description');
		$type=$this->input->post('type');
		$unite=$this->input->post('unite');

		$seuil=$this->input->post('seuil');
		$quantite=$this->input->post('quantite');
		$min=$this->input->post('min');
		$max=$this->input->post('max');
		$degre=$this->input->post('degre');

		$data=array('INTRANT_MEDICAUX_CODE'=>$code_intrant,
	                'INTRANT_MEDICAUX_DESCR'=>$description,
	                'TYPE_INTRANT_ID'=>$type,
	                'INTRANT_UNITE_ID'=>$unite,
	                'QUANTITE_SEUIL'=>$seuil,
	                'QUANTITE_NATIONALE_DISPO'=>$quantite,
	                'TEMPERATURE_MIN_CONSERVATION'=>$min,
	                'TEMPERATURE_MAX_CONSERVATION'=>$max,
	                'DEGRE_HUMIDITE'=>$degre
	              );
$sql=$this->Modele->updateData('intrant_medicaux',$data,array('INTRANT_MEDICAUX_ID'=>$id));
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                     </a><strong> Oup! </strong> 
			                     Intervenant modifier avec succes ! .
			               </div>
			            <br>' ;
            
		} else {
			$sms['sms']='<br>
			                <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                      </a><strong> Oup! </strong> 
			                      Une erreur s\'est produit ! .
			                </div>
			            <br>' ;
		}
     }

     $this->session->set_flashdata($sms) ;
     redirect('ihm/Intrants_Medico');
   }



}