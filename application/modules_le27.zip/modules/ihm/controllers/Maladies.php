<?php
/**
*Auteur du fichier:Mutunge Ixella
Date debut:le 29/01/2021
Date fin:le 29/01/2021
commentaire: CRUD MALADIES
*/

defined('BASEPATH') OR exit('No direct script access allowed');

class Maladies extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }


  function index()
  {
    $data['error']='';
    $this->listing();
  }

  function nouveau()
  {
    $data['title']='Nouvelle maladie';
    $this->load->view('Maladies_Add_View',$data);
   
  }

  function listing()
  {

   $sql="SELECT MALADIE_ID,MALADIE_DESCR,MALADIE_CODE FROM maladies";
    // $table="maladies";
   $maladies=$this->Modele->getRequete($sql);
   $malaladies_array=array();
   foreach ($maladies as $maladie) {
     $sub_array_maladie=array();
     $sub_array_maladie[]=$maladie['MALADIE_DESCR'];
     $sub_array_maladie[]=$maladie['MALADIE_CODE'];


     $sub_array_maladie['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
     <i class="fa fa-cog"></i>
     Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array_maladie['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydelete" . $maladie['MALADIE_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
     $sub_array_maladie['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Maladies/getOne/'. $maladie['MALADIE_ID']) . "'><font>&nbsp;&nbsp;Modifier</font></a></li>";
     $sub_array_maladie['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $maladie['MALADIE_ID'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h5><strong>Voulez-vous supprimer?</strong><br><b style:'background-color:prink';><i style='color:green;'>" . $maladie['MALADIE_DESCR']."</i></b></h5></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Maladies/delete/'. $maladie['MALADIE_ID']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";


     $malaladies_array[]=$sub_array_maladie;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('MALADIE','CODE MALADIE','ACTIONS'));
   $data['donnees_Maladie']=$malaladies_array;
   $data['title'] = "Liste des maladies";
   $this->load->view('Maladie_List_View',$data);
   

 }
 public function add()
 {
   $this->form_validation->set_rules('MALADIE_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   $this->form_validation->set_rules('MALADIE_CODE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   if ($this->form_validation->run() == FALSE)
   {
     $data['title'] = "Nouvelle Maladie"; 
     $this->load->view('Maladies_Add_View',$data);
   }

   else
   {
     $dataInsert=array('MALADIE_DESCR'=>$this->input->post('MALADIE_DESCR'),
       'MALADIE_CODE'=>$this->input->post('MALADIE_CODE')
     );


     $this->Modele->create('maladies',$dataInsert);
     $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'une maladie <b>".' '.$this->input->post('MALADIE_DESCR').'</b> '." est faite avec succès".'</div>';
     $this->session->set_flashdata($data);
     redirect(base_url('ihm/Maladies/listing'));
   }
 }

 public function update()
 {
   $this->form_validation->set_rules('MALADIE_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ description est obligatoire</font>'));

   $this->form_validation->set_rules('MALADIE_CODE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ description est obligatoire</font>'));

   if ($this->form_validation->run() == FALSE)
   {
     $id=$this->input->post('MALADIE_ID');
     $data['maladie']=$this->Modele->getOne('maladies',array('MALADIE_ID'=>$id));
     $data['title']='Modifier une maladie';

     $this->load->view('Maladies_Update_View',$data);
   
   }

   else
   {
     $id=$this->input->post('MALADIE_ID');
     $data=array(
      'MALADIE_DESCR'=>$this->input->post('MALADIE_DESCR'),
      'MALADIE_CODE'=>$this->input->post('MALADIE_CODE')
    );
     $this->Modele->update('maladies',array('MALADIE_ID'=>$id),$data);
     $datas['message']='<div class="alert alert-success text-center" id="message">La modification du  '.$this->input->post('MALADIE_DESCR').'</b> faite avec succès</div>';
     $this->session->set_flashdata($datas);
     redirect(base_url('ihm/Maladies/listing'));
   }

 }
 public function delete()
 {
   $table="maladies";
   $criteres['MALADIE_ID']=$this->uri->segment(4);
   $data['rows']= $this->Modele->getOne( $table,$criteres);
   $this->Modele->delete($table,$criteres);

   $data['message']='<div class="alert alert-success text-center" id="message">'."La maladie <b> ".' '.$data['rows']['MALADIE_DESCR'].' </b> '." est supprimée avec succès".'</div>';
   $this->session->set_flashdata($data);
   redirect(base_url('ihm/Maladies/listing'));


 }
 public function getOne()
 {
   $id=$this->uri->segment(4);
   $data['maladie']=$this->Modele->getOne('maladies',array('MALADIE_ID'=>$id));
   $data['title']='Modifier une maladie';
   $this->load->view('Maladies_Update_View',$data);


 }



}
?>
