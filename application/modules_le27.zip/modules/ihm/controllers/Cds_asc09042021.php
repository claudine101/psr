<?php

/**
 * auteur:Cedric
 * date debut:02/03/2021
 * date fin:01/02/2021
 * commentaire:crud de la table Partenaires technique financier
 */
class Cds_asc extends CI_Controller
{

	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['error']='';
		$this->listing();
	}
	function listing()
	{
		$sql='SELECT CDS_ASC_ID, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID = CDS_ID) AS CDS, (SELECT CONCAT(NOM," ",PRENOM," (",TELEPHONE1,")") FROM intervenants_rh WHERE INTERVENANT_RH_ID = cds_asc.INTERVENANT_RH_ID ) AS INTERVENANT FROM cds_asc WHERE 1 ';
		$affectations = $this->Modele->getRequete($sql);

		$data_bds=array();

		foreach ($affectations as $key) {
			$ptf_structure= array();
			$ptf_structure[] = $key['CDS'];
			$ptf_structure[] = $key['INTERVENANT'];

			$ptf_structure["OPTIONS"]= '<div class="dropdown">
			<a class="btn btn-outline-primary btn-sm dropdown-toggle" data-toggle="dropdown">
			<i class="fa fa-cog"></i>
			Action
			<span class="caret"></span></a>
			<ul class="dropdown-menu dropdown-menu-left">
			';

			$ptf_structure["OPTIONS"] .= "<li><a hre='#' data-toggle='modal'
			data-target='#mydelete" . $key['CDS_ASC_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
			$ptf_structure["OPTIONS"] .= "<li><a class='btn-md' href='" . base_url('ihm/Cds_asc/getOne/'. $key['CDS_ASC_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";
			$ptf_structure["OPTIONS"] .= " </ul>
			</div>
			<div class='modal fade' id='mydelete" . $key['CDS_ASC_ID'] . "'>
			<div class='modal-dialog'>
			<div class='modal-content'>

			<div class='modal-body'>
			<center><h5><strong>Voulez - vous supprimer?</strong><br><b style='background-color:prink;color:green;'><i style='color:green;'>" . $key['CDS']."(".$key['INTERVENANT'].")"."</i></b></h5></center>
			</div>

			<div class='modal-footer'>
			<a class='btn btn-outline-danger btn-md' href='" . base_url('ihm/Cds_asc/delete/'. $key['CDS_ASC_ID']) . "'>Supprimer</a>
			<button class='btn btn-outline-primary btn-md' data-dismiss='modal'>Quitter</button>
			</div>

			</div>
			</div>
			</div>";


			$data_bds[]=$ptf_structure;
		}
		$template = array(
			'table_open' => '<table id="mytable" class="table table-stripped table-hover table-condensed">',
			'table_close' => '</table>'
		);
		$this->table->set_template($template);
		$this->table->set_heading(array('CDS','ASC','Actions'));

		$data['donnees_ptf']=$data_bds;

		$data['title']="Liste des partenaires technique financier";
		$this->load->view('Cds_asc_List_View',$data);

		
	}

	function nouveau($cds_id = null ,$asc_id = null)
	{
		$data['error']='';
		$data['title']="Affectation des ASCS aux CDS";
		$data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "CDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR ASC');
		$data['asc'] = $this->Modele->getRequete('SELECT r.INTERVENANT_RH_ID, CONCAT(r.NOM," ",r.PRENOM," (",r.TELEPHONE1,")") AS Nom, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh r  JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = r.INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "ASC" ORDER BY Nom');

		$data['CDS_ID'] = $cds_id;
		$data['INTERVENANT_RH_ID'] = $asc_id;
		$this->load->view('Cds_asc_Add_View',$data);
	}

	public function check_double_cds()
	{
		$bds_id = $this->input->post('CDS_ID');
		$cds_id = $this->input->post('INTERVENANT_RH_ID');
		$cds_asc_id = $this->input->post('CDS_ASC_ID');
		$critere = !empty($cds_asc_id) ? ' AND CDS_ASC_ID != '.$cds_asc_id.' ' : '' ;
		if (!empty($bds_id)) {
			if (!empty($cds_id)) {
				$get = $this->Modele->getRequete('SELECT INTERVENANT_RH_ID FROM cds_asc WHERE CDS_ID = '.$bds_id.' AND INTERVENANT_RH_ID = '.$cds_id.'  '.$critere.'');
				if (!empty($get)) {
					$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Cette affectation existe déjà!</font>');
					return FALSE;
				}else{
					return TRUE;
				}
			}else{
				$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Ce champ est obligatoire!</font>');
				return FALSE;
			}
		}else{
			$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Le champ de CDS est obligatoire!</font>');
			return FALSE;
		}
	}

	function ajouter()
	{

		$this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('INTERVENANT_RH_ID','', 'trim|required|is_unique[cds_asc.INTERVENANT_RH_ID]',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>','is_unique'=>'<font style="color:red;size:2px;">Existe déjà</font>'));


		if ($this->form_validation->run() == FALSE) {
			$this->nouveau($this->input->post('CDS_ID'),$this->input->post('INTERVENANT_RH_ID'));
		} else {
			$dataInsert=array(
				'CDS_ID'=>$this->input->post('CDS_ID'),
				'INTERVENANT_RH_ID'=>$this->input->post('INTERVENANT_RH_ID')
			);
			$this->Modele->create('cds_asc',$dataInsert);
			$data['message']='<div class="alert alert-success text-center" id="message">'."L'affectation est faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Cds_asc/listing'));
		}
	}


	function getOne()
	{
		$data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "CDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR');
		$data['asc'] = $this->Modele->getRequete('SELECT r.INTERVENANT_RH_ID, CONCAT(r.NOM," ",r.PRENOM," (",r.TELEPHONE1,")") AS Nom, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh r  JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = r.INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "ASC" ORDER BY Nom');
		$id=$this->uri->segment(4);
		$data['cds_asc'] = $this->Modele->getOne('cds_asc',array('CDS_ASC_ID'=>$id));

		//print_r($data['cds_asc']);die();
		$data['error']='';
		$data['title'] = "Modification d'une affectation";
		$this->load->view('Cds_asc_Modif_View',$data);
	}

	function modifier()
	{
		$this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('INTERVENANT_RH_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('INTERVENANT_RH_ID','', 'callback_check_double_cds');
		if ($this->form_validation->run() == FALSE) {
			$CDS_ASC_ID=$this->input->post('CDS_ASC_ID');
			$data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "CDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR');
		    $data['asc'] = $this->Modele->getRequete('SELECT r.INTERVENANT_RH_ID, CONCAT(r.NOM," ",r.PRENOM," (",r.TELEPHONE1,")") AS Nom, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh r  JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = r.INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE = "ASC" ORDER BY Nom');
		//$id=$this->uri->segment(4);
		$data['cds_asc'] = $this->Modele->getOne('cds_asc',array('CDS_ASC_ID'=>$CDS_ASC_ID));
		$data['error']='';
		$data['title'] = "Modification d'une affectation";
		$this->load->view('Cds_asc_Modif_View',$data);
		} else {
			$data_mod=array(
				'CDS_ID'=>$this->input->post('CDS_ID'),
				'INTERVENANT_RH_ID'=>$this->input->post('INTERVENANT_RH_ID')
			);
			$this->Modele->update('cds_asc',array('CDS_ASC_ID'=>$this->input->post('CDS_ASC_ID')),$data_mod);
			$data['message']='<div class="alert alert-success text-center" id="message">'."Modification faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Cds_asc/listing'));
		}
	}
	function delete()
	{
		$criteres['CDS_ASC_ID']=$this->uri->segment(4);
		$this->Modele->delete('cds_asc',$criteres);
		$data['message']='<div class="alert alert-success text-center" id="message">'."Suppression faite avec succès!".'</div>';
		$this->session->set_flashdata($data);
		redirect(base_url('ihm/Cds_asc/listing'));
	}


}

?>
