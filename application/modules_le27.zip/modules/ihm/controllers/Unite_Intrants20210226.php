<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 01/2/2021
 Date fin :Le 01/2/2021
 Commentaire: controller pour le CRUD des Unite des Intrants
 */

class Unite_Intrants extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
        $data['title']='Listes des Unites des Intrants Medico';
	    $unite_intrants=$this->Modele->getList('intrant_unites');
	   
		$tabledata = array();
		foreach ($unite_intrants as $unite_intrant ) {

		$type=array();
		$type[]=$unite_intrant['INTRANT_UNITE_DESCR'];
				

$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
                        <a class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog"></i> Options<span class="caret"></span>
                        </a> 
	                    <ul class="dropdown-menu dropdown-menu-left">';
$type['OPTIONS'] .="<li>
                      <a href='".base_url('ihm/Unite_Intrants/update_Unite_intrant_view/').$unite_intrant['INTRANT_UNITE_ID'] ."'>
                          <label class='text-info'>Modifier</label>
                      </a>
                    </li>";
$type['OPTIONS'] .="<li>
                       <a href='#' data-toggle='modal' data-target='#mydelete".$unite_intrant['INTRANT_UNITE_ID']."'>
                         <label class='text-danger'>Supprimer</label>
                       </a>
                    </li>";



 $type['OPTIONS'] .= " </ul>
 </div>
 <div class='modal fade' id='mydelete".$unite_intrant['INTRANT_UNITE_ID']."'>
	 <div class='modal-dialog'>
		 <div class='modal-content'>

		 <div class='modal-body'>
			 <center>
			     <h5><strong>VOULEZ-VOUS SUPPRIMER L'INTRANT </strong> : <b style:'background-color:prink';><i style='color:green;'>" . $unite_intrant['INTRANT_UNITE_DESCR']."</i></b> ?
			     </h5>
			 </center>
		 </div>

		 <div class='modal-footer'>
			 <a class='btn btn-danger btn-md' href='" . base_url('ihm/Unite_Intrants/delete_unite_intrant/').$unite_intrant['INTRANT_UNITE_ID'] . "'>
			 Supprimer
			 </a>
			 <button class='btn btn-secondary btn-md' data-dismiss='modal'>
			 Quitter
			 </button>
		 </div>

		 </div>
	 </div>
 </div>";

$tabledata[]=$type;

		}

$template = array('table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">', 'table_close' => '</table>');
$this->table->set_template($template);
$this->table->set_heading(array('UNITE INTRANT','ACTONS'));
$data['tableau']=$tabledata;
$this->page='ihm/Unite_Intrants_Listing_View';
$this->layout($data);

  }

	public function add_unite_intrant_view(){
	   $data['title']='Formulaire pour ajouter un nouveau Unite';
	   $this->page='ihm/Unite_Intrants_Add_View';
	   $this->layout($data);
	}

	public function insert_unite_intrant(){

        $this->form_validation->set_rules('description','Description','required');

    if ($this->form_validation->run()==FALSE) {
       $data['title']='Formulaire pour ajouter un nouveau Unite';
	   $this->page='ihm/Unite_Intrants_Add_View';
	   $this->layout($data);
        } else {

		$description=$this->input->post('description');

		$data=array('INTRANT_UNITE_DESCR'=>$description);
		$sql=$this->Modele->Add_data('intrant_unites',$data);
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Oup! </strong> Unite Intrant ajouter avec succes !
			               .</div>
			              <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Unite_Intrants');
		} else {
			$sms['sms']='<br>
			                <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                    </a><strong> Oup! </strong> Une erreur s\'est produit ! 
			                .</div>
			              <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Unite_Intrants');
		}

      }

    }


   public function delete_unite_intrant($id){

   	$sql=$this->Modele->deleteData('intrant_unites',array('INTRANT_UNITE_ID'=>$id));
   	if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                    </a><strong> Oup! </strong> 
			                    Unite Intrant supprimer avec succes ! .
			               </div>
			             <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Unite_Intrants/index');
		} else {
			$sms['sms']='<br>
			                <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                    </a><strong> Oup! </strong> 
			                    Une erreur s\'est produit ! .
			                </div>
			              <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Unite_Intrants');
		}
   }
    
   public function update_Unite_intrant_view($id){

   	 $data['title']='Formulaire de modification';
	 $data['unite_intrants']=$this->Modele->getOne('intrant_unites',array('INTRANT_UNITE_ID'=>$id));

     $this->page='ihm/Unite_Intrants_Update_View';
	 $this->layout($data);
   }

   public function update_unite_intrant($id){
   	    $this->form_validation->set_rules('description','Description','required');

    if ($this->form_validation->run()==FALSE) {

	     $data['title']='Formulaire de modification';
		 $data['unite_intrants']=$this->Modele->getOne('intrant_unites',array('INTRANT_UNITE_ID'=>$id));
		 $data['error']='';

	     $this->page='ihm/Unite_Intrants_Update_View';
		 $this->layout($data);
        } else {

		$description=$this->input->post('description');
		$data=array('INTRANT_UNITE_DESCR'=>$description);
        $sql=$this->Modele->updateData('intrant_unites',$data,array('INTRANT_UNITE_ID'=>$id));
		if ($sql) {
			$sms['sms']='<br>
			               <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
			                   <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                   </a><strong> Oup! </strong> 
			                   Unite Intrant modifier avec succes ! .
			                </div>
			              <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Unite_Intrants');
		} else {
			$sms['sms']='<br>
			                <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
			                </a><strong> Oup! </strong> 
			                Une erreur s\'est produit ! .
			              </div>
			             <br>' ;
            $this->session->set_flashdata($sms) ;
            redirect('ihm/Unite_Intrants');
		}
     }
   }



}