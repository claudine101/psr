<?php

/**
 * auteur:Cedric
 * date debut:02/03/2021
 * date fin:01/02/2021
 * commentaire:crud de la table Partenaires technique financier
 *	Auteur: Nandou
 * date debut:16/04/2021
 * date fin:16/04/2021
 * commentaire:Liste json
 */
class Cds_asc extends CI_Controller
{

	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index()
	{
		$data['title']="Liste des partenaires technique financier";
		$this->load->view('Cds_asc_List_View',$data);
	}

	function getInfo()
	{
		$critere_array =array();
		$var_search = $_POST['search']['value'];
		$sql='SELECT cds_asc.CDS_ASC_ID,intervenants_structure.INTERVENANT_STRUCTURE_DESCR AS CDS, intervenants_rh.NOM, intervenants_rh.PRENOM, intervenants_rh.TELEPHONE1 FROM cds_asc JOIN intervenants_structure ON intervenants_structure.INTERVENANT_STRUCTURE_ID=cds_asc.CDS_ID JOIN intervenants_rh ON intervenants_rh.INTERVENANT_RH_ID=cds_asc.INTERVENANT_RH_ID';
		$limit='LIMIT 0,10';
		if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$order_by=" ORDER BY intervenants_structure.INTERVENANT_STRUCTURE_DESCR ASC";
		$search = !empty($_POST['search']['value']) ? ("WHERE intervenants_structure.INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR intervenants_rh.NOM LIKE '%$var_search%' OR intervenants_rh.PRENOM LIKE '%$var_search%' OR CONCAT(intervenants_rh.NOM,' ',intervenants_rh.PRENOM) LIKE '%$var_search%' OR intervenants_rh.TELEPHONE1 LIKE '%$var_search%'") : '';
		$query_secondaire=$sql.' '.$search.' '.$order_by.' '.$limit;
		$query_filtrer=$sql.' '.$search;
		$fetch_data = $this->Modele->datatable($query_secondaire);
		$tabledata=array();
		foreach ($fetch_data as $req)
		{
			$ptf_structure=array();
			$ptf_structure[]=$req->NOM;
			$ptf_structure[]=$req->PRENOM;
			$ptf_structure[]=$req->TELEPHONE1;
			$ptf_structure[]=$req->CDS;
			$OPTIONS='<div class="dropdown">
			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
			<i class="fa fa-cog"></i>
			Action
			<span class="caret"></span></a>
			<ul class="dropdown-menu dropdown-menu-left">
			';
			$OPTIONS.="<li><a hre='#' data-toggle='modal'
			data-target='#mydelete".$req->CDS_ASC_ID."'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
			$OPTIONS.= "<li><a class='btn-md' href='".base_url('ihm/Cds_asc/getOne/'. $req->CDS_ASC_ID)."'>&nbsp;&nbsp;Modifier</a></li>";

			$OPTIONS.=" </ul>
			</div>
			<div class='modal fade' id='mydelete" .$req->CDS_ASC_ID. "'>
			<div class='modal-dialog'>
			<div class='modal-content'>

			<div class='modal-body'>
			<center><h5><strong>Voulez - vous supprimer?</strong><br><b style='background-color:prink;color:green;'><i style='color:green;'>". $req->CDS."(".$req->NOM." ".$req->NOM.")"."</i></b></h5></center>
			</div>

			<div class='modal-footer'>
			<a class='btn btn-danger btn-md' href='" . base_url('ihm/Cds_asc/delete/'.$req->CDS_ASC_ID) . "'>Supprimer</a>
			<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
			</div>

			</div>
			</div>
			</div>";



			$ptf_structure[]=$OPTIONS;
			$tabledata[]=$ptf_structure;
		}

		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($sql),
			"recordsFiltered" => $this->Modele->filtrer($query_filtrer),
			"data" => $tabledata
		);
		echo json_encode($output);
	}

	function listing()
	{
		redirect(base_url('ihm/Cds_asc/index'));
	}

	// function index()
	// {
	// 	$data['error']='';
	// 	$this->listing();
	// }
	// function listing()
	// {
	// 	$sql='SELECT CDS_ASC_ID, (SELECT INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure WHERE INTERVENANT_STRUCTURE_ID = CDS_ID) AS CDS, (SELECT CONCAT(NOM," ",PRENOM," (",TELEPHONE1,")") FROM intervenants_rh WHERE INTERVENANT_RH_ID = cds_asc.INTERVENANT_RH_ID ) AS INTERVENANT FROM cds_asc WHERE 1 ';
	// 	$affectations = $this->Modele->getRequete($sql);

	// 	$data_bds=array();

	// 	foreach ($affectations as $key) {
	// 		$ptf_structure= array();
	// 		$ptf_structure[] = $key['CDS'];
	// 		$ptf_structure[] = $key['INTERVENANT'];

	// 		$ptf_structure["OPTIONS"]= '<div class="dropdown">
	// 		<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
	// 		<i class="fa fa-cog"></i>
	// 		Action
	// 		<span class="caret"></span></a>
	// 		<ul class="dropdown-menu dropdown-menu-left">
	// 		';

	// 		$ptf_structure["OPTIONS"] .= "<li><a hre='#' data-toggle='modal'
	// 		data-target='#mydelete" . $key['CDS_ASC_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
	// 		$ptf_structure["OPTIONS"] .= "<li><a class='btn-md' href='" . base_url('ihm/Cds_asc/getOne/'. $key['CDS_ASC_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";
	// 		$ptf_structure["OPTIONS"] .= " </ul>
	// 		</div>
	// 		<div class='modal fade' id='mydelete" . $key['CDS_ASC_ID'] . "'>
	// 		<div class='modal-dialog'>
	// 		<div class='modal-content'>

	// 		<div class='modal-body'>
	// 		<center><h5><strong>Voulez - vous supprimer?</strong><br><b style='background-color:prink;color:green;'><i style='color:green;'>" . $key['CDS']."(".$key['INTERVENANT'].")"."</i></b></h5></center>
	// 		</div>

	// 		<div class='modal-footer'>
	// 		<a class='btn btn-danger btn-md' href='" . base_url('ihm/Cds_asc/delete/'. $key['CDS_ASC_ID']) . "'>Supprimer</a>
	// 		<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
	// 		</div>

	// 		</div>
	// 		</div>
	// 		</div>";


	// 		$data_bds[]=$ptf_structure;
	// 	}
	// 	$template = array(
	// 		'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
	// 		'table_close' => '</table>'
	// 	);
	// 	$this->table->set_template($template);
	// 	$this->table->set_heading(array('CDS','ASC','Actions'));

	// 	$data['donnees_ptf']=$data_bds;

	// 	$data['title']="Liste des partenaires technique financier";
	// 	$this->load->view('Cds_asc_List_View',$data);


	// }

	function nouveau($cds_id = null ,$asc_id = null)
	{
		$data['error']='';
		$data['title']="Affectation des ASCS aux CDS";
		// $data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.TYPE_INTERVENANT_STRUCTURE_DESCR = "CDS"');

		$data['asc'] = $this->Modele->getRequete('SELECT r.INTERVENANT_RH_ID, CONCAT(r.NOM," ",r.PRENOM," (",r.TELEPHONE1,")") AS Nom FROM intervenants_rh r WHERE r.INTERVENANT_STRUCTURE_ID IN (SELECT intervenants_structure.INTERVENANT_STRUCTURE_ID FROM intervenants_structure WHERE intervenants_structure.INTERVENANT_STRUCTURE_DESCR LIKE "ASC" ) ORDER BY Nom');

		$data['bds']=$this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR,t.CODE_STRUCTURE FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID=i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE="BDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR');

		$data['CDS_ID'] = $cds_id;
		$data['INTERVENANT_RH_ID'] = $asc_id;
		$this->load->view('Cds_asc_Add_View',$data);
	}

	public function select_cds(){
		$bds_id=$this->input->post('bds_id');
		$cds=$this->Modele->getRequete('SELECT bds.BDS_ID,bds.CDS_ID,i.INTERVENANT_STRUCTURE_ID,i.INTERVENANT_STRUCTURE_DESCR FROM bds_cds bds JOIN intervenants_structure i ON i.INTERVENANT_STRUCTURE_ID=bds.CDS_ID WHERE bds.BDS_ID='.$bds_id.' ORDER BY i.INTERVENANT_STRUCTURE_DESCR');

		echo '<option value="" >Séléctionner</option>';
		if (!empty($cds)) {
			foreach ($cds as $value) {
				echo '<option value="'.$value['INTERVENANT_STRUCTURE_ID'].'" >'.$value['INTERVENANT_STRUCTURE_DESCR'].'</option>';
			}
		}else{
			echo 'Auncun CDS trouvé';	
		}
	}


	public function check_double_cds()
	{
		$bds_id = $this->input->post('CDS_ID');
		$cds_id = $this->input->post('INTERVENANT_RH_ID');
		$cds_asc_id = $this->input->post('CDS_ASC_ID');
		$critere = !empty($cds_asc_id) ? ' AND CDS_ASC_ID != '.$cds_asc_id.' ' : '' ;
		if (!empty($bds_id)) {
			if (!empty($cds_id)) {
				$get = $this->Modele->getRequete('SELECT INTERVENANT_RH_ID FROM cds_asc WHERE CDS_ID = '.$bds_id.' AND INTERVENANT_RH_ID = '.$cds_id.'  '.$critere.'');
				if (!empty($get)) {
					$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Cette affectation existe déjà!</font>');
					return FALSE;
				}else{
					return TRUE;
				}
			}else{
				$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Ce champ est obligatoire!</font>');
				return FALSE;
			}
		}else{
			$this->form_validation->set_message('check_double_cds','<font style="color:red;size:2px;">Le champ de CDS est obligatoire!</font>');
			return FALSE;
		}
	}

	function ajouter()
	{

		// $this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('INTERVENANT_RH_ID','', 'trim|required|is_unique[cds_asc.INTERVENANT_RH_ID]',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>','is_unique'=>'<font style="color:red;size:2px;">Existe déjà</font>'));


		if ($this->form_validation->run() == FALSE) {
			$this->nouveau($this->input->post('CDS_ID'),$this->input->post('INTERVENANT_RH_ID'));
		} else {
			$dataInsert=array(
				'CDS_ID'=>$this->input->post('CDS_ID'),
				'INTERVENANT_RH_ID'=>$this->input->post('INTERVENANT_RH_ID')
			);
			$this->Modele->create('cds_asc',$dataInsert);
			$data['message']='<div class="alert alert-success text-center" id="message">'."L'affectation est faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Cds_asc/index'));
		}
	}


	function getOne()
	{
		// $data['cds'] = $this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.TYPE_INTERVENANT_STRUCTURE_DESCR = "CDS"');
		// $data['asc'] = $this->Modele->getRequete('SELECT r.INTERVENANT_RH_ID, CONCAT(r.NOM," ",r.PRENOM," (",r.TELEPHONE1,")") AS Nom, t.TYPE_INTERVENANT_STRUCTURE_DESCR FROM intervenants_rh r  JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID = r.INTERVENANT_STRUCTURE_ID WHERE t.TYPE_INTERVENANT_STRUCTURE_DESCR = "ASC"');

		$data['asc'] = $this->Modele->getRequete('SELECT r.INTERVENANT_RH_ID, CONCAT(r.NOM," ",r.PRENOM," (",r.TELEPHONE1,")") AS Nom FROM intervenants_rh r WHERE r.INTERVENANT_STRUCTURE_ID IN (SELECT intervenants_structure.INTERVENANT_STRUCTURE_ID FROM intervenants_structure WHERE intervenants_structure.INTERVENANT_STRUCTURE_DESCR LIKE "ASC" ) ORDER BY Nom');

		$data['bds']=$this->Modele->getRequete('SELECT i.INTERVENANT_STRUCTURE_ID, i.INTERVENANT_STRUCTURE_DESCR,t.CODE_STRUCTURE FROM intervenants_structure i JOIN type_intervenants_structures t ON t.TYPE_INTERVENANT_STRUCTURE_ID=i.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.CODE_STRUCTURE="BDS" ORDER BY i.INTERVENANT_STRUCTURE_DESCR');

		$id=$this->uri->segment(4);
		$data['cds_asc'] = $this->Modele->getOne('cds_asc',array('CDS_ASC_ID'=>$id));

		$cds_id = $this->Modele->getOne('cds_asc',array('CDS_ASC_ID'=>$id));

		$data['cds_id']=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$cds_id['CDS_ID']));
		$bds_id=$this->Modele->getOne('bds_cds',array('CDS_ID'=>$cds_id['CDS_ID']));
		$data['bds_select']=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$bds_id['BDS_ID']));

		//print_r($data['cds_asc']);die();
		$data['error']='';
		$data['title'] = "Modification d'une affectation";
		$this->load->view('Cds_asc_Modif_View',$data);
	}

	function modifier()
	{
		// $this->form_validation->set_rules('CDS_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('INTERVENANT_RH_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Ce champ est obligatoire</font>'));
		$this->form_validation->set_rules('INTERVENANT_RH_ID','', 'callback_check_double_cds');
		if ($this->form_validation->run() == FALSE) {
			
			$this->getOne();
		} else {
			$data_mod=array(
				'CDS_ID'=>$this->input->post('CDS_ID'),
				'INTERVENANT_RH_ID'=>$this->input->post('INTERVENANT_RH_ID')
			);
			$this->Modele->update('cds_asc',array('CDS_ASC_ID'=>$this->input->post('CDS_ASC_ID')),$data_mod);
			$data['message']='<div class="alert alert-success text-center" id="message">'."Modification faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('ihm/Cds_asc/index'));
		}
	}
	function delete()
	{
		$criteres['CDS_ASC_ID']=$this->uri->segment(4);
		$this->Modele->delete('cds_asc',$criteres);
		$data['message']='<div class="alert alert-success text-center" id="message">'."Suppression faite avec succès!".'</div>';
		$this->session->set_flashdata($data);
		redirect(base_url('ihm/Cds_asc/index'));
	}


}

?>
