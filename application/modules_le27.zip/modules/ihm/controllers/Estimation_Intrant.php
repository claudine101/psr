<?php

/**
 *@author jules_ndihokubwayo@mediabox.bi 
 */
class Estimation_Intrant extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		$this->is_auth();
	}
	public function is_auth($value='')
	{
		# code...$this->is_auth();
		if (empty($this->session->userdata('iccm_USER_ID'))) {
			# code...
			redirect(base_url());
		}
	}	
	public function index($value='')
	{
		# code...
		$sql="SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR`,`INTRANT_MEDICAUX_CODE` FROM `intrant_medicaux` WHERE 1 ORDER BY `INTRANT_MEDICAUX_DESCR` ASC";
		$intrant=$this->Modele->getRequete($sql);
		$this->load->view('Estimation_Intrant_View',array('array_intrant_stock'=>$intrant,'title'=>'INTRANTS – Estimation annuelle '.date('Y')));
	}
	public function listing($value='')
	{
		# code...
		$sql  = 'SELECT `INTERVENANT_STRUCTURE_DESCR`,`INTERVENANT_STRUCTURE_ID` FROM `intervenants_structure` iss JOIN type_intervenants_structures tis ON iss.`TYPE_INTERVENANT_STRUCTURE_ID`=tis.TYPE_INTERVENANT_STRUCTURE_ID WHERE tis.CODE_STRUCTURE like "BDS" ORDER BY `INTERVENANT_STRUCTURE_DESCR` ASC';

		$bds=$this->Modele->datatable($sql);
		$array_intrant_stock = $_POST['array_intrant_stock'];
		 $data = array();  

	    foreach ($bds as $key) {	 
            $u=0;
		    $sub_array = array();
		    $sub_array[] = str_replace("DISTRICT", "", $key->INTERVENANT_STRUCTURE_DESCR);
		  foreach ($array_intrant_stock as $row) {

		  	
		  		# code...
		  	   $sql_stck="SELECT `QUANTITE_ANNUEL` FROM `estimation_intrants` WHERE `INTERVENANT_STRUCTURE_ID`=".$key->INTERVENANT_STRUCTURE_ID." AND `ID_INTRANT_MEDICAUX`=".$row['INTRANT_MEDICAUX_ID'];
			   
			   $stk = $this->Modele->getRequeteOne($sql_stck);

		       	$sub_array[]=number_format($stk['QUANTITE_ANNUEL'],0,' ',' ').'<br><span class="tooltipp"><i class="topp"><b>Modifier la valeur</b></i><i style="cursor: pointer;" class="fas fa-edit" onclick="edit_quantity('.$key->INTERVENANT_STRUCTURE_ID.','.$row['INTRANT_MEDICAUX_ID'].','.$stk['QUANTITE_ANNUEL'].')" ></i></span><input type="hidden"  id="QUANTITE_ANNUEL'.$key->INTERVENANT_STRUCTURE_ID.''.$row['INTRANT_MEDICAUX_ID'].'" value="'.$stk['QUANTITE_ANNUEL'].'" style="border:0px;">
		       	    <input type="hidden" id="INTERVENANT_STRUCTURE_DESCR'.$key->INTERVENANT_STRUCTURE_ID.''.$row['INTRANT_MEDICAUX_ID'].'" value="'.$key->INTERVENANT_STRUCTURE_DESCR.'">
					<input type="hidden" id="INTRANT_MEDICAUX_DESCR'.$key->INTERVENANT_STRUCTURE_ID.''.$row['INTRANT_MEDICAUX_ID'].'" value="'.$row['INTRANT_MEDICAUX_DESCR'].'">';

		       	   
               
		    }

            $data[] = $sub_array;

          

		  

		}

		$output = array(
		 // "draw" => intval($_POST['draw']),
		 // "recordsTotal" =>$this->Modele->all_data($query_principal),
		 // "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
	}
	public function update($value='')
	{
		# code...
		$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
        $NOUVEAU_QUANTITE=$this->input->post('NOUVEAU_QUANTITE');
        $ANCIENNE_QUANTITE=$this->input->post('ANCIENNE_QUANTITE');

        $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
        $reponse= $this->Modele->update('estimation_intrants',array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'ID_INTRANT_MEDICAUX'=>$INTRANT_MEDICAUX_ID),    	                          array('QUANTITE_ANNUEL'=>$NOUVEAU_QUANTITE,'QUANTITE_MENSUEL'=>$NOUVEAU_QUANTITE/12));
        $id= $this->Modele->getOne('estimation_intrants',array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID,'ID_INTRANT_MEDICAUX'=>$INTRANT_MEDICAUX_ID));
        $ESTIMATION_ID=$id['ID_ESTIMATION'];
        $QUANTITE_ANNUEL=$ANCIENNE_QUANTITE;
        $estimation_intrants_historique=array('ESTIMATION_ID'=>$ESTIMATION_ID,'QUANTITE_ANNUEL'=>$QUANTITE_ANNUEL);
        $this->Modele->insert_last_id('estimation_intrants_historique',$estimation_intrants_historique);

        if ($reponse) {
        	# code...
        	echo 1;
        }
	}
    public function FunctionName($value='')
    {
    	# code...
    	 $m=$this->mylibrary->get_valeur_mensuelle(26,12);
    	 $m=$this->mylibrary->get_valeur_mensuelle_cds(26,3);
        echo $m;
    }
}



?>