<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: Niyongabire Pacifique (niyodon)
 Date debut :Le 01/2/2021
 Date fin :Le 01/2/2021
 Commentaire: controller pour le CRUD des Types des Intrants
 */

 class Type_Intrants extends CI_Controller
 {

 	public function __construct()
 	{
 		parent::__construct();
 	}

 	public function index()
 	{
 		$data['title']='Liste des types des intrants';
 		$type_intrants=$this->Modele->getList('type_intrants');

 		$tabledata = array();
 		foreach ($type_intrants as $type_intrant ) {

 			$type=array();
 			$type[]=$type_intrant['TYPE_INTRANT_DESCR'];


 			$type['OPTIONS'] = '<div class="dropdown" style="color:#fff;">
 			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog">
 			</i> Options  <span class="caret"></span>
 			</a>
 			<ul class="dropdown-menu dropdown-menu-left">';
 			$type['OPTIONS'] .="<li>
 			<a href='".base_url('ihm/Type_Intrants/update_type_intrant_view/').$type_intrant['TYPE_INTRANT_ID'] ."'>
 			<label class='text-info'>&nbsp;&nbsp;Modifier</label>
 			</a>
 			</li>";
 			$type['OPTIONS'] .="<li>
 			<a href='#' data-toggle='modal' data-target='#mydelete".$type_intrant['TYPE_INTRANT_ID']."'>
 			<label class='text-danger'>&nbsp;&nbsp;Supprimer</label>
 			</a>
 			</li>";



 			$type['OPTIONS'] .= " </ul>
 			</div>
 			<div class='modal fade' id='mydelete".$type_intrant['TYPE_INTRANT_ID']."'>
 			<div class='modal-dialog'>
 			<div class='modal-content'>

 			<div class='modal-body'>
 			<center><h5><strong>Voulez-vous supprimer </strong>?<br> <b style:'background-color:prink';><i style='color:green;'>" . $type_intrant['TYPE_INTRANT_DESCR']."</i></b></h5></center>
 			</div>

 			<div class='modal-footer'>
 			<a class='btn btn-danger btn-md' href='" . base_url('ihm/Type_Intrants/delete_type_intrant/').$type_intrant['TYPE_INTRANT_ID'] . "'>Supprimer</a>
 			<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
 			</div>

 			</div>
 			</div>
 			</div>";

 			$tabledata[]=$type;

 		}

 		$template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
 		$this->table->set_template($template);
 		$this->table->set_heading(array('TYPE D\'INTRANT','ACTIONS'));
 		$data['tableau']=$tabledata;

 		$this->load->view('ihm/Type_Intrants_Listing_View',$data);


 	}

 	public function add_type_intrant_view(){
 		$data['title']='Nouveau type d\'intrant';

 		$this->load->view('ihm/Type_Intrants_Add_View',$data);

	   // $this->page='ihm/Type_Intrants_Add_View';
	   // $this->layout($data);
 	}

 	public function insert_type_intrant(){

 		$this->form_validation->set_rules('description','Description','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		if ($this->form_validation->run()==FALSE) {
 			$this->add_type_intrant_view();
 		} else {

 			$description=$this->input->post('description');

 			$data=array('TYPE_INTRANT_DESCR'=>$description);
 			$sql=$this->Modele->create('type_intrants',$data);
 			if ($sql) {
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Type d\'intrant ajouté avec succès ! .
 				</div>
 				<br>' ;
 			} else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produite ! .
 				</div>
 				<br>' ;
 			}

 			$this->session->set_flashdata($sms) ;
 			redirect('ihm/Type_Intrants');

 		}

 	}


 	public function delete_type_intrant($id){

 		$sql=$this->Modele->delete('type_intrants',array('TYPE_INTRANT_ID'=>$id));
 		if ($sql) {
 			$sms['sms']='<br>
 			<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			Type d\'intrant supprimé avec succès ! .
 			</div>
 			<br>' ;

 		} else {
 			$sms['sms']='<br>
 			<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 			</a><strong> Oup! </strong>
 			Une erreur s\'est produite ! .
 			</div>
 			<br>' ;
 		}

 		$this->session->set_flashdata($sms) ;
 		redirect('ihm/Type_Intrants/index');
 	}

 	public function update_type_intrant_view($id){

 		$data['title']='Formulaire de modification';
 		$data['type_intrants']=$this->Modele->getOne('type_intrants',array('TYPE_INTRANT_ID'=>$id));

 		$this->load->view('ihm/Type_Intrants_Update_View',$data);

  //    $this->page='ihm/Type_Intrants_Update_View';
	 // $this->layout($data);
 	}

 	public function update_type_intrant($id){
 		$this->form_validation->set_rules('description','Description','required',array('required'=>'<font style="color:red;font-size:15px;">Le champs est obligatoire</font>'));
 		if ($this->form_validation->run()==FALSE) {
 			$this->update_type_intrant_view($id);
 		} else {

 			$description=$this->input->post('description');
 			$data=array('TYPE_INTRANT_DESCR'=>$description);
 			$sql=$this->Modele->update('type_intrants',array('TYPE_INTRANT_ID'=>$id),$data);
 			if ($sql) {
 				$sms['sms']='<br>
 				<div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Type d\'intrant modifié avec succès ! .
 				</div>
 				<br>' ;

 			} else {
 				$sms['sms']='<br>
 				<div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
 				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
 				</a><strong> Oup! </strong>
 				Une erreur s\'est produite ! .
 				</div>
 				<br>' ;
 			}
 		}

 		$this->session->set_flashdata($sms) ;
 		redirect('ihm/Type_Intrants');
 	}



 }
