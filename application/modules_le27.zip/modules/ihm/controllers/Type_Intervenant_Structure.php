<?php

/*
Auteur du fichier:Mutunge Ixella
Date debut:le 2/02/2021
Date fin:le 2/02/2021
commentaire: CRUD Type_Intervenant_Structure

**/

defined('BASEPATH') OR exit('No direct script access allowed');

class Type_Intervenant_Structure extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }


  function index()
  {
    $data['error']='';
    $this->listing();
  }

  function nouveau()
  {
    $data['title']='Type Intervenant Structure';
    $this->load->view('Type_Intervenant_Structure_Add_View',$data);

  }

  function listing()
  {
    $sql="SELECT `TYPE_INTERVENANT_STRUCTURE_ID`, `TYPE_INTERVENANT_STRUCTURE_DESCR`, `CODE_STRUCTURE` FROM `type_intervenants_structures` WHERE 1 ORDER BY `TYPE_INTERVENANT_STRUCTURE_ID` ASC";
    // $table="type_intervenants_structures";
    $intervenants=$this->Modele->getRequete($sql);
    $intervenants_array=array();
    foreach ($intervenants as $intervenant) {
     $sub_array_intervenant=array();
     $sub_array_intervenant[]=$intervenant['TYPE_INTERVENANT_STRUCTURE_DESCR'];
     $sub_array_intervenant[]=$intervenant['CODE_STRUCTURE'];


     $sub_array_intervenant['OPTIONS'] = '<div class="dropdown ">
     <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">Action
     <span class="caret"></span></a>
     <ul class="dropdown-menu dropdown-menu-left">
     ';

     $sub_array_intervenant['OPTIONS'] .= "<li><a hre='#' data-toggle='modal'
     data-target='#mydelete" . $intervenant['TYPE_INTERVENANT_STRUCTURE_ID'] . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
     $sub_array_intervenant['OPTIONS'] .= "<li><a class='btn-md' href='" . base_url('ihm/Type_Intervenant_Structure/getOne/'. $intervenant['TYPE_INTERVENANT_STRUCTURE_ID']) . "'>&nbsp;&nbsp;Modifier</a></li>";
     $sub_array_intervenant['OPTIONS'] .= " </ul>
     </div>
     <div class='modal fade' id='mydelete" . $intervenant['TYPE_INTERVENANT_STRUCTURE_ID'] . "'>
     <div class='modal-dialog'>
     <div class='modal-content'>

     <div class='modal-body'>
     <center><h5><strong>Voulez-vous supprimer? </strong><br><b style:'background-color:prink';><i style='color:green;'>" . $intervenant['TYPE_INTERVENANT_STRUCTURE_DESCR']."</i></b></h5></center>
     </div>

     <div class='modal-footer'>
     <a class='btn btn-danger btn-md' href='" . base_url('ihm/Type_Intervenant_Structure/delete/'. $intervenant['TYPE_INTERVENANT_STRUCTURE_ID']) . "'>Supprimer</a>
     <button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
     </div>

     </div>
     </div>
     </div></form>";


     $intervenants_array[]=$sub_array_intervenant;
   }

   $template = array(
    'table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">',
    'table_close' => '</table>'
  );
   $this->table->set_template($template);
   $this->table->set_heading(array('DESCRIPTION','CODE STRUCTURE','ACTIONS'));
   $data['data_Intervenant']=$intervenants_array;
   $data['title'] = "Type Intervenant Structure";
   $this->load->view('Type_Intervenant_Structure_List_View',$data);


 }


 public function add()
 {
   $this->form_validation->set_rules('TYPE_INTERVENANT_STRUCTURE_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
   $this->form_validation->set_rules('CODE_STRUCTURE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

   if ($this->form_validation->run() == FALSE)
   {
     $this->nouveau();
   }

   else
   {
     $data_array=array('TYPE_INTERVENANT_STRUCTURE_DESCR'=>$this->input->post('TYPE_INTERVENANT_STRUCTURE_DESCR'),'CODE_STRUCTURE'=>$this->input->post('CODE_STRUCTURE'));
     $this->Modele->create('type_intervenants_structures',$data_array);

     $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement  type Intervenant <b>".' '.$this->input->post('TYPE_INTERVENANT_STRUCTURE_DESCR').'</b> '." est faite avec succès".'</div>';
     $this->session->set_flashdata($data);
     redirect(base_url('ihm/Type_Intervenant_Structure/listing'));


   }
 }

 public function update()
 {
   $this->form_validation->set_rules('TYPE_INTERVENANT_STRUCTURE_DESCR','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ description est obligatoire</font>'));
   $this->form_validation->set_rules('CODE_STRUCTURE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ description est obligatoire</font>'));

   if ($this->form_validation->run() == FALSE)
   {
     $id=$this->input->post('TYPE_INTERVENANT_STRUCTURE_ID');
    $data['types']=$this->Modele->getOne('type_intervenants_structures',array('TYPE_INTERVENANT_STRUCTURE_ID'=>$id));
     $data['data']=$this->Modele->getOne('type_intervenants_structures',array('TYPE_INTERVENANT_STRUCTURE_ID'=>$id));
     $data['title']='Modifier le Type Intervenant Structure';
     $this->load->view('Type_Intervenant_Structure_Update_View',$data);
    
   }

   else
   {
     $id=$this->input->post('TYPE_INTERVENANT_STRUCTURE_ID');

      $data_array=array('TYPE_INTERVENANT_STRUCTURE_DESCR'=>$this->input->post('TYPE_INTERVENANT_STRUCTURE_DESCR'),'CODE_STRUCTURE'=>$this->input->post('CODE_STRUCTURE'));
     
     $this->Modele->update('type_intervenants_structures',array('TYPE_INTERVENANT_STRUCTURE_ID'=>$id),$data_array);
     $datas['message']='<div class="alert alert-success text-center" id="message">La modification du  '.$this->input->post('TYPE_INTERVENANT_STRUCTURE_DESCR').'</b> Faite avec Succes</div>';
     $this->session->set_flashdata($datas);
     redirect(base_url('ihm/Type_Intervenant_Structure/listing'));
   }

 }
 public function delete()
 {
   $table="type_intervenants_structures";
   $criteres['TYPE_INTERVENANT_STRUCTURE_ID']=$this->uri->segment(4);
   $data['rows']= $this->Modele->getOne( $table,$criteres);
   $this->Modele->delete($table,$criteres);
   $data['message']='<div class="alert alert-success text-center" id="message">'."Le Type <b> ".' '.$data['rows']['TYPE_INTERVENANT_STRUCTURE_DESCR'].' </b> '." est supprimé avec succès".'</div>';
   $this->session->set_flashdata($data);
   redirect(base_url('ihm/Type_Intervenant_Structure/listing'));
 }
 public function getOne()
 {
   $id=$this->uri->segment(4);
   $data['types']=$this->Modele->getOne('type_intervenants_structures',array('TYPE_INTERVENANT_STRUCTURE_ID'=>$id));
   $data['title']='Type Structure Intervenant';
   $this->load->view('Type_Intervenant_Structure_Update_View',$data);
   
 }



}
?>
