<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 Auteur du fichier: NTIRAMPEBA JEAN DE DIEU
 Date debut :Le 12/02/2021
 Commentaire: controller pour Sens de Demande d Intrant
 */
 class Sens_Demande_Intrant extends CI_Controller
 {
  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {

    $sql=$this->Modele->getList('stock_code_sens');

    $tabledata = array();
    $u=1;
    foreach ($sql as $sens_descr) {

      $type=array();
      $type[]=$u++;
      $type[]=$sens_descr['CODE_SENS_DESCR'];


      $type['OPTIONS'] = '<div class="dropdown">
      <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
      <i class="fa fa-cog"></i>
      Options <span class="caret"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-left">';
      $type['OPTIONS'] .="<li>
      <a href='".base_url('ihm/Sens_Demande_Intrant/update_sens_demande_intrant_view/').$sens_descr['CODE_SENS_ID'] ."'>
      <label class='text-info' style='margin-left:20%;'>Modifier</label>
      </a>
      </li>";
      $type['OPTIONS'] .="<li>
      <a href='#' data-toggle='modal' data-target='#mydelete".$sens_descr['CODE_SENS_ID']."'>
      <label class='text-danger' style='margin-left:20%;'>Supprimer</label>
      </a>
      </li>";


      $type['OPTIONS'] .= " </ul>
      </div>
      <div class='modal fade' id='mydelete".$sens_descr['CODE_SENS_ID']."'>
      <div class='modal-dialog'>
      <div class='modal-content'>

      <div class='modal-body'>
      <center>
      <h5><strong>Voulez-vous supprimé le code sens </strong> : <b style:'background-color:prink';>
      <i style='color:green;'>" . $sens_descr['CODE_SENS_DESCR']."</i></b> ?
      </h5>
      </center>
      </div>

      <div class='modal-footer'>
      <a class='btn btn-danger btn-md' href='" . base_url('ihm/Sens_Demande_Intrant/delete_sens_demande_intrant/').$sens_descr['CODE_SENS_ID'] . "'>Supprimer
      </a>
      <button class='btn btn-default btn-md' data-dismiss='modal'>
      Quitter
      </button>
      </div>

      </div>
      </div>
      </div>";

      $tabledata[]=$type;
    }

    $template = array('table_open' => '<table id="mytable" class="table table-bordered table-striped table-hover table-condensed">', 'table_close' => '</table>');
    $this->table->set_template($template);
    $this->table->set_heading(array('CODE SENS','DESCRIPTION DU SENS','ACTION'));
    $data['title']='Liste de sens de demande d\'intrant';
    $data['demandes']=$tabledata;

    $this->load->view('ihm/Sens_Demande_Intrant_List_View',$data);

    // $this->page='ihm/Sens_Demande_Intrant_List_View';
    // $this->layout($data);
  }

  public function add_sens_demande_intrant()
  {

    $data['title']='Ajouter sens de demande d\'intrant';
   $data['DESCRIPTION']=$this->input->post('DESCRIPTION');
   $this->load->view('ihm/Sens_Demande_Intrant_Add_View',$data);
     // $this->page='ihm/Sens_Demande_Intrant_Add_View';
     // $this->layout($data);
 }
 public function _validation()
 {
  $this->form_validation->set_rules('DESCRIPTION','DESCRIPTION','trim|required',array('required'=>'<font style="color:red;font-size:15px;">Le champ est obligatoire</font>'));
}
public function insert_sens_demande_intrant()
{
  $this->_validation();
  if ($this->form_validation->run()==FALSE)
  {
    $this->add_sens_demande_intrant();
  }
  else
  {

    $DESCRIPTION=$this->input->post('DESCRIPTION');
    $data=array('CODE_SENS_DESCR'=>$DESCRIPTION
  );
    $sql=$this->Modele->create('stock_code_sens',$data);
    if ($sql)
    {
      $sms['sms']='<br>
      <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Demande ajouter avec succes ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Demande_Intrant/index');
    }
    else
    {
      $sms['sms']='<br>
      <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Une erreur s\'est produit ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Demande_Intrant/index');
    }

  }
}

public function update_sens_demande_intrant_view($id){

 $data['title']='Editer le sens de demande d\'intrant';
 $data['DESCR']=$this->Modele->getOne('stock_code_sens' ,array('CODE_SENS_ID'=>$id));
 $data['DESCRIPTION']=$this->input->post('DESCRIPTION');

 $this->load->view('ihm/Sens_Demande_Intrant_Update_View',$data);
     // $this->page='ihm/Sens_Demande_Intrant_Update_View';
     // $this->layout($data);


}

public function update_sens_demande_intrant($id)
{
  $this->_validation();
  if ($this->form_validation->run()==FALSE)
  {
    $this->update_sens_demande_intrant_view($id);
  }
  else
  {

    $DESCRIPTION=$this->input->post('DESCRIPTION');
    $data=array('CODE_SENS_DESCR'=>$DESCRIPTION
  );
    $sql=$this->Modele->update('stock_code_sens',$data,array('CODE_SENS_ID'=>$id));
    if ($sql)
    {
      $sms['sms']='<br>
      <div class="alert alert-success text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Demande ajouter avec succes ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Demande_Intrant/index');
    }
    else
    {
      $sms['sms']='<br>
      <div class="alert alert-danger text-center alert-dismissible fade in col-md-8 col-md-offset-2">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
      </a><strong> Oup! </strong>
      Une erreur s\'est produit ! .
      </div>
      <br>' ;
      $this->session->set_flashdata($sms) ;
      redirect('ihm/Sens_Demande_Intrant/index');
    }

  }
}


public function delete_sens_demande_intrant($id)
{
  $this->Modele->delete('stock_code_sens',array('CODE_SENS_ID'=>$id));
  $data['message']='<div class="alert alert-success text-center" id ="message">'."Suppression faite avec succès".'</div>';
  $this->session->set_flashdata($data);
  redirect(base_url('ihm/Sens_Demande_Intrant/index'));
}

}
