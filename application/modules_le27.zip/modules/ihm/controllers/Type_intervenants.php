<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Type_intervenants extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function index()
  {
     $data['title'] ="Nouveau type d'intervenant";
     $this->page = 'Type_intervenants_New';

     $this->layout($data);

    //$data = [];
    //$this->load->view('Type_intervenants_New', $data);
  }

}
