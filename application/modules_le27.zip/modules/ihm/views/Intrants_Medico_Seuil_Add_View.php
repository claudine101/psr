

<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>

 

<style type="text/css">
   .mapbox-improve-map{
    display: none;
  }
  
      .leaflet-control-attribution{
    display: none !important;
}
.leaflet-control-attribution{
    display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php' ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?=$title?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6 text-right">


            <span style="margin-right: 15px">

        <a href="<?= base_url('ihm/Intrants_Medico_Seuil/index')?>" 
        class="btn btn-primary btn-sm pull-right"><i class="fa fa-list"></i>
        Liste
      </a>
              
            </span>
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">




            <div class="col-md-12 col-xl-12 grid-margin stretch-card">

              <div class="card">
                <div class="card-body">



                  <div class="row">
  <div class="col-md-12">
    <form action="<?= base_url('ihm/Intrants_Medico_Seuil/insert_intrant_seuil')?>" method="post">

      <div class="row">
        <div class="col-md-6">
           <label>Structures des Intervenants :</label>
           <select class="form-control" name="intervenants_structures">
            <option value="">--select structure--</option>
<?php foreach ($intervenants_structures as $intervenants_structure) {     
  if (set_value('intervenants_structures')==$intervenants_structure['TYPE_INTERVENANT_STRUCTURE_ID']) { ?>
    <option selected value="<?= $intervenants_structure['TYPE_INTERVENANT_STRUCTURE_ID'];?>">
        <?= $intervenants_structure['TYPE_INTERVENANT_STRUCTURE_DESCR'];?> 
    </option>
<?php  } else {  ?>
   <option value="<?= $intervenants_structure['TYPE_INTERVENANT_STRUCTURE_ID'];?>">
      <?= $intervenants_structure['TYPE_INTERVENANT_STRUCTURE_DESCR'];?> 
   </option>
<?php  }
  
          
 }  ?>
           </select>
           <label style="color:red;"><?php echo form_error('intervenants_structures'); ?></label>
        </div>
        <div class="col-md-6">
           <label>Intrant Medicaux:</label>
           <select class="form-control" name="intrant">
            <option value="" selected="">--select intrant--</option>
<?php foreach ($intrants as $intrant) {      
  if (set_value('intrant')==$intrant['INTRANT_MEDICAUX_ID']) {  ?>
    <option selected value="<?= $intrant['INTRANT_MEDICAUX_ID'];?>">
      <?= $intrant['INTRANT_MEDICAUX_DESCR'];?> 
    </option>
<?php  } else {  ?>
    <option value="<?= $intrant['INTRANT_MEDICAUX_ID'];?>">
      <?= $intrant['INTRANT_MEDICAUX_DESCR'];?> 
    </option>
<?php  }
  
          
 }  ?>
           </select>
           <label style="color:red;"><?php echo form_error('intrant'); ?></label>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
           <label>Quantite Seuil :</label>
           <input type="number" value="<?=set_value('quantite_seuil');?>" class="form-control" name="quantite_seuil">
           <label style="color:red;"><?php echo form_error('quantite_seuil'); ?></label>
        </div>
        <div class="col-md-6">
          <button type="submit" class="btn btn-primary form-control" style="margin-top: 25px;">
            Enregistrer
          </button>
        </div>
      </div>
    </form>
  </div>
</div>





   </div>
              </div>
            </div>
           
          </div>
        
        <!-- Rapport partie -->

     

        <!-- End Rapport partie -->
          
        </div>
          </div>
            </div>          
          </div>

     
    </section>


    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>


