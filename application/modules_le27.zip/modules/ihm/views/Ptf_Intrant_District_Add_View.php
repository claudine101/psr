<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php' ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php' ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php' ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h5 class="m-0"><?=$title?></h5>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">

              <span style="margin-right: 15px">
               <a href="<?= base_url('ihm/Ptf_Intrant_District/'); ?>" class="btn btn-primary btn-sm pull-right">
                <i class="fa fa-list"></i>
                Liste
              </a>
              
            </span>



          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">




      <div class="col-md-12 col-xl-12 grid-margin stretch-card">

        <div class="card">

          <div class="card-body">




           <form name="myform" method="post" class="form-horizontal" action="<?= base_url('ihm/Ptf_Intrant_District/add');?>" >
            <div class="row">
              
          <!--   <div class="col-md-6">
              <label for="">PTF</label>
              <select class="form-control" name="PTF_ID" id="PTF_ID"> value="<?=set_value('PTF_ID') ?>">
                <option value="">Séléctionner</option>
                <?php 
                foreach ($ptf as $key_ptf) 
                {
        # code...
                  ?>
                  <option value="<?= $key_ptf['PTF_ID'] ?>"><?= $key_ptf['INTERVENANT_STRUCTURE_DESCR'] ?></option>
                  <?php
                }

                ?>
              </select>
              <?php echo form_error('PTF_ID', '<div class="text-danger">', '</div>'); ?> 

            </div> -->

            <div class="col-md-6">
              <label for="LName">PTF</label>
              
              <select class="form-control" name="PTF_ID" id="PTF_ID">
                
                <option value="">Sélectionner</option>
                <?php 
                foreach ($ptf as $key_ptf) 
                {
                  if ($key_ptf['INTERVENANT_STRUCTURE_ID']==set_value('PTF_ID')) 
                    {?>
                      <option value="<?= $key_ptf['INTERVENANT_STRUCTURE_ID'] ?>" selected><?= $key_ptf['INTERVENANT_STRUCTURE_DESCR'] ?></option>
                    <?php } else {?>
                      <option value="<?= $key_ptf['INTERVENANT_STRUCTURE_ID'] ?>"><?= $key_ptf['INTERVENANT_STRUCTURE_DESCR'] ?></option>
                      <?php 
                    }
                  }

                  ?>

                </select>
                <?php echo form_error('PTF_ID', '<div class="text-danger">', '</div>'); ?> 

              </div> 


              <div class="col-md-6">
                <label for="">BDS</label>
                <select class="form-control selectpicker" name="BDS_ID" id="BDS_ID" onchange='annee()'>
                  <option value="">Sélectionner</option>
                  <?php 
                  foreach ($districts as $key_district) {

                    if ($key_district['INTERVENANT_STRUCTURE_ID']==set_value('BDS_ID')) {

                      ?>
                      <option value="<?=$key_district['INTERVENANT_STRUCTURE_ID'] ?>"selected><?=$key_district['INTERVENANT_STRUCTURE_DESCR'] ?></option>
                      <?php 
                    }else{
                      ?>
                      <option value="<?=$key_district['INTERVENANT_STRUCTURE_ID'] ?>"><?=$key_district['INTERVENANT_STRUCTURE_DESCR'] ?></option>

                      <?php
                    }
                  }

                  ?>
                </select>
                <?php echo form_error('BDS_ID', '<div class="text-danger">', '</div>'); ?> 

              </div>
            </div>
            <div class="row">
              
             <div class="col-md-6">
              <label for="">INTRANT MEDICAL</label>
              
              <select id="ID_VILLE" name="INTRANT_MEDICAUX_ID[]" class="form-control select2 selectpicker"  multiple="multiple"  data-live-search="true" value="<?=set_value('INTRANT_MEDICAUX_ID') ?>">
                <option value="">Sélectionner</option>
                <?php
                foreach ($intrant_medicaux as $key_intrant) {

                  if(in_array($key_intrant['INTRANT_MEDICAUX_ID'],$exist)) 
                    {  ?>
                     <option value="<?=$key_intrant['INTRANT_MEDICAUX_ID']?>" selected><?=$key_intrant['INTRANT_MEDICAUX_DESCR']?></option> 
                   <?php   } else {
                     echo "<option value=".$key_intrant['INTRANT_MEDICAUX_ID']." >".$key_intrant['INTRANT_MEDICAUX_DESCR']." </option>";
                   }
                 }
                 ?>       
               </select>

               <?php echo form_error('INTRANT_MEDICAUX_ID[]', '<div class="text-danger">', '</div>'); ?> 

             </div>
             <div class="col-md-6" style="margin-top: 31px;" >
              <button  type="submit" style="float: right;" class="btn btn-primary"><span class="fa fa-save"></span> Enregistrer </button>
            </div>
          </div>
        </form>


      </div>
    </div>
  </div>

</div>

<!-- Rapport partie -->



<!-- End Rapport partie -->

</div>
</div>
</div>          
</div>


</section>


<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>




<script type="text/javascript">
 $(document).ready(function () {
   var row_count ="1000000";
   $("#mytable").DataTable({

     "paging": true,
     "lengthChange": true,
     "searching": true,
      //"ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,

      lengthMenu: [[5,10,50, 100, row_count], [5,10,50, 100, "All"]],
      pageLength: 5,
      "columnDefs":[{
        "targets":[],
        "orderable":false
      }],

      dom: 'Bfrtlip',
      buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
      ],
      language: {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      }


    });
 });

</script>
