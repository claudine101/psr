<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php'; ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php'; ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-9">
            <h1 class="m-0"><?=$title?></h1>
          </div><!-- /.col -->
          <div class="col-sm-3">
            <a href="<?=base_url('stock_reception/Reception')?>" class='btn btn-primary float-right'>
              <i class="nav-icon fas fa-plus"></i>
              Nouvelle
            </a>
          </div><!-- /.col -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
<section class="container" >

<div class="card" >
<?=  $this->session->flashdata('message');?>

<div class="container-fluid">
 <div class="col-5" style="padding: 5px;">
   <label for="PTF_ID">PTF</label>
   <select  class="form-control"  id="PTF_ID" onclick="get_list(this.value)">
    <option value="" selected="">sélectionner</option>
          <?php foreach ($ptf as $key) {
          ?>
          <option value="<?= $key['TYPE_INTERVENANT_STRUCTURE_ID'] ?> "><?= $key['TYPE_INTERVENANT_STRUCTURE_DESCR'] ?></option>

          <?php } ?>
   </select>
 </div> 
 <br>

  <div class="col-md-12 table-responsive">
    <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
      <thead>
        <tr>
          <th>#</th>
          <th>STRUCTURE</th>
          <th>PROVINCE</th>
          <th>COMMUNE</th>
          <th>COLLINE</th>
          <th>TELEPHONE</th>
          <th>EMAIL</th>
          <th>OPTION</th>
        </tr>
      </thead>
    </table>  
  </div>
  
    
</div>
</div>
<!-- ************************************** -->

      

      
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>

<script type="text/javascript">
  $(document).ready(function(){ 
     $("#message").delay("slow").fadeOut(3000);
    get_list();


  });
  function get_list(ID) {
  // body...
    var PTF_ID=ID;

    var row_count ="1000000";

   $("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
       "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
            url:"<?=base_url()?>administration/Structure_Intervenants_List/listing",
            type:"POST",
            data : {
               
               PTF_ID:PTF_ID,


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[],
            "orderable":false
        }],

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });
}
</script>

