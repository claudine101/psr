

<div class="row">
  	<div>
  	  <h3>Liste des Provinces Sanitaire</h3>	
  	</div>
  	<div class="pull-right">
	  	<a href="<?= base_url('Provinces/Add_province')?>" class="btn btn-primary">
	  	  Ajouter
	  	</a>
    </div>
  <div class="table">
  	<table class="table table-responsive">
  	  <thead>
        <tr>
	        <th>Code</th>
	  	  	<th>Province</th>
	  	  	<th>Latitude</th>
	  	  	<th>Latitude</th>
	  	  	<th>Action</th>
        </tr>
  	  </thead>
  	  <tbody>
<?php foreach ($data as $value) { ?>
	  <tr>
  	  	 <td><?=$value['PROVINCE_CODE'];?></td>
  	  	 <td><?=$value['PROVINCE_NOM'];?></td>
  	  	 <td><?=$value['LATITUDE'];?></td>
  	  	 <td><?=$value['LONGITUDE'];?></td>
  	  	 <td>
  	  	   <a href="<?=base_url('Provinces/Update_view/').$value['PROVINCE_ID']?>" class="btn btn-primary">Modifier</a>

  	  	   <a href="<?= base_url('Provinces/Delete_Province/').$value['PROVINCE_ID']?>" class="btn btn-danger">Supprimer</a>
  	  	 </td>
  	  </tr>
<?php } ?>
  	  </tbody>	
  	</table>
  </div>
</div>
