

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('Provinces/Supprimer')?>" method="post">
        <div class="col-md-6">
           <label>Code:</label>
           <input type="text" value="<?=$province['PROVINCE_CODE'];?>"class="form-control" name="code">
        </div>
        <div class="col-md-6">
           <label>Nom:</label>
           <input type="text"value="<?=$province['PROVINCE_NOM'];?>"class="form-control" name="nom">
        </div>
        <div class="col-md-6">
           <label>Latitude :</label>
           <input type="text" value="<?=$province['LATITUDE'];?>"class="form-control" name="latitude">
        </div>
        <div class="col-md-6">
           <label>Longitude :</label>
           <input type="text" value="<?=$province['LONGITUDE'];?>" class="form-control" name="longitude">
        </div>
        <br><br>
      	<div> 
      	  <input type="submit" class="btn btn-primary" name="submit" value="Supprimer">
       	</div>
    </form>
  </div>
</div>