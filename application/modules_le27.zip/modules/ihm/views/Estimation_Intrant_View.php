
<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->
<style type="text/css">
  .bordersolid{
    border-style: solid;
    border-color: gray;
    border-width: 1px;
  }
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
</style>
  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php'; ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-6">
          <h1 class="m-0"><?=$title?></h1>
    <!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

<section class="container">
<!-- ************************************************************************************************** -->

<!-- small modal -->
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content" >
      <div class="row" style="padding: 30px;">
        <span id="structure"></span>
        <i id="intran"></i>
        <input type="number" id="QUANTITE" value="0">
         <input type="hidden" id="ANCIENNE_QUANTITE" value="0">
         <input type="hidden" id="STRUCTURE_ID" value="0">
         
         <input type="hidden" id="INTRANT_ID" value="0">

        <button class=" fa fa-edit" onclick="update_estimation()" id="btn_update_estimation"></button>
        <span id="error_span"></span>
      </div>
      
    </div>
  </div>
</div>


<!-- #############################################################
 -->
<div class="card" >
<div class="container-fluid">
<div class="row">
  <div class="col-12 table-responsive" style="padding: 25px;">
    <table id='mytable' class="table table-bordered table-striped table-hover table-condensed table-sm">
      <thead>
        <tr>
          <th>BDS</th>
          <?php 

           foreach ($array_intrant_stock as $key) {
            # code...
           ?>
 <!--          <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="<?= $key['INTRANT_MEDICAUX_CODE'] ?>"> -->

          <th>
          <span class="tooltipp">
            <p class="topp"><b>
            <?= $key['INTRANT_MEDICAUX_DESCR'] ?></b>
            </p>            
            <?= str_replace("-", "", $key['INTRANT_MEDICAUX_CODE']) ?></th>
          </span>
          <?php } ?>
        <!--   </span> -->
          
        </tr>
      </thead>

    </table>

  </div>




</div>
  
</div>
<!-- ********************************************************************************************** -->
</div>

      
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">

 $(document).ready(function(){
 $('#app_title').html('Estimations <?= date('Y').' '.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_DESCR')?>');
   get_liste();

   //$('#mytable_length').hide();
   //$('#mytable_info').hide();
   //$("input, textarea").prop("readonly", true);

 });
</script>

<script type="text/javascript">
  function edit_quantity(INTERVENANT_STRUCTURE_ID,INTRANT_MEDICAUX_ID,QUANTITE_ANNUEL) {
    // body...
    // alert(INTERVENANT_STRUCTURE_ID);
    // alert(INTRANT_MEDICAUX_ID);
    // alert(QUANTITE_ANNUEL);
    $('.modal').modal();
    $('#QUANTITE').val(QUANTITE_ANNUEL);
    var INTERVENANT_STRUCTURE_DESCR=$('#INTERVENANT_STRUCTURE_DESCR'+INTERVENANT_STRUCTURE_ID+INTRANT_MEDICAUX_ID).val();
    var INTRANT_MEDICAUX_DESCR=$('#INTRANT_MEDICAUX_DESCR'+INTERVENANT_STRUCTURE_ID+INTRANT_MEDICAUX_ID).val();
    $('#intran').html();
    $('#structure').html(INTERVENANT_STRUCTURE_DESCR);
    $('#intran').html(INTRANT_MEDICAUX_DESCR);
    $('#INTRANT_ID').val(INTRANT_MEDICAUX_ID);
    $('#STRUCTURE_ID').val(INTERVENANT_STRUCTURE_ID);
    $('#ANCIENNE_QUANTITE').val(QUANTITE_ANNUEL);
  }
function update_estimation() {
    // body...
    var INTERVENANT_STRUCTURE_ID=Number($('#STRUCTURE_ID').val());
    var ANCIENNE_QUANTITE=Number($('#ANCIENNE_QUANTITE').val());
    var INTRANT_MEDICAUX_ID=Number($('#INTRANT_ID').val());
    var NOUVEAU_QUANTITE=Number($('#QUANTITE').val());
    if (NOUVEAU_QUANTITE>0  && INTERVENANT_STRUCTURE_ID>0&& INTRANT_MEDICAUX_ID>0) {
      $("#btn_update_estimation").prop("readonly", true);
      $('.modal').modal({ backdrop: false });

      $.post('<?php echo base_url();?>ihm/Estimation_Intrant/update',
      {
        INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
        NOUVEAU_QUANTITE:NOUVEAU_QUANTITE,
        ANCIENNE_QUANTITE:ANCIENNE_QUANTITE,
        INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID
        
        },
        function(data) 
        { 
           if (data="1" || data==1) {
            $('#error_span').html('<span class="text-info hide_msg">Opération réussi!</span>');
            $('.modal').modal('hide');
            get_liste();
          //  $('.modal').hide();
            $('#error_span').html('');
            $("#btn_update_estimation").prop("readonly", false);

           }

        });       
    }else if (NOUVEAU_QUANTITE<0) {
      $('#error_span').html('<span class="text-danger hide_msg">Veuillez saisir la quantité valide</span>');
    }

}
  function get_liste() { 



    var row_count=1000000; 

    var table = $('#mytable').DataTable({ 
        "ajax":{
            url:"<?=base_url()?>ihm/Estimation_Intrant/listing/",
            type:"POST",
            data : {
               
               array_intrant_stock : <?= json_encode($array_intrant_stock) ?>,


            }
        },
       "scrollX": false,
       "destroy" : true, 
       'columnDefs': [{
       'stateSave': true,
       'bDestroy': true,
       'processing':true,
       'serverSide':true,
       'searchable': false,
       'orderable': false,
       'className': 'dt-body-center', 
       

     }],

     dom: 'Bfrtlip',
     lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
     exportOptions: { columns: [ 0, 1,2,3,4,5,6]  },
     pageLength: 10,
     buttons: ['excel', 'pdf', 'print'  ],
    language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            },
    'order': [[0, 'asc']]
  });


    $('#mytable').on('processing.dt', function (e, settings, processing) {
      if (processing) {

      } else {
      //  $("#test").modal('hide');

    }
  });
  }
</script>

