
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
.mapbox-improve-map{
  display none;
}

.leaflet-control-attribution{
  display none !important;
}
.leaflet-control-attribution{
  display none !important;
}


.mapbox-logo {
  display none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<!-- Navbar -->
<?php include VIEWPATH.'templates/navbar.php'; ?>

<!-- /.navbar -->

<!-- Main Sidebar Container -->
<?php include VIEWPATH.'templates/sidebar.php'; ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0"><?=$title?></h1>
        </div><!-- /.col -->
        <div class="col-sm-6 text-right">


          <span style="margin-right 15px">

           <a class="btn btn-primary btn-sm pull-right" href="<?= base_url('ihm/Intrants_Medico/index')?>">
            <i class="fa fa-list"></i> Liste
          </a>

        </span>

      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">




  <div class="col-md-12 col-xl-12 grid-margin stretch-card">

    <div class="card">
      <div class="card-body">

        <div class="row">
          <div class="col-md-12">
            <form action="<?= base_url('ihm/Intrants_Medico/insert_intrant')?>" method="post">
             <div class="row">
              <div class="col-md-6">
               <label>Degré d'Humidité <span style="color: red;">*</span> </label>
               <input type="text" autocomplete="off" value="<?= set_value('degre');?>" class="form-control" name="degre">
               <label style="color:red;"><?php echo form_error('degre'); ?></label>
             </div>
             <div class="col-md-6">
               <label>Description <span style="color: red;">*</span></label>
               <input type="text" autocomplete="off" value="<?= set_value('description');?>" class="form-control" name="description">
               <label style="color:red;"><?php echo form_error('description'); ?></label>

             </div>
             
<!--              <div class="col-md-6">
               <label>Quantité seuil <span style="color: red;">*</span></label>
               <input type="number" autocomplete="off" step="any" value="<?= set_value('seuil');?>" class="form-control" name="seuil">
               <label style="color:red;"><?php echo form_error('seuil'); ?></label>
             </div>
             <div class="col-md-6">
               <label>Quantité de BDS </label>
               <input type="number" autocomplete="off" step="any" value="<?= set_value('QUANTITE_SEUIL_BDS');?>" class="form-control" name="QUANTITE_SEUIL_BDS">
               
             </div>

             <div class="col-md-6">
               <label>Quantité de CDS </label>
               <input type="number" autocomplete="off" step="any" value="<?= set_value('QUANTITE_SEUIL_CDS');?>" class="form-control" name="QUANTITE_SEUIL_CDS">
             </div> -->


             <div class="col-md-6">
               <label>Température minimale de conservation <span style="color: red;">*</span></label>
               <input type="number" autocomplete="off" step="any" value="<?= set_value('min');?>" class="form-control" name="min">
               <label style="color:red;"><?php echo form_error('min'); ?></label>
             </div>
             <div class="col-md-6">
               <label>Température maximale de conservation <span style="color: red;">*</span></label>
               <input type="number" autocomplete="off" step="any" value="<?= set_value('max');?>" class="form-control" name="max">
               <label style="color:red;"><?php echo form_error('max'); ?></label>
             </div>



             <div class="col-md-6">
               <label>Type d'Intrant <span style="color: red;">*</span></label>
               <select class="form-control" name="type">
                <option value="<?= set_value('type');?>" selected>--select type--</option>
                <?php foreach ($type_intrants as $type_intrant) {       ?>
                  <option value="<?= $type_intrant['TYPE_INTRANT_ID'];?>">
                    <?= $type_intrant['TYPE_INTRANT_DESCR'];?> 
                  </option>
                  <?php }  ?>
                </select>

                <label style="color:red;"><?php echo form_error('type'); ?></label>
              </div>

              <div class="col-md-6">
               <label>Mode de réception</label>
               <select class="form-control" name="MODE_RECEPTION_ID">
                <option value="0" selected>--mode--</option>

                <?php
                foreach ($modes as $key) 
                {
                  if ($key['MODE_RECEPTION_ID']==set_value('MODE_RECEPTION_ID')) 
                  {?>
                    <option value="<?=$key['MODE_RECEPTION_ID']?>" selected=''><?=$key['MODE_RECEPTION_DESCR']?></option>
                  <?php }else{?>
                    <option value="<?=$key['MODE_RECEPTION_ID']?>"><?=$key['MODE_RECEPTION_DESCR']?></option>
                  <?php }
                  }
                  ?>
                  
                </select>
                
                
              </div>


              <div class="col-md-6">
               <label>Unité d'Intrant </label>
               <select class="form-control" name="unite">
                <option value="<?= set_value('unite');?>" selected>--select unite--</option>
                <?php foreach ($unite_intrants as $unite_intrant) {       ?>
                  <option value="<?= $unite_intrant['INTRANT_UNITE_ID'];?>">
                    <?= $unite_intrant['INTRANT_UNITE_DESCR'];?> 
                  </option>
                  <?php }  ?>
                </select>
                <label style="color:red;"><?php echo form_error('unite'); ?></label>
              </div>
              <div class="col-md-6">
                <label>Nbre de dose</label>
                <input type="number" autocomplete="off" step="any" name="NOMBRE_DOSE" class="form-control">
              </div>
              <div class="col-md-2" style="margin-top:31px;">
                <button type="submit" class="btn btn-primary"><span class="fas fa-save"></span> Enregistrer</button>
              </div>
            </div>
          </form>
        </div>
      </div>



    </div>
  </div>
</div>

</div>

<!-- Rapport partie -->



<!-- End Rapport partie -->

</div>
</div>
</div>          
</div>


</section>


<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
