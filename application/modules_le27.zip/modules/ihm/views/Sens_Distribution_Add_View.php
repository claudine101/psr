<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>

 

<style type="text/css">
   .mapbox-improve-map{
    display: none;
  }
  
      .leaflet-control-attribution{
    display: none !important;
}
.leaflet-control-attribution{
    display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php' ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?=$title?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6 text-right">


            <span style="margin-right: 15px">

          <a class="btn btn-primary" href="<?= base_url('ihm/Sens_Distribution/index')?>">
         <i class="fa fa-list"></i> Liste
       </a>
              
            </span>
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">




            <div class="col-md-12 col-xl-12 grid-margin stretch-card">

              <div class="card">
                <div class="card-body">



<div class="row">
  <div class="col-md-12">
    <form action="<?= base_url('ihm/Sens_Distribution/insert_sens_distribution')?>" method="post">
      <div class="row">
        <div class="col-md-5">
           <label>Demande sens description :</label>
           <input type="text" class="form-control" name="DEMANDE_SENS" value="<?=set_value('DEMANDE_SENS')?>">
           <label style="color:red;"><?php echo form_error('DEMANDE_SENS'); ?></label>
        </div>
        <div class="col-md-5 col-sm-12 col-xs-12">
           <label>Sens de distribution:</label>
           <select class="form-control" name="DISTRIBUTION" >
             <option value="">--choisir--</option>
             <?php
             foreach ($stock as $key)
             {
                if ($DISTRIBUTION==$key['CODE_SENS_ID']) {?>
                 <option value="<?=$key['CODE_SENS_ID']?>" selected=''><?=$key['CODE_SENS_DESCR']?></option>
                <?php } else {?>
                  <option value="<?=$key['CODE_SENS_ID']?>"><?=$key['CODE_SENS_DESCR']?></option>
                <?php }

              }
             ?>
           </select>
           <font color='red'><?php echo form_error('DISTRIBUTION'); ?></font>
         </div>
         <div class="col-md-2" style="margin-top:31px;">
          <button type="submit" class="btn btn-primary"><span class="fas fa-save"></span> Enregistrer</button>
           <!-- <input type="submit" name="" class="btn btn-primary" value="mmm"> -->
        </div>
      </div>
    </form>
  </div>
</div>



   </div>
              </div>
            </div>
           
          </div>
        
        <!-- Rapport partie -->

     

        <!-- End Rapport partie -->
          
        </div>
          </div>
            </div>          
          </div>

     
    </section>


    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>


