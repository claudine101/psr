<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-12">
              <!-- <h4 class="m-0"><?=$title?></h4> -->
              <?php
              $menu1="nav-link";
              $menu2="nav-link active";
              $menu3="nav-link"; 
              $menu4="nav-link"; 
              $menu5="nav-link"; 
              $menu6="nav-link"; 
              include VIEWPATH.'sousmenu/sous_menu_deces.php'; ?>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">


              <span style="margin-right: 15px">


              </span>

            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-12">
            <!-- Custom Tabs -->
            <div class="card">
               <div class="col-12" id="message"></div>

                <div class="card-body" style="overflow-x: auto;" >
                  <div style="padding-top: 5px;" class="col-md-12">
                    <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                      <thead>
                        <tr>
                          <!-- <th>#</th> -->
                          <th>STRUCTURE</th>
                          <th>Q.DISPO</th>
                          <th>SEUIL</th>
                          <th>INTRANT</th>
                          <th>TICKET</th>
                          <th>STATUS</th>
                          <th>DATE</th>
                          <th>OPTION</th>
                        </tr>
                      </thead>

                    </table>


                  </div>


                </div>
             

            </div>
            <!-- ./card -->
          </div>
          <!-- /.col -->
        </div>
      </section>
      <!-- /.content -->
    </div>

  </div>
  <!-- ./wrapper -->
  <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>


<script>

  var table;
  $(document).ready(function(){

    // var ID_STATUT_TICKET=$("#COMPTEUR").val();
    // var i=$("#COMPTEUR1").val();
    // get_stock_rupture(ID_STATUT_TICKET,i);
    get_stock_rupture();

   
  });


  function show_traiter(ID_STOCK_RUPTURE_TICKET,ID_STATUT_TICKET) {
    // body...
  $('#ID_STOCK_RUPTURE_TICKET').val(ID_STOCK_RUPTURE_TICKET);
  $.post('<?php echo base_url();?>ihm/Stock_Rupture_Ticket/get_statut/',
  {
    ID_STATUT_TICKET:ID_STATUT_TICKET
    
    },
    function(data) 
    { 

    if (data) {
       ID_STATUT_TICKET.innerHTML = data; 
      $('#ID_STATUT_TICKET').html(data);
      $('#traiter_modal').modal();
    }


    }); 
  }




  function traiter() {
  // body...
  var ID_STOCK_RUPTURE_TICKET=$('#ID_STOCK_RUPTURE_TICKET').val();
  // document.getElementById("COMPTEUR1").value=i;
  var ID_STATUT_TICKET=$('#ID_STATUT_TICKET').val();
  var COMMENTAIRE=$('#COMMENTAIRE').val().trim();
  if (Number(ID_STATUT_TICKET)>1 && COMMENTAIRE!="") {
    $('#traiter_modal').modal({ backdrop: false });
   $('#message_ret').html('<div class="alert alert-info">Opération en cours...</div>')
   
   $('#do_act').attr('disabled', true);
   
  $.post('<?php echo base_url();?>ihm/Stock_Rupture_Ticket/update_statut/',
  {
    ID_STOCK_RUPTURE_TICKET:ID_STOCK_RUPTURE_TICKET,
    ID_STATUT_TICKET:ID_STATUT_TICKET,
    COMMENTAIRE:COMMENTAIRE
    
    },
    function(data) 
    { 
      if (data) {
     $('#message_ret').html('<div id="message" class="alert alert-success">Opération réussi avec succes</div>')
     // get_list();
     // get_stock_rupture(ID_STATUT_TICKET);
     table.ajax.reload(null,false);
     setTimeout(function(){ 
      $('#traiter_modal').modal({ backdrop: true });
      $('#traiter_modal').modal('hide');
      $('#do_act').attr('disabled', false);
      $("#message").delay("slow").fadeOut(3000);
      }, 3000);
}

    });
}

if (Number(ID_STATUT_TICKET)==1) {
$('#message_ret').html('<div id="message" class="alert alert-danger">Veillez changer le statut</div>');
}

if(COMMENTAIRE==""){
      // show_intrant();
       $('#message_ret').html('<div id="message" class="alert alert-danger">Tous les champs sont requis</div>');
       //$('#traiterticket').modal();
}

}



// function get_stock_rupture(ID_STATUT_TICKET=0,i=0)

  function get_stock_rupture()
  {

    
      var row_count ="1000000";
      table=$("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
        "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
          url:"<?=base_url()?>ihm/Stock_Rupture_Ticket/getInfo",
          type:"POST"
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
        pageLength: 10,
        "columnDefs":[{
          "targets":[],
          "orderable":false
        }],

        dom: 'Bfrtlip',
        buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        language: {
          "sProcessing":     "Traitement en cours...",
          "sSearch":         "Rechercher&nbsp;:",
          "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
          "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
          "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
          "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
          "sInfoPostFix":    "",
          "sLoadingRecords": "Chargement en cours...",
          "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
          "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
          "oPaginate": {
            "sFirst":      "Premier",
            "sPrevious":   "Pr&eacute;c&eacute;dent",
            "sNext":       "Suivant",
            "sLast":       "Dernier"
          },
          "oAria": {
            "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
            "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
          }
        }

      });

    }





// HISTORIQUE
  function show_historique(ID_STOCK_RUPTURE_TICKET) {
    // body...
  
  $.post('<?php echo base_url();?>ihm/Stock_Rupture_Ticket/get_histo/',
  {
    ID_STOCK_RUPTURE_TICKET:ID_STOCK_RUPTURE_TICKET
    
    },
    function(data) 
    { 

    if (data) {
       HISTO.innerHTML = data; 
      $('#HISTO').html(data);
      $('#histo_modal').modal();
    }


    }); 
  }


</script>


<div class="col-md-12 table-responsive" style="padding: 30px;">
<div class="modal fade" id="traiter_modal" tabindex="-1" role="dialog" aria-labelledby="traiterticketLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="traiterticketLabel">Traitement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
       
      </div>
     
      <div class="modal-body">
        <div class="row" id="message_ret"></div>
        <form>
          <div class="form-group">
            <input type="hidden" id="ID_STOCK_RUPTURE_TICKET">
            <label for="ID_STATUT_TICKET" class="col-form-label">Statut</label>
            <select class="form-control" id="ID_STATUT_TICKET"></select>
          </div>
          <div class="form-group">
            <label for="COMMENTAIRE" class="col-form-label">Commentaire</label>
            <textarea class="form-control" id="COMMENTAIRE"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
<!--         <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
 -->        <button type="button" id="do_act" class="btn btn-primary" onclick="traiter()">Traiter</button>
      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="histo_modal" tabindex="-1" role="dialog" aria-labelledby="histo_modalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="histo_modalTitle">Historique de Traitement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="HISTO">
              
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
      </div>
    </div>
  </div>
</div>
  

</div>

