<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url('assets/bootstrap/')?>bootstrap.min.js"></script>
<legend>RECEPTION DES INTRANTS</legend> -->
<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php'; ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php'; ?>

<style type="text/css">
  table.datatable {
  width:100%;
  border: none;
  background:#fff;
}
table.datatable td.table_foot {
  border: none;
  background: #fff;
  text-align: center;
}
table.datatable tr.odd_col {
  background: none;
}
table.datatable tr.even_col {
  background: #ddd;
}
table.datatable td {
  font-size:10pt;
  padding:5px 10px;
  border-bottom:1px solid #ddd;
  text-align: left;
}
table.datatable th {
  text-align: left;
  font-size: 8pt;
  padding: 10px 10px 7px;   
  text-transform: uppercase;
  color: #fff;
  background-color: black;
  font-family: sans-serif;
}
</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <!-- <h1 class="m-0"><?=$title?></h1> -->
              <?php
              $menu1="nav-link";
              $menu2="nav-link";
              $menu3="nav-link"; 
              $menu4="nav-link"; 
              $menu5="nav-link active"; 
              $menu6="nav-link"; 
              include VIEWPATH.'sousmenu/sous_menu_deces.php'; ?>
          </div><!-- /.col -->
        </div>
      </div><!-- /.container-fluid -->
    </section>
<section class="container" >
<!-- ************************************************************************************************** -->
<div class="card" >

<div id="modal" class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content" id="message_ret">
      
    </div>
  </div>
</div>
<!-- fin modal comite -->
<div class="container-fluid">

 <br>

  <div class="col-md-12 table-responsive">
<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="traite-tab" data-toggle="tab" href="#traite" role="tab" aria-controls="traite" aria-selected="true" onclick="show_intrant()">Demande non prise en charge</a>
  </li>
  <?php if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS"|| $this->session->userdata('iccm_PROFIL_CODE')=="CDS" ) {
    # code...
   ?>
  <li class="nav-item">
    <a class="nav-link" id="non_traite-tab" data-toggle="tab" href="#non_traite" role="tab" aria-controls="non_traite" aria-selected="false" onclick="get_list()">Demande prise en charge</a>
  </li>
<?php } ?>

</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="traite" role="tabpanel" aria-labelledby="traite-tab">
    <br><table id="mytable_1" class="table table-striped table-bordered">
            <thead>
        <tr>
          <th>#</th>
          <th>INTRANT</th>
          <th>SEUIL</th>
          <th>QTE.DISPONIBLE</th>
          <th>QUANTITE(Seuil+5%)</th>
          <?php if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS" || $this->session->userdata('iccm_PROFIL_CODE')=="CDS") { ?>
          <th>OPTION</th>
          <?php } ?>
          <th>DATE</th>
        </tr>
            </thead>

      <tbody id="dem_intant">
      
   </table>
  </div>
  <div class="tab-pane fade" id="non_traite" role="tabpanel" aria-labelledby="non_traite-tab">
    <br><table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
      <thead>
        <tr>
          <th>#</th>
          <th>INTRANT</th>
          <th>SEUIL</th>
          <th>QUANTITE DISPONIBLE</th>
          <th>QUANTITE</th>
          <th>DATE</th>

        </tr>
      </thead>

    </table>    
   

  </div>

</div>

<div>
 

  <div >


    </div>
</div>
      
  </div>
  
    
</div>
</div>
<!-- ********************************************************************************************** -->

      

      
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
  function show_intrant() {
    // body...
 /* $.post('<?php echo base_url();?>ihm/Traiter_Auto_Demande/get_dem_virt/',
  {
    
    
    },
    function(data) 
    { 
    dem_intant.innerHTML = data; 
    $('#dem_intant').html(data);

    }); */
    var row_count ="1000000";


    var table = $('#mytable_1').DataTable({ 
        "ajax":{
            url:"<?=base_url()?>ihm/Traiter_Auto_Demande/get_dem_virt/",
            type:"POST",
            data : {
               



            }
        },
       "scrollX": false,
       "destroy" : true, 
       'columnDefs': [{
       'stateSave': true,
       'bDestroy': true,
       'processing':true,
       'serverSide':true,
       'searchable': false,
       'orderable': false,
       //'className': 'dt-body-center', 
       

     }],

     dom: 'Bfrtlip',
     lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
     exportOptions: { columns: [ 0, 1,2,3,4,5,6]  },
     pageLength: 10,
     buttons: ['excel', 'pdf', 'print'  ],
    language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            },
    'order': [[0, 'asc']]
  });


    $('#mytable').on('processing.dt', function (e, settings, processing) {
      if (processing) {

      } else {
      //  $("#test").modal('hide');

    }
  });
  }
function do_demande(ID_DEMANDE_SYSTEME,INTRANT_MEDICAUX_ID) {
  // body...
  var QUANTITE=parseFloat($('#QUANTITE'+ID_DEMANDE_SYSTEME).val());
  if (QUANTITE>0) {
   $('#message_ret').html('<div class="alert alert-info">Opération en cours...</div>')
   $('#modal').modal({ backdrop: false });
   $('#modal').modal()
  $.post('<?php echo base_url();?>ihm/Traiter_Auto_Demande/add_demande/',
  {
    QUANTITE:QUANTITE,
    ID_DEMANDE_SYSTEME:ID_DEMANDE_SYSTEME,
    INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID
    
    },
    function(data) 
    { 
     show_intrant()
    //dem_intant.innerHTML = data;
    $('#message_ret').html('<div class="alert alert-success">Opération réussi avec succes</div>')
    //$('#dem_intant').html(data);
    $('#modal').modal({ backdrop: true });
    $('#modal').modal();
    $('#modal').modal('hide');

    });
}else{
       show_intrant();
       $('#message_ret').html('<div class="alert alert-danger">Veillez saisir la quantité valide</div>')
       $('#modal').modal();
}

}
</script>
<script type="text/javascript">
  $(document).ready(function(){ 
     $("#message").delay("slow").fadeOut(3000);
   show_intrant();
   get_list();


  });
  function get_list() {
  // body...
    

    var row_count ="1000000";

   $("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
       "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
            url:"<?=base_url()?>ihm/Traiter_Auto_Demande/liste/",
            type:"POST",
            data : {
               


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[],
            "orderable":false
        }],

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });
}
</script>

<script type="text/javascript">
$(function() {
  //If check_all checked then check all table rows
  $("#check_all").on("click", function () {
    if ($("input:checkbox").prop("checked")) {
      $("input:checkbox[name='row-check']").prop("checked", true);
    } else {
      $("input:checkbox[name='row-check']").prop("checked", false);
    }
  });

  // Check each table row checkbox
  $("input:checkbox[name='row-check']").on("change", function () {
    var total_check_boxes = $("input:checkbox[name='row-check']").length;
    var total_checked_boxes = $("input:checkbox[name='row-check']:checked").length;
    alert(total_checked_boxes);
    // If all checked manually then check check_all checkbox
    if (total_check_boxes === total_checked_boxes) {
      $("#check_all").prop("checked", true);
    }
    else {
      $("#check_all").prop("checked", false);
    }
  });
});
</script>
<script>
    $(document).ready(function() {
        $("button").click(function(){
            var favorite = [];
            $.each($("input[name='row-check']:checked"), function(){
                favorite.push($(this).val());
            });
            alert("My favourite sports are: " + favorite);
            

            var form= new FormData(); 
            for (var i = favorite.length - 1; i >= 0; i--) {
              //alert(favorite[i]);
                    
                form.append("QUANTITE"+favorite[i],$('#QUANTITE'+favorite[i]).val());
            }

        });
    });
</script>