<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Intervenants_rh/index')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>



      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">

              <div class="col-md-12">

               <form action="<?= base_url('ihm/Intervenants_rh/update/').$records['INTERVENANT_RH_ID']?>" method="post">
                <input type="hidden" value="<?=$records['INTERVENANT_RH_ID']?>" name="id">
                <div class="row">
                  <div class="col-md-6">
                   <label>Nom </label>
                   <input type="text" value="<?= $records['NOM'];?>" class="form-control" name="nom">
                   <?php echo form_error('nom', '<div class="text-danger">', '</div>'); ?>
                 </div>
                 <div class="col-md-6">
                   <label>Prénom </label>
                   <input type="text" value="<?= $records['PRENOM'];?>" class="form-control" name="prenom" >
                   <?php echo form_error('prenom', '<div class="text-danger">', '</div>'); ?>
                 </div>
               </div>

               <div class="row">
                <div class="col-6">
                 <label>Fonction</label>
                 <!-- <select class="form-control" name="ID_FONCTION">
                  <option value="" selected="">Sélectionner</option> 
                  <?php foreach ($fonction as $value) {     
                    if ($records['ID_FONCTION']==$value['ID_FONCTION']) { ?>

                      <option selected value="<?= $value['ID_FONCTION'];?>">
                        <?= $value['FONCTION_DESCR'];?> 
                      </option>
                      <?php } else {  ?>
                        <option value="<?= $value['ID_FONCTION'];?>">
                          <?= $value['FONCTION_DESCR'];?> 
                        </option>
                        <?php  }


                      }  ?>
                    </select> -->

                    <select id="ID_FONCTION" name="ID_FONCTION" class="form-control" data-live-search="true">
                        <!-- <option value="">Sélectionner</option> --> 
                        <?php
                        foreach ($fonction as $data) {
                          if ($records['ID_FONCTION']==$data['ID_FONCTION']) 
                          {
                            echo "<option value=".$data['ID_FONCTION']." selected=''>".$data['FONCTION_DESCR']."</option>";
                          } else {
                            echo "<option value=".$data['ID_FONCTION'].">".$data['FONCTION_DESCR']." </option>";
                          }
                        }
                        ?>           
                      </select>
                    <?php echo form_error('ID_FONCTION', '<div class="text-danger">', '</div>'); ?> 

                  </div>

                <div class="col-md-6">
                 <label>Téléphone</label>
                 <input type="number" value="<?= $records['TELEPHONE1'];?>" class="form-control" name="tel" >
                 <?php echo form_error('tel', '<div class="text-danger">', '</div>'); ?>
               </div>
              </div>
               <div class="row">
               <div class="col-md-6">
                 <label>Autre téléphone </label>
                 <input type="text" value="<?= $records['TELEPHONE2'];?>" class="form-control" name="autre_tel" >

               </div>
             

            
              <div class="col-md-6">
               <label>Email </label>
               <input type="text" value="<?= $records['EMAIL'];?>" class="form-control" name="email" >
               <?php echo form_error('email', '<div class="text-danger">', '</div>'); ?>
              </div>
              </div>
<!--              <div class="col-md-6">
               <label>Profile </label>
               <select class="form-control" name="PROFIL_ID" >

                <?php
                foreach ($profil as  $value) {
                  if ($value['PROFIL_ID']==$records['INTERVENANT_PROFIL_ID']) {?>
                    <option value="<?= $value['PROFIL_ID'];?>" selected=""><?= $value['PROFIL_DESCR'];?></option>
                    <?php } else {?>
                      <option value="<?= $value['PROFIL_ID'];?>"><?= $value['PROFIL_DESCR'];?></option>
                      <?php }


                    }
                    ?>



                  </select>
                  <?php echo form_error('PROFIL_ID', '<div class="text-danger">', '</div>'); ?>
                </div> -->
<!--               </div>

              <div class="row"> -->
<!--                 <div class="col-md-6">
                 <label>Structure </label>
                 <select class="form-control select2" name="structure" >
                  <?php
                  foreach ($structure as $key => $value)
                  {

                    if ($value['INTERVENANT_STRUCTURE_ID']==$records['INTERVENANT_STRUCTURE_ID']) {?>
                      <option value="<?= $value['INTERVENANT_STRUCTURE_ID'];?>" selected=''><?= $value['INTERVENANT_STRUCTURE_DESCR'];?></option>
                      <?php } else {?>
                        <option value="<?= $value['INTERVENANT_STRUCTURE_ID'];?>"><?= $value['INTERVENANT_STRUCTURE_DESCR'];?></option>
                        <?php 
                      }

                    }
                    ?>
                  </select>
                  <?php echo form_error('structure', '<div class="text-danger">', '</div>'); ?>
                </div> -->
                <div class="row">
                <div class="col-6">
                 <label>Sexe</label>
                 <!-- <select class="form-control" name="SEXE_ID">
                  <option value="" selected="">Sélectionner</option> 
                  <?php foreach ($sex as $value) {     
                    if ($records['SEXE_ID']==$value['SEXE_ID']) { ?>
                      <option selected value="<?= $value['SEXE_ID'];?>">
                        <?= $value['SEXE_DESCR'];?> 
                      </option>
                      <?php } else {  ?>
                        <option value="<?= $value['SEXE_ID'];?>">
                          <?= $value['SEXE_DESCR'];?> 
                        </option>
                        <?php  }


                      }  ?>
                    </select> -->

                    <select id="SEXE_ID" name="SEXE_ID" class="form-control" data-live-search="true">
                        <!-- <option value="">Sélectionner</option>  -->
                        <?php
                        foreach ($sex as $data) {
                          if ($records['SEXE_ID']==$data['SEXE_ID']) 
                          {
                            echo "<option value=".$data['SEXE_ID']." selected=''>".$data['SEXE_DESCR']."</option>";
                          } else {
                            echo "<option value=".$data['SEXE_ID'].">".$data['SEXE_DESCR']." </option>";
                          }
                        }
                        ?>           
                      </select>

                    <?php echo form_error('SEXE_ID', '<div class="text-danger">', '</div>'); ?> 

                  </div>
               
                   <div class="col-md-6">
                <input type="hidden" name="INTERVENANT_RH_PROFIL" id="INTERVENANT_RH_PROFIL" value="<?= $INTERVENANT_RH_PROFIL ?>">

               <label>Profile </label>
               <select class="form-control" name="PROFIL_ID" >

                <?php
                foreach ($profil as  $value) {
                  if ($INTERVENANT_RH_PROFIL==$value['PROFIL_ID']) {?>
                    <option value="<?= $value['PROFIL_ID'];?>" selected=""><?= $value['PROFIL_DESCR'];?></option>
                    <?php } else {?>
                      <option value="<?= $value['PROFIL_ID'];?>"><?= $value['PROFIL_DESCR'];?></option>
                      <?php }


                    }
                    ?>



                  </select>
                  <?php echo form_error('PROFIL_ID', '<div class="text-danger">', '</div>'); ?>
                </div>
                </div>
                <div class="row">
                  <div class="col-md-12" style="margin-top:31px;">
                    <button type="submit" class="btn btn-primary"><span class="fas fa-edit"></span> Modifier</button>
                  </div>
                  </div>

                </div>

              </form>

            </div>


            <!--  VOS CODE ICI  -->



          </div>
        </div>
      </div>
    </section>
  </div>
</div>
</body>

<?php include VIEWPATH.'templates/footer.php'; ?>


