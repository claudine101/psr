<div class="row">
  <legend>
    Nouveau Agent
    <div class="pull-right" style="padding-bottom:20px;">
      <a href="<?= base_url('ihm/Agents_Sante/listing'); ?>" class="btn btn-secondary"><i class="fa fa-list"></i>
        Liste
      </a>
    </div>
  </legend>
</div>
<form  name="myform" method="post" class="form-horizontal" action="<?= base_url('ihm/Agents_Sante/updateAgent'); ?>">
  <div class="row">
   <input type="hidden" class="form-control" name="ASC_ID" value="<?=$asc['ASC_ID']?>" >
   <div class="col-md-6 col-sm-6 col-xs-6">
     <label>Nom</label>
     <input type="text" name="ASC_NOM" value="<?=$asc['ASC_NOM']?>" class="form-control" id="ASC_NOM">
     <?php echo form_error('ASC_NOM', '<div class="text-danger">', '</div>'); ?>

   </div>
   <div class="col-md-6 col-sm-6 col-xs-6">
     <label>Prenom</label>
     <input type="text" name="ASC_PRENOM" value="<?=$asc['ASC_PRENOM']?>" class="form-control" id="ASC_PRENOM">
     <?php echo form_error('ASC_PRENOM', '<div class="text-danger">', '</div>'); ?>
   </div>
 </div>
 <div class="row">
  <div class="col-md-3 col-sm-4 col-xs-4">
   <label>Telephone1</label>
   <input type="text" name="TELEPHONE1" value="<?=$asc['TELEPHONE1']?>" class="form-control" id="TELEPHONE1">
   <?php echo form_error('TELEPHONE1', '<div class="text-danger">', '</div>'); ?>
 </div>

 <div class="col-md-3 col-sm-4 col-xs-4">
   <label>Telephone2</label>
   <input type="text" name="TELEPHONE2" value="<?=$asc['TELEPHONE2']?>" class="form-control" id="TELEPHONE2">
   <?php echo form_error('TELEPHONE2', '<div class="text-danger">', '</div>'); ?>
 </div>
 <div class="col-md-6 col-sm-6 col-xs-6">
   <label>Mail</label>
   <input type="e_mail" name="EMAIL" value="<?=$asc['EMAIL']?>" class="form-control" id="EMAIL">
   <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?>
 </div>
</div>
 <div class="row">
 <div class="col-md-6 col-sm-6 col-xs-6">
  <label>Centre de Sante</label>

  <select id="CDS_ID" name="CDS_ID" class="form-control selectpicker" data-live-search="true">
    <option value="">--Sélectionnez--</option>
    <?php
    foreach ($type as $data) {
     if  ($data['CDS_ID'] ==$data['CDS_ID']) 
     {
       echo "<option value=".$data['CDS_ID']." selected=''>".$data['CDS_NOM']."</option>";
     } else {
      echo "<option value=".$data['CDS_ID'].">".$data['CDS_NOM']." </option>";
    }
  }
  ?>           
</select>
<div style="color: red"><?php echo form_error('CDS_ID'); ?></div>
</div> 


 <div class="col-md-6 col-sm-6 col-xs-6">
   <label>Code Agent</label>
   <input type="text" name="ASC_CODE" value="<?=$asc['ASC_CODE']?>" class="form-control" id="ASC_CODE">
   <?php echo form_error('ASC_CODE', '<div class="text-danger">', '</div>'); ?>
 </div>
</div>
 <div class="col-md-12 col-sm-12 col-xs-6">
  <button type="submit" class="btn btn-secondary btn-block" style="margin-top: 20px">Modifier</button>

</div>

</form>






<!-- partial -->




<!-- End custom js for this page-->






