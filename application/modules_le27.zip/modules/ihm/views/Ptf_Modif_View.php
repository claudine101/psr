<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php';?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-9">
              <?php
          $menu1="nav-link active";
          $menu2="nav-link";
           
          VIEWPATH.include('includes/sous_menu_ptf.php'); 
          ?>
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-3">
              <a href="<?=base_url('ihm/Ptf/index')?>" class='btn btn-primary float-right'>
                <i class="nav-icon fas fa-list ul"></i>
                Liste
              </a>
            </div><!-- /.col -->
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">

          <div class="card">
            <div class="card-body">

              <div class="col-md-12">

                     <form  name="myform" method="post" class="form-horizontal" action="<?= base_url('ihm/Ptf/update'); ?>" >
            <div class="row">
              <div class="col-md-6">
                <input type="hidden" class="form-control" name="INTERVENANT_STRUCTURE_ID" value="<?=$data['INTERVENANT_STRUCTURE_ID']?>" >

                <label for="FName">PTF</label>
                <input type="text" name="INTERVENANT_STRUCTURE_DESCR" id="INTERVENANT_STRUCTURE_DESCR" value="<?= $data['INTERVENANT_STRUCTURE_DESCR'] ?>" class="form-control">

              <!--  <select class="form-control" data-live-search="true"  name="INTERVENANT_STRUCTURE" >
               <?php 
               foreach($ptf as $key_ptf) { 
                if ($key_ptf['INTERVENANT_STRUCTURE_ID'] ==$data['INTERVENANT_STRUCTURE_ID']) { 
                  echo "<option value='".$key_ptf['INTERVENANT_STRUCTURE_ID']."' selected>".$key_ptf['INTERVENANT_STRUCTURE_DESCR']."</option>";
                }  else{
                 echo "<option value='".$key_ptf['INTERVENANT_STRUCTURE_ID']."' >".$key_ptf['INTERVENANT_STRUCTURE_DESCR']."</option>"; 
               } }?>
             </select> -->

                <?php echo form_error('INTERVENANT_STRUCTURE', '<div class="text-danger">', '</div>'); ?> 

              </div>

              <div class="col-md-6">
                <label for="LName">Code Intervenant</label>
                <input type="text" name="INTERVENANT_STRUCTURE_CODE" value="<?=$data['INTERVENANT_STRUCTURE_CODE'] ?>"  id="INTERVENANT_STRUCTURE_CODE" class="form-control">
                <?php echo form_error('INTERVENANT_STRUCTURE_CODE', '<div class="text-danger">', '</div>'); ?> 

              </div>
            </div>

            <div class="row">
              <!-- <div class="col-md-6">
                <label for="" >Province:</label>

                <select class="form-control" data-live-search="true"  name="PROVINCE_ID" >
                 <?php foreach($type as $key_province) { 
                  if ($key_province['PROVINCE_ID'] ==$data['PROVINCE_ID']) { 
                    echo "<option value='".$key_province['PROVINCE_ID']."' selected>".$key_province['PROVINCE_NOM']."</option>";
                  }  else{
                   echo "<option value='".$key_province['PROVINCE_ID']."' >".$key_province['PROVINCE_NOM']."</option>"; 
                 } }?>
               </select>
               <?php echo form_error('PROVINCE_ID', '<div class="text-danger">', '</div>'); ?> 

             </div> -->
             <div class="col-md-6">
              <label for="LName">Email</label>
              <input type="text" name="EMAIL" id="EMAIL" autocomplete="off" value="<?= $data['EMAIL'] ?>" class="form-control">
              <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?> 

            </div>

            <div class="col-md-6">
              <label for="LName">Téléphone</label>
              <input type="text" name="TELEPHONE" id="TELEPHONE" value="<?= $data['TELEPHONE'] ?>" class="form-control">
              <?php echo form_error('TELEPHONE', '<div class="text-danger">', '</div>'); ?> 

            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <label for="FName">Latitude</label>
              <input type="text" name="LATITUDE" id="LATITUDE" value="<?= $data['LATITUDE'] ?>" class="form-control">
              <?php echo form_error('LATITUDE', '<div class="text-danger">', '</div>'); ?> 

            </div>

            <div class="col-md-6">
              <label for="LName">Longitude</label>
              <input type="text" name="LONGITUDE" id="LONGITUDE" value="<?= $data['LONGITUDE'] ?>" class="form-control">
              <?php echo form_error('LONGITUDE', '<div class="text-danger">', '</div>'); ?> 

            </div>
          </div>
          <div class="row">

            <div class="col-md-6">
              <label for="LName">Type d'intervenant</label>

              <select class="form-control" data-live-search="true"  name="TYPE_INTERVENANT_STRUCTURE_ID" >
               <?php 
               foreach($types as $key_type_intervenant) { 
                if ($key_type_intervenant['TYPE_INTERVENANT_STRUCTURE_ID'] ==$data['TYPE_INTERVENANT_STRUCTURE_ID']) { 
                  echo "<option value='".$key_type_intervenant['TYPE_INTERVENANT_STRUCTURE_ID']."' selected>".$key_type_intervenant['TYPE_INTERVENANT_STRUCTURE_DESCR']."</option>";
                }  else{
                 echo "<option value='".$key_type_intervenant['TYPE_INTERVENANT_STRUCTURE_ID']."' >".$key_type_intervenant['TYPE_INTERVENANT_STRUCTURE_DESCR']."</option>"; 
               } }?>
             </select>
             <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 

           </div>

           <div class="col-md-6" style="margin-top:31px;">
            <button type="submit" style="float: right;" class="btn btn-primary"><span class="fas fa-edit"></span> Modifier</button>
            <!-- <input type="submit" name="" class="btn btn-primary" value="mmm"> -->
          </div>
        </div>


      </form>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </body>

      <?php include VIEWPATH.'templates/footer.php'; ?>


