<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h4 class="m-0"><?=$title?></h4>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">


              <span style="margin-right: 15px">


              </span>

            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-12">
            <!-- Custom Tabs -->
            <div class="card">
              <div class="card-header d-flex p-0">

                <ul class="nav nav-pills left">
                  <?php
                  $i=0;
                  foreach ($status as $value) {
                    if ($i==0) {?>

                      <li class="nav-item"><a class="nav-link" id="statut<?= $i ?>" onclick="get_stock_rupture(<?=$value['ID_STATUT_TICKET'].','.$i?>)"  href="#" data-toggle="tab"><?=$value['DESCRIPTION']?></a></li>
                      

                      <?php }else{?>

                        <li class="nav-item"><a class="nav-link" id="statut<?= $i ?>" onclick="get_stock_rupture(<?=$value['ID_STATUT_TICKET'].','.$i?>)"  href="#" data-toggle="tab"><?=$value['DESCRIPTION']?></a></li>

                        <?php }
                        echo "<input type='hidden' name='COMPTEUR' id='COMPTEUR' value='".$value['ID_STATUT_TICKET']."'>";
                        $i++;

                      }
                      ?>
                    </ul>
                    
                    <input type="hidden" name="COMPTEUR1" id="COMPTEUR1" value="0">

                  </div><!-- /.card-header -->
                  <div class="card">

                    <div class="col-12" id="message"></div>

                    <div class="card-body" style="overflow-x: auto;" >
                      <div style="padding-top: 5px;" class="col-md-12">
                        <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>STRUCTURE</th>
                              <th>QTE DISPONIBLE</th>
                              <th>QTE SEUIL</th>
                              <th>INTRANT</th>
                              <th>TICKET</th>
                              <!-- <th>STATUS</th> -->
                              <th>DATE</th>
                              <th>OPTION</th>
                            </tr>
                          </thead>

                        </table>


                      </div>


                    </div>
                  </div>

                </div>
                <!-- ./card -->
              </div>
              <!-- /.col -->
            </div>
          </section>
          <!-- /.content -->
        </div>

      </div>
      <!-- ./wrapper -->
      <?php include VIEWPATH.'templates/footer.php'; ?>
    </body>
    </html>


    <script>

      var table;
      $(document).ready(function(){

        var ID_STATUT_TICKET=$("#COMPTEUR").val();
        var i=$("#COMPTEUR1").val();

        

        get_stock_rupture(ID_STATUT_TICKET,i);
      });

      function get_stock_rupture(ID_STATUT_TICKET=0,i=0)
      {

        document.getElementById("COMPTEUR").value=ID_STATUT_TICKET;
        document.getElementById("COMPTEUR1").value=i;

        var compt_id=$("#COMPTEUR").val();
        // var counter=$("#COMPTEUR1").val();

        // counter=Number(counter);

        // alert(compt_id);


        document.getElementById("COMPTEUR1").value=i
        var counter='<?= $i ?>';

        counter=Number(counter);
        j=0;
        while(j<counter){

         if (j==i) {
          document.getElementById("statut"+j).className = "nav-link active";

        }else {
          document.getElementById("statut"+j).className = "nav-link ";
        }
        j++;
      }


      var row_count ="1000000";
      table=$("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
        "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
          url:"<?=base_url()?>ihm/Stock_Rupture_Ticket/getInfo/"+compt_id,
          type:"POST"
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
        pageLength: 10,
        "columnDefs":[{
          "targets":[],
          "orderable":false
        }],

        dom: 'Bfrtlip',
        buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        language: {
          "sProcessing":     "Traitement en cours...",
          "sSearch":         "Rechercher&nbsp;:",
          "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
          "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
          "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
          "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
          "sInfoPostFix":    "",
          "sLoadingRecords": "Chargement en cours...",
          "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
          "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
          "oPaginate": {
            "sFirst":      "Premier",
            "sPrevious":   "Pr&eacute;c&eacute;dent",
            "sNext":       "Suivant",
            "sLast":       "Dernier"
          },
          "oAria": {
            "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
            "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
          }
        }

      });

    }





    function traiter_status(id)
    {
      $('#traiter_modal').modal('show');
      document.getElementById('ID_STOCK_RUPTURE_TICKET').value=id;
      var test=$("#ID_STOCK_RUPTURE_TICKET").val();
      $('.modal-title').text('Traitement des statut du stock');
    }



    function changer_statut()
    {

      // $('#traiter_modal').modal('show');

  // $('.modal-title').text('Traitement des statut du stock');

  var ID_STOCK_RUPTURE_TICKET=$("#ID_STOCK_RUPTURE_TICKET").val();
  var ID_STATUT_TICKET=$("#ID_STATUT_TICKET").val();
  var COMMENTAIRE=$("#COMMENTAIRE").val();


  $.post('<?php echo base_url();?>ihm/Stock_Rupture_Ticket/add_statut/',
  {
    ID_STOCK_RUPTURE_TICKET:ID_STOCK_RUPTURE_TICKET,
    ID_STATUT_TICKET:ID_STATUT_TICKET,
    COMMENTAIRE:COMMENTAIRE


  },
  function(data)
  {
    if (ID_STATUT_TICKET>0) 
    {
      $("#traiter_modal").modal('hide');
      $("#form_traiter")[0].reset();
      $('#message').html("<div class='alert alert-success' role='alert'><center>Le statut a été changé avec succès</center></div>");
        $('#message').delay('slow').fadeOut(5000);
      table.ajax.reload(null,false);
    }else{
      $("#error_status").html('Le status est obligatoire');
      $("#error_status").css('color','red');
      $('#error_status').delay('slow').fadeOut(2000);
    }


  });


}


</script>



<div class="modal fade bd-example-modal-lg" id="traiter_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="statut"></h4>
          <button type="button"  class="close btn btn-outline-danger btn-sm" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="container-fluid" style="padding: 20px;">
          <center><span id="message_retour"></span></center>
          <div class="col-md-12">
            <form id="form_traiter">
             <div class="row">

               <div class="col-md-12">
                <input type="hidden" name="ID_STOCK_RUPTURE_TICKET" id="ID_STOCK_RUPTURE_TICKET" value="8">
                <label>Statut</label>
                <select class="form-control" id="ID_STATUT_TICKET" name="ID_STATUT_TICKET">
                 <option value="" selected="" disabled="">--Statut</option>
                 <?php
                 foreach ($status as $key)
                   {?>

                    <option value="<?=$key['ID_STATUT_TICKET']?>"><?=$key['DESCRIPTION']?></option>

                    <?php }
                    ?>
                  </select>
                  <label class="text-danger" id="error_status"></label>
                </div>
                <div class="col-md-12">
                 <label>Commentaire</label>
                 <textarea class="form-control" name="COMMENTAIRE" id="COMMENTAIRE"></textarea>
               </div>
             </div>

             <!-- <input type="hidden" name="structure" id="structure"> -->
             <div class="row">

              <div class="col-md-6">
                <button type="button" id="btn_status" onclick="changer_statut()" class="btn btn-primary btn-sm" style="margin-top: 25px;">
                  <i class="nav-icon fas fa-save"></i>
                  <b>Enregistrer</b>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
