

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('ihm/Cds/Supprimer')?>" method="post">
        <div class="col-md-6">
           <label>Code:</label>
           <input type="text" value="<?=$cds['CDS_CODE'];?>"class="form-control" name="code">
        </div>
        <div class="col-md-6">
           <label>Nom:</label>
           <input type="text"value="<?=$cds['CDS_NOM'];?>"class="form-control" name="nom">
        </div>
        <div class="col-md-6">
           <label>Latitude :</label>
           <input type="text" value="<?=$cds['LATITUDE'];?>"class="form-control" name="latitude">
        </div>
        <div class="col-md-6">
           <label>Longitude :</label>
           <input type="text" value="<?=$cds['LONGITUDE'];?>" class="form-control" name="longitude">
        </div>
        <div class="col-md-6">
           <label>district_id :</label>
           <input type="text" value="<?=$cds['DISTRICT_ID'];?>" class="form-control" name="district_id">
        </div>
        <br><br>
      	<div> 
      	  <input type="submit" class="btn btn-primary" name="submit" value="Supprimer">
       	</div>
    </form>
  </div>
</div>