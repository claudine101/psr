

<div class="row">
  	<div>
  	  <h3>Liste des Centres de Santé</h3>	
  	</div>
  	<div class="pull-right">
	  	<a href="<?= base_url('Cds/Add_Cds')?>" class="btn btn-primary">
	  	  Ajouter
	  	</a>
    </div>
  <div class="table">
  	<table class="table table-responsive">
  	  <thead>
        <tr>
	  	  	<th>Code</th>
          <th>Cds</th>
	  	  	<th>Latitude</th>
	  	  	<th>Longitude</th>
          <th>district_id</th>
	  	  	<th>Action</th>
        </tr>
  	  </thead>
  	  <tbody>
<?php foreach ($data as $value) { ?>
	  <tr>
  	  	 <td><?=$value['CDS_CODE'];?></td>
  	  	 <td><?=$value['CDS_NOM'];?></td>
  	  	 <td><?=$value['LATITUDE'];?></td>
  	  	 <td><?=$value['LONGITUDE'];?></td>
          <td><?=$value['DISTRICT_ID'];?></td>
  	  	 <td>
  	  	   <a href="<?=base_url('Cds/Update_view/').$value['CDS_ID']?>" class="btn btn-primary">Modifier</a>

  	  	   <a href="<?= base_url('Cds/Delete_Cds/').$value['CDS_ID']?>" class="btn btn-danger">Supprimer</a>
  	  	 </td>
  	  </tr>
<?php } ?>
  	  </tbody>	
  	</table>
  </div>
</div>
