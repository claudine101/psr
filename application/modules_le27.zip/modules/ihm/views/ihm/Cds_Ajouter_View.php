<legend>
    <?= $title ?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?= base_url('ihm/Cds/index')?>"><i class="fa fa-list"></i>Liste</a>
    </div>
</legend>


<div class="col-md-12">
  
    <form action="<?= base_url('ihm/Cds/Ajouter')?>" method="post">
      <div class="row">
        <div class="col-md-6">
           <label>Code:</label>
           <input type="text" class="form-control" name="code" > 
           <span><font color="red"><?=form_error('code');?></font></span>
        </div>
      
        <div class="col-md-6">
           <label>Nom:</label>
           <input type="text" class="form-control" name="nom" >
           <span><font color="red"><?=form_error('nom');?></font></span>
        </div>
      </div>
        <div class="row">
        <div class="col-md-6">
           <label>Latitude :</label>
           <input type="text" class="form-control" name="latitude" >
           <span><font color="red"><?=form_error('latitude');?></font></span>

        </div>
        <div class="col-md-6">
           <label>Longitude :</label>
           <input type="text" class="form-control" name="longitude" >
           <span><font color="red"><?=form_error('longitude');?></font></span>
           
        </div>
        </div>
        <div class="row">
        <div class="col-md-6">
          <label>District :</label>
          <select name="district_id" class="form-control">
            <option selected="">---Séléctionner---</option>
             <?php foreach($cds as $key_cds) {  ?>
                <option value="<?= $key_cds['DISTRICT_ID'];?>"><?= $key_cds['DISTRICT_NOM'];?></option>
              <?php }  ?>            
          </select>
        </div>
      
        <div class="col-md-6"> 
          <br><input type="submit" class="btn btn-primary form-control" style="margin-top: 10px;" value="Enregistrer">
        </div>
        </div>
    </form>
 
