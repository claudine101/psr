


<div class="row">
  <legend>
  	<?= $title ?>
  	<div class="pull-right">
  	  <a class="btn btn-primary" href="<?= base_url('ihm/Cds/Add_cds')?>"><i class="fa fa-plus"></i>Ajouter</a>
  	</div>
  </legend>
</div>
<div class="row">
  <?= $this->table->generate($data); ?>	
</div>