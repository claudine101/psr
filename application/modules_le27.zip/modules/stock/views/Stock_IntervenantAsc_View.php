
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php' ?>

    <!-- /.navbar -->
    <style type="text/css">
      .bordersolid{
        border-style: solid;
        border-color: gray;
        border-width: 1px;
      }
    </style>
    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-6">
            <!-- <h1 class="m-0"><?=$title?></h1> -->
            <?php
            $menu_cam_1="nav-link";
            $menu_cam_2="nav-link";
            $menu_cam_3="nav-link"; 
            $menu_cam_4="nav-link active"; 

            $menu_bds_1="nav-link";
            $menu_bds_2="nav-link";
            $menu_bds_3="nav-link active";

            $menu_cds_1="nav-link";
            $menu_cds_2="nav-link active";
            include VIEWPATH.'sousmenu/sous_menu_stock_intervenant.php'; ?>
            <!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>

      <section class="container">
        <!-- ************************************************************************************************** -->

        <!-- Large modal -->



<!-- #############################################################
-->
<div class="card" >
  <div class="container-fluid">
    <div class="row">
      <div class="col-12 table-responsive" style="padding: 20px;">

        <table id='mytable' class="table table-bordered table-striped table-hover table-condensed table-sm">
          <thead>
            <tr>
              <th>ASC</th>
              <?php 

              foreach ($array_intrant_stock as $key) {
            # code...
               ?>
               <!--          <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="<?= $key['INTRANT_MEDICAUX_CODE'] ?>"> -->

                <th>
                  <span class="tooltipp">
                    <p class="topp">
                      <?= $key['INTRANT_MEDICAUX_DESCR'] ?>
                    </p>            
                    <?= str_replace("-", "", $key['INTRANT_MEDICAUX_CODE']) ?>
                  </span>    
                </th>

              <?php } ?>
              <!--   </span> -->

            </tr>
          </thead>
          <tfoot>
            <tr>
              <th></th>
              <?php 

              foreach ($array_intrant_stock as $key) {
            # code...
               ?>
               <!--          <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="<?= $key['INTRANT_MEDICAUX_CODE'] ?>"> -->

                <th></th>

              <?php } ?>
              <!--   </span> -->
              
            </tr>
          </tfoot>

        </table>

      </div>




    </div>

  </div>
  <!-- ********************************************************************************************** -->
</div>



</section>
<!-- /.content -->
</div>

</div>
<!-- ./wrapper -->
<?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
 $(document).ready(function(){
   $('#app_title').html('Stock du <?= date('d-m-Y').' '.$INTERVENANT_STRUCTURE_DESCR ?>');
   get_liste();

   //$('#mytable_length').hide();
   //$('#mytable_info').hide();

 });
</script>

<script type="text/javascript">
  function get_liste() { 



    var row_count=1000000; 

    var table = $('#mytable').DataTable({ 
      "ajax":{
        url:"<?=base_url()?>stock/Stock_Intervenant/asc_stock/",
        type:"POST",
        data : {

         array_intrant_stock : <?= json_encode($array_intrant_stock) ?>,
         ID_CDS:<?= $ID_CDS ?>


       }
     },
     "scrollX": false,
     "destroy" : true, 
     'columnDefs': [{
       'stateSave': true,
       'bDestroy': true,
       'processing':true,
       'serverSide':true,
       'searchable': false,
       'orderable': false,
       //'className': 'dt-body-center', 
       

     }],

     dom: 'Bfrtlip',
     lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
     exportOptions: { columns: [ 0, 1,2,3,4,5,6]  },
     pageLength: 10,
     // buttons: ['excel', 'pdf', 'print'  ],

     buttons: [
     { extend: 'pdfHtml5', footer: true },
     { extend: 'excelHtml5', footer: true },
     { extend: 'print', footer: true },
     ],

     "footerCallback": function ( row, data, start, end, display ) {
      var api = this.api(), data;

      /* converting to interger to find total */
      var intVal = function ( i ) {
        return typeof i === 'string' ?
        i.replace(/ /g , '')*1 :
        typeof i === 'number' ?
        i : 0;
      };

      function formatNumber ( toFormat ) {
        return toFormat.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
      };
      /* computing column Total of the complete result if (colonnes_total.length() > 0) { */
        <?php 
        $ar = '';
        for ($i=1; $i <= count($array_intrant_stock); $i++) { 
          $ar .= $i.',';
        } ?>
        var colonnes_total = [<?=$ar?>];
        colonnes_total.forEach(Total_Colonnes);

        function Total_Colonnes(colonne) {
          var montantT = api
          .column( colonne, { search: 'applied' } )
          .data()
          .reduce( function (a, b) {
            let s = intVal(a) + intVal(b);
            return s.toString();
          }, 0 );
          /* Update footer by showing the total with the reference of the column index */
          $( api.column( 0 ).footer() ).html('Totaux');
          $( api.column( colonne ).footer() ).html(formatNumber(montantT));
        }
        /* } */
      },
      language: {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      },
      'order': [[0, 'asc']]
    });


    $('#mytable').on('processing.dt', function (e, settings, processing) {
      if (processing) {

      } else {
      //  $("#test").modal('hide');

    }
  });
  }
</script>

