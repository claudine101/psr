<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script> -->
<legend>STOCKAGE DES INTRANTS</legend>

<!-- modal -->

<div class="modal fade" id="stockValidate" tabindex="-1" role="dialog" aria-labelledby="stockValidateLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="stockValidateLabel">STOCKAGE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="get_list()">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <div id="reponse_status"></div>
        <form>
          <div class="form-group">
            <label for="QUANTITE_A_STOCKER" class="col-form-label">QUANTITE</label>

            <input type="number" class="form-control" id="QUANTITE_A_STOCKER" onchange="check_if_max(this.value)" onkeyup="check_if_max(this.value)">
            <span id="erreur_max_value" style="color:red;"></span>
            <input type="hidden" name="RECEPTION_INTRANT_ID" id="RECEPTION_INTRANT_ID">
            <input type="hidden" name="QUANTITEASTOCKER" id="QUANTITEASTOCKER">
            <input type="hidden" name="RECEPTION_CODE" id="RECEPTION_CODE">
            <input type="hidden" name="INTRANT_ID" id="INTRANT_ID">
          </div>
          <div class="form-group">
            <label for="COMMENT" class="col-form-label">OBSERVATION</label>
            <textarea class="form-control" id="COMMENT"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary"  data-dismiss="modal" onclick="get_list()">Quitter</button>
        <button type="button" class="btn btn-primary" id="validate" onclick="valider()">Valider</button>
      </div>
    </div>
  </div>
</div>
<!-- fin modal -->
<!-- modal historique -->
<div class="modal fade bd-example-modal-lg" id="modal_histo" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="stockValidateLabel">HISTORIQUE DE STOCKAGE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="SHOW_HISTO"></div>
    </div>
  </div>
</div>
<!-- fin modal histo -->
<div class="container-fluid">
 <div class="col-md-5">
   <label for="RECEPTION_COD">Code de réception</label>
   <select  class="form-control"  id="RECEPTION_COD" onclick="get_list(this.value)">
    <option value="" selected="">sélectionner</option>
    <?php foreach ($code as $key) {
      # code...
     ?>
     <option value="<?= $key['RECEPTION_ID'] ?>"><?= $key['RECEPTION_CODE'] ?></option>

    <?php } ?>
   </select>
 </div> 

  <div class="col-md-12">
    <table id='mytable' class="table table-bordered table-striped table-hover table-condensed table-responsive" style="width: 100%;">
      <thead>
        <tr>
          <th>#</th>
          <th>CODE DE RECEPTION</th>
          <th>INTRANT</th>
          <th>QUANTITE</th>
          <th>QUANTITE DEJA STOCKE</th>
          <th>QUANTITE RESTANT A STOCKE</th>
          <th>STATUT STOCKAGE</th>
          <th>DATE DE RECEPTION</th>
          
          <th>OPTION</th>
        </tr>
      </thead>

    </table>

      
  </div>
  
    
</div>
<script type="text/javascript">
  function show_historique(RECEPTION_INTRANT_ID) {
    // body...
  $("#modal_histo").modal();
  $.post('<?php echo base_url();?>stock/Stock/get_history/',
  {
    RECEPTION_INTRANT_ID:RECEPTION_INTRANT_ID
    
    },
    function(data) 
    { 
    SHOW_HISTO.innerHTML = data; 
    $('#SHOW_HISTO').html(data);

    }); 
  }
</script>
<script type="text/javascript">
  $(document).ready(function(){ 
    get_list();
  });
  function get_list() {
  // body...
    var RECEPTION_ID=$('#RECEPTION_COD').val();

    var row_count ="1000000";

   $("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
       "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
            url:"<?=base_url()?>stock/Stock/liste/",
            type:"POST",
            data : {
               
               RECEPTION_ID:RECEPTION_ID,


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[],
            "orderable":false
        }],

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });
}
</script>
<script type="text/javascript">
  function show_modal(id_reception_intrant,quantite_a_stocker,RECEPTION_CODE="",INTRANT_ID) {
    // body...
    $("#stockValidate").modal({backdrop:false});
    $('#QUANTITE_A_STOCKER').val(quantite_a_stocker);
    $('#RECEPTION_INTRANT_ID').val(id_reception_intrant);
    $('#QUANTITEASTOCKER').val(quantite_a_stocker);
    $('#RECEPTION_CODE').val(RECEPTION_CODE); 
    $('#INTRANT_ID').val(INTRANT_ID); 
  }
  function check_if_max(QUANTITE_A_STOCKER) {
    // body...
    $('#erreur_max_value').html("");
    var r=1;
     var QUANTITEASTOCKER=Number($('#QUANTITEASTOCKER').val());

    if (Number(QUANTITE_A_STOCKER) > QUANTITEASTOCKER) {
      $('#erreur_max_value').html("Veuillez saisir la quantité inférieure ou égale à la quantité à stocker");
      r=0;
    }else{
      $('#erreur_max_value').html("");
    }
    return r;
  }
</script>

<script type="text/javascript">
function valider()
{
  var QUANTITE_A_STOCKER=$('#QUANTITE_A_STOCKER').val();
  var RECEPTION_INTRANT_ID=$('#RECEPTION_INTRANT_ID').val();
  var COMMENT=$('#COMMENT').val();
  var RECEPTION_CODE=$('#RECEPTION_CODE').val();
  var QUANTITEASTOCKER=$('#QUANTITEASTOCKER').val();
  var INTRANT_ID=$('#INTRANT_ID').val();
  
  
  
  if(check_if_max()==1 && Number(QUANTITE_A_STOCKER)>0 && Number(QUANTITE_A_STOCKER)<=Number(QUANTITEASTOCKER)){
  $('#validate').attr('disabled', true);
  $('#reponse_status').html("<center><span class='text-info'>Opération en cours ...</span></center>");
  $.post('<?php echo base_url();?>stock/Stock/valider/',
  {
    QUANTITE_A_STOCKER:QUANTITE_A_STOCKER,
    RECEPTION_INTRANT_ID:RECEPTION_INTRANT_ID,
    COMMENT:COMMENT,
    RECEPTION_CODE:RECEPTION_CODE,
    QUANTITEASTOCKER:QUANTITEASTOCKER,
    INTRANT_ID:INTRANT_ID

    
    },
    function(data) 
    { 
      if (data==1) {
        $('#reponse_status').html("<center><span class='text-success'>Opération réussie</span></center>");
        $('#QUANTITE_A_STOCKER').val("");
        $('#COMMENT').val("");
        $('#validate').attr('disabled', false);
         get_list();
         setTimeout($("#stockValidate").modal('hide'), 9000);
        

      }
    
    

    
    }); 
}else{
  $('#reponse_status').html("<span class='text-danger'>Quantité invalide.</span>");
}
 
}


</script>