<?php
/**
 * @author jules_ndihokubwayo@mediabox.bi
 *with help of God
 */
class Stock_Intervenant extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		$this->is_auth();
	}
	public function is_auth($value='')
	{
		# code...$this->is_auth();
		if (empty($this->session->userdata('iccm_USER_ID'))) {
			# code...
			redirect(base_url());
		}
	}
	public function get_bds_stock($value='')
	{
		# code...
        $crit_dods_pnilp='';
		if ($this->session->userdata('iccm_PROFIL_CODE')=="PNLIP"){

             $crit_dods_pnilp=' WHERE MODE_RECEPTION_ID IN ( SELECT MODE_RECEPTION_ID FROM rc_mode_reception WHERE MODE_RECEPTION_DESCR LIKE "'.$this->session->userdata('iccm_PROFIL_CODE').'")';

		}
		$sql  = 'SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR`,`INTRANT_MEDICAUX_CODE` FROM `intrant_medicaux` WHERE `INTRANT_MEDICAUX_ID` IN ( SELECT rc_reception_intrant_detail.INTRANT_ID FROM rc_reception_intrant_detail '.$crit_dods_pnilp.')';
		$intrant_in_camebu_stock=$this->Modele->getRequete($sql);//intran in camebu stock
		if (empty($intrant_in_camebu_stock)) {
			# code...
			$intrant_in_camebu_stock=array();
		}
        $stock_disponible="";//$this->mylibrary->get_stock_intervenant($this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'));

		$data=array('array_intrant_stock'=>$intrant_in_camebu_stock,'title'=>'Stock BDS','stock_disponible'=>$stock_disponible);

		$this->load->view('Stock_Intervenant_View',$data);
	}
	public function get_stock_cds($ID_DISTRICT=0)
	{
		# code...
		if (empty($ID_DISTRICT)) {
			# code...
			$ID_DISTRICT=0;
		}
		if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS") {
			# code...
			$ID_DISTRICT=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
		}


		$str=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$ID_DISTRICT));
        $crit_dods_pnilp="";
		if (/*$this->session->userdata('iccm_PROFIL_CODE')=="DODS" || */$this->session->userdata('iccm_PROFIL_CODE')=="PNLIP"){
             $crit_dods_pnilp=' WHERE MODE_RECEPTION_ID IN ( SELECT MODE_RECEPTION_ID FROM rc_mode_reception WHERE MODE_RECEPTION_DESCR LIKE "'.$this->session->userdata('iccm_PROFIL_CODE').'")';
		}
		$sql  = 'SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR`,`INTRANT_MEDICAUX_CODE` FROM `intrant_medicaux` WHERE `INTRANT_MEDICAUX_ID` IN ( SELECT rc_reception_intrant_detail.INTRANT_ID FROM rc_reception_intrant_detail '.$crit_dods_pnilp.')';
		$intrant_in_camebu_stock=$this->Modele->getRequete($sql);//intran in camebu stock
        $stock_disponible="";//$this->mylibrary->get_stock_intervenant($ID_DISTRICT);//stock dispo a cette intervenant
		$data=array('array_intrant_stock'=>$intrant_in_camebu_stock,'ID_DISTRICT'=>$ID_DISTRICT,'INTERVENANT_STRUCTURE_DESCR'=>$str['INTERVENANT_STRUCTURE_DESCR'],'title'=>'Stock aux CDS','stock_disponible'=>$stock_disponible);

		$this->load->view('Stock_IntervenantCds_View',$data);
	}
	public function get_stock_asc($ID_CDS=0)
	{
		# code...get_stock_asc
		if (empty($ID_CDS)) {
			# code...
			$ID_CDS=0;
		}
			# code...
			if ($this->session->userdata('iccm_PROFIL_CODE')=="CDS" ) {
				# code...
				$ID_CDS=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
			}
			
		
		//$sql_nbrasc  = 'SELECT COUNT(*) nbr FROM `cds_asc` WHERE `CDS_ID`='.$ID_CDS;
        //$nbr_asc=$this->Modele->getRequeteOne($sql_nbrasc);
		$str=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$ID_CDS));
        $stock_disponible="";//$this->mylibrary->get_stock_intervenant($ID_CDS);//stock dispo
        $crit_dods_pnilp="";
		if (/*$this->session->userdata('iccm_PROFIL_CODE')=="DODS" || */$this->session->userdata('iccm_PROFIL_CODE')=="PNLIP"){
             $crit_dods_pnilp=' WHERE MODE_RECEPTION_ID IN ( SELECT MODE_RECEPTION_ID FROM rc_mode_reception WHERE MODE_RECEPTION_DESCR LIKE "'.$this->session->userdata('iccm_PROFIL_CODE').'")';
		}
		$sql  = 'SELECT `INTRANT_MEDICAUX_ID`,`INTRANT_MEDICAUX_DESCR`,`INTRANT_MEDICAUX_CODE` FROM `intrant_medicaux` WHERE `INTRANT_MEDICAUX_ID` IN ( SELECT rc_reception_intrant_detail.INTRANT_ID FROM rc_reception_intrant_detail '.$crit_dods_pnilp.')';
		$intrant_in_camebu_stock=$this->Modele->getRequete($sql);//intran in camebu stock

		$data=array('array_intrant_stock'=>$intrant_in_camebu_stock,'ID_CDS'=>$ID_CDS,'INTERVENANT_STRUCTURE_DESCR'=>$str['INTERVENANT_STRUCTURE_DESCR'],'title'=>'Stock aux ASC','stock_disponible'=>$stock_disponible,/*'nbr_asc'=>$nbr_asc['nbr']*/);

		$this->load->view('Stock_IntervenantAsc_View',$data);
	}
	public function bds_stock($value='')
	{
		# code...
		$sql  = 'SELECT `INTERVENANT_STRUCTURE_DESCR`,`INTERVENANT_STRUCTURE_ID` FROM `intervenants_structure` iss JOIN type_intervenants_structures tis ON iss.`TYPE_INTERVENANT_STRUCTURE_ID`=tis.TYPE_INTERVENANT_STRUCTURE_ID WHERE tis.CODE_STRUCTURE like "BDS" ORDER BY `INTERVENANT_STRUCTURE_DESCR` ASC';

		$bds=$this->Modele->datatable($sql);
		$array_intrant_stock =$this->input->post('array_intrant_stock'); //$_POST['array_intrant_stock'];
		if (empty($array_intrant_stock)) {
			# code...
			$array_intrant_stock=array();
		}
		 $data = array();  

	    foreach ($bds as $key) {	 
            $u=0;
		    $sub_array = array();
		    $sub_array[] = '<a href="'.base_url('stock/Stock_Intervenant/get_stock_cds/'.$key->INTERVENANT_STRUCTURE_ID).'" target="_blank">'.$key->INTERVENANT_STRUCTURE_DESCR.'</a>';
		  foreach ($array_intrant_stock as $row) {

		  	
		  		# code...
			   $sql_stck  = 'SELECT SUM(`QUANTITE`) QTE_DISPO FROM `stock_intervenat` WHERE `INTERVENANT_STRUCTURE_ID`='.$key->INTERVENANT_STRUCTURE_ID.' AND `INTRANT_ID`='.$row['INTRANT_MEDICAUX_ID'];
			   $stk = $this->Modele->getRequeteOne($sql_stck);
			   $QUANTITE_SEUIL_DISTRICT=$this->mylibrary->get_valeur_mensuelle($key->INTERVENANT_STRUCTURE_ID,$row['INTRANT_MEDICAUX_ID']);
		       if ($stk['QTE_DISPO'] < $QUANTITE_SEUIL_DISTRICT) {
		       	# code...
		       	$sub_array[] = number_format($stk['QTE_DISPO'],0,' ',' ');// "<span class='text-danger'>".number_format($stk['QTE_DISPO'],0,' ',' ')."</span>";
		       }else{
		       	$sub_array[]=number_format($stk['QTE_DISPO'],0,' ',' ');
		       }		   
               //$sub_array[]=number_format($stk['QTE_DISPO'],0,' ',' ');
               
		    }

            $data[] = $sub_array;

          

		  

		}

		$output = array(
		 // "draw" => intval($_POST['draw']),
		 // "recordsTotal" =>$this->Modele->all_data($query_principal),
		 // "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
	}
	public function cds_stock($value='')
	{
		# code...
		$BDS_ID=$_POST['ID_DISTRICT'];
		if ($BDS_ID>0) {
			# code...
			$sql  = 'SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_ID` IN (SELECT bds_cds.CDS_ID FROM bds_cds WHERE bds_cds.BDS_ID='.$BDS_ID.')';
		}else{
			$sql  = 'SELECT `INTERVENANT_STRUCTURE_ID`,`INTERVENANT_STRUCTURE_DESCR` FROM `intervenants_structure` i JOIN type_intervenants_structures t ON i.TYPE_INTERVENANT_STRUCTURE_ID=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE t.TYPE_INTERVENANT_STRUCTURE_DESCR LIKE "CDS"';
		}
		
        

		$bds=$this->Modele->datatable($sql);
		//$array_intrant_stock = $_POST['array_intrant_stock'];
		$array_intrant_stock =$this->input->post('array_intrant_stock'); //$_POST['array_intrant_stock'];
		if (empty($array_intrant_stock)) {
			# code...
			$array_intrant_stock=array();
		}
		 $data = array();  

	    foreach ($bds as $key) {	 
            $u=0;
		    $sub_array = array();
		    $sub_array[] = '<a href="'.base_url('stock/Stock_Intervenant/get_stock_asc/'.$key->INTERVENANT_STRUCTURE_ID).'" target="_blank">'.$key->INTERVENANT_STRUCTURE_DESCR.'</a>';
		    $BDS=$this->mylibrary->getBdsDependance($key->INTERVENANT_STRUCTURE_ID);
		    if (empty($BDS)) {
		    	# code...
		    	$BDS=-1;
		    }
		  foreach ($array_intrant_stock as $row) {

		  	
		  		# code...
			   $sql_stck  = 'SELECT SUM(`QUANTITE`) QTE_DISPO FROM `stock_intervenat` WHERE `INTERVENANT_STRUCTURE_ID`='.$key->INTERVENANT_STRUCTURE_ID.' AND `INTRANT_ID`='.$row['INTRANT_MEDICAUX_ID'];
			   $stk = $this->Modele->getRequeteOne($sql_stck);
			   $QUANTITE_SEUIL_CDS=$this->mylibrary->get_valeur_mensuelle_cds($BDS,$row['INTRANT_MEDICAUX_ID']);

		       if ($stk['QTE_DISPO']<$QUANTITE_SEUIL_CDS) {
		       	# code...
		       	$sub_array[] = number_format($stk['QTE_DISPO'],0,' ',' ');
		       	// $sub_array[]="<span class='text-danger'>".number_format($stk['QTE_DISPO'],0,' ',' ')."</span>";
		       }else{
		       	$sub_array[]=number_format($stk['QTE_DISPO'],0,' ',' ');
		       }
               
               
		    }

            $data[] = $sub_array;

          

		  

		}

		$output = array(
		 // "draw" => intval($_POST['draw']),
		 // "recordsTotal" =>$this->Modele->all_data($query_principal),
		 // "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
	}
	public function asc_stock($value='')
	{
		# code...
		$ID_CDS=$_POST['ID_CDS'];
		if ($ID_CDS>0) {
			# code...
			$sql  = "SELECT `INTERVENANT_RH_ID`,concat(`NOM`,'(',`TELEPHONE1`,')') nom FROM `intervenants_rh` WHERE `INTERVENANT_RH_ID` IN ( SELECT `INTERVENANT_RH_ID` FROM cds_asc WHERE cds_asc.CDS_ID=".$ID_CDS." )";
		}else{
			if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS" ) {
				# code...
				$sql  = "SELECT `INTERVENANT_RH_ID`,concat(`NOM`,'(',`TELEPHONE1`,')') nom FROM `intervenants_rh` WHERE `INTERVENANT_RH_ID` IN ( SELECT `INTERVENANT_RH_ID` FROM cds_asc WHERE cds_asc.CDS_ID IN (SELECT `CDS_ID` FROM `bds_cds` WHERE `BDS_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').") )";
			}else{
				$sql  = "SELECT `INTERVENANT_RH_ID`,concat(`NOM`,'(',`TELEPHONE1`,')') nom FROM `intervenants_rh` WHERE `INTERVENANT_RH_ID` IN ( SELECT `INTERVENANT_RH_ID` FROM cds_asc WHERE 1 )";
			}
			
		}
		

		$bds=$this->Modele->datatable($sql);
		//$array_intrant_stock = $_POST['array_intrant_stock'];
		$array_intrant_stock =$this->input->post('array_intrant_stock'); //$_POST['array_intrant_stock'];
		if (empty($array_intrant_stock)) {
			# code...
			$array_intrant_stock=array();
		}
		 $data = array();  

	    foreach ($bds as $key) {	 
            $u=0;
		    $sub_array = array();
		    $sub_array[] = $key->nom;
		  foreach ($array_intrant_stock as $row) {

		  	
		  		# code...
			   $sql_stck  = 'SELECT SUM(`QUANTITE`) QTE_DISPO FROM `stock_intervenat` WHERE `INTERVENANT_RH_ID`='.$key->INTERVENANT_RH_ID.' AND `INTRANT_ID`='.$row['INTRANT_MEDICAUX_ID'];
			   $stk = $this->Modele->getRequeteOne($sql_stck);
		   
               $sub_array[]=number_format($stk['QTE_DISPO'],0,' ',' ');
               
		    }

            $data[] = $sub_array;

          

		  

		}

		$output = array(
		 // "draw" => intval($_POST['draw']),
		 // "recordsTotal" =>$this->Modele->all_data($query_principal),
		 // "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
	}
}

?>