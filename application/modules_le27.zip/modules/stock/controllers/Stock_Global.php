<?php

/**
 * @author jules_ndihokubwayo@mediabox.bi
 *stock global:-CAMEBU
               -DODS/PNILP
               -INTERVENANT
 *
 */
class Stock_Global extends MY_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		$this->is_auth();
	}

	public function is_auth($value='')
	{
		# code...
		if (empty($this->session->userdata('iccm_USER_ID'))) {
			# code...
			redirect(base_url());
		}
	}
	//CAMEBU
	public function index($value='')
	{
		# code...
		if ($this->session->userdata('iccm_PROFIL_CODE')=="CAM" || $this->session->userdata('iccm_PROFIL_CODE')=="PTF") {
			# code...
		
         $sql="SELECT DISTINCT `INTRANT_ID` FROM `rc_reception_intrant_detail` WHERE 1";
		 $intrant=$this->Modele->getRequete($sql);
	     $data =array('title'=>'Stock - '.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_DESCR').'','intrant'=>$intrant);
	     $this->load->view('Stock_Global_View',$data);
	     // $this->page = 'Stock_Global_View';
	     // $this->layout($data);
	    }else if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS" || $this->session->userdata('iccm_PROFIL_CODE')=="CDS") {
	    	# code...
	    	redirect(base_url('stock/Stock_Global/indexintev'));
	    }else if ($this->session->userdata('iccm_PROFIL_CODE')=="DODS" || $this->session->userdata('iccm_PROFIL_CODE')=="PNLIP") {
	    	# code...
	    	redirect(base_url('stock/Stock_Global/indexdp'));
	    }


	    else{
	    	redirect(base_url());//f*cking out
	    }
	}
	//DODS/PNILP
	public function indexdp($value='')
	{
		# code...rrc.`MODE_RECEPTION_ID`='.$MODE_RECEPTION_ID.' and 

		if ($this->session->userdata('iccm_PROFIL_CODE')=="PNLIP") {
			# code...
			$sql="SELECT DISTINCT `INTRANT_ID` FROM `rc_reception_intrant_detail` WHERE MODE_RECEPTION_ID IN ( SELECT MODE_RECEPTION_ID FROM rc_mode_reception WHERE MODE_RECEPTION_DESCR LIKE '".$this->session->userdata('iccm_PROFIL_CODE')."')";
		}else{
			$sql="SELECT DISTINCT `INTRANT_ID` FROM `rc_reception_intrant_detail`";
		}
		
         
        
		 $intrant=$this->Modele->getRequete($sql);
	     $data =array('title'=>'Stock - '.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_DESCR').'','intrant'=>$intrant);

	     $this->load->view('Stock_Global_Dods_Pnilp_View',$data);

	}
	//INTERVENANT
	public function indexintev($value='')
	{
		# code...
		
		// echo $this->session->userdata('iccm_INTERVENANT_RH_ID');die();
         $sql="SELECT DISTINCT `INTRANT_ID` FROM `stock_distribution_intrant_detail`";
		 $intrant=$this->Modele->getRequete($sql);
		  
		 if (empty($this->session->userdata('iccm_INTERVENANT_RH_ID'))) {
         	# code...
         	$SS_iccm_INTERVENANT_RH_ID=0;
         	
         }else{
            $SS_iccm_INTERVENANT_RH_ID=$this->session->userdata('iccm_INTERVENANT_RH_ID');
         }
         	$intervenants_rh=$this->Modele->getOne('intervenants_rh',array('INTERVENANT_RH_ID'=>$this->session->userdata('iccm_INTERVENANT_RH_ID')));
         	$intervenants_structure=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$intervenants_rh['INTERVENANT_STRUCTURE_ID']));
         
	     $data =array(
	     	           'title'=>'Stock - '.$this->session->userdata('iccm_INTERVENANT_STRUCTURE_DESCR').'',
	     	           'intrant'=>$intrant,
	     	           'INTERVENANT_STRUCTURE_ID'=>$intervenants_rh['INTERVENANT_STRUCTURE_ID'],
	     	           'INTERVENANT_STRUCTURE_DESCR'=>$intervenants_structure['INTERVENANT_STRUCTURE_DESCR']);
	     $this->load->view('Stock_Global_Structure_Intervenant_View',$data);
	     // $this->page = 'Stock_Global_Structure_Intervenant_View';
	     // $this->layout($data);
	}	
}
?>