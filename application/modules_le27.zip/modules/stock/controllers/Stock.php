<?php

/**
 * @author jules_ndihokubwayo@mediabox.bi
 *Processus de stockage chez camebu les intrants receptionner
 *
 */
class Stock extends MY_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
		$this->is_auth();
	}
	public function is_auth($value='')
	{
		# code...$this->is_auth();
		if (empty($this->session->userdata('iccm_USER_ID'))) {
			# code...
			redirect(base_url());
		}
	}
	public function index($value='')
	{
		# code...
		 $sql="SELECT   `RECEPTION_CODE`,`RECEPTION_ID` FROM `rc_reception` ORDER BY `RECEPTION_DATE` DESC";
		 $code=$this->Modele->getRequete($sql);
	     $data =array('title'=>'Stock','code'=>$code);

	      $data =array('title'=>'Stock Global','intrant'=>$intrant);
	     $this->load->view('Stock_Reception_View',$data);
	    
	}
    public function liste($value=0)
    {
        
          $RECEPTION_ID=$this->input->post('RECEPTION_ID');

		  $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		  $var_search=str_replace("'", "\'", $var_search);  
		  $query_principal='SELECT RECEPTION_INTRANT_ID,`QUANTITE`,QUANTITE_DEJA_STOCKE,im.INTRANT_MEDICAUX_DESCR,rr.RECEPTION_CODE,rr.RECEPTION_DATE,rr.RECEPTION_ID,INTRANT_ID FROM `rc_reception_intrant_detail` rri JOIN intrant_medicaux im ON rri.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID JOIN rc_reception rr ON rri.`RECEPTION_ID`=rr.RECEPTION_ID';
          $critaire="";
          if (!empty($RECEPTION_ID)) {
          	# code...
          	$critaire=" WHERE rr.RECEPTION_ID=".$RECEPTION_ID;
          }
		  $limit='LIMIT 0,10';
		  if($_POST['length'] != -1){
		    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		  }
		  $order_by='';
		  if($_POST['order']['0']['column']!=0){
		    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTRANT_MEDICAUX_DESCR DESC';
		  }

		  $search = !empty($_POST['search']['value']) ? (" AND (INTRANT_MEDICAUX_DESCR LIKE '%$var_search%' OR  RECEPTION_CODE LIKE '%$var_search%')") : '';


		  
		  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		  $query_filter=$query_principal.'  '.$critaire.' '.$search;

		  $fetch_enqueteurs = $this->Modele->datatable($query_secondaire);
		  $u=0;
		  $data = array();
		  foreach ($fetch_enqueteurs as $row) {

		   $qte_a_stocke=$row->QUANTITE-$row->QUANTITE_DEJA_STOCKE;
		   $qte_deja_stocke=$row->QUANTITE_DEJA_STOCKE-$row->QUANTITE;
		   $u++;
		   $sub_array = array();
		   $sub_array[] =  $u;
		   $sub_array[] =$row->RECEPTION_CODE;
           $sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
		   $sub_array[]=number_format($row->QUANTITE,0,' ',',');
           $sub_array[]=number_format($qte_deja_stocke,2,' ',',');//quantite deja stocke
           $sub_array[]=number_format($qte_a_stocke,2,' ',',');//quantite pas encore stocke
           if ($row->QUANTITE_DEJA_STOCKE<$row->QUANTITE) {
           	# code...=
           	$sub_array[]='<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw"></i>';
           }else{
           	$sub_array[]='<i style="color:green;" class="fa fa-check" aria-hidden="true"></i>';
           }
           $sub_array[]=$row->RECEPTION_DATE;
           
           $opt='<div class="dropdown" style="color:#fff;">
                       <a class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown">
                       <i class="fa fa-cog"></i> Options<span class="caret">
                       </span></a> 
	                   <ul class="dropdown-menu dropdown-menu-left">';
	        if ($row->QUANTITE_DEJA_STOCKE<$row->QUANTITE) {
	                   	# code...
	                     $COD="";
	                     $COD=$row->RECEPTION_CODE;        

	                  $opt.="<li><a href='#' onclick='show_modal(".$row->RECEPTION_INTRANT_ID.",".$qte_a_stocke.",\"".$COD."\",".$row->INTRANT_ID.")'>Stocker</a></li>";
            }
            $opt.='<li><a href="#" onclick="show_historique('.$row->RECEPTION_INTRANT_ID.')">Historique de stockage</a></li>';
	       $opt.='</ul>';

          $sub_array[]=$opt;
		  $data[] = $sub_array;

		}
 
		$output = array(
		 "draw" => intval($_POST['draw']),
		 "recordsTotal" =>$this->Modele->all_data($query_principal),
		 "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
}
public function valider($value='')
{
	# code...
    $QUANTITE_A_STOCKER=$this->input->post('QUANTITE_A_STOCKER');
    $RECEPTION_INTRANT_ID=$this->input->post('RECEPTION_INTRANT_ID');
    $COMMENT=$this->input->post('COMMENT');
    $RECEPTION_CODE=$this->input->post('RECEPTION_CODE');
    $QUANTITEASTOCKER=$this->input->post('QUANTITEASTOCKER');
    $INTRANT_ID=$this->input->post('INTRANT_ID');
    $USER_ID=$this->session->userdata('iccm_USER_ID');
    if (empty($USER_ID)) {
    	# code...
    	$USER_ID='-1';
    }
    $retour=0;
    //si quantite restant a stocker <= a quantite envoye
    if ($QUANTITE_A_STOCKER<=$QUANTITEASTOCKER) {

	   
      
      ####################################STOCK CAMEBU#################################################
	   $quantite_precedent_sock_camebu=$this->Modele->getOne('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'INTRANT_ID'=>$INTRANT_ID));

       if (empty($quantite_precedent_sock_camebu['INTRANT_ID'])) {
       	# code...
	    $quantite_precedent_sock_camebu['QUANTITE']=0;
       }
	   

	   if ((!empty($quantite_precedent_sock_camebu['QUANTITE']) || $quantite_precedent_sock_camebu['QUANTITE']>=0) && !empty($quantite_precedent_sock_camebu['INTRANT_ID']) ) {
	   	# code...
	   	$QUANTITE_STOCK_CAMEBU=$quantite_precedent_sock_camebu['QUANTITE']+$QUANTITE_A_STOCKER;
	   	$this->Modele->update('stock_camebu',array('RECEPTION_CODE'=>$RECEPTION_CODE,'INTRANT_ID'=>$INTRANT_ID),array('QUANTITE'=>$QUANTITE_STOCK_CAMEBU,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));

	   }else{
	   	$stock_camebu=array(
	   		'RECEPTION_CODE'=>$RECEPTION_CODE,
	   		'QUANTITE'=>$QUANTITE_A_STOCKER,
	   		'INTRANT_ID'=>$INTRANT_ID,
	   		'USER_STOCKEUR_ID'=>$USER_ID,
	   		'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s'),
	   		'DATE_ENTRE_STOCK'=>date('Y-m-d H:i:s'),

	   );
	   	$this->Modele->create('stock_camebu',$stock_camebu);
	   }
       $came=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID` FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');
       if (empty($came['INTERVENANT_STRUCTURE_ID'])) {
       	# code...
       	$came['INTERVENANT_STRUCTURE_ID']=8;// pris par hasard du structure CAMEBU
       }
	   $INTERVENANT_STRUCTURE_ID=$came['INTERVENANT_STRUCTURE_ID'];
     ###########################################STOCK INTERVENANT################################################
	   $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));
       $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']+$QUANTITE_A_STOCKER;
	   if ($quantite_precedent_sock_intervenant['QUANTITE']>=0 && !empty($quantite_precedent_sock_intervenant['INTRANT_ID'])) {
	   	# code...
	   	$this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
	   }else{
	   	$stock_intervenat=array('INTERVENANT_STRUCTURE_ID' => $INTERVENANT_STRUCTURE_ID,
	   		                    'INTRANT_ID' => $INTRANT_ID,
	   		                    'QUANTITE' =>$QUANTITE_A_STOCKER ,
	   		                    'DATE_LAST_UPDATE' =>date('Y-m-d H:i:s'),
	   		                    );
	   	$this->Modele->create('stock_intervenat',$stock_intervenat);
	   }
     #####################################INTRANT DETAIL####################################
        $quantite_precedent=$this->Modele->getOne('rc_reception_intrant_detail',array('RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID));
	    $QUANTITE_DEJA_STOCKE=$quantite_precedent['QUANTITE_DEJA_STOCKE']+$QUANTITE_A_STOCKER;

    
    	# code...
    	$stock_reception_historique=array('QUANTITE'=>$QUANTITE_A_STOCKER,
    		                  'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
    		                  'RECEPTION_CODE'=>$RECEPTION_CODE,
    		                  'COMMENT'=>$COMMENT,
    		                  'INTRANT_ID'=>$INTRANT_ID,
    		                  'USER_ID'=>$USER_ID

    		                  );
    	$this->Modele->create('stock_reception_historique',$stock_reception_historique);

    	$this->Modele->update('rc_reception_intrant_detail',array('RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID),array('QUANTITE_DEJA_STOCKE'=>$QUANTITE_DEJA_STOCKE));
    	$retour=1;
    }
    echo $retour;
    
    
}
public function get_history($value='')
{
	# code...
	$RECEPTION_INTRANT_ID=$this->input->post('RECEPTION_INTRANT_ID');
	$sql="SELECT COMMENT, `DATE_INSERTION`,`QUANTITE`,im.INTRANT_MEDICAUX_DESCR,au.USER_NAME FROM `stock_reception_historique` sr JOIN intrant_medicaux im ON sr.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID LEFT JOIN admin_users au ON sr.`USER_ID`=au.USER_ID WHERE `RECEPTION_INTRANT_ID`=".$RECEPTION_INTRANT_ID;
	$histo=$this->Modele->getRequete($sql);
	$table='<table class="table">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">INTRANT</th>
			      <th scope="col">QUANTITE</th>
			      <th scope="col">DATE</th>
			      <th scope="col">GESTIONNAIRE</th>
			      <th scope="col">OBSERVATION<th>
			    </tr>
			  </thead>
			  <tbody>';
	$i=0;
	foreach ($histo as $key ) {
		# code...
		$i++;
		$table.="<tr><td>".$i."</td><td>".$key['INTRANT_MEDICAUX_DESCR']."</td><td>".number_format($key['QUANTITE'],0,' ',',')."</td><td>".$key['DATE_INSERTION']."</td><td>".$key['USER_NAME']."</td><td>".$key['COMMENT']."</td></tr>";
	}
	echo $table."</tbody></table>";
}

}

?>