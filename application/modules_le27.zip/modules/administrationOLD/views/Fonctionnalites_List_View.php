
      
      
  


<div class="row">
  <legend>
    <?= $title;?>
    <div class="pull-right" style="padding-bottom:20px;">
      <a href="<?= base_url('administration/Fonctionnalites/ajouterFonctionnalite'); ?>" class="btn btn-secondary"><i class="fa fa-plus"></i>
        Ajouter
      </a>
    </div>
  </legend>
</div>

<?=  $this->session->flashdata('message');?>
<?= $this->table->generate($donnees_Fonctionnalite); ?> 
           
        
   



   
   
   <!-- partial -->
   


   
   <!-- End custom js for this page-->





