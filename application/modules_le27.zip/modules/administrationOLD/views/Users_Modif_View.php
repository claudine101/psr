<div class="row">
  <legend>
    <?= $title;?>

    <div class="pull-right">
      <a href="<?= base_url('administration/Users/listing'); ?>" class="btn btn-primary btn-sm pull-right">
        <i class="fa fa-list"></i>
        Liste
      </a>
    </div>
  </legend>
      
</div>

<form name="myform" method="post" class="form-horizontal" action="<?= base_url('administration/Users/update'); ?>">
	<div class="row">
      <input type="hidden" class="form-control" name="USER_ID" value="<?=$data_users['USER_ID']?>" >
       <input type="hidden" class="form-control" name="INTERVENANT_RH_ID" value="<?=$data_users['INTERVENANT_RH_ID']?>" >

    <div class="col-md-6">
      <label for="FName">Username:</label>
      <input type="text" name="USER_NAME" value="<?=$data_users['USER_NAME']?>" class="form-control" id="USER_NAME" >
  		<?php echo form_error('USER_NAME', '<div class="text-danger">', '</div>'); ?> 
  	</div>

    <div class="col-md-6">
      <label for="LName">Email:</label>
      <input type="text" name="EMAIL" value="<?=$data_users['EMAIL']?>" class="form-control" id="EMAIL">
       <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?>
    </div>
  </div>
  <div class="row">
     
    <div class="col-md-6">
      <label for="FName">Active:</label>
      <select class="form-control selectpicker" data-live-search="true"  name="IS_ACTIVE" >

      	<option value=''>Séléctionner</option>
        <?php 
         
	          	if ($data_users['IS_ACTIVE'] ==1) 
	          	{ ?>
			        	<option value='1' selected>Oui</option>
			        	<option value='0'>Non</option>
			  <?php } 
			        else if ($data_users['IS_ACTIVE'] ==0)
			        {  ?>

	              <option value='1'>Oui</option>
			        	<option value='0' selected>Non</option>			        
			    <?php } 
			        else 
			        {  ?>

			        	<option value='1'>Oui</option>
			        	<option value='0'>Non</option>	
               
          <?php }?>
      </select>
   	  <?php echo form_error('IS_ACTIVE', '<div class="text-danger">', '</div>'); ?> 
  </div>

    <div class="col-md-6">
      <label for="LName">Profil:</label>
      <select class="form-control selectpicker" data-live-search="true"  name="PROFIL_ID" >
        <?php 
         	foreach($admin_profil as $key_profil)
         	  { 
	          	if ($key_profil['PROFIL_ID'] == $data_users['PROFIL_ID']) 
	          	{ 
			       	  echo "<option value='".$key_profil['PROFIL_ID']."' selected>".$key_profil['PROFIL_DESCR']."</option>";
			        } 
			        else
			        {
			        	echo "<option value='".$key_profil['PROFIL_ID']."' >".$key_profil['PROFIL_DESCR']."</option>"; 
			        }
            }
        ?>
      </select>
      <?php echo form_error('PROFIL_ID', '<div class="text-danger">', '</div>'); ?>
    </div>
  </div>
  <div>
  	<div class="col-md-6 col-sm-6 col-xs-6 col-md-push-2">
      <button type="submit" class="btn btn-primary form-control" style="margin-top: 20px;">Modifier
      </button>
    </div>
  </div>
</form>