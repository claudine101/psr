

<div class="row">
  	<div>
  	  <h3>Liste des Profils</h3>	
  	</div>
  	<div class="pull-right">
	 	<a href="<?= base_url('Admin_Profil/Add_profil')?>" class="btn btn-primary">
	  	  Ajouter
	  	</a>
    </div>
  <div class="table">
  	<table class="table table-responsive">
  	  <thead>
        <tr>
	        <th>Code</th>
	  	  	<th>Profil</th>
	  	  	<th>Action</th>
        </tr>
  	  </thead>
  	  <tbody>
<?php foreach ($data as $value)
 { ?>
	  <tr>
  	  	 <td><?=$value['PROFIL_CODE'];?></td>
  	  	 <td><?=$value['PROFIL_DESCR'];?></td>

  	  	 <td>
  	  	   <a href="<?=base_url('Admin_Profil/Update_view/').$value['PROFIL_ID']?>" class="btn btn-primary">Modifier</a>

  	  	   <a href="<?= base_url('Admin_Profil/Delete_Profil/').$value['PROFIL_ID']?>" class="btn btn-danger">Supprimer</a>
  	  	 </td>
  	  </tr>
<?php } ?>
  	  </tbody>	
  	</table>
  </div>
</div>
