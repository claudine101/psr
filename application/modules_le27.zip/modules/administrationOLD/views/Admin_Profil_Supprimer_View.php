

<div class="row">
  <div class="col-md-10">
    <form action="<?= base_url('Admin_Profil/Supprimer')?>" method="post">
        <div class="col-md-6">
           <label>Code:</label>
           <input type="text" value="<?=$admin_profil['PROFIL_CODE'];?>"class="form-control" name="code" >
        </div>
        <div class="col-md-6">
           <label>Descr:</label>
           <input type="text"value="<?=$admin_profil['PROFIL_DESCR'];?>"class="form-control" name="descr" >
        </div>
       
        <br><br>
      	<div> 
      	  <input type="submit" class="btn btn-primary" name="submit" value="Supprimer">
       	</div>
    </form>
  </div>
</div>