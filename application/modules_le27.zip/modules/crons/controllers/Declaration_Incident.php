<?php
/**
* 
*/
class Declaration_Incident extends CI_Controller
{
	
	public function index_declaration_incident()
	{
		
		$flux=file_get_contents('php://input');
		$array_declaration=json_decode($flux);
		 $this->Modele->create('json_declaration_incident',array('DATA_JSON'=>$flux));   
	}

	function traiter()
	{
		$incidents=$this->Modele->getList('json_declaration_incident',array('TRAITER'=>0));

		foreach ($incidents as $key)
		{
		  $array_inc = str_replace('/', '_', $key['DATA_JSON']);
          $array = json_decode($array_inc); 

          $DATA_INCIDENT=str_replace("/", "_",$key['DATA_JSON']);
          $DATA_INCIDENT=json_decode($DATA_INCIDENT);


          $code=$array->incident_code;
          $sex=$array->incident_sexe;
          $type_maladie=$array->incident_maladie;
          $tranche=$array->incident_tranche_age;
          $type_incident=$array->incident_types_incidents;

          if (array_key_exists($code, array)) 
          {
          	
          }


          // echo "<pre>";
          // print_r($array);
		}
		// die();

	}
}