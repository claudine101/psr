<?php
/**
 * @author jules_ndihokubwayo@mediabox.bi
 *le 10-05-2021
 *TACHE:Auto creation des demandes en cas de rupture du stock et si le stock de de securite est atteint
 *plus generation des notif de seuil
 */
class Auto_Demande extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function generate_demande($value='')
	{
			# code...
			$sql  = 'SELECT s.`INTERVENANT_STRUCTURE_ID`,`INTRANT_ID`,`QUANTITE`,i.INTRANT_MEDICAUX_DESCR,iss.INTERVENANT_STRUCTURE_DESCR,iss.EMAIL,ti.TYPE_INTERVENANT_STRUCTURE_DESCR,ti.CODE_STRUCTURE FROM `stock_intervenat` s JOIN intrant_medicaux i ON s.`INTRANT_ID`=i.INTRANT_MEDICAUX_ID JOIN intervenants_structure iss ON s.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID JOIN type_intervenants_structures ti ON iss.TYPE_INTERVENANT_STRUCTURE_ID=ti.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_RH_ID` IS NULL';
			$intr=$this->Modele->getRequete($sql);
			/**********************************************************************************/
			$get_mail_minisante=$this->Modele->getRequete("SELECT intv.EMAIL FROM intervenants_structure intv JOIN type_intervenants_structures typ ON typ.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE 'MINISANTE'");

			foreach ($get_mail_minisante as $key) {
				$EMAIL_CC_DODS_PNILP[]=$key['EMAIL'];
				
			}
			$EMAIL_CAMBEBU=$this->Modele->getRequeteOne("SELECT intv.EMAIL FROM intervenants_structure intv JOIN type_intervenants_structures typ ON typ.TYPE_INTERVENANT_STRUCTURE_ID=intv.TYPE_INTERVENANT_STRUCTURE_ID WHERE typ.CODE_STRUCTURE LIKE 'CAMEBU'");

			$EMAIL_CC_DODS_PNILP[]=$EMAIL_CAMBEBU['EMAIL'];
			/***********************************************************************************/
				foreach ($intr as $key) {
				# code...CDS...CAMEBU...BDS
				//$sql_tp  = 'SELECT t.CODE_STRUCTURE,EMAIL FROM `intervenants_structure` iss JOIN type_intervenants_structures t ON iss.`TYPE_INTERVENANT_STRUCTURE_ID`=t.TYPE_INTERVENANT_STRUCTURE_ID WHERE `INTERVENANT_STRUCTURE_ID`='.$key['INTERVENANT_STRUCTURE_ID'];
				//$type=$this->Modele->getRequeteOne($sql_tp);
				$QUANTITE_SEUIL=0;
				if ($key['CODE_STRUCTURE']=="CAMEBU") {
					# code...
	                $QUANTITE_SEUIL=$this->mylibrary->get_valeur_mensuelle_camebu($key['INTRANT_ID']);
	                $EMAIL_CC=$EMAIL_CC_DODS_PNILP;
				}
				if ($key['CODE_STRUCTURE']=="BDS") {
					# code...
					$QUANTITE_SEUIL=$this->mylibrary->get_valeur_mensuelle($key['INTERVENANT_STRUCTURE_ID'],$key['INTRANT_ID']);
                    $EMAIL_CC=$EMAIL_CC_DODS_PNILP;
				}
				if ($key['CODE_STRUCTURE']=="CDS") {
					# code...
					$BDS=$this->mylibrary->getBdsDependance($key['INTERVENANT_STRUCTURE_ID']);
	           	    $QUANTITE_SEUIL=$this->mylibrary->get_valeur_mensuelle_cds($BDS,$key['INTRANT_ID']);
	           	    $EMAIL_BDS_PARENT=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$BDS));
	           	    $EMAIL_CC_DODS_PNILP[]=$EMAIL_BDS_PARENT['EMAIL'];
	           	    $EMAIL_CC=$EMAIL_CC_DODS_PNILP;
				}

				if ($QUANTITE_SEUIL>=$key['QUANTITE']) {
					# code...
					if ($QUANTITE_SEUIL==$key['QUANTITE']) {
						# code...
						$DESCRIPTION_TICKET="La quantité disponible est égale à la quantité seuil";
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock en ".$key['INTRANT_MEDICAUX_DESCR']." est  égal au seuil de sécurité depuis le ".date('d-m-Y')."";
					} 
					if ($key['QUANTITE']==0) {
						# code...
						$DESCRIPTION_TICKET="Stock épuisé";
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock en ".$key['INTRANT_MEDICAUX_DESCR']." est  épuisé depuis le ".date('d-m-Y').".";
					}
				    if ($QUANTITE_SEUIL>$key['QUANTITE']) {
						# code...
						$DESCRIPTION_TICKET="La quantité disponible est inférieure à la quantité seuil";
						$MESSAGE="Cher ".$key['INTERVENANT_STRUCTURE_DESCR']." votre stock en ".$key['INTRANT_MEDICAUX_DESCR']." est  inférieur au seuil de sécurité depuis le ".date('d-m-Y')."";
					}
				$taux=(($QUANTITE_SEUIL*5)/100)+$QUANTITE_SEUIL;
				$stock_demade_systeme = array(
		      
		        'INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID'] ,
		        'INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID'] ,
		        'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,
		        'QUANTITE_DISPONIBLE'=>$key['QUANTITE'],
		        'QUANTITE' =>round($taux),
		        'STATUT_VALIDATION'=>0
		       );
				$stock_demade_systeme_2 = array(
		      
		        'INTERVENANT_STRUCTURE_ID' =>$key['INTERVENANT_STRUCTURE_ID'] ,
		        'INTRANT_MEDICAUX_ID' =>$key['INTRANT_ID'] ,

		        'QUANTITE' =>round($taux),
		        'STATUT_VALIDATION'=>0
		       );
                $d2=$this->Modele->getOne('stock_demade_systeme',$stock_demade_systeme_2);
                if (empty($d2['QUANTITE'])) {
                    	# code...
   					    $this->Modele->create('stock_demade_systeme',$stock_demade_systeme);
                }
				$d=$this->Modele->getOne('stock_demade_systeme',$stock_demade_systeme);
				if (empty($d['QUANTITE'])) {
					# code...
					$OBJECT=$key['INTERVENANT_STRUCTURE_DESCR']." - Rupture du stock - ".$key['INTRANT_MEDICAUX_DESCR'];
					$EMAIL_TO=$key['EMAIL'];

					$array_stock_rupture_tick=array(
						         'INTERVENANT_STRUCTURE_ID'=>$key['INTERVENANT_STRUCTURE_ID'],
						         'INTRANT_ID'=>$key['INTRANT_ID'],
						         'QUANTITE_DISPONIBLE'=>$key['QUANTITE'],
						         'QUANTITE_SEUIL'=>$QUANTITE_SEUIL,
						         'DESCRIPTION_TICKET'=>$DESCRIPTION_TICKET);

					$array_notification_rupture_seuil=array(
						         'MESSAGE'=>$MESSAGE,
						         'INTRANT_ID'=>$key['INTRANT_ID'],
						         'QUANTITE_RESTANT'=>$key['QUANTITE'],
						         'INTERVENANT_STRUCTURE_ID'=>$key['INTERVENANT_STRUCTURE_ID'],
						     );
					$this->Modele->create('notification_seuil_stock',$array_notification_rupture_seuil);
					$ID_STOCK_RUPTURE_TICKET=$this->Modele->insert_last_id('stock_rupture_ticket',$array_stock_rupture_tick);
					$array_historique=array('ID_STOCK_RUPTURE_TICKET'=>$ID_STOCK_RUPTURE_TICKET,'COMMENTAIRE'=>$DESCRIPTION_TICKET);
					$this->Modele->create('stock_rupture_ticket_historique',$array_historique);


					$this->notifications->send_mail($EMAIL_TO,$OBJECT,$EMAIL_CC,$MESSAGE,array());
					//print_r($stock_demade_systeme);
				}

				//print_r($d['QUANTITE']);
			}

		}


	}
}
?>