<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>



<style type="text/css">
 .mapbox-improve-map{
  display: none;
}

.leaflet-control-attribution{
  display: none !important;
}
.leaflet-control-attribution{
  display: none !important;
}


.mapbox-logo {
  display: none;
}
</style>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
               <?php
              $menu1="nav-link";
              $menu2="nav-link active";
              //$menu3="nav-link active"; 
              include('includes/sous_menu_intervenant_structure.php'); ?>
    
<!--               <h4 class="m-0"><?=$title?></h4>
 -->            </div><!-- /.col -->
            <div class="col-sm-6">
<!-- <a href="stock_distribution/Liste_Sms_Distribution/">Distribution sms</a> -->
           
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="col-md-12 col-xl-12 grid-margin stretch-card">
          <div class="card">
      
            <div class="card-body" style="overflow-x: auto;" >

             

              <div style="padding-top: 5px;" class="col-md-12">
               <div class="col-5" style="padding: 5px;">
                 <label for="INTERVENANT_STRUCTURE_ID">BDS</label>
                 <select  class="form-control"  id="INTERVENANT_STRUCTURE_ID" onclick="getList(this.value)">
                  <option value="" selected="">sélectionner</option>
                        <?php foreach ($intervenants_structure as $key) {
                          # code...
                        ?>
                        <option value="<?= $key['INTERVENANT_STRUCTURE_ID'] ?> " <?php if ($this->session->userdata('iccm_INTERVENNT_ASTRUCTURE_ID')== $key['INTERVENANT_STRUCTURE_ID']) {
                          # code...
                          echo "selected";
                        } ?> ><?= $key['INTERVENANT_STRUCTURE_DESCR'] ?></option>

                        <?php } ?>
                 </select>
               </div> 
               <br>
                <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                  <thead>
                    <tr>
                      <th>STRUCTURE</th> 
                      <th>ASC</th>
                      <th>MALADIE</th> 
                      <th>DATE</th> 
                      <th>TELEPHONE</th> 
                      <th>INTRANTS</th> 
                       
                    </tr>
                  </thead>

                </table>


              </div>
              

            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>

  </div>
  <!-- ./wrapper -->
  <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>



<script>

  $(document).ready(function(){
    getList();
  });
  function detail_intra(id=<?=$INTERVENTION_ID?>)
  {
    $("#intrant_detail").modal("show");

    $(document).ready(function(){
     var row_count ="1000000";
     $("#mydetail").DataTable({
      "processing":true,
      "destroy" : true,
      "serverSide":true,
      "oreder":[[ 0, 'desc' ]],
      "ajax":{
        url:"<?=base_url()?>stock_distribution/Liste_Sms_Distribution/get_Detail/"+id,
        type:"POST"
      },
      lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
      pageLength: 10,
      "columnDefs":[{
        "targets":[],
        "orderable":false
      }],

      dom: 'Bfrtlip',
      buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
      ],
      language: {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      }

    });
   })
  }


  function getList(BDS=0)
  {
    
   var row_count ="1000000";
   $("#mytable").DataTable({
    "processing":true,
    "destroy" : true,
    "serverSide":true,
    "oreder":[[ 0, 'desc' ]],
    "ajax":{
      url:"<?=base_url()?>stock_distribution/Liste_Sms_Distribution/listing/",
      type:"POST"
    }
    ,
    data : {
               
               INTERVENANT_STRUCTURE_ID:BDS,


            },
    lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
    "columnDefs":[{
      "targets":[],
      "orderable":false
    }],

    dom: 'Bfrtlip',
    buttons: [
    'copy', 'csv', 'excel', 'pdf', 'print'
    ],
    language: {
      "sProcessing":     "Traitement en cours...",
      "sSearch":         "Rechercher&nbsp;:",
      "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
      "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
      "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
      "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
      "sInfoPostFix":    "",
      "sLoadingRecords": "Chargement en cours...",
      "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
      "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
      "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
      },
      "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
      }
    }

  });

 }


</script>





<div class="modal fade bd-example-modal-lg" id="intrant_detail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="statut"></h4>
          <button type="button"  class="close btn btn-outline-danger btn-sm" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="container-fluid" style="padding: 20px;">
          <center><span id="message_retour"></span></center>
          <div class="col-md-12">
           <table id='mydetail' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
            <thead>
              <tr>
                <th>INTRANTS</th>
                <th>QUANTITE</th>
                
              </tr>
            </thead>

          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
