<div class="row">
  <legend>
    <?= $title;?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?= base_url('stock_distribution/Distribution_Intrants/distribution/'.$DEMANDE_ID)?>">
        <i class="fa fa-plus"></i>Distribué 
      </a>
      <a class="btn btn-primary" href="<?= base_url('stock_distribution/Distribution_Intrants/index')?>">
        <i class="fa fa-th"></i> Liste
      </a>
    </div>
  </legend>
</div>
<div class="row">
 <!--  <div class="col-md-12">
    <form action="<?=base_url('stock_distribution/Distribution_Intrants/listing_distribution/'.$DEMANDE_ID)?>" method="POST" id="myform">
      <div class="row">


          <div class="col-md-4">

           <label>Structures intervenants :</label>
           <select class="form-control"  onchange="load_structures()" name="INTERVENANT_STRUCTURE_ID">
             <option value="">--choisir--</option>
             <?php

             foreach ($structures_intervenant as $structure) {

              if ($structure['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')) {?>
                <option value="<?=$structure['INTERVENANT_STRUCTURE_ID']?>" selected=''><?=$structure['INTERVENANT_STRUCTURE_DESCR']?></option>
                <?php } else {?>
                  <option value="<?=$structure['INTERVENANT_STRUCTURE_ID']?>"><?=$structure['INTERVENANT_STRUCTURE_DESCR']?></option>
                  <?php }
                  
                }
                
                ?>
              </select>

            </div>

            <div class="col-md-4">

             <label>Intrants :</label>
             <select class="form-control"  onchange="load_intrants()" name="INTRANT_MEDICAUX_ID">
               <option value="">--choisir--</option>
               <?php

               foreach ($intrants as $value) {

                if ($value['INTRANT_MEDICAUX_ID']==set_value('INTRANT_MEDICAUX_ID')) {?>
                  <option value="<?=$value['INTRANT_MEDICAUX_ID']?>" selected=''><?=$value['INTRANT_MEDICAUX_DESCR']?></option>
                  <?php } else {?>
                    <option value="<?=$value['INTRANT_MEDICAUX_ID']?>"><?=$value['INTRANT_MEDICAUX_DESCR']?></option>
                    <?php }

                  }

                  ?>
                </select>

              </div>




              <div class="col-md-4">

               <label>Date de distribution :</label>
               <input type="date" name="DISTRIBUTION_DATE" value="<?=set_value('DISTRIBUTION_DATE')?>" onchange="load_date();" class="form-control">


             </div>


           </div>
         </form>
       </div>
     </div> -->
     <br><br>
     <div class="row">
      <div class="col-md-12">
        <?= $this->table->generate($distributions);?>
      </div>
    </div>