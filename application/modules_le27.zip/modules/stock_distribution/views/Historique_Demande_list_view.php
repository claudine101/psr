<div class="row">
<?php if($this->session->flashdata('sms')){
   echo $this->session->flashdata('sms');
} ?>
</div>
<div class="col-md-12" style="padding:5px;">
  <legend>
    <?= $title;?>
    <div class="pull-right">
      <a class="btn btn-primary" href="<?= base_url('stock_distribution/Distribution_Intrants/distribution/'.$DEMANDE_ID)?>">
        <i class="fa fa-plus"></i> Distribué 
      </a>
      <a class="btn btn-primary" href="<?= base_url('stock_distribution/Distribution_Intrants/index')?>">
        <i class="fa fa-th"></i> Liste
      </a>
    </div>
    <br>
  </legend>
</div>
<div class="row" style="padding:5px;">
  <div class="col-md-12">
    <?php echo $this->table->generate($array_historique); ?>
  </div>
</div>





