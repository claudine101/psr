<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<div class="row">
<?php if($this->session->flashdata('sms')){
   echo $this->session->flashdata('sms');
} ?>
</div>



<div class="row col-md-12">
  <legend>
    <h4><?= $title;?></h4>
    <div class="pull-right" style="padding:10px;">
      <a class="btn btn-primary" href="#">
        <i class="fa fa-plus"></i>Nouveau
      </a>
      <a class="btn btn-primary" href="<?=base_url('stock_distribution/Distribution_Intrants/historique')?>">
        <i class="fa fa-book"></i> Historique
      </a>
      
      
    </div>
  </legend>
</div>
<div class="row col-md-12" style="padding:20px;">
  <?php echo $this->table->generate($array_stock_demande); ?>
</div>



<script type="text/javascript">


$(document).ready(function() {
    $('#mytable').DataTable( {
       // "scrollY":        "200px",
       // "scrollCollapse": true,
       "ordering": false,

      "columnDefs":[{
            "targets":[],
            "orderable":false
        }],
        "paging":         true,
        buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
    } );
} );
</script>





