
<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php'; ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            
            <?php
              $menu1="nav-link active";
              $menu2="nav-link";

              include VIEWPATH.'sousmenu/sous_menu_demande.php'; ?>              
           
          </div>
          <div class="col-sm-12 ">
           <?php  if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS") {
             # code...
            ?>
           <a href="<?=base_url('demande/Demande/add_demande')?>" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Nouvelle demande</a>
           <?php } ?>
          </div>          <!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

<section class="container">
<!-- ************************************************************************************************** -->

<!-- Large modal -->

<div class="modal fade bd-example-modal-lg" id="modal_appr" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="title"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div  id="error_message"></div>

      <div id="ret_data" class="col-12"></div> 
      </div>
      <div class="modal-footer">
        <button  type="button" id="btn_approuver" class="btn btn-primary" onclick="valider_approuvation(2)">Approuver</button>
        <button  type="button" id="btn_ar" class="btn btn-primary" onclick="valider_approuvation(1)">Confirmer</button>
      </div>     
    </div>
  </div>
</div>

<!-- #############################################################
 -->
<div class="card" >
<div class="container-fluid">
<div class="col-12" style="padding: 10px;">
  <?php echo $this->session->flashdata('sms'); ?>
</div>
  <div class="col-12" style="padding: 10px;">
    <ul class="nav nav-tabs">
      <li  class="nav-item"><a class="nav-link active" id="mes_dem" href="#" onclick="get_list(1,1)">Mes demandes  à CAMEBU</a></li>
      <li class="nav-item"><a class="nav-link" id="dem_cds" href="#" onclick="get_list(2,3)">Demandes des CDS</a></li>

    </ul>
  </div>
  <div class="col-12" id="nav_mesdemande">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link active bg-success" id="nv_mesdem_enc" onclick="set_hidden_field_value('nv_mesdem_enc',1,'carct_dem')"  href="#">En cours</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="nv_mesdem_recu" onclick="set_hidden_field_value('nv_mesdem_recu',2,'carct_dem')" href="#">Servies</a>
      </li>
    </ul>    
  </div>

    <div id="nav_demande_cds" class="col-12" style="display: none;">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link active bg-success" id="nv_demcds_encours" onclick="set_hidden_field_value('nv_demcds_encours',3,'carct_dem')"  href="#">En cours</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="nv_demcds_appr" onclick="set_hidden_field_value('nv_demcds_appr',4,'carct_dem')" href="#">Approuvé</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="nv_demcds_servi" onclick="set_hidden_field_value('nv_demcds_servi',5,'carct_dem')" href="javascript:;">Servies</a>
      </li>
    </ul>    
  </div>
  <input type="hidden" name="NIVEAU"   id="NIVEAU"  value="1">
  <input type="hidden" name="carct_dem"   id="carct_dem"  value="0">


  <div style="padding-top: 5px;" class="col-md-12">
    <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
      <thead>
        <tr>
          <th>#</th>
          <!-- <th>CODE</th> -->
          <th>DEMANDEUR</th>
          <th>DEMANDES</th>
          <th>STATUT</th>
          <th>PV</th>
          <th>DATE</th>

          <th>OPTION</th>
        </tr>
      </thead>

    </table>

      
  </div>
  
    
</div>
<!-- ********************************************************************************************** -->
</div>
      

      
    </section>
    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>
<script type="text/javascript">
  function valider_approuvation(type_action) {
    // body...
    let compteur=$('#counter').val();
    let DEMANDE=$('#DEMANDE').val();
    let NIVEAU=$('#NIVEAU').val();
    let carct_dem=$('#carct_dem').val();
   // alert(NIVEAU);
    //alert(carct_dem);
    type_action= Number(type_action);
    if (type_action==1) {
      //accuse de reception


    let i=0;
    var QUANTITE_RECU=0;
    var QUANTITE_COMFIRMER_RECU=0;
    var form= new FormData();
    let u=0;
    for (let i = 0; i < compteur; i++) {
    

       QUANTITE_RECU=parseFloat($('#QUANTITE_RECU'+i).val());
       QUANTITE_COMFIRMER_RECU=parseFloat($('#QUANTITE_COMFIRMER_RECU'+i).val());
       DETAIL_ID=parseFloat($('#DETAIL_ID'+i).val());

       
       if (QUANTITE_RECU<QUANTITE_COMFIRMER_RECU) {
         $('#error_message').html('<div class="text-danger">Veuillez saisir la quantité inférieure ou égale à la quantité reçue</div>');
         u=5
       }else{
         form.append("QUANTITE_COMFIRMER_RECU"+i,QUANTITE_COMFIRMER_RECU);
         form.append("DETAIL_ID"+i,DETAIL_ID);
       }
    
    
    }
    form.append("compteur",compteur);
    form.append("DEMANDE_ID",DEMANDE);
    form.append("type_action",type_action);
    if (u!=5) {
   
    

  
       $.ajax({
              url: "<?php echo base_url('stock_distribution/DistributionBdsCds/valider_approuvation');?>",
              type: "POST",
              data: form,
              processData: false,  
              contentType: false,
              success:function(data) 
              { 
                 if (data==1) {
                  $('#error_message').html('<div class="text-success">Opération faite avec succès</div>');
                  get_list(NIVEAU,carct_dem);
                  $('#modal_appr').modal('hide');

                 }else{
                    $('#error_message').html('<div class="text-danger">Opération echouée</div>');

                 }
                 

               }

           });
    } 
    


    }else{
    //Approbation

    let i=0;
    var QUANTITE_APPROUVEE=0;
    var QUANTITE_DISPONIBLE=0;
    var form= new FormData();
    let u=0;
    for (let i = 0; i < compteur; i++) {
    

       QUANTITE_APPROUVEE=parseFloat($('#QUANTITE_APPROUVEE'+i).val());
       QUANTITE_DISPONIBLE=parseFloat($('#QUANTITE_DISPONIBLE'+i).val());
       DETAIL_ID=parseFloat($('#DETAIL_ID'+i).val());

       
       if (QUANTITE_DISPONIBLE<QUANTITE_APPROUVEE) {
         $('#error_message').html('<div class="text-danger">Veuillez saisir la quantité inférieure ou égale à la quantité disponible</div>');
         u=5
       }else{
         form.append("QUANTITE_APPROUVEE"+i,QUANTITE_APPROUVEE);
         form.append("DETAIL_ID"+i,DETAIL_ID);
       }
    
    
    }
    form.append("compteur",compteur);
    form.append("DEMANDE_ID",DEMANDE);
    form.append("type_action",type_action);
    if (u!=5) {
   
    

  
       $.ajax({
              url: "<?php echo base_url('stock_distribution/DistributionBdsCds/valider_approuvation');?>",
              type: "POST",
              data: form,
              processData: false,  
              contentType: false,
              success:function(data) 
              { 
                 if (data==1) {
                  $('#error_message').html('<div class="text-success">Opération faite avec succès</div>');
                  get_list(NIVEAU,carct_dem);
                  $('#modal_appr').modal('hide');

                 }else{
                    $('#error_message').html('<div class="text-danger">Opération echouée</div>');

                 }
                 

               }

           });
    }



  }

  }
</script>
<script type="text/javascript">
  function get_demande_for_ar(DEMANDE_ID,TEST_VALUE) {
    // body...
    if (TEST_VALUE==1) {
      $('#title').html('Accusé de réception');
      $('#btn_ar').show();
      $('#btn_approuver').hide();
    }else{
      $('#title').html('Approbation');
      $('#btn_ar').hide();
      $('#btn_approuver').show();
    }
    $('#modal_appr').modal({ backdrop: false });
      $.post('<?php echo base_url();?>stock_distribution/DistributionBdsCds/get_demande_detail',
    {
      DEMANDE_ID:DEMANDE_ID,
      TEST_VALUE:TEST_VALUE
      
      },
      function(data) 
      { 
      ret_data.innerHTML = data;  
      $('#ret_data').html(data);

      });  
  }
</script>
<script type="text/javascript">

  $(document).ready(function(){
    $("#message").delay("slow").fadeOut(3000);

     $("#carct_dem").val(1);
     $("#NIVEAU").val(1);
     type_demande=1
     get_list(type_demande,1);

    $('#mes_dem').on('click',function() {
      $('[name = "NIVEAU"]').val(1);
      document.getElementById("nv_mesdem_enc").className = "nav-link bg-success";
      document.getElementById("nv_mesdem_recu").className = "nav-link";
      document.getElementById("nv_demcds_servi").className = "nav-link";

    });
    $('#dem_cds').on('click',function() {
      $('[name = "NIVEAU"]').val(2);
      document.getElementById("nv_demcds_encours").className = "nav-link bg-success";
      document.getElementById("nv_demcds_appr").className = "nav-link";


    });
    /******************************************/
    $('#nv_mesdem_enc').on('click',function() {
     
      document.getElementById("nv_mesdem_enc").className = "nav-link bg-success";
      document.getElementById("nv_mesdem_recu").className = "nav-link";
      document.getElementById("nv_demcds_encours").className = "nav-link";
      document.getElementById("nv_demcds_appr").className = "nav-link";

    });
    $('#nv_mesdem_recu').on('click',function() {
      document.getElementById("nv_mesdem_enc").className = "nav-link";
      document.getElementById("nv_mesdem_recu").className = "nav-link bg-success";
      document.getElementById("nv_demcds_encours").className = "nav-link";
      document.getElementById("nv_demcds_appr").className = "nav-link";      

    });
    $('#nv_demcds_servi').on('click',function() {
      document.getElementById("nv_mesdem_enc").className = "nav-link";
      document.getElementById("nv_mesdem_recu").className = "nav-link";
      document.getElementById("nv_demcds_servi").className = "nav-link bg-success";
      document.getElementById("nv_demcds_encours").className = "nav-link";
      document.getElementById("nv_demcds_appr").className = "nav-link";      

    });
    $('#nv_demcds_encours').on('click',function() {
      document.getElementById("nv_mesdem_enc").className = "nav-link";
      document.getElementById("nv_mesdem_recu").className = "nav-link";
      document.getElementById("nv_demcds_servi").className = "nav-link";
      document.getElementById("nv_demcds_encours").className = "nav-link bg-success";
      document.getElementById("nv_demcds_appr").className = "nav-link"     

    });
    $('#nv_demcds_appr').on('click',function() {
      document.getElementById("nv_mesdem_enc").className = "nav-link";
      document.getElementById("nv_mesdem_recu").className = "nav-link";
      document.getElementById("nv_demcds_servi").className = "nav-link";
      document.getElementById("nv_demcds_encours").className = "nav-link";
      document.getElementById("nv_demcds_appr").className = "nav-link bg-success"       

    });

  });
  function set_hidden_field_value(id_nav,valeur,id_input_hidden) {
    // body...
    $("#"+id_input_hidden).val(valeur);
    var type_demande=Number($('#NIVEAU').val());
    get_list(type_demande,valeur);


  }

  
  function get_list(type_demande,caractere_demande) {

  // body...
    //var type_demande=Number($('#NIVEAU').val());
    var caractere_demande=Number(caractere_demande);
    if (Number(type_demande)==2) {
     document.getElementById("mes_dem").className = "nav-link";
     document.getElementById("dem_cds").className = "nav-link active";
     $("#nav_mesdemande").hide();  
     $("#nav_demande_cds").show();

    }else{
      document.getElementById("mes_dem").className = "nav-link active";
      document.getElementById("dem_cds").className = "nav-link";
      $("#nav_demande_cds").hide();
      $("#nav_mesdemande").show();    
    }
    var INTERVENANT_STRUCTURE_ID='<?= $INTERVENANT_STRUCTURE_ID ?>';//intervenant parent
    var row_count ="1000000";

   $("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
       "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
            url:"<?=base_url()?>stock_distribution/DistributionBdsCds/demandes_des_cds/",
            type:"POST",
            data : {
               
            INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
            type_demande:type_demande,
            caractere_demande:caractere_demande
            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[],
            "orderable":false
        }],

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });
}
</script>

