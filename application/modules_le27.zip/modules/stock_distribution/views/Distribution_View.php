<!DOCTYPE html>
<html lang="en">
  <?php include VIEWPATH.'templates/header.php' ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <?php include VIEWPATH.'templates/navbar.php' ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include VIEWPATH.'templates/sidebar.php' ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-8">
            <h4 class="m-0"><?=$title?></h4>
          </div><!-- /.col -->
          <div class="col-sm-12 ">
            <a href="<?= base_url('demande/Demande') ?>" class="btn btn-primary">Demande</a>
           <a href="<?= base_url('stock_distribution/Liste_Distribution') ?>" class="btn btn-primary float-right">Liste</a>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->

    <section class="content">
      <input type="hidden" value="0" id="COMPTEUR">
      <div class="card" >
        <div class="container" style="padding:12px;">
          <div class="col-12 row">
            <div class="col-4">
              <label>Bénéficiaire<span class="text-danger">*</span></label>
            <select class="form-control" name="INTERVENANT_RH_ID" id="INTERVENANT_RH_ID">
              <option value="0">sélectionner</option>
              <?php foreach ($intervenants_rh as $key) {
                # code...
               ?>
               <option value="<?= $key['INTERVENANT_RH_ID']?>"><?= $key['name']?></option>

              <?php  } ?>
              
            </select>
            </div>

<!--             <div class="col-4">
              <label>Pièce justificatif</label>
              <input type="file" name="PIECE_JUSTIFICATIF" id="PIECE_JUSTIFICATIF" class="form-control">
            </div> -->
            <div class="col-4">
              <label>Commentaire</label>
              <textarea class="form-control" name="COMMENT" id="COMMENT"></textarea>
            </div>
          </div>
          <ul style=" margin-top: 5px;" class="nav nav-tabs">
            <?php
                $i=0;
                foreach ($stock_demande_detail as $key) {
                  # code...


                  if ($i==0) {
                    # code...
                
                

            ?>
            <input type="hidden" id="INTRANT_MEDICAUX_ID" value="<?= $key['INTRANT_MEDICAUX_ID'] ?>">

            <li  class="nav-item"><a class="nav-link" id="intr<?= $i ?>" href="#" onclick="get_intrant_dispo_by_ptf(<?= $key['INTRANT_MEDICAUX_ID'].",".$i ?>);getstock_total(<?= $key['INTRANT_MEDICAUX_ID'].",".$INTERVENANT_STRUCTURE_ID ?>);get_historique(<?= $key['INTRANT_MEDICAUX_ID'].",".$INTERVENANT_STRUCTURE_ID ?>)"><span class="tooltipp"><span class="topp"><?= $key['INTRANT_MEDICAUX_DESCR'] ?></span><?= $key['INTRANT_MEDICAUX_CODE'] ?></span></a></li>

           <?php }else{ ?>

            <li class="nav-item"><a class="nav-link tooltipp" id="intr<?= $i ?>" href="#" onclick="get_intrant_dispo_by_ptf(<?= $key['INTRANT_MEDICAUX_ID'].",".$i ?>);getstock_total(<?= $key['INTRANT_MEDICAUX_ID'].",".$INTERVENANT_STRUCTURE_ID ?>);get_historique(<?= $key['INTRANT_MEDICAUX_ID'].",".$INTERVENANT_STRUCTURE_ID ?>)">

             
              <span class="tooltipp"><span class="topp"><?= $key['INTRANT_MEDICAUX_DESCR'] ?></span><?= $key['INTRANT_MEDICAUX_CODE'] ?></span></a></li>
            <?php
              }
            $i++;
            }
            ?>

          </ul>
        <div class="modal fade bd-example-modal-sm err" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div id="error" ></div>
            </div>
          </div>
        </div>
        <div class="modal fade bd-example-modal-sm" id="toblock" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <i class="text-info">Opération en cours...</i>
            </div>
          </div>
        </div>
        <div class="col-12 row">
          <div class="col-sm-6 text-info" id="qte_total"></div>
          <div class="col-12 table-responsive">
          <table id='mytable' class="table table-bordered table-striped table-hover table-condensed table-sm" style="margin-top: 8px;" >
            <thead>
              <tr>
                <th>#</th>
                <th>PTF</th>
                <th>LOT</th>
                <th>PEREMPTION</th>
                <th>QTE.DISPONIBLE</th>
                <th>QTE.APPROUVEE</th>
                <th>OPTION</th>
              </tr>
            </thead>

          </table>
        </div>
          <div class="col-12 table-responsive">
          <table id='mytable2' class="table table-bordered table-striped table-hover table-condensed table-sm" style="margin-top: 8px;" >
            <thead>
             <tr class="text-center"><th colspan="6" class="text-center"><h4>Historique</h4></th></tr>

              <tr>
                <th>#</th>
                <th>PTF</th>
                <th>LOT</th>
                <th>QTE REÇUE</th>
                <th>QTE RESTANTE</th>
                <th>QTE DISTRIBUE</th>
              </tr>
            </thead>

          </table>
        </div>
        </div>
         

        </div>
      </div>     
    </section>

    <!-- /.content -->
  </div>

</div>
<!-- ./wrapper -->
 <?php include VIEWPATH.'templates/footer.php'; ?>
</body>

<script type="text/javascript">
function get_valeur(u) {

  // body...
  var QUANTITE_APPROUVE=$('#QUANTITE_APPROUVE'+u).val();
 
  document.getElementById("QUANTITE_APPROUVE"+u).value=QUANTITE_APPROUVE;
  var QUANTITE_APPROUVE=$('#QUANTITE_APPROUVE'+u).val();


}
function valider(INTRANT_MEDICAUX_ID,i,QUANTITE_DISPONIBLE,RECEPTION_INTRANT_ID,QUANTITE_APPROUVEE,comteur_id,DEMANDE_ID) {
  // body...
  var QUANTITE_DISPO=parseFloat(QUANTITE_DISPONIBLE);
  var QUANTITE_APPROUVE=parseFloat($('#QUANTITE_APPROUVE'+i).val());
  var INTERVENANT_RH_ID =Number($('#INTERVENANT_RH_ID').val());
  var COMPTEUR =Number($('#COMPTEUR').val());

  //alert(QUANTITE_APPROUVE);
  //alert(QUANTITE_APPROUVEE);

  var test=1;

  if (INTERVENANT_RH_ID==0) {

     test=0;

  }

  if ( QUANTITE_DISPO >= QUANTITE_APPROUVE && QUANTITE_APPROUVE>0  && test==1 && QUANTITE_APPROUVE<=QUANTITE_APPROUVEE){

   //  alert(parseFloat(QUANTITE_DISPONIBLE) );
  //|  $.post('<?php echo base_url();?>stock_distribution/Distribution/valider',
 // {
  //|  //   QUANTITE_APPROUVE:QUANTITE_APPROUVE,
   //   :INTRANT_MEDICAUX_ID,
  //   RECEPTION_INTRANT_ID:RECEPTION_INTRANT_ID,
 //   DEMANDE_ID:DEMANDE_ID
    
  // },

    $('#toblock').modal({ backdrop: false });

    var form= new FormData();   
    form.append("QUANTITE_APPROUVE",QUANTITE_APPROUVE);
    form.append("INTRANT_MEDICAUX_ID",INTRANT_MEDICAUX_ID);
    //form.append("PIECE_JUSTIFICATIF",$('input[type=file]')[0].files[0]);
    form.append("RECEPTION_INTRANT_ID",RECEPTION_INTRANT_ID);
    form.append("DEMANDE_ID",DEMANDE_ID);
    form.append("INTERVENANT_RH_ID",INTERVENANT_RH_ID);
    form.append("COMMENT",$('#COMMENT').val());
  
       $.ajax({
              url: "<?php echo base_url('stock_distribution/Distribution/valider');?>",
              type: "POST",
              data: form,
              processData: false,  
              contentType: false,
  success:function(data) 
  { 


     if (data=="2") {


     $('#error').html('<div class="alert alert-success">Opération réussi avec succes</div>')
     $('.err').modal();
     get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,COMPTEUR);
     getstock_total(INTRANT_MEDICAUX_ID,<?=$INTERVENANT_STRUCTURE_ID ?>)
     $('#toblock').modal('hide');


      }else{
     $('#toblock').modal('hide');
     $('#error').html('<div class="alert alert-danger">Erreur de connexion!</div>')
     $('.err').modal();
      }
   }

 });

  }else{

    if (INTERVENANT_RH_ID==0) {
         $('#error').html('<div class="alert alert-danger">Le champ pour le Réceptioniste est obligatoire</div>')
         $('.err').modal();
         test=0;

      }else{
       $('#error').html('<div class="alert alert-danger">Veillez saisir la quantité valide</div>')
       $('.err').modal();
     }

  }
}

$(document).ready(function () { 
  var i =0;
  var INTRANT_MEDICAUX_ID=$('#INTRANT_MEDICAUX_ID').val();
 // document.getElementById("intr"+i).className = "nav-link active";
 get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,i);
 getstock_total(INTRANT_MEDICAUX_ID,<?=$INTERVENANT_STRUCTURE_ID ?>);
 get_historique(INTRANT_MEDICAUX_ID,<?=$INTERVENANT_STRUCTURE_ID ?>);

});
function get_intrant_dispo_by_ptf(INTRANT_MEDICAUX_ID,i=0) {
  // body...
   
  document.getElementById("COMPTEUR").value=i;
   var counter='<?= $i ?>';
   counter=Number(counter);
   j=0;
   while(j<counter){

     if (j==i) {
        document.getElementById("intr"+j).className = "nav-link active";

     }else {
      document.getElementById("intr"+j).className = "nav-link ";

     }
    j++;
   }

    var DEMANDE_ID='<?= $DEMANDE_ID ?>';
    var row_count ="1000000";
    $('#mytable').DataTable( {
        "processing":true,
        "destroy" : true,
       "serverSide":true,
       "searching": false,
       "paging": false,
       "responsive": true, "lengthChange": true, "autoWidth": true,
        "order":[[ 0, 'desc' ]],
        "buttons": ["copy", "csv", "excel", "pdf", "print"],
        "ajax":{
            url:"<?=base_url()?>stock_distribution/Distribution/liste_intrant_quantite/",
            type:"POST",
            data : {
               
               INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
               i:i,
               DEMANDE_ID:DEMANDE_ID


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[1,2,3,4,5,6],
            "orderable":false
        }],

       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
    } )
}
function get_historique(INTRANT_MEDICAUX_ID,INTERVENANT_STRUCTURE_ID) {
  // body...


    var row_count ="1000000";
    $('#mytable2').DataTable( {
        "processing":true,
        "destroy" : true,
       "serverSide":true,
       "searching": false,
       "paging": false,
       "responsive": true, "lengthChange": true, "autoWidth": true,
        "order":[[ 0, 'desc' ]],
        "buttons": ["copy", "csv", "excel", "pdf", "print"],
        "ajax":{
            url:"<?=base_url()?>stock_distribution/Distribution/historique/",
            type:"POST",
            data : {
               
               INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID,
               INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[1,2,3,4,5],
            "orderable":false
        }],

       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
    } )
}
function getstock_total(INTRANT_MEDICAUX_ID,STRUCTURE_ID)
{
  var INTERVENANT_STRUCTURE_ID=STRUCTURE_ID;

    $.post('<?php echo base_url();?>stock_distribution/Distribution/getstock_total/',
  {
    INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID,
    INTRANT_MEDICAUX_ID:INTRANT_MEDICAUX_ID
    
    },
    function(data) 
    { 
    qte_total.innerHTML = data; 
    $('#qte_total').html(data);

   // $('#INTERVENANT_STRUCTURE_ID').selectpicker('refresh');
    }); 
 
}
</script>
</html>

