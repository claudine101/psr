<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<!-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> -->
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<div class="row col-md-12">
  <legend>
    <h4><?= $title;?></h4>
    <div class="pull-right" style="padding:10px;">
      <!-- <a class="btn btn-primary" href="#">
        <i class="fa fa-plus"></i>Nouveau
      </a> -->

    </div>
  </legend>
</div>
<div class="row col-md-12">
  <form action="<?=base_url('stock_distribution/Distribution_Intrants/Mes_distribution')?>" method="POST" id="myform">

    <div class="col-md-3">
        <label>Institutions</label>
        <select class="form-control" onchange="load_institutions();" name="INTERVENANT_STRUCTURE_ID" id="INTERVENANT_STRUCTURE_ID">
          <option value="">--Institutions</option>
          <?php
          foreach ($structures as $structure) {
           if ($structure['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')) {?>
            <option value="<?=$structure['INTERVENANT_STRUCTURE_ID']?>" selected=''><?=$structure['INTERVENANT_STRUCTURE_DESCR']?></option>
            <?php }else{?>
              <option value="<?=$structure['INTERVENANT_STRUCTURE_ID']?>"><?=$structure['INTERVENANT_STRUCTURE_DESCR']?></option>
              <?php }
            }
            ?>
          </select>
      </div>

    <div class="col-md-3">
      <label>Demandeurs</label>
      <select class="form-control" onchange="load_demandeurs();" id="DEMANDE_ID" name="DEMANDE_ID">
        <option value="">--Demandeurs</option>
        <?php
        foreach ($demandeurs as $demand) {
         if ($demand['DEMANDE_ID']==set_value('DEMANDE_ID')) {?>
          <option value="<?=$demand['DEMANDE_ID']?>" selected=''><?=$demand['DEMANDE_CODE']?></option>
          <?php }else{?>
            <option value="<?=$demand['DEMANDE_ID']?>"><?=$demand['DEMANDE_CODE']?></option>
            <?php }
          }
          ?>
        </select>
      </div>

      <div class="col-md-3">
        <label>Code sens</label>
        <select class="form-control" onchange="load_code_sens();" name="CODE_DEMANDE_SENS_ID" id="CODE_DEMANDE_SENS_ID">
          <option value="">--Code sens</option>
          <?php
          foreach ($code_sens as $code) {
           if ($code['CODE_DEMANDE_SENS_ID']==set_value('CODE_DEMANDE_SENS_ID')) {?>
            <option value="<?=$code['CODE_DEMANDE_SENS_ID']?>" selected=''><?=$code['CODE_DEMANDE_SENS_DESCR']?></option>
            <?php }else{?>
              <option value="<?=$code['CODE_DEMANDE_SENS_ID']?>"><?=$code['CODE_DEMANDE_SENS_DESCR']?></option>
              <?php }
            }
            ?>
          </select>
        </div>

      

        <div class="col-md-3">
          <label>Date de distribution</label>
          <input type="date" name="DATE_DISTRIBUTION" id="DATE_DISTRIBUTION" onchange="load_date();" value="<?=set_value('DATE_DISTRIBUTION')?>" class="form-control">
        </div>
      </form>

    </div>
    <div class="row col-md-12" style="padding:30px;">
      <table id="table_info" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

        <thead>

          <tr>

            <th>#</th>
            <th>CODE DE DISTRIBUTION</th>
            <th>CODE SENS</th>
            <th>INSTITUTION</th>
            <th>INTERVENANT RH</th>
            <th>DATE DE DISTRIBUTION</th>
            <th>OPTIONS</th>


          </tr>

        </thead>

        <tbody>

        </tbody>

      </table>

    </div>


<script type="text/javascript">



  function histo_distribution(id=<?=$DISTRIBUTION_ID?>)
{
    //alert(id);
    $('#modal_historique').modal('show');


      $(document).ready(function() {

  var row_count ="1000000";   
   table=$("#info_histo").DataTable({
        "destroy" : true ,
        "processing":true,
        "serverSide":true,
        "order":[],
        "ajax":{
             url:"<?php echo base_url('stock_distribution/Distribution_Intrants/get_Info1/')?>"+id,
            type:"POST"
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs": [
        { 
          "targets": [ 0 ],
          "orderable": false,
        },
        { 
          "targets": [ -1 ], 
          "orderable": false, 
        },
        ]

        ,

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });

});
        
 }






var table;

$(document).ready(function() {

     var row_count ="1000000";   
   table=$("#table_info").DataTable({
        "processing":true,
        "serverSide":true,
        "order":[],
        "ajax":{
            url:"<?php echo base_url('stock_distribution/Distribution_Intrants/get_Info/')?>",
            type:"POST",
            data:{
              INTERVENANT_STRUCTURE_ID:$('#INTERVENANT_STRUCTURE_ID').val(),
              DEMANDE_ID:$('#DEMANDE_ID').val(),
              CODE_DEMANDE_SENS_ID:$('#CODE_DEMANDE_SENS_ID').val(),
              DATE_DISTRIBUTION:$('#DATE_DISTRIBUTION').val()
            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs": [
        { 
          "targets": [ 0 ],
          "orderable": false,
        },
        { 
          "targets": [], 
          "orderable": false, 
        },
        ]

        ,

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });

});

      function load_demandeurs()
      {
        myform.submit();
        // $('#DATE_DISTRIBUTION').html('');
        // $('#INTRANT_ID').html('');
      }

      function load_institutions()
      {
        myform.submit();
        //$('#DATE_DISTRIBUTION').html('');
      }

      function load_code_sens()
      {
        myform.submit();
        //$('#DATE_DISTRIBUTION').html('');
      }

      function load_date()
      {
        myform.submit();
        //$('').html('');
      }
    </script>




    <div class="modal fade" id="modal_historique" role="dialog">
          <div class="modal-dialog" style="width:800px;">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Historique des intrants distribués</h4>
              </div>

              <div class="modal-body table-responsive">
                <div class="panel-body">
                   
                  <table id="info_histo" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

                        <thead>

                        <tr>
                          <th>#</th>
                          <th>CODE DE RECEPTION</th>
                          <th>INTRANTS</th>
                          <th>QUANTITE DISTRIBUEE</th>
                          <th>QUANTITE RESTANTE</th>
                         
                        </tr>

                        </thead>

                        <tbody>

                        </tbody>

                      </table>
                         </div>
                

                
              </div>
              </div>
            </div>
        </div>






