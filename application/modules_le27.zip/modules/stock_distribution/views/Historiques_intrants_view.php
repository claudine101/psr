<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<div class="row">
  <?php if($this->session->flashdata('sms')){
   echo $this->session->flashdata('sms');
 } ?>
</div>



<div class="row col-md-12">
  <legend>
    <h4><?= $title;?></h4>
    <div class="pull-right" style="padding:10px;">
      <a class="btn btn-primary" href="<?=base_url('stock_distribution/Distribution_Intrants/index')?>">
        <i class="fa fa-list"></i> Liste
      </a>
     
    </div>
  </legend>
</div>
<div class="row col-md-12">
  <form action="<?=base_url('stock_distribution/Distribution_Intrants/historique')?>" method="POST" id="myform">
    <div class="col-md-4">
      <label>Strucures</label>
      <select class="form-control" onchange="load_structures();" id="INTERVENANT_STRUCTURE_ID" name="INTERVENANT_STRUCTURE_ID">
        <option value="">--Structures</option>
        <?php
        foreach ($structures as $structure) {
         if ($structure['INTERVENANT_STRUCTURE_ID']==set_value('INTERVENANT_STRUCTURE_ID')) {?>
          <option value="<?=$structure['INTERVENANT_STRUCTURE_ID']?>" selected=''><?=$structure['INTERVENANT_STRUCTURE_DESCR']?></option>
          <?php }else{?>
            <option value="<?=$structure['INTERVENANT_STRUCTURE_ID']?>"><?=$structure['INTERVENANT_STRUCTURE_DESCR']?></option>
            <?php }
          }
          ?>
        </select>
      </div>

      <div class="col-md-4">
        <label>Intrants</label>
        <select class="form-control" onchange="load_intrants();" name="INTRANT_ID" id="INTRANT_ID">
          <option value="">--Intrants</option>
          <?php
          foreach ($intrants as $intra) {
           if ($intra['INTRANT_ID']==set_value('INTRANT_ID')) {?>
            <option value="<?=$intra['INTRANT_ID']?>" selected=''><?=$intra['INTRANT_MEDICAUX_DESCR']?></option>
            <?php }else{?>
              <option value="<?=$intra['INTRANT_ID']?>"><?=$intra['INTRANT_MEDICAUX_DESCR']?></option>
              <?php }
            }
            ?>
          </select>
        </div>

        <div class="col-md-4">
          <label>Date de distribution</label>
          <input type="date" name="DATE_DISTRIBUTION" id="DATE_DISTRIBUTION" onchange="load_date();" value="<?=set_value('DATE_DISTRIBUTION')?>" class="form-control">
        </div>
      </form>

    </div>
    <div class="row col-md-12" style="padding:30px;">

      <?=$this->table->generate($array_histo)?>
    </div>


    <script type="text/javascript">


      $(document).ready(function() {
        $('#mytable').DataTable( {
       // "scrollY":        "200px",
       // "scrollCollapse": true,
       "ordering": false,

       "columnDefs":[{
        "targets":[],
        "orderable":false
      }],
      "paging":         true,
      buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
      ],
      language: {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
          "sFirst":      "Premier",
          "sPrevious":   "Pr&eacute;c&eacute;dent",
          "sNext":       "Suivant",
          "sLast":       "Dernier"
        },
        "oAria": {
          "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
          "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
      }
    } );
      } );


      function load_structures()
      {
        myform.submit();
        $('#DATE_DISTRIBUTION').html('');
        $('#INTRANT_ID').html('');
      }

      function load_intrants()
      {
        myform.submit();
        $('#DATE_DISTRIBUTION').html('');
      }

      function load_date()
      {
        myform.submit();
        //$('').html('');
      }
    </script>





