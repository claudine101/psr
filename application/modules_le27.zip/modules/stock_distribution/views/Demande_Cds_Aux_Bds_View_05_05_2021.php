
<!DOCTYPE html>
<html lang="en">
<?php include VIEWPATH.'templates/header.php'; ?>
<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php include VIEWPATH.'templates/navbar.php'; ?>

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include VIEWPATH.'templates/sidebar.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h4 class="m-0"></h4>
            </div><!-- /.col -->
            <div class="col-sm-12 text-right">


              <span style="margin-right: 15px">
                <div class="col-sm-12" style="float:right;">
                  <?php  if ($this->session->userdata('iccm_PROFIL_CODE')=="CDS") {
                    ?>
                    <a href="<?=base_url('demande/Demande/add_demande')?>" class="btn btn-primary float-right"><i class="fa fa-plus"></i> Nouvelle demande</a>
                    <!-- <a href="<?=base_url('stock_distribution/Detail/index')?>" class="btn btn-primary float-left"><i class="fa fa-book"></i>Historique de distribution</a>
 -->
                    <?php } ?>
                  </div>

                </span>

              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>


        <div class="modal fade bd-example-modal-lg" id="modal_appr" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div  id="error_message"></div>

                <div id="ret_data" class="col-12"></div> 
              </div>
              <div class="modal-footer">
                <button  type="button" id="btn_approuver" class="btn btn-primary" onclick="valider_approuvation(2)">Approuver</button>
                <button  type="button" id="btn_ar" class="btn btn-primary" onclick="valider_approuvation(1)">Comfirmer</button>
              </div>     
            </div>
          </div>
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
          <div class="col-md-12 col-xl-12 grid-margin stretch-card">

            <div class="card">
              <div class="card-body">

                <div class="col-md-12">
                 <div class="card">
                  <div class="card-header d-flex p-0">
                    <h3 class="card-title p-3">Mes demandes</h3>
                    <ul class="nav nav-pills ml-auto p-3">
                      <li class="nav-item"><a class="nav-link active" href="#tab_1" onclick="tabs_verify(0)" id="ENCOURS"  data-toggle="tab">En cours</a></li>
                      <li class="nav-item"><a class="nav-link" href="#tab_2" id="RECU" onclick="tabs_verify(1)"  data-toggle="tab">Reçue</a></li>
                    </ul>
                  </div><!-- /.card-header -->
                  <div class="card-body">
                    <div class="tab-content">
                      <div class="tab-pane active" id="tab_1">
                        <div style="padding-top: 5px;" class="col-md-12">
                          <?php echo $this->session->flashdata('sms'); ?>
                        </div>

                        <div style="padding-top: 5px;" class="col-md-12">
                          <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                            <thead>
                              <tr>
                                <th>#</th>
                                <th>CODE</th>
                                <th>DEMANDEUR</th>
                                <th>DEMANDES</th>
                                <th>OPTION</th>
                              </tr>
                            </thead>

                          </table>


                        </div>
                      </div>

                    </div>
                    <!-- /.tab-content -->
                  </div><!-- /.card-body -->
                </div>
              </div>


              <!--  VOS CODE ICI  -->



            </div>
          </div>
        </div>
      </section>

    </div>

  </div>
  <!-- ./wrapper -->
  <?php include VIEWPATH.'templates/footer.php'; ?>
</body>
</html>

<script type="text/javascript">
  $(document).ready(function()
  {

   $("#message").delay("slow").fadeOut(3000);

   $( "#ENCOURS" ).on('click',function() {

     getList(0);
   });

   $( "#RECU" ).on('click',function() {


     getList(1);
   });



   getList(0);
   
 });
</script>

<script type="text/javascript">
  function get_demande_for_ar(DEMANDE_ID,TEST_VALUE) {
    // body...
    if (TEST_VALUE==1) {
      $('#title').html('Accusé de réception');
      $('#btn_ar').show();
      $('#btn_approuver').hide();
    }else{
      $('#title').html('Approbation');
      $('#btn_ar').hide();
      $('#btn_approuver').show();
    }
    $('#modal_appr').modal({ backdrop: false });
    $.post('<?php echo base_url();?>stock_distribution/DistributionCdsAsc/get_demande_detail',
    {
      DEMANDE_ID:DEMANDE_ID,
      TEST_VALUE:TEST_VALUE
      
    },
    function(data) 
    { 
      ret_data.innerHTML = data;  
      $('#ret_data').html(data);

    });  
  }
</script>


<script type="text/javascript">
  function valider_approuvation(type_action) {
    // body...
    let compteur=$('#counter').val();
    let DEMANDE=$('#DEMANDE').val();
    type_action= Number(type_action);
    if (type_action==1) {
      //accuse de reception


      let i=0;
      var QUANTITE_RECU=0;
      var QUANTITE_COMFIRMER_RECU=0;
      var form= new FormData();
      let u=0;
      for (let i = 0; i < compteur; i++) {


       QUANTITE_RECU=parseFloat($('#QUANTITE_RECU'+i).val());
       QUANTITE_COMFIRMER_RECU=parseFloat($('#QUANTITE_COMFIRMER_RECU'+i).val());
       DETAIL_ID=parseFloat($('#DETAIL_ID'+i).val());

       
       if (QUANTITE_RECU<QUANTITE_COMFIRMER_RECU) {
         $('#error_message').html('<div class="text-danger">Veuillez saisir la quantité inférieure ou égale à la quantité reçue</div>');
         u=5
       }else{
         form.append("QUANTITE_COMFIRMER_RECU"+i,QUANTITE_COMFIRMER_RECU);
         form.append("DETAIL_ID"+i,DETAIL_ID);
       }
       
       
     }
     form.append("compteur",compteur);
     form.append("DEMANDE_ID",DEMANDE);
     form.append("type_action",type_action);
     if (u!=5) {

       $.ajax({
        url: "<?php echo base_url('stock_distribution/DistributionCdsAsc/valider_approuvation');?>",
        type: "POST",
        data: form,
        processData: false,  
        contentType: false,
        success:function(data) 
        { 
         if (data==1) {
          $('#error_message').html('<div class="text-success">Opération faite avec succès</div>');
          $('#modal_appr').modal('hide');

        }else{
          $('#error_message').html('<div class="text-danger">Opération echouée</div>');

        }
        

      }

    });
     } 
     


   }else{
    //Approbation

    let i=0;
    var QUANTITE_APPROUVEE=0;
    var QUANTITE_DISPONIBLE=0;
    var form= new FormData();
    let u=0;
    for (let i = 0; i < compteur; i++) {


     QUANTITE_APPROUVEE=parseFloat($('#QUANTITE_APPROUVEE'+i).val());
     QUANTITE_DISPONIBLE=parseFloat($('#QUANTITE_DISPONIBLE'+i).val());
     DETAIL_ID=parseFloat($('#DETAIL_ID'+i).val());

     
     if (QUANTITE_DISPONIBLE<QUANTITE_APPROUVEE) {
       $('#error_message').html('<div class="text-danger">Veuillez saisir la quantité inférieure ou égale à la quantité disponible</div>');
       u=5
     }else{
       form.append("QUANTITE_APPROUVEE"+i,QUANTITE_APPROUVEE);
       form.append("DETAIL_ID"+i,DETAIL_ID);
     }
     
     
   }
   form.append("compteur",compteur);
   form.append("DEMANDE_ID",DEMANDE);
   form.append("type_action",type_action);
   if (u!=5) {




     $.ajax({
      url: "<?php echo base_url('stock_distribution/DistributionCdsAsc/valider_approuvation');?>",
      type: "POST",
      data: form,
      processData: false,  
      contentType: false,
      success:function(data) 
      { 
       if (data==1) {
        $('#error_message').html('<div class="text-success">Opération faite avec succès</div>');
        
        $('#modal_appr').modal('hide');

      }else{
        $('#error_message').html('<div class="text-danger">Opération echouée</div>');

      }
      

    }

  });
   }



 }

}
</script>


<script>

  function tabs_verify(recu)
  {
    let recur=recu;
    
    //alert(recur);
    getList(recur);


  }
  

  



  function getList(idvalue)
  {

//alert(idvalue);
var INTERVENANT_STRUCTURE_ID='<?= $INTERVENANT_STRUCTURE_ID ?>';
 //var INTERVENANT_STRUCTURE_ID=219;
 var row_count ="1000000";
 $("#mytable").DataTable({
  "processing":true,
  "destroy" : true,
  "serverSide":true,
  "oreder":[[ 0, 'desc' ]],
  "ajax":{
    url:"<?=base_url()?>stock_distribution/DistributionCdsAsc/demandes_des_cds/",
    type:"POST",
    data : {
      idvalue:idvalue,
      INTERVENANT_STRUCTURE_ID:INTERVENANT_STRUCTURE_ID
    }
  },
  lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
  pageLength: 10,
  "columnDefs":[{
    "targets":[],
    "orderable":false
  }],

  dom: 'Bfrtlip',
  buttons: [
  'copy', 'csv', 'excel', 'pdf', 'print'
  ],
  language: {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
      "sFirst":      "Premier",
      "sPrevious":   "Pr&eacute;c&eacute;dent",
      "sNext":       "Suivant",
      "sLast":       "Dernier"
    },
    "oAria": {
      "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
      "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    }
  }

});

}



</script>



