<?php
/**
 *
 AUTHOR:Niyongabire Pacifique
 @niyodon
 */
 class Detail extends CI_Controller
 {
 	
 	function __construct()
 	{
 		parent::__construct();
 	}

 	public function index(){
    $this->select_asc_intrant();
  }

  public function select_asc_intrant(){
   $data['cds_id']=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');

   $asc_agent=$this->Modele->getRequete('SELECT c.CDS_ID,c.INTERVENANT_RH_ID,CONCAT(rh.NOM," ",rh.PRENOM," (",rh.TELEPHONE1,")") AS NOM FROM cds_asc c JOIN intervenants_rh rh ON rh.INTERVENANT_RH_ID=c.INTERVENANT_RH_ID');


   $INTERVENANT_RH_ID=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')));

   $intrants=$this->Modele->getRequete('SELECT st.INTRANT_ID,med.INTRANT_MEDICAUX_DESCR FROM stock_intervenat st JOIN intrant_medicaux med ON med.INTRANT_MEDICAUX_ID=st.INTRANT_ID WHERE st.INTERVENANT_RH_ID=100 ORDER BY st.INTRANT_ID');

   $output='<table class="table table-striped table-hover table-bordered">
   <thead>';
   $output.='<tr>
   <td> #' ;
   foreach ($intrants as $intrant) {
    $output.='<th title="'.$intrant['INTRANT_MEDICAUX_DESCR'].'">'.substr($intrant['INTRANT_MEDICAUX_DESCR'], 0,6).'...</th>';
  }
  $output.=' </tr>
  </thead>
  <tbody>
  ';

  foreach ($asc_agent as $agent) {
    $output.='<tr>
    <td>'.$agent['NOM'].'</td>';
    foreach ($intrants as $intrant) {
      $donnees=$this->Modele->getRequeteOne('SELECT * FROM stock_intervenat st WHERE st.INTERVENANT_RH_ID='.$agent['INTERVENANT_RH_ID'].' AND st.INTRANT_ID='.$intrant['INTRANT_ID'].' ORDER BY st.INTRANT_ID');

      if (!empty($donnees['QUANTITE'])) {
        $output.='    <td>'.$donnees['QUANTITE'].'</td>';
      } else {
        $output.='    <td>0</td>';
      }



    }
    $output.='  </tr>';
  }

  $output.='</tbody>
  </table>';
  $data['output']=$output;
  $this->load->view('Detail_View',$data);
}

}