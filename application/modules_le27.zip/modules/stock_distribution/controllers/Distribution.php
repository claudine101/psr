<?php

/**
 * @author jules_ndihokubwayo@mediabox.bi
 *le 15-03-2021
 *ihm de processus de distribution des intrants des intrants camebu -bds
 *with @God help
 */
class Distribution extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function index($DEMANDE_ID=1)
	{
		# code...
	   $id['DISTRIBUTION_ID']=NULL;
       $this->session->set_userdata($id);
       $sql_demande = "SELECT `DEMANDE_ID`,sd.`INTERVENANT_STRUCTURE_ID`,`DEMANDE_CODE`,iss.INTERVENANT_STRUCTURE_DESCR FROM `stock_demande` sd JOIN intervenants_structure iss ON sd.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE `DEMANDE_ID`=".$DEMANDE_ID;

       $demande=$this->Modele->getRequeteOne($sql_demande);
        $sql = "SELECT im.INTRANT_MEDICAUX_ID,im.INTRANT_MEDICAUX_DESCR,INTRANT_MEDICAUX_CODE FROM `stock_demande_detail` sdd JOIN intrant_medicaux im ON sdd.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID WHERE sdd.`DEMANDE_ID`=".$DEMANDE_ID ;
        if (empty($demande['INTERVENANT_STRUCTURE_ID'])) {
        	# code...
        	$demande['INTERVENANT_STRUCTURE_ID']=-1;
        }
        $sql2 = 'SELECT `INTERVENANT_RH_ID`,concat(`NOM`," ",`PRENOM`,"(",IF(f.FONCTION_DESCR IS null," ",f.FONCTION_DESCR),")") AS name FROM `intervenants_rh` i LEFT JOIN intervenant_fonction f ON i.`ID_FONCTION`=f.ID_FONCTION WHERE `INTERVENANT_STRUCTURE_ID`='.$demande['INTERVENANT_STRUCTURE_ID']." ORDER BY name";

        $stock_demande_detail=$this->Modele->getRequete($sql);
        $intervenants_rh=$this->Modele->getRequete($sql2);

	    $data =array(
	    	          'title'=>'Intrants - Distribution  <br> '.$demande['INTERVENANT_STRUCTURE_DESCR'].'',
	    	          'DEMANDE_ID'=>$DEMANDE_ID,
	    	          'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID'],
	    	          'stock_demande_detail'=>$stock_demande_detail,
	    	          'intervenants_rh'=>$intervenants_rh
	    	        );

	    $this->load->view('Distribution_View',$data);

	}
    public function liste_intrant_quantite($value=0)
    {
          $DEMANDE_ID=$this->input->post('DEMANDE_ID');
          $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
          
          $sql = "SELECT SUM(`QUANTITE_APPROUVEE_RESTANT`) QUANTITE_APPROUVEE FROM `stock_demande_detail` WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND DEMANDE_ID=".$DEMANDE_ID;
          $qte=$this->Modele->getRequeteOne($sql);
		  $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		  $var_search=str_replace("'", "\'", $var_search);  
		  $query_principal='SELECT RECEPTION_INTRANT_ID, rc.INTERVENANT_STRUCTURE_DESCR,(ri.QUANTITE-ri.QUANTITE_DISTRIBUTUEE) QUANTITE_DISPONIBL,ri.NUMERO_LOT,ri.DATE_PEREMPTION FROM (SELECT iss.INTERVENANT_STRUCTURE_DESCR,`RECEPTION_ID` FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE 1) rc JOIN rc_reception_intrant_detail ri ON rc.`RECEPTION_ID`=ri.RECEPTION_ID WHERE ri.INTRANT_ID='.$INTRANT_MEDICAUX_ID.' HAVING QUANTITE_DISPONIBL>0';
          $group="";
          $critaire="";

		  $limit='LIMIT 0,10';
		  if($_POST['length'] != -1){
		    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		  }
		  $order_by='';
		  if($_POST['order']['0']['column']!=0){
		    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
		  }

		  $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';


		  
		  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
		  $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

		  $fetch_intrants = $this->Modele->datatable($query_secondaire);
		  $u=0;
		  $data = array();
		  // if ($qte['QUANTITE_APPROUVEE']==0) {
		  // 	# code...
		  // 	$fetch_intrants=array();
		  // }
		  $QUANTITE_STOCK_DISPO_TOTAL=0;
		  foreach ($fetch_intrants as $row) {

		   $u++;
		   $sub_array = array();
		   $sub_array[] =  $u;
           $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
           $sub_array[]=$row->NUMERO_LOT;
           $sub_array[]=$row->DATE_PEREMPTION;
		   $sub_array[]=number_format($row->QUANTITE_DISPONIBL, 0, ' ', ' ');
           $comteur_id=0;
           $sub_array[]='<input type="number" step="any" name="QUANTITE_APPROUVE'.$u.'" id="QUANTITE_APPROUVE'.$u.'" class="form-control-sm" value="'.$qte['QUANTITE_APPROUVEE'].'" onchange="get_valeur('.$u.')" onkeyup="get_valeur('.$u.')">';
           $sub_array[]='<a href="#" onclick="valider('.$INTRANT_MEDICAUX_ID.','.$u.','.$row->QUANTITE_DISPONIBL.','.$row->RECEPTION_INTRANT_ID.','.$qte['QUANTITE_APPROUVEE'].','.$comteur_id.','.$DEMANDE_ID.')">Valider</a>';


		  $data[] = $sub_array;

		}
 
		$output = array(
		 "draw" => intval($_POST['draw']),
		 "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
		 "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
}

public function valider($value='')
{
	# code...
	$QUANTITE_APPROUVE=$this->input->post('QUANTITE_APPROUVE');
	$INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
	$RECEPTION_INTRANT_ID=$this->input->post('RECEPTION_INTRANT_ID');
    $DEMANDE_ID=$this->input->post('DEMANDE_ID');
    $INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');
    $COMMENT=$this->input->post('COMMENT');

    $demande=$this->Modele->getOne('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID));
    $i=0;
    if ($demande['CODE_DEMANDE_SENS_ID']==1) {
		# code...
	if (empty($this->session->userdata('DISTRIBUTION_ID'))) {
		# code...
		#echo substr('abcdef', 1);     // bcdef
		$PIECE_JUSTIFICATIF="";//$this->upload_document($_FILES['PIECE_JUSTIFICATIF']['tmp_name'],$_FILES['PIECE_JUSTIFICATIF']['name'],$DEMANDE_ID);
		$stock_distribution = array(
        'DISTRIBUTION_DATE' => date('Y-m-d'),
        'CODE_SENS_ID' => 1,
        'DEMANDE_ID' => $DEMANDE_ID,
        'USER_ID' =>$this->session->userdata('iccm_USER_ID') ,
        'INTERVENANT_RH_ID' =>$demande['USER_DEMANDEUR_ID'] ,
        'COMMENT'=>$COMMENT,
        'PIECE_JUSTIFICATIF'=>$PIECE_JUSTIFICATIF,
        'INTERVENANT_STRUCTURE_ID' =>$demande['INTERVENANT_STRUCTURE_ID'],
        'INTERVENANT_STRUCTURE_DONNATEUR'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'),


    );
	   $DISTRIBUTION_ID=$this->Modele->insert_last_id('stock_distribution',$stock_distribution);
	   $DISTRIBUTION_CODE="DSTR-".substr("".date('Ymd')."", 2)."-".$DISTRIBUTION_ID;
	   $this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>$DISTRIBUTION_CODE));
	   $id['DISTRIBUTION_ID']=$DISTRIBUTION_ID;
       $this->session->set_userdata($id);
       $i=1;
       $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('STATUT_DISTRIBUTION'=>1));
	}else{
       $DISTRIBUTION_ID=$this->session->userdata('DISTRIBUTION_ID');
	}
    /*******************************misajour de la qte distribue********************************************/
	  $sql = "SELECT rc.RECEPTION_CODE,rci.`QUANTITE_DISTRIBUTUEE` FROM `rc_reception_intrant_detail` rci JOIN rc_reception rc ON rci.`RECEPTION_ID`=rc.RECEPTION_ID WHERE `RECEPTION_INTRANT_ID`=".$RECEPTION_INTRANT_ID;

      $code_rec=$this->Modele->getRequeteOne($sql);
      if (empty($code_rec['QUANTITE_DISTRIBUTUEE'])) {
      	# code...
      	$code_rec['QUANTITE_DISTRIBUTUEE']=0;
      }
      $QUANTITE_DISTRIBUTUEE=$code_rec['QUANTITE_DISTRIBUTUEE']+$QUANTITE_APPROUVE;

      $this->Modele->update('rc_reception_intrant_detail',array('RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID),array('QUANTITE_DISTRIBUTUEE'=>$QUANTITE_DISTRIBUTUEE));
    /*****************************inserttion stock_distribution_intrant_detail*******************************/
    //eviter d'ajouter un mm intrant de mm lot ,mm reception et mm distribution
     $array_for_test=array(
        'DISTRIBUTION_ID' => $DISTRIBUTION_ID,
        'RECEPTION_CODE' => $code_rec['RECEPTION_CODE'],
        'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
        'INTRANT_ID' => $INTRANT_MEDICAUX_ID,

     );
     $quantite_approuve_existant=0;
	 $array_for_test_sdid=$this->Modele->getOne('stock_distribution_intrant_detail',$array_for_test);
	
	 if (intval($array_for_test_sdid['INTRANT_ID'])>0) {
	 	# code...
	 	$quantite_approuve_existant=$array_for_test_sdid['QUANTITE']+$QUANTITE_APPROUVE;
	 	$this->Modele->update('stock_distribution_intrant_detail',$array_for_test,array(
        'QUANTITE' => $quantite_approuve_existant,
        'QUANTITE_RESTANTE'=>$quantite_approuve_existant
           
	 	));


	 }else{
 
      $stock_distribution_intrant_detail = array(
        'DISTRIBUTION_ID' => $DISTRIBUTION_ID,
        'RECEPTION_CODE' => $code_rec['RECEPTION_CODE'],
        'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
        'INTRANT_ID' => $INTRANT_MEDICAUX_ID,
        'QUANTITE' => $QUANTITE_APPROUVE,
        'QUANTITE_RESTANTE'=>$QUANTITE_APPROUVE
    );        
    $this->Modele->create('stock_distribution_intrant_detail',$stock_distribution_intrant_detail);
    }
    ###########################################################################################
    ####################################STOCK CAMEBU######################################
    $quantite_precedent_sock_camebu=$this->Modele->getOne('stock_camebu',array('RECEPTION_CODE'=>$code_rec['RECEPTION_CODE'],'INTRANT_ID'=>$INTRANT_MEDICAUX_ID));

    if (empty($quantite_precedent_sock_camebu['INTRANT_ID'])) {
	    $quantite_precedent_sock_camebu['QUANTITE']=0;
	}
	$QUANTITE_STOCK_CAMEBU=$quantite_precedent_sock_camebu['QUANTITE']-$QUANTITE_APPROUVE;
	$this->Modele->update('stock_camebu',array('RECEPTION_CODE'=>$code_rec['RECEPTION_CODE'],'INTRANT_ID'=>$INTRANT_MEDICAUX_ID),array('QUANTITE'=>$QUANTITE_STOCK_CAMEBU,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
    ########################################################################################

    /*******************************mis a jour du stock du donateur*****************************************/
	  $came=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID`,EMAIL,INTERVENANT_STRUCTURE_DESCR FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');
	  if (empty($came['INTERVENANT_STRUCTURE_ID'])) {
	       	# code...
	       	$came['INTERVENANT_STRUCTURE_ID']=-1;// pris par hasard du structure CAMEBU
	  }

      $INTERVENANT_STRUCTURE_ID=$came['INTERVENANT_STRUCTURE_ID'];
      $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));
      $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']-$QUANTITE_APPROUVE;
      $this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));//mis a jour de la stock de camebu dans structure intervenant


    /*******************************************************************************************/

    /******************mis a jour pour structure demandeur*********************************************/
    $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID']));

    if (empty($quantite_precedent_sock_intervenant['QUANTITE'])) {
    	# code...
    	$quantite_precedent_sock_intervenant['QUANTITE']=0;
    }

      $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']+$QUANTITE_APPROUVE;



      if ($quantite_precedent_sock_intervenant['QUANTITE']>=0 && !empty($quantite_precedent_sock_intervenant['INTRANT_ID'])) {
			   	# code...
			   	$this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID']),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
		}else{
			   	$stock_intervenat=array('INTERVENANT_STRUCTURE_ID' => $demande['INTERVENANT_STRUCTURE_ID'],
			   		                    'INTRANT_ID' => $INTRANT_MEDICAUX_ID,
			   		                    'QUANTITE' =>$QUANTITE_STOCK_INTERVENANT ,
			   		                    'DATE_LAST_UPDATE' =>date('Y-m-d H:i:s'),
			   		                    );
			   	$this->Modele->create('stock_intervenat',$stock_intervenat);
	 }
    /*******************************************************************************************************/
    $stock_demande_detail=$this->Modele->getOne('stock_demande_detail',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'DEMANDE_ID'=>$DEMANDE_ID));
    $QUANTITE_APPROUVEE_RESTANT=$stock_demande_detail['QUANTITE_APPROUVEE_RESTANT']-$QUANTITE_APPROUVE;
    $this->Modele->update('stock_demande_detail',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'DEMANDE_ID'=>$DEMANDE_ID),array('QUANTITE_APPROUVEE_RESTANT'=>$QUANTITE_APPROUVEE_RESTANT));
	/******************************************send mail***********************************************/
	
	$sql_sm = "SELECT iss.INTERVENANT_STRUCTURE_ID PTF_ID,iss.INTERVENANT_STRUCTURE_DESCR PTF_NOM,`RECEPTION_ID` id,iss.EMAIL,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND `RECEPTION_ID`=id) NUMERO_LOT FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE RECEPTION_CODE LIKE '".$code_rec['RECEPTION_CODE']."'";
	$info_reception_ptf=$this->Modele->getRequeteOne($sql_sm);

    $intrant=$this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID));
    $recepteur_intrant=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID']));

	$message = "Cher ".$info_reception_ptf['PTF_NOM'].", Une quantité <b>".$QUANTITE_APPROUVE."</b> de l'intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." a été distribuée(s) à ".$recepteur_intrant['INTERVENANT_STRUCTURE_DESCR'];
	$subjet =$came['INTERVENANT_STRUCTURE_DESCR']."-Distribution d'un intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." du lot ".$info_reception_ptf['NUMERO_LOT'];
	$emailTo = $info_reception_ptf['EMAIL'];//email du ptf
    $cc_emails=array();
    $cc_emails[]=$recepteur_intrant['EMAIL'];//email du bds demandeur
    $cc_emails[]=$came['EMAIL'];//email camebu
	$array_notifications = array(
					            'MESSAGE'=>$message,
								'PTF_ID'=>$info_reception_ptf['PTF_ID'],
								'EMAIL_NOTIFIE'=>$info_reception_ptf['EMAIL'],
								'INTRANT_ID'=>$INTRANT_MEDICAUX_ID,
								//'INTRANT_ID'=>$QUANTITE_APPROUVE,
								'IS_DISTRIBUTION'=>1
									);
	$this->Modele->insert_last_id('sms_mouvement_stock',$array_notifications);
	$this->notifications->send_mail($emailTo, $subjet, $cc_emails, $message, array());    
	
    $i=2;

	}
    
 
echo $i;
}
public function getstock_total($value='')
{
	# code...
	$INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
	$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');

	$sql = "SELECT SUM((ri.QUANTITE-ri.QUANTITE_DISTRIBUTUEE)) QUANTITE_DISPONIBL_TOTAL FROM (SELECT iss.INTERVENANT_STRUCTURE_DESCR,`RECEPTION_ID` FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE 1) rc JOIN rc_reception_intrant_detail ri ON rc.`RECEPTION_ID`=ri.RECEPTION_ID WHERE ri.INTRANT_ID=".$INTRANT_MEDICAUX_ID;
    $ST=$this->Modele->getRequeteOne($sql);
    $sql2 = "SELECT iss.INTERVENANT_STRUCTURE_DESCR,`QUANTITE` FROM `stock_intervenat`  si JOIN intervenants_structure iss ON si.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID  WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND si.`INTERVENANT_STRUCTURE_ID`=".$INTERVENANT_STRUCTURE_ID;
    $ST_INTERVENANT=$this->Modele->getRequeteOne($sql2);

    echo "Quantité totale disponible <strong>".number_format($ST['QUANTITE_DISPONIBL_TOTAL'], 0, ' ', ' ')."</strong><br>Quantité totale disponible au ".$ST_INTERVENANT['INTERVENANT_STRUCTURE_DESCR']." <strong>".number_format($ST_INTERVENANT['QUANTITE'], 0, ' ', ' ')."</strong>";





}

public function historique($value=0)
 {
          $PTF_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
          $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
          

		  $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
		  $var_search=str_replace("'", "\'", $var_search);  
		  $query_principal='SELECT distinct INTERVENANT_STRUCTURE_DESCR,all_receive.QUANTITE AS QUANTITERECU,NUMERO_LOT,QUANTITERESTANTE,(sdi.`QUANTITE`-sdi.`QUANTITE_RESTANTE`) QUANTITE_DEJA_DISTRIBUE_NIVEAU_BDS ,PTF_ID FROM `stock_distribution_intrant_detail` sdi JOIN (SELECT INTERVENANT_STRUCTURE_DESCR,`NUMERO_LOT`,`QUANTITE`,QUANTITE_DISTRIBUTUEE QUANTITERESTANTE,PTF_ID,RECEPTION_CODE,rri.`INTRANT_ID` FROM `rc_reception_intrant_detail` rri JOIN (SELECT `RECEPTION_CODE`,`RECEPTION_ID`,iss.INTERVENANT_STRUCTURE_DESCR,PTF_ID FROM `rc_reception` rr JOIN intervenants_structure iss on rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE 1) reception ON rri.`RECEPTION_ID`=reception.RECEPTION_ID ) all_receive ON sdi.`RECEPTION_CODE`=all_receive.RECEPTION_CODE JOIN stock_distribution sd ON sdi.DISTRIBUTION_ID=sd.DISTRIBUTION_ID WHERE all_receive.`INTRANT_ID`='.$INTRANT_MEDICAUX_ID.' AND sd.INTERVENANT_STRUCTURE_ID='.$PTF_ID;

          $group="";
          $critaire="";

		  $limit='LIMIT 0,10';
		  if($_POST['length'] != -1){
		    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		  }
		  $order_by='';
		  if($_POST['order']['0']['column']!=0){
		    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
		  }

		  $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';


		  
		  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
		  $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

		  $fetch_intrants = $this->Modele->datatable($query_secondaire);
		  $u=0;
		  $data = array();
	
		  foreach ($fetch_intrants as $row) {

		   $u++;
		   $sub_array = array();
		   $sub_array[] =  $u;
           $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
           $sub_array[]=$row->NUMERO_LOT;
           $sub_array[]=number_format($row->QUANTITERECU, 0, ' ', ' ');
		   $sub_array[]=number_format($row->QUANTITERESTANTE, 0, ' ', ' ');
		   $sub_array[]=number_format($row->QUANTITE_DEJA_DISTRIBUE_NIVEAU_BDS, 0, ' ', ' ');
   		   $data[] = $sub_array;

		}
 
		$output = array(
		 "draw" => intval($_POST['draw']),
		 "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
		 "recordsFiltered" => $this->Modele->filtrer($query_filter),
		 "data" => $data
		);
		echo json_encode($output);
}
public function upload_document($nom_file,$nom_champ,$DEMANDE_ID)
{
  # code...

      $rep_doc =FCPATH.'uploads/distribution/';
      $code=date("YmdHis");
      $fichier=basename($code."piece".$DEMANDE_ID);
      $file_extension = pathinfo($nom_champ, PATHINFO_EXTENSION);
      $file_extension = strtolower($file_extension);
      $valid_ext = array('png','jpeg','jpg');

      if(!is_dir($rep_doc)) //create the folder if it does not already exists   
      {
          mkdir($rep_doc,0777,TRUE);
                                                     
      }  
     // if ($size<1000000 && in_array($file_extension,$valid_ext)) {
     	# code...

      move_uploaded_file($nom_file, $rep_doc.$fichier.".".$file_extension);
      $pathfile="uploads/distribution/".$fichier.".".$file_extension;
      return $pathfile;

     // }else{

     // 	return "file_non_suport";

     // }

}
}

?>