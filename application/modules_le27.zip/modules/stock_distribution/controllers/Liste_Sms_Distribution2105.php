<?php 

/**
 * christa
 * Liste de distribution ASC - Population
 */
class Liste_Sms_Distribution extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}

	function index($INTERVENTION_ID=0)
	{
		$data['error'] = '';
		$data['title'] = 'INTRANTS - Distribution Asc - Population';
		$data['INTERVENTION_ID'] = $INTERVENTION_ID;
		$this->load->view('Liste_Sms_Distribution_View',$data);
		
	}

	function listing()
	{
		$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

		if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS") {

			$query_principal="SELECT sdi.`INTERVENTION_ID`,concat(i.NOM,' ',i.PRENOM) as nom,maladies.MALADIE_DESCR,sdi.DATE_INSERTION,sdi.TELEPHONE,sdi.TEST,sdi.TRANCHE_AGE FROM sms_distribution_intervention sdi JOIN intervenants_rh i ON sdi.INTERVENANT_RH_ID=i.INTERVENANT_RH_ID JOIN maladies ON sdi.MALADIE_ID=maladies.MALADIE_ID WHERE sdi.`INTERVENANT_RH_ID` IN (SELECT `INTERVENANT_RH_ID` FROM `cds_asc` WHERE `CDS_ID` IN (SELECT bds_cds.CDS_ID FROM bds_cds WHERE BDS_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')." ))";

		}elseif ($this->session->userdata('iccm_PROFIL_CODE')=="BDS") {
			# code...
			$query_principal="SELECT sdi.`INTERVENTION_ID`, concat(i.NOM,' ',i.PRENOM) as nom,maladies.MALADIE_DESCR,sdi.DATE_INSERTION,sdi.TELEPHONE,sdi.TEST,sdi.TRANCHE_AGE FROM sms_distribution_intervention sdi JOIN intervenants_rh i ON sdi.INTERVENANT_RH_ID=i.INTERVENANT_RH_ID JOIN maladies ON sdi.MALADIE_ID=maladies.MALADIE_ID WHERE sdi.`INTERVENANT_RH_ID` IN (SELECT `INTERVENANT_RH_ID` FROM `cds_asc` WHERE `CDS_ID`=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID').")";
		}else{
				$query_principal="SELECT sdi.`INTERVENTION_ID`,concat(i.NOM,' ',i.PRENOM) as nom,maladies.MALADIE_DESCR,sdi.DATE_INSERTION,sdi.TELEPHONE,sdi.TEST,sdi.TRANCHE_AGE FROM sms_distribution_intervention sdi JOIN intervenants_rh i ON sdi.INTERVENANT_RH_ID=i.INTERVENANT_RH_ID JOIN maladies ON sdi.MALADIE_ID=maladies.MALADIE_ID";
		}
		$limit='LIMIT 0,10';


		if($_POST['length'] != -1) {
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}


		$order_by='';
		if($_POST['order']['0']['column']!=0){
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY nom   DESC';
		}

		$search = !empty($_POST['search']['value']) ? (" AND  nom LIKE '%$var_search%'  ") : '';

		$critaire="";
		$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		$query_filter=$query_principal.'  '.$critaire.' '.$search;


		$fetch_sms_distribution= $this->Modele->datatable($query_secondaire);

		$data = array();
		foreach ($fetch_sms_distribution as $row) {

		$sqli="SELECT * FROM `sms_distribution_intervention_detail` WHERE `INTERVENTION_ID`=".$row->INTERVENTION_ID; 

        $intrants=$this->Modele->getRequete($sqli);
     
        $stt="";
      if (!empty($row->TEST)) {
      	# code...
				if ($row->TEST == 1) {
					$stt='Positif';
				}

				if($row->TEST == 0){
					$stt='Négatif';
				}
      }

			
			$sub_array = array();

			$sub_array[] = $row->nom;  //(!empty($row->DATE_PEREMPTION)) ? $row->DATE_PEREMPTION : 'N/A';
			$sub_array[] = $row->MALADIE_DESCR;
			$sub_array[] = $row->DATE_INSERTION;
			$sub_array[] = $row->TELEPHONE;
			$sub_array[] =$stt;//$row->TEST;
			$sub_array[] = "<center><a href='#' onclick='detail_intra(".$row->INTERVENTION_ID.");' style='cursor:pointer;'>".sizeof($intrants)."</a></center>";

			
			$data[] = $sub_array;

		}
		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Modele->all_data($query_principal),
			"recordsFiltered" => $this->Modele->filtrer($query_filter),
			"data" => $data
		);

		echo json_encode($output);
	}


   function get_Detail($id)
  {


  	$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
  	$var_search=str_replace("'", "\'", $var_search);  
  	$query_principal="SELECT
    intr.INTRANT_MEDICAUX_DESCR,
    st.QUANTITE
    FROM
    sms_distribution_intervention_detail st
    JOIN intrant_medicaux intr ON
    intr.INTRANT_MEDICAUX_ID=st.INTRANT_ID WHERE 1
    ";

  	$group="";
  	$critaire=" AND st.INTERVENTION_ID=".$id;

  	$limit='LIMIT 0,10';
  	if($_POST['length'] != -1){
  		$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
  	}
  	$order_by='';
  	if($_POST['order']['0']['column']!=0){
  		$order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY intr.INTRANT_MEDICAUX_DESCR DESC';
  	}

  	$search = !empty($_POST['search']['value']) ? (" AND (intr.INTRANT_MEDICAUX_DESCR LIKE '%$var_search%')") : '';



  	$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
  	$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

  	$fetch_data = $this->Modele->datatable($query_secondaire);
  	$u=0;
  	$data = array();


  	foreach ($fetch_data as $row) {

  		$u++;
  		$sub_array = array();
  		$sub_array[]=$row->INTRANT_MEDICAUX_DESCR;
  		$sub_array[]=$row->QUANTITE;
  		
  		$data[] = $sub_array;

  	}

  	$output = array(
  		"draw" => intval($_POST['draw']),
  		"recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
  		"recordsFiltered" => $this->Modele->filtrer($query_filter),
  		"data" => $data
  	);
  	echo json_encode($output);

  }
}

 ?>