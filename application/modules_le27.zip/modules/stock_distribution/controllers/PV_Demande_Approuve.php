<?php
/**
* @Author:NSHIMIRIMANA REVERIEN
* @Commentaire:PV DE DOTATION DES MEDICAMENTS
*/
class PV_Demande_Approuve extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	function index($DEMANDE_ID=6)
	{

		

		include 'pdfinclude/fpdf/mc_table.php';
		include 'pdfinclude/fpdf/pdf_config.php';
		$pdf = new PDF_CONFIG('P','mm','A4');
		$pdf->addPage();


		//REQUETES

		// $demande=$this->Modele->getOne("stock_demande",array('DEMANDE_ID'=>$DEMANDE_ID,'APPROUVE'=>1));

		$demandeur=$this->Modele->getRequeteOne("SELECT stock_demande.DEMANDE_CODE,stock_demande.APPROUVE,stock_demande.INTERVENANT_STRUCTURE_ID,stock_demande.CODE_DEMANDE_SENS_ID,stock_demande.DATE_INSERTION,intv.INTERVENANT_STRUCTURE_DESCR FROM `stock_demande` JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=stock_demande.INTERVENANT_STRUCTURE_ID WHERE stock_demande.DEMANDE_ID=".$DEMANDE_ID." AND APPROUVE=1");

		$tableau_intrants=$this->Modele->getRequete('SELECT stde.QUANTITE_APPROUVEE,stde.QUANTITE QTE_DEMANDE,intra.INTRANT_MEDICAUX_DESCR FROM `stock_demande` JOIN stock_demande_detail stde ON stde.DEMANDE_ID=stock_demande.DEMANDE_ID  JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stde.INTRANT_ID  WHERE stock_demande.DEMANDE_ID='.$DEMANDE_ID.' AND stock_demande.APPROUVE=1');


		$DATE_APPROBATION=date("d-m-Y",strtotime($demandeur['DATE_INSERTION']));


		$pdf->Ln(18);
		$pdf->SetFont('Arial','BU',12);
		$pdf->Cell(150,5,utf8_decode('Procès-verbal d\' approbation des intrants'),0,1,'R');
		$pdf->SetFont('Arial','',12);

		$pdf->Ln(14);

		$pdf->MultiCell(189,5,utf8_decode('Cher '.$demandeur['INTERVENANT_STRUCTURE_DESCR'].' vous avez été approuvé à la demande que vous avez fait en date du '.$DATE_APPROBATION.'.'));
		$pdf->Ln();
		$pdf->MultiCell(189,5,utf8_decode('Code:'.$demandeur['DEMANDE_CODE']));
		$pdf->Ln(10);

		$pdf->MultiCell(189,5,utf8_decode('Tableau des intrants demandés'));
		$pdf->Ln();

	    $pdf->SetWidths(array('9','92','37','45'));
	    $pdf->SetLineHeight(5);
	    $pdf->SetFont('Arial','B',12);
	    $pdf->Row(array(utf8_decode('No.'),utf8_decode('Nom du produit'),utf8_decode('Qté demandée'),utf8_decode('Qté approuvée')),'C');
	     $pdf->SetFont('Arial','',12);

	    $u=0;
	    foreach ($tableau_intrants as $row) 
	    {
	    	$u++;
	    $pdf->Row(array(utf8_decode($u),utf8_decode($row['INTRANT_MEDICAUX_DESCR']),utf8_decode($row['QTE_DEMANDE']),utf8_decode(number_format($row['QUANTITE_APPROUVEE'],0,' ',' '))));
	    }
	    $pdf->SetFont('Arial','',10);
        $pdf->Ln();

       $pdf->MultiCell(185,5,utf8_decode('Fait à ........., le '.date('d/m/Y')),0,'R');

       $pdf->output('I');
        // $pdf->output('Pv de demande du code -'.$demandeur['DEMANDE_CODE'].'.pdf','D');
}
}