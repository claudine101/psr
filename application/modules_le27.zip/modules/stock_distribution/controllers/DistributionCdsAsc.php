<?php

/**
 *
 AUTHOR:NSHIMIRIMANA REVERIEN
 */
 class DistributionCdsAsc extends CI_Controller
 {

   function __construct()
   {
		# code...
    parent::__construct();
  }
  public function index($DEMANDE_ID='')
  {
		

    $sql_distribution = "SELECT intv.INTERVENANT_STRUCTURE_DESCR,stock_distribution.INTERVENANT_STRUCTURE_ID,stock_distribution.CODE_SENS_ID,stock_distribution.DISTRIBUTION_CODE,stock_distribution.DISTRIBUTION_ID,stock_distribution.DEMANDE_ID,stdid.RECEPTION_CODE,stdid.DISTRIBUTION_ID FROM `stock_distribution`  JOIN stock_distribution_intrant_detail stdid ON stdid.DISTRIBUTION_ID=stock_distribution.DISTRIBUTION_ID JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=stock_distribution.INTERVENANT_STRUCTURE_ID JOIN stock_demande ON stock_demande.DEMANDE_ID=stock_distribution.DEMANDE_ID WHERE intv.INTERVENANT_STRUCTURE_ID IN (SELECT bds_cds.CDS_ID FROM bds_cds WHERE bds_cds.CDS_ID=intv.INTERVENANT_STRUCTURE_ID) AND stock_demande.DEMANDE_ID=".$DEMANDE_ID." AND CODE_SENS_ID=2";





    $distri=$this->Modele->getRequeteOne($sql_distribution);

     //print_r($distri);die();

    $sql_intrants ="SELECT DISTINCT im.INTRANT_MEDICAUX_ID,im.INTRANT_MEDICAUX_CODE FROM `stock_distribution_intrant_detail` sdd JOIN intrant_medicaux im ON sdd.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID JOIN stock_distribution std ON std.DISTRIBUTION_ID=sdd.DISTRIBUTION_ID WHERE std.DEMANDE_ID=".$distri['DEMANDE_ID'];

    $intrants=$this->Modele->getRequete($sql_intrants);

    $CDS_PARENT_ID=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');
    $CODE_SENS_ID=$distri['CODE_SENS_ID'];

    //print_r($CDS_PARENT_ID);die();
    

    $sql_cds_asc="SELECT cds_asc.INTERVENANT_RH_ID as INTERVENANT_STRUCTURE_ID,CONCAT(intervenants_rh.NOM,' ',intervenants_rh.PRENOM,' (',intervenants_rh.TELEPHONE1,') ') NOM  FROM `cds_asc` JOIN intervenants_rh ON intervenants_rh.INTERVENANT_RH_ID=cds_asc.INTERVENANT_RH_ID WHERE cds_asc.CDS_ID =".$CDS_PARENT_ID."";
    
    $asc=$this->Modele->getRequete($sql_cds_asc);
    
    if (empty($distri['INTERVENANT_STRUCTURE_ID'])) {
        	# code...
      $distri['INTERVENANT_STRUCTURE_ID']=-1;
    }

    $sql2 = "SELECT r.INTERVENANT_RH_ID,CONCAT(r.NOM,' ',r.PRENOM,' (',r.TELEPHONE1,') ') NOM FROM intervenants_rh r JOIN cds_asc ON cds_asc.INTERVENANT_RH_ID=r.INTERVENANT_RH_ID WHERE cds_asc.CDS_ID=".$CDS_PARENT_ID." ORDER BY NOM ASC";

    $intervenants_rh=$this->Modele->getRequete($sql2);

    $data =array(
      'title'=>'Distribution des intrants aux ASC.<br> Code:'.$distri['DISTRIBUTION_CODE'].'<br>Processus PNILP/DODS <br> '.$distri['INTERVENANT_STRUCTURE_DESCR'].'',
      'DEMANDE_ID'=>$DEMANDE_ID,
    // 'INTERVENANT_STRUCTURE_ID'=>$asc['INTERVENANT_STRUCTURE_ID'],//structure pour le cas c'est l'ASC qui va recevoir des intrants
    'CODE_SENS_ID'=>$CODE_SENS_ID,
    'CDS_PARENT_ID'=>$CDS_PARENT_ID,//LE CDS QUI DISTRIBUE LES INTRANTS AUX ASC
    'stock_distribution_detail'=>$intrants,
    'intervenants_rh'=>$intervenants_rh
    // 'intervenants_rh'=>$intervenants_rh
  );

    $this->load->view('DistributionCdsAsc_View',$data);

  }



  public function liste_intrant_quantite($value=0)
  {
    // $DEMANDE_ID=$this->input->post('DEMANDE_ID');
    // $DEMANDE_ID=2;
    $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
    $CDS_PARENT_ID=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');

    if (empty($CDS_PARENT_ID)) {
          	# code...
      $CDS_PARENT_ID=-1;
    }
    if (empty($INTRANT_MEDICAUX_ID)) {
  	# code...
     $INTRANT_MEDICAUX_ID=-1;
   }


   // $sql = "SELECT SUM(`QUANTITE_RESTANTE`) QUANTITE_RESTANTE FROM `stock_distribution_intrant_detail` sdi JOIN stock_distribution std ON std.`DISTRIBUTION_ID`=sdi.`DISTRIBUTION_ID` WHERE  CODE_SENS_ID=2 AND sdi.`INTRANT_ID`=".$INTRANT_MEDICAUX_ID;

    $sql = "SELECT SUM(`QUANTITE_RESTANTE`) QUANTITE_RESTANTE,std.DEMANDE_ID FROM `stock_distribution_intrant_detail` sdi JOIN stock_distribution std ON std.`DISTRIBUTION_ID`=sdi.`DISTRIBUTION_ID` WHERE  CODE_SENS_ID=2 AND sdi.`INTRANT_ID`=".$INTRANT_MEDICAUX_ID.'  GROUP BY std.DEMANDE_ID';

   $qte=$this->Modele->getRequeteOne($sql);

   $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
   $var_search=str_replace("'", "\'", $var_search);  

   $query_principal='SELECT std.INTERVENANT_STRUCTURE_ID,CODE_SENS_ID,stdi.RECEPTION_CODE,stdi.RECEPTION_INTRANT_ID,DEMANDE_ID,DETAIL_ID,INTRANT_ID,QUANTITE_RESTANTE QUANTITE_DISPO,(SELECT  intev.INTERVENANT_STRUCTURE_DESCR FROM rc_reception rcr JOIN intervenants_structure intev ON intev.INTERVENANT_STRUCTURE_ID=rcr.PTF_ID WHERE rcr.RECEPTION_CODE LIKE stdi.RECEPTION_CODE ) PTF,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` r JOIN rc_reception rcr ON r.`RECEPTION_ID`=rcr.RECEPTION_ID WHERE r.`INTRANT_ID`=stdi.`INTRANT_ID` AND rcr.RECEPTION_CODE LIKE stdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=stdi.`RECEPTION_INTRANT_ID` ) NUMERO_LOT,(SELECT `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` r JOIN rc_reception rcr ON r.`RECEPTION_ID`=rcr.RECEPTION_ID WHERE r.`INTRANT_ID`=stdi.`INTRANT_ID` AND rcr.RECEPTION_CODE LIKE stdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=stdi.`RECEPTION_INTRANT_ID`) DATE_PEREMPTION FROM `stock_distribution_intrant_detail` stdi JOIN stock_distribution std ON std.DISTRIBUTION_ID=stdi.`DISTRIBUTION_ID` WHERE std.INTERVENANT_STRUCTURE_ID='.$CDS_PARENT_ID.' AND `INTRANT_ID`='.$INTRANT_MEDICAUX_ID.' HAVING QUANTITE_RESTANTE>0';

   $group="";
   $critaire="";

   $limit='LIMIT 0,10';
   if($_POST['length'] != -1){
    $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
  }
  $order_by='';
  if($_POST['order']['0']['column']!=0){
    $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY PTF DESC';
  }

  $search = !empty($_POST['search']['value']) ? (" AND (PTF LIKE '%$var_search%')") : '';



  $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
  $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

  $fetch_intrants = $this->Modele->datatable($query_secondaire);
  $u=0;
  $data = array();

  $QUANTITE_STOCK_DISPO_TOTAL=0;
  foreach ($fetch_intrants as $row) {

   $u++;
   $sub_array = array();
   $sub_array[] =  $u;
   $sub_array[]=$row->PTF;
   $sub_array[]=$row->NUMERO_LOT;
   $sub_array[]=$row->DATE_PEREMPTION;
   $sub_array[]=number_format($row->QUANTITE_DISPO, 0, ' ', ' ');
   $comteur_id=0;
   $code=substr($row->RECEPTION_CODE,-14);
   $sub_array[]='<input type="number" step="any" name="QUANTITE_APPROUVE'.$u.'" id="QUANTITE_APPROUVE'.$u.'" class="form-control-sm"  value="'.$qte['QUANTITE_RESTANTE'].'" onchange="get_valeur('.$u.')" onkeyup="get_valeur('.$u.')">';

   $sub_array[]='<a href="#" onclick="valider('.$INTRANT_MEDICAUX_ID.','.$u.','.$row->QUANTITE_DISPO.','.$row->DETAIL_ID.','.$qte['QUANTITE_RESTANTE'].','.$comteur_id.','.$row->RECEPTION_INTRANT_ID.','.$row->DEMANDE_ID.','.$code.')">Valider</a>';





   $data[] = $sub_array;

 }

 $output = array(
   "draw" => intval($_POST['draw']),
   "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
   "recordsFiltered" => $this->Modele->filtrer($query_filter),
   "data" => $data
 );
 echo json_encode($output);
}


public function valider($value='')
{
  # code...


    $id['DISTRIBUTION_ID']=NULL;
    $this->session->set_userdata($id);


  $QUANTITE_DISPONIBLE=$this->input->post('QUANTITE_DISPONIBLE');
  $QUANTITE_APPROUVE=$this->input->post('QUANTITE_APPROUVE');
  $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
  $DETAIL_ID=$this->input->post('DETAIL_ID');
  $RECEPTION_INTRANT_ID=$this->input->post('RECEPTION_INTRANT_ID');
  $DEMANDE_ID=$this->input->post('DEMANDE_ID');
  $RECEPTION_CODE=$this->input->post('RECEPTION_CODE');
  $COMMENT=$this->input->post('COMMENT');
  $INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');
  $CDS_PARENT_ID=$this->input->post('CDS_PARENT_ID');



  $INTERVENANT_STRUCTURE_ASC=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_CODE'=>"ASC"));

  $INTERVENANT_STRUCTURE_ID=$INTERVENANT_STRUCTURE_ASC['INTERVENANT_STRUCTURE_ID'];

  $distribu=$this->Modele->getOne('stock_distribution',array('DEMANDE_ID'=>$DEMANDE_ID));


  
  $came=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID`,EMAIL FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');//recuperation email camebu
  $i=0;

  if ($distribu['CODE_SENS_ID']==2) {
    # code...
    if (empty($this->session->userdata('DISTRIBUTION_ID'))) {
    # code..2
    #echo substr('abcdef', 1);     // bcdef
      $PIECE_JUSTIFICATIF = (!empty($_FILES['PIECE_JUSTIFICATIF']['tmp_name'])) ? $this->upload_document($_FILES['PIECE_JUSTIFICATIF']['tmp_name'],$_FILES['PIECE_JUSTIFICATIF']['name'],$DEMANDE_ID) : NULL ;
      
      $stock_distribution = array(
        'DISTRIBUTION_DATE' => date('Y-m-d'),
        'CODE_SENS_ID' =>3,
        'DEMANDE_ID' => $DEMANDE_ID,
        'USER_ID' =>$this->session->userdata('iccm_USER_ID') ,
        'INTERVENANT_RH_ID' =>$INTERVENANT_RH_ID ,
        'COMMENT'=>$COMMENT,
        'PIECE_JUSTIFICATIF'=>$PIECE_JUSTIFICATIF,
        'INTERVENANT_STRUCTURE_ID' =>$INTERVENANT_STRUCTURE_ID,
        'INTERVENANT_STRUCTURE_DONNATEUR'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'),
      );
      $DISTRIBUTION_ID=$this->Modele->insert_last_id('stock_distribution',$stock_distribution);
      $DISTRIBUTION_CODE="DSTR-".substr("".date('Ymd')."", 2)."-".$DISTRIBUTION_ID;
      $this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>$DISTRIBUTION_CODE));
      $id['DISTRIBUTION_ID']=$DISTRIBUTION_ID;
      $this->session->set_userdata($id);
      $i=1;
      // $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('STATUT_DISTRIBUTION'=>1));
    }else{
     $DISTRIBUTION_ID=$this->session->userdata('DISTRIBUTION_ID');
   }


   /*****************************inserttion stock_distribution_intrant_detail*******************************/
    //eviter d'ajouter un mm intrant de mm lot ,mm reception et mm distribution
   $array_for_test=array(
    'DISTRIBUTION_ID' => $DISTRIBUTION_ID,
    'RECEPTION_CODE' => 'RC'.$RECEPTION_CODE,
    'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
    'INTRANT_ID' => $INTRANT_MEDICAUX_ID
    

  );
   $quantite_approuve_existant=0;
   $array_for_test_sdid=$this->Modele->getOne('stock_distribution_intrant_detail',$array_for_test);

   if (intval($array_for_test_sdid['INTRANT_ID'])>0) {
    # code...

    $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_RESTANTE'=>($QUANTITE_DISPONIBLE-$QUANTITE_APPROUVE)));
    
    $quantite_approuve_existant=$array_for_test_sdid['QUANTITE_RESTANTE']+$QUANTITE_APPROUVE;
    $this->Modele->update('stock_distribution_intrant_detail',$array_for_test,array(
      'QUANTITE_RESTANTE'=>$quantite_approuve_existant


    ));




  }else{

    $stock_distribution_intrant_detail = array(
      'DISTRIBUTION_ID' => $DISTRIBUTION_ID,
      'RECEPTION_CODE' => 'RC'.$RECEPTION_CODE,
      'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
      'INTRANT_ID' => $INTRANT_MEDICAUX_ID,
      'QUANTITE' =>$QUANTITE_APPROUVE,
      'QUANTITE_RESTANTE'=>$QUANTITE_APPROUVE
    );       
     
    $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_RESTANTE'=>($QUANTITE_DISPONIBLE-$QUANTITE_APPROUVE)));
    $this->Modele->create('stock_distribution_intrant_detail',$stock_distribution_intrant_detail);

  }

  


  /***************mis a jour de la stock  intervenant donnateur*****************************/

      //$INTERVENANT_STRUCTURE_ID=$CDS_PARENT_ID;
  $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$CDS_PARENT_ID));
  $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']-$QUANTITE_APPROUVE;
      $this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$CDS_PARENT_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));//mis a jour de la stock  dans structure intervenant


      /*******************************************************************************************/
      /******************mis a jour pour structure demandeur*********************************************/
      $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID));
      if (empty($quantite_precedent_sock_intervenant['QUANTITE'])) {
      # code...
        $quantite_precedent_sock_intervenant['QUANTITE']=0;
      }
      $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']+$QUANTITE_APPROUVE;

      if ($quantite_precedent_sock_intervenant['QUANTITE']>=0 && !empty($quantite_precedent_sock_intervenant['INTRANT_ID']) && !empty($quantite_precedent_sock_intervenant['INTERVENANT_RH_ID'])) {
          # code...
        $this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_RH_ID'=>$INTERVENANT_RH_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
      }else{

        
        
        $stock_intervenat=array('INTERVENANT_STRUCTURE_ID' =>$INTERVENANT_STRUCTURE_ID,
          'INTRANT_ID' => $INTRANT_MEDICAUX_ID,
          'QUANTITE' =>$QUANTITE_STOCK_INTERVENANT ,
          'INTERVENANT_RH_ID' =>$INTERVENANT_RH_ID ,
          'DATE_LAST_UPDATE' =>date('Y-m-d H:i:s'),
        );
        $this->Modele->create('stock_intervenat',$stock_intervenat);
      }

      /******************************************send mail***********************************************/

      $sql_sm = "SELECT iss.INTERVENANT_STRUCTURE_ID PTF_ID,iss.INTERVENANT_STRUCTURE_DESCR PTF_NOM,`RECEPTION_ID` id,iss.EMAIL,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND `RECEPTION_ID`=id AND RECEPTION_INTRANT_ID=".$RECEPTION_INTRANT_ID.") NUMERO_LOT FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE RECEPTION_CODE LIKE '".'RC'.$RECEPTION_CODE."'";
      $info_reception_ptf=$this->Modele->getRequeteOne($sql_sm);

      $intrant=$this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID));
      $recepteur_intrant=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$CDS_PARENT_ID));

      $message = "Cher ".$info_reception_ptf['PTF_NOM'].", Une quantité <b>".$QUANTITE_APPROUVE."</b> de l'intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." a été distribuée(s) à ".$recepteur_intrant['INTERVENANT_STRUCTURE_DESCR'];
      $subjet = "Distribution d'un intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." du lot ".$info_reception_ptf['NUMERO_LOT'];
  $emailTo = $info_reception_ptf['EMAIL'];//email du ptf
  $cc_emails=array();
    $cc_emails[]=$recepteur_intrant['EMAIL'];//email du bds demandeur
    $cc_emails[]=$came['EMAIL'];//email camebu

    $array_notifications = array(
      'MESSAGE'=>$message,
      'PTF_ID'=>$info_reception_ptf['PTF_ID'],
      'EMAIL_NOTIFIE'=>$info_reception_ptf['EMAIL'],
      'INTRANT_ID'=>$INTRANT_MEDICAUX_ID,
      'INTRANT_ID'=>$QUANTITE_APPROUVE,
      'IS_DISTRIBUTION'=>1
    );
    $this->Modele->insert_last_id('sms_mouvement_stock',$array_notifications);
    $this->notifications->send_mail($emailTo, $subjet, $cc_emails, $message, array());    

    $i=2;

  }


  echo $i;
}








public function getstock_total($value='')
{
	# code...
	$INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
	//$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
  $CDS_PARENT_ID=$this->input->post('CDS_PARENT_ID');
  
  if (empty($CDS_PARENT_ID)) {
          	# code...
   $CDS_PARENT_ID=-1;
 }
 if (empty($INTRANT_MEDICAUX_ID)) {
          	# code...
   $INTRANT_MEDICAUX_ID=-1;
 }
 $sql = "SELECT `QUANTITE` QUANTITE_DISPONIBL_TOTAL FROM `stock_intervenat` WHERE `INTERVENANT_STRUCTURE_ID`=".$CDS_PARENT_ID." AND `INTRANT_ID`=".$INTRANT_MEDICAUX_ID;
 $ST=$this->Modele->getRequeteOne($sql);


 $sql2 = "SELECT iss.INTERVENANT_STRUCTURE_DESCR,`QUANTITE` FROM `stock_intervenat`  si JOIN intervenants_structure iss ON si.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID  WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND si.`INTERVENANT_STRUCTURE_ID`=".$CDS_PARENT_ID;
 $ST_INTERVENANT=$this->Modele->getRequeteOne($sql2);

 echo "Quantité totale disponible <strong>".number_format($ST['QUANTITE_DISPONIBL_TOTAL'], 0, ' ', ' ')."</strong><br>Quantité totale disponible au ".$ST_INTERVENANT['INTERVENANT_STRUCTURE_DESCR']." <strong>".number_format($ST_INTERVENANT['QUANTITE'], 0, ' ', ' ')."</strong>";





}

public function historique($value=0)
{
  $CDS_PARENT_ID=$this->input->post('CDS_PARENT_ID');
  $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
  if (empty($CDS_PARENT_ID)) {
          	# code...
   $CDS_PARENT_ID=-1;
 }
 if (empty($INTRANT_MEDICAUX_ID)) {
          	# code...
   $INTRANT_MEDICAUX_ID=-1;
 }

 $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
 $var_search=str_replace("'", "\'", $var_search);  
 $query_principal='SELECT sdi.`RECEPTION_INTRANT_ID`,`DETAIL_ID`,`INTRANT_ID`,`RECEPTION_CODE`,
 `QUANTITE_RESTANTE` QUANTITERESTANTE,`QUANTITE` QUANTITERECU,(QUANTITE-QUANTITE_RESTANTE) QUANTITE_DEJA_DISTRIBUE_NIVEAU_CDS,

 (SELECT iss.INTERVENANT_STRUCTURE_DESCR FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE rr.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` ) AS INTERVENANT_STRUCTURE_DESCR,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` r JOIN rc_reception c ON r.`RECEPTION_ID`=c.RECEPTION_ID WHERE r.`INTRANT_ID`=sdi.`INTRANT_ID` AND c.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=sdi.`RECEPTION_INTRANT_ID` ) NUMERO_LOT,

 (SELECT `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` r JOIN rc_reception c ON r.`RECEPTION_ID`=c.RECEPTION_ID WHERE r.`INTRANT_ID`=sdi.`INTRANT_ID` AND c.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=sdi.`RECEPTION_INTRANT_ID`) DATE_PEREMPTION 

 FROM `stock_distribution_intrant_detail` sdi JOIN stock_distribution sd ON sdi.`DISTRIBUTION_ID`=sd.DISTRIBUTION_ID  WHERE sd.INTERVENANT_STRUCTURE_ID='.$CDS_PARENT_ID.' AND `INTRANT_ID`='.$INTRANT_MEDICAUX_ID.' AND CODE_SENS_ID=2';

 $group="";
 $critaire="";

 $limit='LIMIT 0,10';
 if($_POST['length'] != -1){
  $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
}
$order_by='';
if($_POST['order']['0']['column']!=0){
  $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
}

$search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';



$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

$fetch_intrants = $this->Modele->datatable($query_secondaire);
$u=0;
$data = array();

foreach ($fetch_intrants as $row) {

 $u++;
 $sub_array = array();
 $sub_array[] =  $u;
 $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
 $sub_array[]=$row->NUMERO_LOT;
 $sub_array[]=number_format($row->QUANTITERECU, 0, ' ', ' ');
 $sub_array[]=number_format($row->QUANTITERESTANTE, 0, ' ', ' ');
 $sub_array[]=number_format($row->QUANTITE_DEJA_DISTRIBUE_NIVEAU_CDS, 0, ' ', ' ');
 $data[] = $sub_array;

}

$output = array(
 "draw" => intval($_POST['draw']),
 "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
 "recordsFiltered" => $this->Modele->filtrer($query_filter),
 "data" => $data
);
echo json_encode($output);
}


public function mes_demande($value='')
{


    
    $sql_intrants ="SELECT DISTINCT im.INTRANT_MEDICAUX_ID,im.INTRANT_MEDICAUX_CODE,im.INTRANT_MEDICAUX_DESCR FROM `stock_distribution_intrant_detail` sdd JOIN intrant_medicaux im ON sdd.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID JOIN stock_distribution std ON std.DISTRIBUTION_ID=sdd.DISTRIBUTION_ID WHERE std.INTERVENANT_STRUCTURE_ID=".$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');

    $intrants=$this->Modele->getRequete($sql_intrants);

    // $CDS_PARENT_ID=1;
    $CDS_PARENT_ID=$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID');

     // $sql_cds_asc="SELECT cds_asc.INTERVENANT_RH_ID as INTERVENANT_STRUCTURE_ID,CONCAT(intervenants_rh.NOM,' ',intervenants_rh.PRENOM,' (',intervenants_rh.TELEPHONE1,') ') NOM  FROM `cds_asc` JOIN intervenants_rh ON intervenants_rh.INTERVENANT_RH_ID=cds_asc.INTERVENANT_RH_ID WHERE cds_asc.INTERVENANT_RH_ID IN (SELECT intervenants_structure.INTERVENANT_STRUCTURE_ID FROM intervenants_structure WHERE cds_asc.CDS_ID =".$CDS_PARENT_ID.")";
    $sql_cds_asc="SELECT cds_asc.INTERVENANT_RH_ID as INTERVENANT_STRUCTURE_ID,CONCAT(intervenants_rh.NOM,' (',intervenants_rh.TELEPHONE1,') ') NOM  FROM `cds_asc` JOIN intervenants_rh ON intervenants_rh.INTERVENANT_RH_ID=cds_asc.INTERVENANT_RH_ID WHERE cds_asc.CDS_ID =".$CDS_PARENT_ID."";
    
    $asc=$this->Modele->getRequete($sql_cds_asc);


	$data=array(
    'INTERVENANT_STRUCTURE_ID'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'),
    'stock_distribution_detail'=>$intrants,
    'CODE_SENS_ID'=>2,
    'CDS_PARENT_ID'=>$CDS_PARENT_ID,
    'intervenants_rh'=>$asc,
    'value'=>$value
  );

  // print_r($value);die();
  // $data['value']=$value;
  $this->load->view('Demande_Cds_Aux_Bds_View',$data);
}


public function demandes_des_cds($value='')
{
 $INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
 $idvalue=intval($this->input->post('idvalue'));


 $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
 $var_search=str_replace("'", "\'", $var_search);  
 $query_principal='SELECT `DEMANDE_ID`,STATUT_DISTRIBUTION,STATUT_RECEPTION,DATE_INSERTION,APPROUVE,`DEMANDE_CODE`,concat(ih.NOM," ",ih.PRENOM) nom,iss.INTERVENANT_STRUCTURE_DESCR,(CASE WHEN APPROUVE=0 THEN "Attente d\'approbation" ELSE "Approuvée" END) statut_approbation FROM `stock_demande` sd JOIN intervenants_structure iss ON sd.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID JOIN intervenants_rh ih ON sd.`USER_DEMANDEUR_ID`=ih.INTERVENANT_RH_ID';

 $group="";
 $critaire="";


 if ($idvalue==0) {
            $critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID` IN (SELECT `CDS_ID` FROM `bds_cds` WHERE `CDS_ID`='.$INTERVENANT_STRUCTURE_ID.') AND APPROUVE=0 AND CODE_DEMANDE_SENS_ID=2'; //non approuver
          } else {
           $critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID` IN (SELECT `CDS_ID` FROM `bds_cds` WHERE `CDS_ID`='.$INTERVENANT_STRUCTURE_ID.') AND APPROUVE=1 AND CODE_DEMANDE_SENS_ID=2'; // approuver
         }




         $limit='LIMIT 0,10';
         if($_POST['length'] != -1){
          $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
        }
        $order_by='';
        if($_POST['order']['0']['column']!=0){
          $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
        }


        $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR concat(ih.NOM,' ',ih.PRENOM) LIKE '%$var_search%' OR DEMANDE_CODE LIKE '%$var_search%')") : '';



        $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
        $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

        $fetch_intrants = $this->Modele->datatable($query_secondaire);
        $u=0;
        $data = array();

        foreach ($fetch_intrants as $row) {
          $det_intrants=$this->Modele->getRequete("
           SELECT
           med.INTRANT_MEDICAUX_DESCR,
           det.QUANTITE,
           det.QUANTITE_APPROUVEE,
           sdt.STATUT_DISTRIBUTION
           FROM
           stock_demande_detail det
           JOIN intrant_medicaux med ON
           med.INTRANT_MEDICAUX_ID = det.INTRANT_ID
           JOIN stock_demande sdt ON sdt.DEMANDE_ID=det.DEMANDE_ID
           WHERE
           det.DEMANDE_ID = ".$row->DEMANDE_ID.""
         );

          $table_intrant='
          <table class="table table-sm table-bordered">
          <thead>
          <tr>
          <th>Intrant</th>
          <th>Q.demandée</th>
          <th>Q.approuvée</th>

          </tr>
          </thead>
          <tbody>';
          foreach ($det_intrants as $intrant) {

            $qt =(!empty($intrant['QUANTITE_APPROUVEE'])) ? $intrant['QUANTITE_APPROUVEE'] : '-';
            // $statut =($intrant['APPROUVE']==0) ? 'En ettente' : 'Approuvée';
           $table_intrant.='<tr>
           <td>'.$intrant['INTRANT_MEDICAUX_DESCR'].'</td>
           <td><center>'.$intrant['QUANTITE'].'</center></td>
           <td><center>'.$qt.'</center></td>
           </tr>';

         }

         $table_intrant.='</tbody>
         </table>
         ' ;
         $u++;
         $sub_array = array();
         $sub_array[] =  $u;
         //$sub_array[]=$row->DEMANDE_CODE;
         $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR."<br>".$row->nom;
         $sub_array[]=$table_intrant;
         $sub_array[]=$row->statut_approbation;
         $sub_array[]=date('d-m-Y',strtotime($row->DATE_INSERTION));

         $opt='<div class="dropdown" style="color:#fff;">
         <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
         <i class="fa fa-cog"></i> Options<span class="caret">
         </span></a> 
         <ul class="dropdown-menu dropdown-menu-left">';

         $opt='<div class="dropdown" style="color:#fff;">
         <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
         <i class="fa fa-cog"></i> Options<span class="caret">
         </span></a> 
         <ul class="dropdown-menu dropdown-menu-left">';

        if ($row->APPROUVE==0 && $idvalue==0) {
          $opt.='<li class="dropdown-item"><a href="'.base_url('demande/Demande/update_demande_view/'.$row->DEMANDE_ID).'">Modifier</a></li>';
          $opt.="<li class='dropdown-item'>
                 <a href='#' data-toggle='modal' data-target='#mydelete".$row->DEMANDE_ID."'>
                       <label class='text-danger'>Supprimer</label>
                       </a></li>";
         }elseif ($row->STATUT_RECEPTION==0 && $idvalue==1) {
          $opt.='<li class="dropdown-item"><a href="#" onclick="get_demande_for_ar('.$row->DEMANDE_ID.',1)">Accusé de réception</a></li>';
         }
         // elseif ($row->STATUT_RECEPTION==1 && $idvalue==1) {
         //  $opt.='<li class="dropdown-item"><a href="'.base_url('stock_distribution/DistributionCdsAsc/index/'.$row->DEMANDE_ID).'">Servir</a></li>';
         //  // $opt.='<li class="dropdown-item"><a href="'.base_url('stock_distribution/PV_Demande_Approuve/index/'.$row->DEMANDE_ID).'">PV</a></li>';
         // }

         



        $opt.="</ul>
        <div class='modal fade' id='mydelete".$row->DEMANDE_ID."'>
        <div class='modal-dialog'>
        <div class='modal-content'>

        <div class='modal-body'>
        <center>
        <h5 class='text-info'>Voulez-vous supprimer cette demande ?
        </h5>
        </center>
        </div>

        <div class='modal-footer'>
        <a class='btn btn-outline-danger btn-md' href='" . base_url('demande/Demande/delete_demande/').$row->DEMANDE_ID. "'>Supprimer
        </a>
        <button class='btn btn-outline-primary btn-md' data-dismiss='modal'>
        Quitter
        </button>
        </div>

        </div>
        </div>
        </div>

        ";

        $sub_array[]=$opt;
        $data[] = $sub_array;

      }

      $output = array(
       "draw" => intval($_POST['draw']),
       "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
       "recordsFiltered" => $this->Modele->filtrer($query_filter),
       "data" => $data
     );
      echo json_encode($output);
    }
    public function get_demande_detail($value='')
    {
	# code...
     $DEMANDE_ID=$this->input->post("DEMANDE_ID");
     $sql = "SELECT b.CDS_ID INTERVENANT_STRUCTURE_ID_PARENT FROM `stock_demande` s JOIN bds_cds b ON s.`INTERVENANT_STRUCTURE_ID`=b.CDS_ID WHERE s.`DEMANDE_ID`=".$DEMANDE_ID;
     $intervenant_parent=$this->Modele->getRequeteOne($sql);

     $TEST_VALUE=intval($this->input->post("TEST_VALUE"));

     if ($TEST_VALUE==1) {
		# code...
		//AR;Accusé de réception
       $table_intrant='
       <table class="table table-sm table-bordered">
       <thead>
       <tr>
       <th>Intrant</th>
       <th>Q.demandée</th>
       <th>Q.approuvée</th>
       <th>Q.reçu</th>
       <th>Q.confirmé reçu</th>

       </tr>
       </thead>
       <tbody>';

       $i=0;
       $det_intrants=$this->Modele->getRequete("
         SELECT
         med.INTRANT_MEDICAUX_DESCR,
         det.QUANTITE,
         det.DETAIL_ID,
         det.QUANTITE_APPROUVEE,
         (det.QUANTITE-det.QUANTITE_APPROUVEE_RESTANT) QUANTITE_RECU


         FROM
         stock_demande_detail det
         JOIN intrant_medicaux med ON
         med.INTRANT_MEDICAUX_ID = det.INTRANT_ID
         WHERE
         det.DEMANDE_ID=".$DEMANDE_ID.""
       );
       $i=0;
       foreach ($det_intrants as $intrant) {

         $table_intrant.='<tr>
         <td>'.$intrant['INTRANT_MEDICAUX_DESCR'].'</td>
         <td>'.$intrant['QUANTITE'].'</td>
         <td >'.$intrant['QUANTITE_APPROUVEE'].'</td>
         <td >'.$intrant['QUANTITE_RECU'].'</td>
         <td>
         <input type="number" step="any" name="QUANTITE_RECU'.$i.'" id="QUANTITE_RECU'.$i.'" value="'.$intrant['QUANTITE_RECU'].'" >
         <input type="hidden" step="any" name="QUANTITE_COMFIRMER_RECU'.$i.'" id="QUANTITE_COMFIRMER_RECU'.$i.'" value="'.$intrant['QUANTITE_RECU'].'" >

         <input type="hidden" step="any" name="DETAIL_ID'.$i.'" id="DETAIL_ID'.$i.'" value="'.$intrant['DETAIL_ID'].'" >
         </td>
         </tr>';
         $i++;				    
       }



     }else{
		//approbation


       $table_intrant='
       <table class="table table-sm table-bordered">
       <thead>
       <tr>
       <th>Intrant</th>
       <th>Q.demandée</th>
       <th>Q.disponible</th>
       <th>Q.approuvée</th>


       </tr>
       </thead>
       <tbody>';
       $det_intrants=$this->Modele->getRequete("
         SELECT
         med.INTRANT_MEDICAUX_DESCR,
         det.QUANTITE,
         det.DETAIL_ID,
         det.QUANTITE_APPROUVEE,
         (SELECT sum(`QUANTITE`) FROM `stock_intervenat` WHERE `INTRANT_ID`=det.INTRANT_ID AND `INTERVENANT_STRUCTURE_ID`=".$intervenant_parent['INTERVENANT_STRUCTURE_ID_PARENT'].") QUANTITE_DISPONIBLE

         FROM
         stock_demande_detail det
         JOIN intrant_medicaux med ON
         med.INTRANT_MEDICAUX_ID = det.INTRANT_ID
         WHERE
         det.DEMANDE_ID = ".$DEMANDE_ID.""
       );
       $i=0;
       foreach ($det_intrants as $intrant) {
         $clas="text-danger";
         if ($intrant['QUANTITE']<$intrant['QUANTITE_DISPONIBLE']) {
				        		# code...
          $clas="text-info";

        }
        $table_intrant.='<tr>
        <td>'.$intrant['INTRANT_MEDICAUX_DESCR'].'</td>
        <td>'.$intrant['QUANTITE'].'</td>
        <td class="'.$clas.'">'.$intrant['QUANTITE_DISPONIBLE'].'</td>
        <td>
        <input type="number" step="any" name="QUANTITE_APPROUVEE'.$i.'" id="QUANTITE_APPROUVEE'.$i.'" value="'.$intrant['QUANTITE'].'" >
        <input type="hidden" step="any" name="QUANTITE_DISPONIBLE'.$i.'" id="QUANTITE_DISPONIBLE'.$i.'" value="'.$intrant['QUANTITE_DISPONIBLE'].'" >
        <input type="hidden" step="any" name="DETAIL_ID'.$i.'" id="DETAIL_ID'.$i.'" value="'.$intrant['DETAIL_ID'].'" >
        </td>
        </tr>';
        $i++;				    
      }



    }
    echo $table_intrant.='</tbody></table><input type="hidden"  id="counter" value="'.$i.'" >
    <input type="hidden"  id="DEMANDE" value="'.$DEMANDE_ID.'" >' ;
  }


  public function valider_approuvation($value='')
  {
	# code...
   $type_action=intval($this->input->post('type_action'));
   $compteur=$this->input->post('compteur');
   $DEMANDE_ID=$this->input->post('DEMANDE_ID');


   $j=0;
   if ($type_action==1) {
		# code...
		// accuse de reception
     for ($i=0; $i < $compteur ; $i++) { 
		# code...
      $QUANTITE_RECU=$this->input->post('QUANTITE_COMFIRMER_RECU'.$i);
      $DETAIL_ID=$this->input->post('DETAIL_ID'.$i);
      $this->Modele->update('stock_demande_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_RECU'=>$QUANTITE_RECU));
      $j=1;

    }
    $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('STATUT_RECEPTION'=>1));

  }else{

   for ($i=0; $i < $compteur ; $i++) { 
		# code...
    $QUANTITE_APPROUVEE=$this->input->post('QUANTITE_APPROUVEE'.$i);
    $DETAIL_ID=$this->input->post('DETAIL_ID'.$i);
    $this->Modele->update('stock_demande_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_APPROUVEE'=>$QUANTITE_APPROUVEE));
    $j=1;

  }
  $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('APPROUVE'=>1));
}
echo $j;

}

public function upload_document($nom_file,$nom_champ,$DEMANDE_ID)
{
  # code...

  $rep_doc =FCPATH.'uploads/distribution/';
  $code=date("YmdHis");
  $fichier=basename($code."piece".$DEMANDE_ID);
  $file_extension = pathinfo($nom_champ, PATHINFO_EXTENSION);
  $file_extension = strtolower($file_extension);
  $valid_ext = array('png','jpeg','jpg');

      if(!is_dir($rep_doc)) //create the folder if it does not already exists   
      {
        mkdir($rep_doc,0777,TRUE);

      }  
     // if ($size<1000000 && in_array($file_extension,$valid_ext)) {
     	# code...

      move_uploaded_file($nom_file, $rep_doc.$fichier.".".$file_extension);
      $pathfile="uploads/distribution/".$fichier.".".$file_extension;
      return $pathfile;

     // }else{

     // 	return "file_non_suport";

     // }

    }








}

?>