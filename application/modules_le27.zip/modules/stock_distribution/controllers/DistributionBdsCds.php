<?php

/**
 * @author jules_ndihokubwayo@mediabox.bi
 *le 15-03-2021
 *ihm de processus de distribution des intrants des intrants camebu -bds
 *with @God help
 */
class DistributionBdsCds extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
	public function index($DEMANDE_ID=0)
	{
		# code...
    $id['DISTRIBUTION_ID']=NULL;
    $this->session->set_userdata($id);
    $sql_demande = "SELECT `DEMANDE_ID`,sd.`INTERVENANT_STRUCTURE_ID`,`DEMANDE_CODE`,iss.INTERVENANT_STRUCTURE_DESCR FROM `stock_demande` sd JOIN intervenants_structure iss ON sd.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE `DEMANDE_ID`=".$DEMANDE_ID;

    $demande=$this->Modele->getRequeteOne($sql_demande);
    if (empty($demande['INTERVENANT_STRUCTURE_ID'])) {
         # code...
      $demande['INTERVENANT_STRUCTURE_ID']=-1;
    }
    $sql = "SELECT im.INTRANT_MEDICAUX_ID,im.INTRANT_MEDICAUX_DESCR,im.INTRANT_MEDICAUX_CODE FROM `stock_demande_detail` sdd JOIN intrant_medicaux im ON sdd.`INTRANT_ID`=im.INTRANT_MEDICAUX_ID WHERE sdd.`DEMANDE_ID`=".$DEMANDE_ID ;
    $sql_bds_cds = "SELECT `BDS_ID` FROM `bds_cds` WHERE `CDS_ID`=".$demande['INTERVENANT_STRUCTURE_ID'];
       $bds_cds=$this->Modele->getRequeteOne($sql_bds_cds);//get BDS parent

       if (empty($demande['INTERVENANT_STRUCTURE_ID'])) {
        	# code...
         $demande['INTERVENANT_STRUCTURE_ID']=-1;
       }
       $sql2 = "SELECT `INTERVENANT_RH_ID`,concat(`NOM`,\" \",`PRENOM`) name FROM `intervenants_rh` WHERE `INTERVENANT_STRUCTURE_ID`=".$demande['INTERVENANT_STRUCTURE_ID']." ORDER BY name";

       $stock_demande_detail=$this->Modele->getRequete($sql);
       $intervenants_rh=$this->Modele->getRequete($sql2);

       $data =array(
        'title'=>'Distribution des intrants.<br> Demande '.$demande['DEMANDE_CODE'].'<br>Processus PNILP/DODS <br> '.$demande['INTERVENANT_STRUCTURE_DESCR'].'',
        'DEMANDE_ID'=>$DEMANDE_ID,
        'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID'],
        'INTERVENANT_STRUCTURE_ID_PARENT'=>$bds_cds['BDS_ID'],
        'stock_demande_detail'=>$stock_demande_detail,
        'intervenants_rh'=>$intervenants_rh
      );
       // echo "<pre>";
        //print_r($data);die();
       $this->load->view('DistributionBdsCds_View',$data);

     }
     public function liste_intrant_quantite($value=0)
     {
      $DEMANDE_ID=$this->input->post('DEMANDE_ID');
      $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
          $INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');//structure demandeur
          $INTERVENANT_STRUCTURE_ID_PARENT=$this->input->post('INTERVENANT_STRUCTURE_ID_PARENT');

          if (empty($INTERVENANT_STRUCTURE_ID_PARENT)) {
          	# code...
          	$INTERVENANT_STRUCTURE_ID_PARENT=-1;
          }
          if (empty($INTERVENANT_STRUCTURE_ID)) {
          	# code...
          	$INTERVENANT_STRUCTURE_ID=-1;
          }
          if (empty($INTRANT_MEDICAUX_ID)) {
          	# code...
          	$INTRANT_MEDICAUX_ID=-1;
          }

          
          $sql = "SELECT SUM(`QUANTITE_APPROUVEE_RESTANT`) QUANTITE_APPROUVEE FROM `stock_demande_detail` WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND DEMANDE_ID=".$DEMANDE_ID;
          $qte=$this->Modele->getRequeteOne($sql);

          $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
          $var_search=str_replace("'", "\'", $var_search);  
          $query_principal='SELECT sdi.`RECEPTION_INTRANT_ID`,`DETAIL_ID`,`INTRANT_ID`,`RECEPTION_CODE`,
          `QUANTITE_RESTANTE` QUANTITE_DISPONIBL,


          (SELECT iss.INTERVENANT_STRUCTURE_DESCR FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE rr.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` ) AS INTERVENANT_STRUCTURE_DESCR,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` r JOIN rc_reception c ON r.`RECEPTION_ID`=c.RECEPTION_ID WHERE r.`INTRANT_ID`=sdi.`INTRANT_ID` AND c.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=sdi.`RECEPTION_INTRANT_ID` ) NUMERO_LOT,

          (SELECT `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` r JOIN rc_reception c ON r.`RECEPTION_ID`=c.RECEPTION_ID WHERE r.`INTRANT_ID`=sdi.`INTRANT_ID` AND c.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=sdi.`RECEPTION_INTRANT_ID`) DATE_PEREMPTION 

          FROM `stock_distribution_intrant_detail` sdi JOIN stock_distribution sd ON sdi.`DISTRIBUTION_ID`=sd.DISTRIBUTION_ID  WHERE sd.INTERVENANT_STRUCTURE_ID='.$INTERVENANT_STRUCTURE_ID_PARENT.' AND `INTRANT_ID`='.$INTRANT_MEDICAUX_ID.' HAVING QUANTITE_RESTANTE>0';

          $group="";
          $critaire="";

          $limit='LIMIT 0,10';
          if($_POST['length'] != -1){
            $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
          }
          $order_by='';
          if($_POST['order']['0']['column']!=0){
            $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
          }

          $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';


          
          $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
          $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

          $fetch_intrants = $this->Modele->datatable($query_secondaire);
          $u=0;
          $data = array();

          $QUANTITE_STOCK_DISPO_TOTAL=0;
          foreach ($fetch_intrants as $row) {

           $u++;
           $sub_array = array();
           $sub_array[] =  $u;
           $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
           $sub_array[]=$row->NUMERO_LOT;
           $sub_array[]=$row->DATE_PEREMPTION;
           $sub_array[]=number_format($row->QUANTITE_DISPONIBL, 0, ' ', ' ');
           $comteur_id=0;
           $sub_array[]='<input type="number" step="any" name="QUANTITE_APPROUVE'.$u.'" id="QUANTITE_APPROUVE'.$u.'" class="form-control-sm" value="'.$qte['QUANTITE_APPROUVEE'].'" onchange="get_valeur('.$u.')" onkeyup="get_valeur('.$u.')">';
           $sub_array[]='<a href="#" onclick="valider('.$INTRANT_MEDICAUX_ID.','.$u.','.$row->QUANTITE_DISPONIBL.','.$row->DETAIL_ID.','.$qte['QUANTITE_APPROUVEE'].','.$comteur_id.','.$DEMANDE_ID.','.$row->RECEPTION_INTRANT_ID.')">Valider</a>';


           $data[] = $sub_array;

         }
         
         $output = array(
           "draw" => intval($_POST['draw']),
           "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
           "recordsFiltered" => $this->Modele->filtrer($query_filter),
           "data" => $data
         );
         echo json_encode($output);
       }

       public function valider($value='')
       {
	# code...
         $QUANTITE_DISPONIBLE=$this->input->post('QUANTITE_DISPONIBLE');
         $QUANTITE_APPROUVE=$this->input->post('QUANTITE_APPROUVE');
         $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
         $DETAIL_ID=$this->input->post('DETAIL_ID');
         $RECEPTION_INTRANT_ID=$this->input->post('RECEPTION_INTRANT_ID');
         $DEMANDE_ID=$this->input->post('DEMANDE_ID');
         $INTERVENANT_RH_ID=$this->input->post('INTERVENANT_RH_ID');
         $COMMENT=$this->input->post('COMMENT');
         $INTERVENANT_STRUCTURE_ID_PARENT=$this->input->post('INTERVENANT_STRUCTURE_ID_PARENT');
         $sqcodel  = 'SELECT rc_reception.RECEPTION_CODE FROM `rc_reception_intrant_detail` JOIN rc_reception ON rc_reception_intrant_detail.RECEPTION_ID=rc_reception.RECEPTION_ID WHERE `RECEPTION_INTRANT_ID`='.$RECEPTION_INTRANT_ID;
         $code_rec=$this->Modele->getRequeteOne($sqcodel);
         $demande=$this->Modele->getOne('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID));
    $came=$this->Modele->getRequeteOne('SELECT `INTERVENANT_STRUCTURE_ID`,EMAIL FROM `intervenants_structure` WHERE `INTERVENANT_STRUCTURE_CODE` LIKE "CAMEBU"');//recuperation email camebu
    $i=0;

    if ($demande['CODE_DEMANDE_SENS_ID']==2) {
		# code...
     if (empty($this->session->userdata('DISTRIBUTION_ID'))) {
		# code..2
		#echo substr('abcdef', 1);     // bcdef
      $PIECE_JUSTIFICATIF="";

      if (!empty($_FILES['PIECE_JUSTIFICATIF']['tmp_name'])) {
      # code...
        $PIECE_JUSTIFICATIF=$this->upload_document($_FILES['PIECE_JUSTIFICATIF']['tmp_name'],$_FILES['PIECE_JUSTIFICATIF']['name'],$DEMANDE_ID);
      }
      

      $stock_distribution = array(
        'DISTRIBUTION_DATE' => date('Y-m-d'),
        'CODE_SENS_ID' => 2,
        'DEMANDE_ID' => $DEMANDE_ID,
        'USER_ID' =>$this->session->userdata('iccm_USER_ID') ,
        'INTERVENANT_RH_ID' =>$demande['USER_DEMANDEUR_ID'] ,
        'COMMENT'=>$COMMENT,
        'PIECE_JUSTIFICATIF'=>$PIECE_JUSTIFICATIF,
        'INTERVENANT_STRUCTURE_ID' =>$demande['INTERVENANT_STRUCTURE_ID'],
        'INTERVENANT_STRUCTURE_DONNATEUR'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID'),
      );
      $DISTRIBUTION_ID=$this->Modele->insert_last_id('stock_distribution',$stock_distribution);
      $DISTRIBUTION_CODE="DSTR-".substr("".date('Ymd')."", 2)."-".$DISTRIBUTION_ID;
      $this->Modele->update('stock_distribution',array('DISTRIBUTION_ID'=>$DISTRIBUTION_ID),array('DISTRIBUTION_CODE'=>$DISTRIBUTION_CODE));
      $id['DISTRIBUTION_ID']=$DISTRIBUTION_ID;
      $this->session->set_userdata($id);
      $i=1;
      $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('STATUT_DISTRIBUTION'=>1));
    }else{
     $DISTRIBUTION_ID=$this->session->userdata('DISTRIBUTION_ID');
   }


   /*****************************inserttion stock_distribution_intrant_detail*******************************/
    //eviter d'ajouter un mm intrant de mm lot ,mm reception et mm distribution
   $array_for_test=array(
    'DISTRIBUTION_ID' => $DISTRIBUTION_ID,
    'RECEPTION_CODE' => $code_rec['RECEPTION_CODE'],
    'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
    'INTRANT_ID' => $INTRANT_MEDICAUX_ID,

  );
   $quantite_approuve_existant=0;
   $array_for_test_sdid=$this->Modele->getOne('stock_distribution_intrant_detail',$array_for_test);
   
   if (intval($array_for_test_sdid['INTRANT_ID'])>0) {
	 	# code...
     $quantite_approuve_existant=$array_for_test_sdid['QUANTITE_RESTANTE']+$QUANTITE_APPROUVE;
     $this->Modele->update('stock_distribution_intrant_detail',$array_for_test,array(
      'QUANTITE_RESTANTE'=>$quantite_approuve_existant
      
    ));


   }else{
     
    $stock_distribution_intrant_detail = array(
      'DISTRIBUTION_ID' => $DISTRIBUTION_ID,
      'RECEPTION_CODE' => $code_rec['RECEPTION_CODE'],
      'RECEPTION_INTRANT_ID'=>$RECEPTION_INTRANT_ID,
      'INTRANT_ID' => $INTRANT_MEDICAUX_ID,
      'QUANTITE' => $QUANTITE_APPROUVE,
      'QUANTITE_RESTANTE'=>$QUANTITE_APPROUVE
    );        
    $this->Modele->create('stock_distribution_intrant_detail',$stock_distribution_intrant_detail);
  }
  
  $this->Modele->update('stock_distribution_intrant_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_RESTANTE'=>($QUANTITE_DISPONIBLE-$QUANTITE_APPROUVE)));

  
  /***************mis a jour de la stock  intervenant donnateur*****************************/
  
  $INTERVENANT_STRUCTURE_ID=$INTERVENANT_STRUCTURE_ID_PARENT;
  $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID));
  $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']-$QUANTITE_APPROUVE;
      $this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));//mis a jour de la stock  dans structure intervenant


      /*******************************************************************************************/
      /******************mis a jour pour structure demandeur*********************************************/
      $quantite_precedent_sock_intervenant=$this->Modele->getOne('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID']));
      if (empty($quantite_precedent_sock_intervenant['QUANTITE'])) {
    	# code...
       $quantite_precedent_sock_intervenant['QUANTITE']=0;
     }
     $QUANTITE_STOCK_INTERVENANT=$quantite_precedent_sock_intervenant['QUANTITE']+$QUANTITE_APPROUVE;

     if ($quantite_precedent_sock_intervenant['QUANTITE']>=0 && !empty($quantite_precedent_sock_intervenant['INTRANT_ID'])) {
			   	# code...
       $this->Modele->update('stock_intervenat',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'INTERVENANT_STRUCTURE_ID'=>$demande['INTERVENANT_STRUCTURE_ID']),array('QUANTITE'=>$QUANTITE_STOCK_INTERVENANT,'DATE_LAST_UPDATE'=>date('Y-m-d H:i:s')));
     }else{
       $stock_intervenat=array('INTERVENANT_STRUCTURE_ID' => $demande['INTERVENANT_STRUCTURE_ID'],
        'INTRANT_ID' => $INTRANT_MEDICAUX_ID,
        'QUANTITE' =>$QUANTITE_STOCK_INTERVENANT ,
        'DATE_LAST_UPDATE' =>date('Y-m-d H:i:s'),
      );
       $this->Modele->create('stock_intervenat',$stock_intervenat);
     }
     /*******************************************************************************************************/
     $stock_demande_detail=$this->Modele->getOne('stock_demande_detail',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'DEMANDE_ID'=>$DEMANDE_ID));
     $QUANTITE_APPROUVEE_RESTANT=$stock_demande_detail['QUANTITE_APPROUVEE_RESTANT']-$QUANTITE_APPROUVE;
     $this->Modele->update('stock_demande_detail',array('INTRANT_ID'=>$INTRANT_MEDICAUX_ID,'DEMANDE_ID'=>$DEMANDE_ID),array('QUANTITE_APPROUVEE_RESTANT'=>$QUANTITE_APPROUVEE_RESTANT));
     /******************************************send mail***********************************************/
     
     $sql_sm = "SELECT iss.INTERVENANT_STRUCTURE_ID PTF_ID,iss.INTERVENANT_STRUCTURE_DESCR PTF_NOM,`RECEPTION_ID` id,iss.EMAIL,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND `RECEPTION_ID`=id AND RECEPTION_INTRANT_ID=".$RECEPTION_INTRANT_ID." LIMIT 1) NUMERO_LOT FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE RECEPTION_CODE LIKE '".$code_rec['RECEPTION_CODE']."'";
     $info_reception_ptf=$this->Modele->getRequeteOne($sql_sm);

     $intrant=$this->Modele->getOne('intrant_medicaux',array('INTRANT_MEDICAUX_ID'=>$INTRANT_MEDICAUX_ID));
     $recepteur_intrant=$this->Modele->getOne('intervenants_structure',array('INTERVENANT_STRUCTURE_ID'=>$INTERVENANT_STRUCTURE_ID_PARENT));

     $message = "Cher ".$info_reception_ptf['PTF_NOM'].", Une quantité <b>".$QUANTITE_APPROUVE."</b> de l'intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." a été distribuée(s) à ".$recepteur_intrant['INTERVENANT_STRUCTURE_DESCR'];
     $subjet = "Distribution d'un intrant ".$intrant['INTRANT_MEDICAUX_DESCR']." du lot ".$info_reception_ptf['NUMERO_LOT'];
	$emailTo = $info_reception_ptf['EMAIL'];//email du ptf
  $cc_emails=array();
    $cc_emails[]=$recepteur_intrant['EMAIL'];//email du cds demandeur

    $cc_emails[]=$came['EMAIL'];//email camebu

    $array_notifications = array(
     'MESSAGE'=>$message,
     'PTF_ID'=>$info_reception_ptf['PTF_ID'],
     'EMAIL_NOTIFIE'=>$info_reception_ptf['EMAIL'],
     'INTRANT_ID'=>$INTRANT_MEDICAUX_ID,
								//'INTRANT_ID'=>$QUANTITE_APPROUVE,
     'IS_DISTRIBUTION'=>1
   );
    $this->Modele->insert_last_id('sms_mouvement_stock',$array_notifications);
    $this->notifications->send_mail($emailTo, $subjet, $cc_emails, $message, array());    
    
    $i=2;

  }
  
  
  echo $i;
}
public function getstock_total($value='')
{
	# code...
	$INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
	$INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
  $INTERVENANT_STRUCTURE_ID_PARENT=$this->input->post('INTERVENANT_STRUCTURE_ID_PARENT');
  if (empty($INTERVENANT_STRUCTURE_ID)) {
          	# code...
   $INTERVENANT_STRUCTURE_ID=-1;
 }
 if (empty($INTERVENANT_STRUCTURE_ID_PARENT)) {
          	# code...
   $INTERVENANT_STRUCTURE_ID_PARENT=-1;
 }
 if (empty($INTRANT_MEDICAUX_ID)) {
          	# code...
   $INTRANT_MEDICAUX_ID=-1;
 }
 $sql = "SELECT `QUANTITE` QUANTITE_DISPONIBL_TOTAL FROM `stock_intervenat` WHERE `INTERVENANT_STRUCTURE_ID`=".$INTERVENANT_STRUCTURE_ID_PARENT." AND `INTRANT_ID`=".$INTRANT_MEDICAUX_ID;
 $ST=$this->Modele->getRequeteOne($sql);


 $sql2 = "SELECT iss.INTERVENANT_STRUCTURE_DESCR,`QUANTITE` FROM `stock_intervenat`  si JOIN intervenants_structure iss ON si.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID  WHERE `INTRANT_ID`=".$INTRANT_MEDICAUX_ID." AND si.`INTERVENANT_STRUCTURE_ID`=".$INTERVENANT_STRUCTURE_ID;
 $ST_INTERVENANT=$this->Modele->getRequeteOne($sql2);

 echo "Quantité totale disponible <strong>".number_format($ST['QUANTITE_DISPONIBL_TOTAL'], 0, ' ', ' ')."</strong><br>Quantité totale disponible au ".$ST_INTERVENANT['INTERVENANT_STRUCTURE_DESCR']." <strong>".number_format($ST_INTERVENANT['QUANTITE'], 0, ' ', ' ')."</strong>";





}

public function historique($value=0)
{
  $INTERVENANT_STRUCTURE_ID_PARENT=$this->input->post('INTERVENANT_STRUCTURE_ID_PARENT');
  $INTRANT_MEDICAUX_ID=$this->input->post('INTRANT_MEDICAUX_ID');
  if (empty($INTERVENANT_STRUCTURE_ID_PARENT)) {
          	# code...
   $INTERVENANT_STRUCTURE_ID_PARENT=-1;
 }
 if (empty($INTRANT_MEDICAUX_ID)) {
          	# code...
   $INTRANT_MEDICAUX_ID=-1;
 }

 $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
 $var_search=str_replace("'", "\'", $var_search);  
 $query_principal='SELECT sdi.`RECEPTION_INTRANT_ID`,`DETAIL_ID`,`INTRANT_ID`,`RECEPTION_CODE`,
 `QUANTITE_RESTANTE` QUANTITERESTANTE,`QUANTITE` QUANTITERECU,(QUANTITE-QUANTITE_RESTANTE) QUANTITE_DEJA_DISTRIBUE_NIVEAU_BDS,


 (SELECT iss.INTERVENANT_STRUCTURE_DESCR FROM `rc_reception` rr JOIN intervenants_structure iss ON rr.`PTF_ID`=iss.INTERVENANT_STRUCTURE_ID WHERE rr.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` ) AS INTERVENANT_STRUCTURE_DESCR,(SELECT `NUMERO_LOT` FROM `rc_reception_intrant_detail` r JOIN rc_reception c ON r.`RECEPTION_ID`=c.RECEPTION_ID WHERE r.`INTRANT_ID`=sdi.`INTRANT_ID` AND c.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=sdi.`RECEPTION_INTRANT_ID` ) NUMERO_LOT,

 (SELECT `DATE_PEREMPTION` FROM `rc_reception_intrant_detail` r JOIN rc_reception c ON r.`RECEPTION_ID`=c.RECEPTION_ID WHERE r.`INTRANT_ID`=sdi.`INTRANT_ID` AND c.RECEPTION_CODE LIKE sdi.`RECEPTION_CODE` AND r.RECEPTION_INTRANT_ID=sdi.`RECEPTION_INTRANT_ID`) DATE_PEREMPTION 

 FROM `stock_distribution_intrant_detail` sdi JOIN stock_distribution sd ON sdi.`DISTRIBUTION_ID`=sd.DISTRIBUTION_ID  WHERE sd.INTERVENANT_STRUCTURE_ID='.$INTERVENANT_STRUCTURE_ID_PARENT.' AND `INTRANT_ID`='.$INTRANT_MEDICAUX_ID;

 $group="";
 $critaire="";

 $limit='LIMIT 0,10';
 if($_POST['length'] != -1){
  $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
}
$order_by='';
if($_POST['order']['0']['column']!=0){
  $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
}

$search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%')") : '';



$query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
$query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;

$fetch_intrants = $this->Modele->datatable($query_secondaire);
$u=0;
$data = array();

foreach ($fetch_intrants as $row) {

 $u++;
 $sub_array = array();
 $sub_array[] =  $u;
 $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR;
 $sub_array[]=$row->NUMERO_LOT;
 $sub_array[]=number_format($row->QUANTITERECU, 0, ' ', ' ');
 $sub_array[]=number_format($row->QUANTITERESTANTE, 0, ' ', ' ');
 $sub_array[]=number_format($row->QUANTITE_DEJA_DISTRIBUE_NIVEAU_BDS, 0, ' ', ' ');
 $data[] = $sub_array;

}

$output = array(
 "draw" => intval($_POST['draw']),
 "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
 "recordsFiltered" => $this->Modele->filtrer($query_filter),
 "data" => $data
);
echo json_encode($output);
}

public function mes_demande($value='')
{
	# code...
	$data=array(
    'INTERVENANT_STRUCTURE_ID'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')
  );
	$this->load->view('Demande_Cds_View',$data);
}
//demande des cds
public function demandes_des_cds($value=0)
{
  $INTERVENANT_STRUCTURE_ID=$this->input->post('INTERVENANT_STRUCTURE_ID');
  $type_demande=intval($this->input->post('type_demande'));
  $caractere_demande=intval($this->input->post('caractere_demande'));
  
  if (empty($INTERVENANT_STRUCTURE_ID)) {
          	# code...
   $INTERVENANT_STRUCTURE_ID=-1;
 }

 $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
 $var_search=str_replace("'", "\'", $var_search);  
 $query_principal='SELECT sd.INTERVENANT_STRUCTURE_ID,DEMANDE_REFUSE,PATH_PV_DEMANDE,`DEMANDE_ID`,STATUT_DISTRIBUTION,APPROUVE,DATE_INSERTION,`DEMANDE_CODE`,concat(ih.NOM," ",ih.PRENOM) nom,iss.INTERVENANT_STRUCTURE_DESCR,STATUT_RECEPTION,(CASE WHEN APPROUVE=0 THEN "Attente d\'approbation" ELSE "Approuvée" END) statut_approbation FROM `stock_demande` sd JOIN intervenants_structure iss ON sd.`INTERVENANT_STRUCTURE_ID`=iss.INTERVENANT_STRUCTURE_ID JOIN intervenants_rh ih ON sd.`USER_DEMANDEUR_ID`=ih.INTERVENANT_RH_ID';

 $group="";
 $critaire="";
 if ($type_demande==2) {
          	# code...
          	//Les demandes des cds
   if ($caractere_demande==3) {
          		# code...
          		//en cours
          		$critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID` IN (SELECT `CDS_ID` FROM `bds_cds` WHERE `BDS_ID`='.$INTERVENANT_STRUCTURE_ID.') AND APPROUVE=0'; //non approuver
          	}elseif ($caractere_demande==5) {
              # code...
              //en cours
              $critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID` IN (SELECT `CDS_ID` FROM `bds_cds` WHERE `BDS_ID`='.$INTERVENANT_STRUCTURE_ID.') AND APPROUVE=1 AND STATUT_DISTRIBUTION = 1';
            }else{
          		//approuver
          		$critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID` IN (SELECT `CDS_ID` FROM `bds_cds` WHERE `BDS_ID`='.$INTERVENANT_STRUCTURE_ID.') AND APPROUVE=1 AND STATUT_DISTRIBUTION = 0';//1
          	}
          	
          }else{
          	//Les demandes du bds connecte
          	if ($caractere_demande==2 || $caractere_demande=="2") {
          		# code...
          		$critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID.' AND STATUT_DISTRIBUTION=1';
          	}else{
               $critaire='WHERE sd.`INTERVENANT_STRUCTURE_ID`='.$INTERVENANT_STRUCTURE_ID.' AND STATUT_DISTRIBUTION=0';//1
             }
           }

           $limit='LIMIT 0,10';
           if($_POST['length'] != -1){
            $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
          }
          $order_by='';
          if($_POST['order']['0']['column']!=0){
            $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY INTERVENANT_STRUCTURE_DESCR DESC';
          }

          $search = !empty($_POST['search']['value']) ? (" AND (INTERVENANT_STRUCTURE_DESCR LIKE '%$var_search%' OR concat(ih.NOM,' ',ih.PRENOM) LIKE '%$var_search%' OR DEMANDE_CODE LIKE '%$var_search%')") : '';


          
          $query_secondaire=$query_principal.'  '.$critaire.' '.$search.' '.$group.' '.$order_by.'   '.$limit;
          $query_filter=$query_principal.'  '.$critaire.' '.$search.' '.$group;
    ///echo $query_secondaire."_".$caractere_demande."_".$type_demande;
          $fetch_intrants = $this->Modele->datatable($query_secondaire);
          $u=0;
          $data = array();
          
          foreach ($fetch_intrants as $row) {
            $det_intrants=$this->Modele->getRequete("
             SELECT
             med.INTRANT_MEDICAUX_DESCR,
             det.QUANTITE,
             det.QUANTITE_APPROUVEE
             FROM
             stock_demande_detail det
             JOIN intrant_medicaux med ON
             med.INTRANT_MEDICAUX_ID = det.INTRANT_ID
             WHERE
             det.DEMANDE_ID = ".$row->DEMANDE_ID.""
           );

            $table_intrant='
            <table class="table table-sm table-bordered">
            <thead>
            <tr>
            <th>Intrant</th>
            <th>Qte.demandée</th>
            <th>Qte.approuvée</th>
            
            </tr>
            </thead>
            <tbody>';
            foreach ($det_intrants as $intrant) {
             if ($row->APPROUVE==0) {
               # code...
              $intrant['QUANTITE_APPROUVEE']="-";
             }
             $table_intrant.='<tr>
             <td>'.$intrant['INTRANT_MEDICAUX_DESCR'].'</td>
             <td><center>'.$intrant['QUANTITE'].'</center></td>
             <td><center>'.$intrant['QUANTITE_APPROUVEE'].'</center></td>
             </tr>';
             
           }

           $table_intrant.='</tbody>
           </table>
           ' ;
           $u++;
           $sub_array = array();
           $sub_array[] =  $u;
           //$sub_array[]=$row->DEMANDE_CODE;
           $sub_array[]=$row->INTERVENANT_STRUCTURE_DESCR."<br>".$row->nom;
           $sub_array[]=$table_intrant;
           if ($row->STATUT_DISTRIBUTION==1) {
             # code...
            $sub_array[]="Servie";
           }else if ($row->DEMANDE_REFUSE==1) {
             # code...
            $sub_array[]="Refusée";
           }


           else{
           $sub_array[]=$row->statut_approbation;
         }
         if (!empty($row->PATH_PV_DEMANDE)) {
           # code...
           $sub_array[]='<a href="'.base_url('uploads/pv_demande/'.$row->PATH_PV_DEMANDE).'" target="_blank"><span class="fa fa-file"></span></a>';
         }else{
           $sub_array[]="";
         }
         

           $sub_array[]=date('d-m-Y',strtotime($row->DATE_INSERTION));

           $opt='<div class="dropdown" style="color:#fff;">
           <a class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown">
           <i class="fa fa-cog"></i> Options<span class="caret">
           </span></a> 
           <ul class="dropdown-menu dropdown-menu-left">';
           //  if ($type_demande==2 && $row->APPROUVE==1) {
           //  	# code...
           //  	// si demande des cds approuver
           
           //  $opt.='<li class="dropdown-item"><a href="'.base_url('stock_distribution/DistributionBdsCds/index/'.$row->DEMANDE_ID).'">Servir</a></li>';
           // }
           if ($type_demande==1 && $row->STATUT_DISTRIBUTION==1 && $row->STATUT_RECEPTION==0) {
           	//demande du bds deja distribue
            $opt.='<li class="dropdown-item"><a href="#" onclick="get_demande_for_ar('.$row->DEMANDE_ID.',1)">Accusé de réception</a></li>';
          }
          if ($type_demande==2 && $row->APPROUVE==0) {
           	//demandes des cds a aprouver
           $opt.='<li class="dropdown-item"><a href="#" onclick="get_demande_for_ar('.$row->DEMANDE_ID.',2)">Approbation</a></li>';

         }
         if ($row->APPROUVE==1 && $type_demande==2) {
              # code...
          if ($caractere_demande!=5){
            $opt.='<li class="dropdown-item"><a href="'.base_url('stock_distribution/DistributionBdsCds/index/'.$row->DEMANDE_ID).'">Servir</a></li>';
          }
          
              // $opt.='<li class="dropdown-item"><a href="'.base_url('stock_distribution/PV_Demande_Approuve/index/'.$row->DEMANDE_ID).'">PV</a></li>';
        }
        if ($row->APPROUVE==0) {
             # code...
            if ($row->INTERVENANT_STRUCTURE_ID==$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')) {
              # code...
            
            $opt.='<li class="dropdown-item"><a href="'.base_url('demande/Demande/update_demande_view/'.$row->DEMANDE_ID).'">Modifier</a></li>';
            $opt.="<li class='dropdown-item'>
            <a href='#' data-toggle='modal' data-target='#mydelete".$row->DEMANDE_ID."'>
            <label class='text-danger'>Supprimer</label>
            </a></li>";
          }
        }
        $opt.="</ul>
        <div class='modal fade' id='mydelete".$row->DEMANDE_ID."'>
        <div class='modal-dialog'>
        <div class='modal-content'>

        <div class='modal-body'>
        <center>
        <h5 class='text-info'>Voulez-vous supprimer cette demande ?
        </h5>
        </center>
        </div>

        <div class='modal-footer'>
        <a class='btn btn-outline-danger btn-md' href='" . base_url('demande/Demande/delete_demande/').$row->DEMANDE_ID. "'>Supprimer
        </a>
        <button class='btn btn-outline-primary btn-md' data-dismiss='modal'>
        Quitter
        </button>
        </div>

        </div>
        </div>
        </div>";
        if ($this->session->userdata('iccm_PROFIL_CODE')=="BDS") {
          $sub_array[]=$opt;
        }else{
          $sub_array[]='';
        }
        $data[] = $sub_array;

      }
      
      $output = array(
       "draw" => intval($_POST['draw']),
       "recordsTotal" =>$this->Modele->all_data($query_principal.' '.$group),
       "recordsFiltered" => $this->Modele->filtrer($query_filter),
       "data" => $data
     );
      echo json_encode($output);
    }
//detail de demande
    public function get_demande_detail($value='')
    {
	# code...
     $DEMANDE_ID=$this->input->post("DEMANDE_ID");
     $sql = "SELECT b.BDS_ID INTERVENANT_STRUCTURE_ID_PARENT FROM `stock_demande` s JOIN bds_cds b ON s.`INTERVENANT_STRUCTURE_ID`=b.CDS_ID WHERE s.`DEMANDE_ID`=".$DEMANDE_ID;
     $intervenant_parent=$this->Modele->getRequeteOne($sql);

     $TEST_VALUE=intval($this->input->post("TEST_VALUE"));

     if ($TEST_VALUE==1) {
		# code...
		//AR;Accusé de réception
       $table_intrant='
       <table class="table table-sm table-bordered">
       <thead>
       <tr>
       <th>Intrant</th>
       <th>Qte.demandée</th>
       <th>Qte.approuvée</th>
       <th>Qte.reçue</th>
       <th>Qte.comfirmée reçue</th>
       
       </tr>
       </thead>
       <tbody>';

       $i=0;
       $det_intrants=$this->Modele->getRequete("
         SELECT
         med.INTRANT_MEDICAUX_DESCR,
         det.QUANTITE,
         det.DETAIL_ID,
         det.QUANTITE_APPROUVEE,
         (det.QUANTITE-det.QUANTITE_APPROUVEE_RESTANT) QUANTITE_RECU
         

         FROM
         stock_demande_detail det
         JOIN intrant_medicaux med ON
         med.INTRANT_MEDICAUX_ID = det.INTRANT_ID
         WHERE
         det.DEMANDE_ID=".$DEMANDE_ID.""
       );
       $i=0;
       foreach ($det_intrants as $intrant) {

         $table_intrant.='<tr>
         <td>'.$intrant['INTRANT_MEDICAUX_DESCR'].'</td>
         <td>'.$intrant['QUANTITE'].'</td>
         <td >'.$intrant['QUANTITE_APPROUVEE'].'</td>
         <td >'.$intrant['QUANTITE_RECU'].'</td>
         <td>
         <input type="number" step="any" name="QUANTITE_RECU'.$i.'" id="QUANTITE_RECU'.$i.'" value="'.$intrant['QUANTITE_RECU'].'" >
         <input type="hidden" step="any" name="QUANTITE_COMFIRMER_RECU'.$i.'" id="QUANTITE_COMFIRMER_RECU'.$i.'" value="'.$intrant['QUANTITE_RECU'].'" >

         <input type="hidden" step="any" name="DETAIL_ID'.$i.'" id="DETAIL_ID'.$i.'" value="'.$intrant['DETAIL_ID'].'" >
         </td>
         </tr>';
         $i++;				    
       }



     }else{
		//approbation


       $table_intrant='
       <table class="table table-sm table-bordered">
       <thead>
       <tr>
       <th>Intrant</th>
       <th>Qte.demandée</th>
       <th>Qte.disponible</th>
       <th>Qte.approuvée</th>

       
       </tr>
       </thead>
       <tbody>';
       $det_intrants=$this->Modele->getRequete("
         SELECT
         med.INTRANT_MEDICAUX_DESCR,
         det.QUANTITE,
         det.DETAIL_ID,
         det.QUANTITE_APPROUVEE,
         (SELECT sum(`QUANTITE`) FROM `stock_intervenat` WHERE `INTRANT_ID`=det.INTRANT_ID AND `INTERVENANT_STRUCTURE_ID`=".$intervenant_parent['INTERVENANT_STRUCTURE_ID_PARENT'].") QUANTITE_DISPONIBLE

         FROM
         stock_demande_detail det
         JOIN intrant_medicaux med ON
         med.INTRANT_MEDICAUX_ID = det.INTRANT_ID
         WHERE
         det.DEMANDE_ID = ".$DEMANDE_ID.""
       );


       $i=0;
       foreach ($det_intrants as $intrant) {
         $clas="text-danger";
         if ($intrant['QUANTITE']<$intrant['QUANTITE_DISPONIBLE']) {
				        		# code...
          $clas="text-info";

        }
        $table_intrant.='<tr>
        <td>'.$intrant['INTRANT_MEDICAUX_DESCR'].'</td>
        <td>'.$intrant['QUANTITE'].'</td>
        <td class="'.$clas.'">'.$intrant['QUANTITE_DISPONIBLE'].'</td>
        <td>
        <input type="number" step="any" name="QUANTITE_APPROUVEE'.$i.'" id="QUANTITE_APPROUVEE'.$i.'" value="'.$intrant['QUANTITE'].'" >
        <input type="hidden" step="any" name="QUANTITE_DISPONIBLE'.$i.'" id="QUANTITE_DISPONIBLE'.$i.'" value="'.$intrant['QUANTITE_DISPONIBLE'].'" >
        <input type="hidden" step="any" name="DETAIL_ID'.$i.'" id="DETAIL_ID'.$i.'" value="'.$intrant['DETAIL_ID'].'" >
        </td>
        </tr>';
        $i++;				    
      }


      
    }
    echo $table_intrant.='</tbody></table><input type="hidden"  id="counter" value="'.$i.'" >
    <input type="hidden"  id="DEMANDE" value="'.$DEMANDE_ID.'" >' ;
  }

//approuvation des domandes des cds
  public function valider_approuvation($value='')
  {
	# code...
   $type_action=intval($this->input->post('type_action'));
   $compteur=$this->input->post('compteur');
   $DEMANDE_ID=$this->input->post('DEMANDE_ID');


   $j=0;
   if ($type_action==1) {
		# code...
		// accuse de reception
     for ($i=0; $i < $compteur ; $i++) { 
		# code...
      $QUANTITE_RECU=$this->input->post('QUANTITE_COMFIRMER_RECU'.$i);
      $DETAIL_ID=$this->input->post('DETAIL_ID'.$i);
      $this->Modele->update('stock_demande_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_RECU'=>$QUANTITE_RECU));
      $j=1;

    }
    $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('STATUT_RECEPTION'=>1));

  }else{

   for ($i=0; $i < $compteur ; $i++) { 
		# code...
    $QUANTITE_APPROUVEE=$this->input->post('QUANTITE_APPROUVEE'.$i);
    $DETAIL_ID=$this->input->post('DETAIL_ID'.$i);
    $this->Modele->update('stock_demande_detail',array('DETAIL_ID'=>$DETAIL_ID),array('QUANTITE_APPROUVEE'=>$QUANTITE_APPROUVEE,'QUANTITE_APPROUVEE_RESTANT'=>$QUANTITE_APPROUVEE));
    $j=1;

  }
  $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('APPROUVE'=>1));
  $structure=$this->Modele->getRequeteOne('SELECT dem.INTERVENANT_STRUCTURE_ID FROM stock_demande dem WHERE dem.DEMANDE_ID='.$DEMANDE_ID.'');
  $email_to=$this->Modele->getOne('intervenants_structure',['INTERVENANT_STRUCTURE_ID'=>$structure['INTERVENANT_STRUCTURE_ID']]);
  $email_ccc=$this->Modele->getOne('intervenants_structure',['INTERVENANT_STRUCTURE_ID'=>$this->session->userdata('iccm_INTERVENANT_STRUCTURE_ID')]);
  $camebu=$this->Modele->getOne('intervenants_structure',['INTERVENANT_STRUCTURE_CODE'=>'CAMEBU']); 
  $email_cc[]=$email_ccc['EMAIL'];
  $email_cc[]=$camebu['EMAIL'];

  $this->pv_attachement($DEMANDE_ID,$email_to['EMAIL'],$email_cc,$email_ccc['INTERVENANT_STRUCTURE_DESCR']);
}

echo $j;

}
//upload des documents 
public function upload_document($nom_file,$nom_champ,$DEMANDE_ID)
{
  # code...

  $rep_doc =FCPATH.'uploads/distribution/';
  $code=date("YmdHis");
  $fichier=basename($code."piece".$DEMANDE_ID);
  $file_extension = pathinfo($nom_champ, PATHINFO_EXTENSION);
  $file_extension = strtolower($file_extension);
  $valid_ext = array('png','jpeg','jpg');

      if(!is_dir($rep_doc)) //create the folder if it does not already exists   
      {
        mkdir($rep_doc,0777,TRUE);
        
      }  
     // if ($size<1000000 && in_array($file_extension,$valid_ext)) {
     	# code...

      move_uploaded_file($nom_file, $rep_doc.$fichier.".".$file_extension);
      $pathfile="uploads/distribution/".$fichier.".".$file_extension;
      return $pathfile;

     // }else{

     // 	return "file_non_suport";

     // }


    }
    public function pv_attachement($DEMANDE_ID,$email_to,$email_cc,$INTERVENANT_STRUCTURE_DESCR)
    {
      
      include 'pdfinclude/fpdf/mc_table.php';
      include 'pdfinclude/fpdf/pdf_config.php';
      $pdf = new PDF_CONFIG('P','mm','A4');
      $pdf->addPage();





      $lien_sauvegarder = FCPATH.'uploads/pv_demande/';

      if(!is_dir($lien_sauvegarder)){
        mkdir($lien_sauvegarder,0777,TRUE); 
      }


    //REQUETES

    // $demande=$this->Modele->getOne("stock_demande",array('DEMANDE_ID'=>$DEMANDE_ID,'APPROUVE'=>1));

      $demandeur=$this->Modele->getRequeteOne("SELECT stock_demande.DEMANDE_CODE,stock_demande.APPROUVE,stock_demande.INTERVENANT_STRUCTURE_ID,stock_demande.CODE_DEMANDE_SENS_ID,stock_demande.DATE_INSERTION,intv.INTERVENANT_STRUCTURE_DESCR FROM `stock_demande` JOIN intervenants_structure intv ON intv.INTERVENANT_STRUCTURE_ID=stock_demande.INTERVENANT_STRUCTURE_ID WHERE stock_demande.DEMANDE_ID=".$DEMANDE_ID." AND APPROUVE=1");

      $tableau_intrants=$this->Modele->getRequete('SELECT stde.QUANTITE, stde.QUANTITE_APPROUVEE,intra.INTRANT_MEDICAUX_DESCR FROM `stock_demande` JOIN stock_demande_detail stde ON stde.DEMANDE_ID=stock_demande.DEMANDE_ID  JOIN intrant_medicaux intra ON intra.INTRANT_MEDICAUX_ID=stde.INTRANT_ID  WHERE stock_demande.DEMANDE_ID='.$DEMANDE_ID.' AND stock_demande.APPROUVE=1');


      $DATE_APPROBATION=date("d-m-Y",strtotime($demandeur['DATE_INSERTION']));


      $pdf->Ln(18);
      $pdf->SetFont('Arial','BU',12);
      $pdf->Cell(150,5,utf8_decode('Procès-verbal d\' approbation des intrants'),0,1,'R');
      $pdf->SetFont('Arial','',12);

      $pdf->Ln(14);

      $pdf->MultiCell(189,5,utf8_decode('Cher '.$demandeur['INTERVENANT_STRUCTURE_DESCR'].' vous avez été approuvé à la demande que vous avez fait en date du '.$DATE_APPROBATION.'.'));
      $pdf->Ln();
      $pdf->MultiCell(189,5,utf8_decode('Code:'.$demandeur['DEMANDE_CODE']));
      $pdf->Ln(10);

      $pdf->MultiCell(189,5,utf8_decode('Intrants demandés'));
      $pdf->Ln();

      $pdf->SetWidths(array('9','92','37','45'));
      $pdf->SetLineHeight(5);
      $pdf->SetFont('Arial','B',12);
      $pdf->Row(array(utf8_decode('No.'),utf8_decode('Nom du produit'),utf8_decode('Qté demandées'),utf8_decode('Qté approuvées')),'C');
      $pdf->SetFont('Arial','',12);

      $u=0;
      foreach ($tableau_intrants as $row) 
      {
        $u++;
        $pdf->Row(array(utf8_decode($u),utf8_decode($row['INTRANT_MEDICAUX_DESCR']),utf8_decode($row['QUANTITE']),utf8_decode(number_format($row['QUANTITE_APPROUVEE'],0,' ',' '))));
      }
      $pdf->SetFont('Arial','',10);
      $pdf->Ln();

      $pdf->MultiCell(185,5,utf8_decode('Fait à ........., le '.date('d/m/Y')),0,'R');
    //$pdf->output('I');
      $nom_file_pdf="pv_de_demande_cds_dmd".$DEMANDE_ID.".pdf";
      $pdf->Output($lien_sauvegarder.$nom_file_pdf,"F");
      $message = "Pv de demande du ".date('Y-m-d')." veuillez ouvrir la  pièce jointe";

       // $pdf->output('I');
        // $pdf->output('Pv de demande du code -'.$demandeur['DEMANDE_CODE'].'.pdf','D');
     $this->Modele->update('stock_demande',array('DEMANDE_ID'=>$DEMANDE_ID),array('PATH_PV_DEMANDE'=>$nom_file_pdf));
      $file_to_attach[]='http://51.83.236.148/iccm_un_v1/uploads/pv_demande/'.$nom_file_pdf;
      
  // $email_to="rnshimirimana48@gmail.com";
  // $email_cc="rnshimirimana48@gmail.com";
      $this->notifications->send_mail($email_to,$INTERVENANT_STRUCTURE_DESCR.'-PV de demande',$email_cc,$message,$file_to_attach);

      
    }
  }

  ?>