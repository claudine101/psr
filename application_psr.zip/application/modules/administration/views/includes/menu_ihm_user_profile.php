

<ul class="nav nav-pills pull-right">
	<li class="<?php echo $menu1 ?>"><a href="<?php echo base_url() ?>administration/User_Profil/index" class="btn-xs">Nouveau</a></li>

     <li class="<?php echo $menu2 ?>"><a href="<?php echo base_url() ?>administration/User_Profil/listing" class="btn-xs">Liste</a></li>
     
     