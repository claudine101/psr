

<ul class="nav nav-pills pull-right">
	<li class="<?php echo $look1 ?>"><a href="<?php echo base_url() ?>administration/Admin_User/index" class="btn-xs">Nouveau</a></li>

     <li class="<?php echo $look2 ?>"><a href="<?php echo base_url() ?>administration/Admin_User/listing" class="btn-xs">Liste</a></li>
     