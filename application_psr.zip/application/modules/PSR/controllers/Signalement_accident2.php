<?php

/**
 *
 *	 
 **/
class Signalement_accident extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->have_droit();
	}

	public function have_droit()
	{
		if ($this->session->userdata('PSR_ELEMENT') != 1) {

			redirect(base_url());
		}
	}
	function index()
	{
		$data['title'] = 'Alertes les accidents';
		$this->load->view('signaler/sign_accident_list_v', $data);
	}

	function listing()
	{
		$i = 1;
		$query_principal = 'SELECT ID_SIGN_ACCIDENT,concat(us.NOM_CITOYEN, " ", us.PRENOM_CITOYEN) as name,us.NOM_UTILISATEUR, PLAQUE, ID_GRAVITE ,tg.DESCRIPTION AS GRAVITE , USER_ID,sa.DESCRIPTION, IMAGE_1, IMAGE_2, IMAGE_3,ROUTE, VALIDATION,LONGITUDE, LATITUDE, DATE_INSERTION FROM sign_accident sa LEFT JOIN utilisateurs us ON us.ID_UTILISATEUR=sa.USER_ID LEFT JOIN type_gravite tg ON tg.ID_TYPE_GRAVITE=sa.ID_GRAVITE WHERE 1';


		$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

		$limit = 'LIMIT 0,10';


		if ($_POST['length'] != -1) {
			$limit = 'LIMIT ' . $_POST["start"] . ',' . $_POST["length"];
		}

		$order_by = '';

		$order_column = array('name', 'PLAQUE', 'DESCRIPTION', 'IMAGE_1', 'IMAGE_2', 'IMAGE_3');

		$order_by = isset($_POST['order']) ? ' ORDER BY ' . $order_column[$_POST['order']['0']['column']] . '  ' . $_POST['order']['0']['dir'] : ' ORDER BY name ASC';

		$search = !empty($_POST['search']['value']) ? ("AND name LIKE '%$var_search%' OR PLAQUE LIKE '%$var_search%' OR DESCRIPTION LIKE '%$var_search%'") : '';

		$critaire = '';

		$query_secondaire = $query_principal . ' ' . $critaire . ' ' . $search . ' ' . $order_by . '   ' . $limit;
		$query_filter = $query_principal . ' ' . $critaire . ' ' . $search;

		$fetch_psr = $this->Modele->datatable($query_secondaire);
		$data = array();

		foreach ($fetch_psr as $row) {
			$image = '';
			$stat='';
			$val_stat='';
			$val_sd='';

			if ($row->VALIDATION == 1) {
				$val_sd='<span style="color : green">validé</span>' ;
			}else{
				$val_stat='<span style="color :red">non validé</span>' ;
			}
			if ($row->IMAGE_1 || $row->IMAGE_2 || $row->IMAGE_3) {
				$img = '<span class = "btn btn-success btn-sm " ><i class = "fa fa-eye" ></i></span>';
			} else {
				$img = 'N/A';
			}
			$plaques='';
			$plaques= str_replace(';',' ',$row->PLAQUE);
			$test=explode(';', $plaques);
			$num='';

			foreach ($test as $key => $value) {
				$num .= $value."</br>";
			}


			$option = '<div class="dropdown ">
			<a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
			<i class="fa fa-cog"></i>
			Action
			<span class="caret"></span></a>
			<ul class="dropdown-menu dropdown-menu-left">
			';

			$option .= "<li><a hre='#' data-toggle='modal'
			data-target='#mydelete" . $row->ID_SIGN_ACCIDENT . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
			$option .= "<li><a class='btn-md' href='" . base_url('PSR/Signalement_accident/getOne/'.$row->ID_SIGN_ACCIDENT) . "'><label class='text-info'>&nbsp;&nbsp;Modifier</label></a></li>";
			$option .= " </ul>
			</div>
			<div class='modal fade' id='mydelete" . $row->ID_SIGN_ACCIDENT . "'>
			<div class='modal-dialog'>
			<div class='modal-content'>

			<div class='modal-body'>
			<center><h5><strong>Voulez-vous supprimer l'historique de?</strong> <br><b style='background-color:prink;color:green;'><i>l 'accident du " . $row->DATE_INSERTION . "</i></b></h5></center>
			</div>

			<div class='modal-footer'>
			<a class='btn btn-danger btn-md' href='" . base_url('PSR/Signalement_accident/delete/' . $row->ID_SIGN_ACCIDENT) . "'>Supprimer</a>
			<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
			</div>

			</div>
			</div>
			</div>";

			$image = "<a hre='#' data-toggle='modal'
			data-target='#image" . $row->ID_SIGN_ACCIDENT . "'>" . $img . "</a>";
			$image .= "
			<div class='modal fade' id='image" . $row->ID_SIGN_ACCIDENT . "'>
			<div class='modal-dialog'>
			<div class='modal-content'>

			<div class='modal-body'>
			<center>
			<p><b>Images</b></center></p>";

			if (!empty($row->IMAGE_1)) {
				$image .= "<img style='width:50%' src='" . $row->IMAGE_1 . "'>";
			}


			if (!empty($row->IMAGE_2)) {
				$image .= "<img style='width:50%' src='" . $row->IMAGE_2 . "'>";
			}

			if (!empty($row->IMAGE_3)) {
				$image .= "<img style='width:50%' src='" . $row->IMAGE_3 . "'>";
			}



			$image .= "</div>

			<div class='modal-footer'>
			
			<button class='btn btn-primary btn-md' data-dismiss='modal'>Quitter</button>
			</div>

			</div>
			</div>
			</div>

			";
			$stat .= "<a href='#' data-toggle='modal'
			data-target='#stat" .$row->ID_SIGN_ACCIDENT. "'><font color='blue'>&nbsp;&nbsp;". $val_stat."</font></a>";

			$stat .= " 
			<div class='modal fade' id='stat".$row->ID_SIGN_ACCIDENT."'>
			<div class='modal-dialog'>
			<div class='modal-content'>

			<div class='modal-body'>
			<center>
			<p> Voulez-vous faire une interation sur l'accident survenue sur la route ".$row->ROUTE."?<br></center>
			</div>

			<div class='modal-footer'>
			<a class='btn btn-primary btn-md' href='" . base_url('PSR/Signalement_accident/change_statut/'.$row->ID_SIGN_ACCIDENT.'/'.$row->VALIDATION) . "'>Oui</a>
			<button class='btn btn-danger btn-md' data-dismiss='modal'>Non</button>
			</div>

			</div>
			</div>
			</div>";

			$sub_array = array();
			// $sub_array[] = $row->DATE_INSERTION;
			$sub_array[] = '<table> <tbody><tr><td><img alt="Avtar" style="border-radius:50%;width:30px;height:30px" src="https://app.mediabox.bi/wasiliEate/uploads/personne.png"></td><td>' . $row->name . ' <font style="font-size:10px;color:red"><i class="far fa-comment-dots"></i></font><br>' . $row->NOM_UTILISATEUR .'</td>
			</tr>
			</tbody></table>';
			$sub_array[] = $num;
			$sub_array[] = $row->GRAVITE;
			$sub_array[] = $val_sd ? $val_sd : $stat;
			$sub_array[] =  !empty($row->DESCRIPTION) ? "<span title='" . $row->DESCRIPTION . "'>commentaire ...</span>" : '-';
			$sub_array[] = $row->ROUTE;
			$sub_array[] = $image;
			$sub_array[] = $row->DATE_INSERTION;
			$sub_array[] = $option;

			$data[] = $sub_array;
		}


		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" => $this->Modele->all_data($query_principal),
			"recordsFiltered" => $this->Modele->filtrer($query_filter),
			"data" => $data
		);
		echo json_encode($output);
	}

	function change_statut($ID_DECLARATION,$STATUT)
	{
		//print_r($ID_DECLARATION,$STATUT);die();
		if ($STATUT==1) {
			$val=0;
		}

		if ($STATUT==0) {
			$val=1;
		}

		$this->Modele->update('sign_accident',array('ID_SIGN_ACCIDENT'=>$ID_DECLARATION),array('VALIDATION'=>$val));

		$datas['message']='<div class="alert alert-success text-center" id="message">La modification du statut est faite avec succès</div>';
		$this->session->set_flashdata($datas);
		redirect(base_url('PSR/Signalement_accident'));

	}


	function ajouter()
	{
		$data['gravites']=$this->Model->getRequete('SELECT ID_TYPE_GRAVITE, DESCRIPTION FROM type_gravite WHERE 1 ORDER BY DESCRIPTION ASC');
		$data['users']=$this->Model->getRequete('SELECT ID_UTILISATEUR,NOM_CITOYEN,PRENOM_CITOYEN FROM utilisateurs WHERE 1  and PROFIL_ID=7 ORDER BY NOM_CITOYEN ASC');
		

		$data['title'] = 'Nouveau Alerte Accident';
		$this->load->view('signaler/sign_accident_add_v',$data);

	}

	function add()
	{

		$this->form_validation->set_rules('PLAQUE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


		$this->form_validation->set_rules('ID_TYPE_GRAVITE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		
		$this->form_validation->set_rules('DESCRIPTION','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('ROUTE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		if($this->form_validation->run() == FALSE)
		{
			$this->ajouter();
		}else{

			$file= $_FILES['IMAGE_1'];
			$path='./uploads/sign_accident/';
			if(!is_dir(FCPATH.'/uploads/sign_accident/')){
				mkdir(FCPATH.'/uploads/sign_accident/', 0777, TRUE);
			}
			$thepath= base_url().'uploads/sign_accident/';
			$config['upload_path']= './uploads/sign_accident/';
			$photonames= date('ymdHisa');
			$config['file_name']=$photonames;
			$config['allowed_types']= '*';
			$this->upload->initialize($config);
			$this->upload->do_upload("IMAGE_1");
			$info=$this->upload->data();

			if($file==''){
				$pathfile= base_url().'uploads/sevtb.png';
			}else{
				$pathfile= base_url().'/uploads/sign_accident/'.$photonames.$info['file_ext'];
			}        

			$data_insert=array(
				'PLAQUE'=>$this->input->post('PLAQUE'),
				'ID_GRAVITE'=>$this->input->post('ID_TYPE_GRAVITE'),
				'USER_ID'=>$this->session->userdata('USER_ID'),
				'DESCRIPTION'=>$this->input->post('DESCRIPTION'),
				'ROUTE'=>$this->input->post('ROUTE'),
				'IMAGE_1'=>$pathfile,
			);

			$table='sign_accident';
			$this->Modele->create($table,$data_insert);

			$data['message']='<div class="alert alert-success text-center" id="message">'."L'ajout se faite avec succès".'</div>';
			$this->session->set_flashdata($data);
			redirect(base_url('PSR/Signalement_accident/index'));

		}

	}	

	function getOne($id=0)
	{
		$data['datas']=$this->Modele->getRequeteOne('SELECT * FROM sign_accident WHERE 1 AND ID_SIGN_ACCIDENT='.$id);
		$data['gravites']=$this->Model->getRequete('SELECT ID_TYPE_GRAVITE, DESCRIPTION FROM type_gravite WHERE 1 ORDER BY DESCRIPTION ASC');
		$data['users']=$this->Model->getRequete('SELECT ID_UTILISATEUR,NOM_CITOYEN,PRENOM_CITOYEN FROM utilisateurs WHERE 1  and PROFIL_ID=7 ORDER BY NOM_CITOYEN ASC');
		
		$data['title'] = "Modification du siganlement";
		$this->load->view('signaler/sign_accident_update_v',$data);
	}



	function update()
	{
		
		$id=$this->input->post('ID_SIGN_ACCIDENT');	
		$datafff=array(
			'PLAQUE'=>$this->input->post('PLAQUE'),
			'ID_GRAVITE'=>$this->input->post('ID_TYPE_GRAVITE'),
			'USER_ID'=>$this->session->userdata('USER_ID'),
			'DESCRIPTION'=>$this->input->post('DESCRIPTION'),
			'ROUTE'=>$this->input->post('ROUTE'),
		);			

		$test=$this->Modele->update('sign_accident',array('ID_SIGN_ACCIDENT'=>$id),$datafff);
        // print_r($test);
        // exit();
		$datas['message']='<div class="alert alert-success text-center" id="message">La modification du menu est faite avec succès</div>';
		$this->session->set_flashdata($datas);
		redirect(base_url('PSR/Signalement_accident/'));
		
	}




	function delete()
	{
		$table = "sign_accident";
		$criteres['ID_SIGN_ACCIDENT'] = $this->uri->segment(4);
		$data['rows'] = $this->Modele->getOne($table, $criteres);
		$this->Modele->delete($table, $criteres);

		$data['message'] = '<div class="alert alert-success text-center" id="message">L"Element est supprimé avec succès</div>';
		$this->session->set_flashdata($data);
		redirect(base_url('PSR/Signalement_accident'));
	}
}
