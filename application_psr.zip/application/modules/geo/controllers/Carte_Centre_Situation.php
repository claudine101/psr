<?php


///Ir NTWARI Raoul  ----------- CARTE DES ALERTES POUR LES INCIDENTS

class Carte_Centre_Situation extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
  }



  function index()
  {

    if (empty($this->session->userdata('USER_NAME'))) {
      redirect(base_url());
    } else {
      $this->load->view('Carte_Centre_Situation_View');
    }
  }







  function getInfration($id = 0){

    $ids =  !empty($id) ? $id : 0;

    $maxId = $this->Model->getRequeteOne('SELECT `NIVEAU_ALERTE`,SUM(p.MONTANT) as AMENDE,SUM(p.POINTS) AS POIN FROM infra_infractions f JOIN infra_peines p ON p.ID_INFRA_INFRACTION=f.ID_INFRA_INFRACTION WHERE f.ID_INFRA_INFRACTION='.$ids);
    $infra = "";
    if (!empty($maxId)) {
    $montant  = !empty($maxId['AMENDE']) ? number_format($maxId['AMENDE'], 0, ',', ' ') : "000";
    $infra .=  $maxId['NIVEAU_ALERTE']."   ".$montant."FBU   ".$maxId['POIN']."/300 points";
    }else{
    $infra .="";
    }

    return $infra;
     
  }






  function get_carte($value = '')
  {

    $zoom = 8;
    $coord = '-3.4313888,29.9079177';
    $PROVINCE_ID = $this->input->post('PROVINCE_ID');
    $ID = $this->input->post('ID');
    $crit = '';

    if (!empty($PROVINCE_ID)) {
      $crit = ' AND incident_declaration.PROVINCE_ID=' . $PROVINCE_ID . '';
    }


    $data_donne = '';

    $maxId = $this->Model->getRequeteOne('SELECT MAX(ID_HISTORIQUE) as maxID FROM historiques h JOIN historiques_categories c on h.ID_HISTORIQUE_CATEGORIE=c.ID_CATEGORIE LEFT JOIN utilisateurs u on u.ID_UTILISATEUR=h.ID_UTILISATEUR LEFT JOIN psr_elements e on e.ID_PSR_ELEMENT=u.PSR_ELEMENT_ID WHERE 1 ');


    $requete = $this->Model->getRequete('SELECT h.ID_IMMATRICULATIO_PEINE,h.ID_ASSURANCE_PEINE,h.ID_CONTROLE_TECHNIQUE_PEINE,h.ID_VOL_PEINE,h.ID_PERMIS_PEINE,ID_HISTORIQUE,MONTANT, IF(IS_PAID=1,"Payé","Non Payé") as PAID,h.LATITUDE,h.LONGITUDE,ID_HISTORIQUE_CATEGORIE,c.DESCRIPTION,h.DATE_INSERTION,e.NUMERO_MATRICULE,IF(`NUMERO_PERMIS` is NULL,`NUMERO_PLAQUE`, NUMERO_PERMIS) as NUMERO FROM historiques h JOIN historiques_categories c on h.ID_HISTORIQUE_CATEGORIE=c.ID_CATEGORIE LEFT JOIN utilisateurs u on u.ID_UTILISATEUR=h.ID_UTILISATEUR LEFT JOIN psr_elements e on e.ID_PSR_ELEMENT=u.PSR_ELEMENT_ID WHERE 1 ORDER by ID_HISTORIQUE DESC ');


    $i = 0;
    $dernier = count($requete);
    $plaques = 0;
    $permis = 0;
    $physique = 0;
    $Scan = 0;

    foreach ($requete as $key => $value) {

      $i++;

      $statut = 0;


      if ($value['ID_HISTORIQUE'] == $maxId['maxID']) {
        $statut = 1;
      }



      $numero = $numero = $value['NUMERO'];



      $DESCRIPTION = $this->remplace_lettre($value['DESCRIPTION']);
      $DESCRIPTION = trim(str_replace('"', '\"', $DESCRIPTION));
      $DESCRIPTION = str_replace("\n", "", $DESCRIPTION);
      $DESCRIPTION = str_replace("\r", "", $DESCRIPTION);
      $DESCRIPTION = str_replace("\t", "", $DESCRIPTION);



      $DATE_INSERTION = $value['DATE_INSERTION'];
      $NUMERO_MATRICULE = $value['NUMERO_MATRICULE'];

      $lat = $value['LATITUDE'];
      $long = $value['LONGITUDE'];

      $provinces = $value['NUMERO_MATRICULE'];

      $color = '';
      $marker = '';
      $pienes = "";

      if ($value['ID_HISTORIQUE_CATEGORIE'] == 1) {
        $color = 'FF8000';
        $marker = '';
        $plaques++;

        $obr = "";
        $Assurance = "";
        $cntrl = "";
        $police = "";


        $obr = !empty($value['ID_IMMATRICULATIO_PEINE']) ? "-".$this->getInfration($value['ID_IMMATRICULATIO_PEINE'])."<br>" : "";

        $Assurance = !empty($value['ID_ASSURANCE_PEINE']) ? "-".$this->getInfration($value['ID_ASSURANCE_PEINE'])."<br>" : "";

        $cntrl = !empty($value['ID_CONTROLE_TECHNIQUE_PEINE']) ? "-".$this->getInfration($value['ID_CONTROLE_TECHNIQUE_PEINE'])."<br>" : "";

        $police = !empty($value['ID_VOL_PEINE']) ? "-".$this->getInfration($value['ID_VOL_PEINE'])."<br>" : "";


        $pienes = $obr.$Assurance.$cntrl.$police;
      }

      if ($value['ID_HISTORIQUE_CATEGORIE'] == 2) {
        $color = '3e9ceb';
        $marker = 'amusement';
        $permis++;

        $psr = !empty($value['ID_PERMIS_PEINE']) ? "-".$this->getInfration($value['ID_PERMIS_PEINE'])."<br>" : "";
        $pienes = $psr;

      }
      if ($value['ID_HISTORIQUE_CATEGORIE'] == 3) {
        $color = 'F1080F';
        $marker = 'civic-building';

        $physique++;
        $pienes = "";
      }
      if ($value['ID_HISTORIQUE_CATEGORIE'] == 4) {
        $color = '800000';
        $marker = 'civic-building';

        $Scan++;
        $pienes = "";
      }


      $amande = !empty($value['MONTANT']) ? number_format($value['MONTANT'], 0, ',', ' ') . "FBU(" . $value['PAID'] . ")" : "000 FBU";




      $data_donne .= $lat . '<>' . $long . '<>' . $DESCRIPTION . '<>' . $value['NUMERO'] . '<>' . $DATE_INSERTION . '<>PSR police<>' . $statut . '<>' . $NUMERO_MATRICULE . '<>' . $value['ID_HISTORIQUE_CATEGORIE'] . '<>' . $plaques . '<>' . $permis . '<>' . $physique . '<>' . $Scan . '<>' . $amande . '<>' . $pienes . '<>' . '$';
    }



    $data['data_donne'] = $data_donne;
    $data['plaques'] = $plaques;
    $data['permis'] = $permis;
    $data['physique'] = $physique;
    $data['Scan'] = $Scan;

    $data['PROVINCE_ID'] = 3;


    $data['provinces'] = $this->Model->getRequete('SELECT * FROM syst_provinces WHERE 1 ');


    $data['dernier'] = $this->Model->getRequeteOne('SELECT MONTANT, IF(IS_PAID=1,"Paié","Non Paié") as PAID,`ID_HISTORIQUE`,h.LATITUDE,h.LONGITUDE,ID_HISTORIQUE_CATEGORIE,c.DESCRIPTION,h.DATE_INSERTION,e.NUMERO_MATRICULE,IF(`NUMERO_PERMIS` is NULL,`NUMERO_PLAQUE`, NUMERO_PERMIS) as NUMERO FROM historiques h JOIN historiques_categories c on h.ID_HISTORIQUE_CATEGORIE=c.ID_CATEGORIE LEFT JOIN utilisateurs u on u.ID_UTILISATEUR=h.ID_UTILISATEUR LEFT JOIN psr_elements e on e.ID_PSR_ELEMENT=u.PSR_ELEMENT_ID WHERE 1  ORDER BY h.ID_HISTORIQUE DESC LIMIT 1');

    if ($ID == 1) {

      $zoom = 18;
      $coord = '' . $data['dernier']['LATITUDE'] . ',' . $data['dernier']['LONGITUDE'] . '';
    }




    $data['dernier_2'] = $this->Model->getRequete('SELECT MONTANT, IF(IS_PAID=1,"Payé","Non Payé") as PAID,`ID_HISTORIQUE`,h.LATITUDE,h.LONGITUDE,ID_HISTORIQUE_CATEGORIE,c.DESCRIPTION,h.DATE_INSERTION,e.NUMERO_MATRICULE,IF(`NUMERO_PERMIS` is NULL,`NUMERO_PLAQUE`, NUMERO_PERMIS) as NUMERO FROM historiques h JOIN historiques_categories c on h.ID_HISTORIQUE_CATEGORIE=c.ID_CATEGORIE LEFT JOIN utilisateurs u on u.ID_UTILISATEUR=h.ID_UTILISATEUR LEFT JOIN psr_elements e on e.ID_PSR_ELEMENT=u.PSR_ELEMENT_ID WHERE 1  ORDER BY h.ID_HISTORIQUE DESC LIMIT 10');

    $data['zoom'] = $zoom;
    $data['coord'] = $coord;


    $map = $this->load->view('Get_Situation', $data, TRUE);
    $output = array('cartes' => $map, 'id' => $ID);
    echo json_encode($output);
  }



  public function getincident($id, $type = null)
  {
    $crito = '';
    $PROVINCE_ID = $this->input->post('PROVINCE_ID');


    if (!empty($PROVINCE_ID)) {
      $crito = ' and incident_declaration.PROVINCE_ID=' . $PROVINCE_ID . '';
    }




    $query_principal = 'SELECT MONTANT, IF(IS_PAID=1,"Paié","Non Paié") as PAID,`ID_HISTORIQUE`,h.LATITUDE,h.LONGITUDE,ID_HISTORIQUE_CATEGORIE,c.DESCRIPTION,h.DATE_INSERTION,e.NUMERO_MATRICULE,IF(`NUMERO_PERMIS` is NULL,`NUMERO_PLAQUE`, NUMERO_PERMIS) as NUMERO FROM historiques h JOIN historiques_categories c on h.ID_HISTORIQUE_CATEGORIE=c.ID_CATEGORIE LEFT JOIN utilisateurs u on u.ID_UTILISATEUR=h.ID_UTILISATEUR LEFT JOIN psr_elements e on e.ID_PSR_ELEMENT=u.PSR_ELEMENT_ID WHERE 1 ';







    $var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

    $limit = 'LIMIT 0,10';


    if ($_POST['length'] != -1) {
      $limit = 'LIMIT ' . $_POST["start"] . ',' . $_POST["length"];
    }
    $order_by = '';

    $order_column = array('INCIDENT_ID', 'DATE_INSERTION');

    $order_by = isset($_POST['order']) ? ' ORDER BY ' . $order_column[$_POST['order']['0']['column']] . '  ' . $_POST['order']['0']['dir'] : ' ORDER BY INCIDENT_ID   DESC';

    $search = !empty($_POST['search']['value']) ? (" AND  (NOM LIKE '%$var_search%' OR DATE_INSERTION LIKE '%$var_search%' OR NUMERO_MATRICULE LIKE '%$var_search%' OR DESCRIPTION LIKE '%$var_search%')  ") : '';

    $critaire = '';

    $query_secondaire = $query_principal . ' ' . $critaire . ' ' . $search . ' ' . $order_by . '   ' . $limit;
    $query_filter = $query_principal . ' ' . $critaire . ' ' . $search;


    $fetch_op = $this->Model->datatable($query_secondaire);
    $data = array();
    foreach ($fetch_op as $row) {



      $sexe = 'Homme';

      // if ($row->SEXE_ID==1) {
      //  $sexe='Homme';
      // }
      // if ($row->SEXE_ID==2) {
      //  $sexe='Femme';
      // }





      $sub_array = array();
      $sub_array[] = $row->NOM . ' ' . $row->PRENOM;
      $sub_array[] = $row->NUMERO_MATRICULE;
      $sub_array[] = $row->TELEPHONE;
      $sub_array[] = $sexe;
      $sub_array[] = $row->DATE_INSERTION;



      $data[] = $sub_array;
    }
    $output = array(
      "draw" => intval($_POST['draw']),
      "recordsTotal" => $this->Model->all_data($query_principal),
      "recordsFiltered" => $this->Model->filtrer($query_filter),
      "data" => $data
    );
    echo json_encode($output);
  }




  public function check_new()
  {

    $get = $this->Model->getRequeteOne('SELECT COUNT(*) AS Nbr FROM historiques WHERE NEW=0');
    $send = 0;
    if ($get['Nbr'] > 0) {
      $send = 1;
      $this->Model->update('historiques', array('NEW' => 0), array('NEW' => 1));
    }


    $output = array('nbr' => $send);
    echo json_encode($output);
  }








  function remplace_lettre($message = "")
  {

    $message = str_replace('é', 'e', $message);

    return  $message;
  }
}
