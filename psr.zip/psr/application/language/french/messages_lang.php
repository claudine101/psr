<?php

//MENU PRINCIPAL

$lang['Compteurs_Inconnus']="Compteurs Inconnus";
$lang['compteur_electricite_type_pdl_list']="Type Produict";
$lang['index_anterieure']="Index Antérieur";
	//Tableau de borb
$lang['Photo_Compteur']="Photo Compteur";
$lang['menu_principal_nav_dashbord']="Tableau de bord";
$lang['menu_principal_nav_dashbord_tableau']="Tableau";

	// Rapporting
$lang['menu_principal_reporting']="Rapport";
	
		//sous menus rapport
$lang['rapport_repartition_de_points']="Répartition des points de collecte par localités";
$lang['rapport_repartition_des_types']="Répartition des types de demandes de semences";
$lang['rapport_des_repartition_des_agronomes']="Répartition des agronomes par provinces d'intervention";
$lang['rapport_semence_accordées']="Semences accordées par province";
$lang['rapport_repartition_des_cooperative']="Répartition des coopératives par points de collecte";
$lang['rapport_repartition_ménage']="Répartition de ménages par profil";
$lang['rapport_quantite_contractuelle']="Quantité contractuelle VS Quantité reçue par coopérative";
$lang['rapport_quantité_accordees_aux_culti']="Quantité accordée aux cultivateurs";
$lang['rapport_qte_collecte_par_point']="Quantité collectée par points de collecte";
$lang['rapport_centre_de_negoce']="Centres de négoce par provinces";

	//IHM
$lang['ihm_chaine_de_valeur']="Chaîne de valeur";
		//IHM sous menus chaine de valeur
$lang['ihm_chaine_agronome']="Agronomes";
$lang['ihm_chaine_monuteurs_agricoles']="Moniteurs agricoles";
$lang['ihm_chaine_commerçants']="Commerçants";
$lang['ihm_chaine_cooperative']="Coopératives";
$lang['ihm_chaine_grands_producteurs']="Grands producteurs";
$lang['ihm_chaine_menage']="Ménages";
$lang['ihm_chaine_producteurs']="Producteurs";
$lang['ihm_chaine_semences']="Semences";
$lang['ihm_chaine_type_de_cooperatives']="Types des coopératives";
	//IHM
$lang['ihm_points_de_collecte']="Points de collecte";
$lang['ihm_collecte_sorgho']="Collecte de sorgho";
	//cartographie
$lang['menu_principal_carto']="Cartographie";

	//sous menus cartographie

$lang['cartographie_carte_globale']="Cartopgraphique des Points de collecte de sorgho";
$lang['recheche_oper']='Recherche opérationnelle';

	//Administration
$lang['menu_principal_administration']="Administration";
	// sous menus administration
$lang['administration_utilisateurs']="Utilisateurs";
$lang['administration_profils']="Profils et Droits";

	//Admin
$lang['menu_principal_admin']="admin";
	//sous menus admin

$lang['admin_modifier_mdp']="Modifier le mot de passe";
$lang['admin_deconnexion']="Déconnexion";

//IHM /chaine de valeur/agronome

$lang['titre_page_agronome']="Ajouter un nouvel agronome";
$lang['bouton_nouveau']="Nouveau";
$lang['bouton_list']="Liste";

//IHM/cahine de valeur/agronome/form

$lang['nom']="Nom";
$lang['prenom']="Prénom";
$lang['lieu_naissance_agro']="Lieu de naissance";
$lang['date_naissance_agro']="Date de naissance";
$lang['cni']="CNI";
$lang['telephone']="Téléphone";
$lang['contrat_agronome']="Contrat";
$lang['employeur_agronome']="Employeur";
$lang['date_embauche_agro']="Date d'embauche";
$lang['provine']="Province";
$lang['commune']="Commune";
$lang['commune_interva']="Commune d'intervention";
$lang['cooperative_sr_agro']="Coopérative sous responsabilité";
$lang['bouton_enregistrer']="Enregistrer";
$lang['alert_compléter_tous_champs']="Il faut compléter tous les champs";
$lang['champ_obligatoire']="Le champ est obligatoire";

//IHM/chaine de valeur/agronome/liste
$lang['titre_agronome_liste']="Liste des agronomes";
$lang['options']="Options";
$lang['action']="Action";
$lang['modifier']="Modifier";
$lang['lieu_interva']="Lieu d'intervention";
$lang['dashbord_agronome']="Tableau de bord";
$lang['employeur_agronome']="Employeur";
$lang['supprimer']="Supprimer";

	//IHM/chaine de valeur/agronome/modifier

$lang['titre_agro_modifier']="Modification d'un agronome";
	//IHM/chaine de valeur/agronome/dashbord
$lang['Admin_Brarudi']="Admin Brarudi";
$lang['description']="Description";
$lang['titre_agronome']="Agronome";
$lang['idendatite_m']="Identification";
$lang['idendatite']="IDENTITEFICATION";
$lang['contrat']="CONTRAT";
$lang['qte_coolecte_date']="QUANTITE COLLECTE PAR DATE";
$lang['quantite']="Quantitée(s)";
$lang['Qte_collecte_date']="Quantite collectée par date ";
$lang['rapport_qte_collect']="Quantité collectée par ";
	//IHM/chaine de valeur/agronome/employeur

$lang['titre_employeur']="Liste des employeurs";
$lang['rechercher']="Rechercher";
$lang['cooperative']="Coopérative";

//IHM/chaine de valeur/agronome/employeur/modification

$lang['titre_Mod_d_employeur']="Modification d'un employeur";
	//IHM/chaine de valeur/agronome/supprimer

$lang['message_supprimer']="Voulez vous supprimer l'agronome?";
$lang['bouton_supprimer']="Supprimer";
$lang['bouton_quitter']="Quitter";
//IHM/chaine de valeur/moniteur/liste

$lang['titre_moniteur']="Liste des moniteurs";
//IHM/chaine de valeur/moniteur/modifier
$lang['titre_moniteur_modifier']="Modification d'un moniteur";
$lang['bouton_modifier']="Modifier";
//IHM/chaine de valeur/moniteur/supprimer

$lang['sms_supprimer']=" Voulez-vous supprimer le moniteur de";
// IHM/chaine de valeur/commerçants/list
$lang['titre_commerçant']="Liste des commerçants";
$lang['email']="Email";
$lang['colline']="Colline";
$lang['production_commerçant']="Production";

// IHM/chaine de valeur/commerçants/nauveau

$lang['titre_comm_nauvau']="Nouveau commerçant";
// IHM/chaine de valeur/commerçants/nauveau/form

$lang['com_prodt_attendue']="Production attendue";
$lang['nif']="NIF";
$lang['rc']="RC";
$lang['copie_st_com']="Copie statut RC ";
$lang['copie_st_nif_com']="Copie statut NIF";
$lang['checkbox_com_ok']="OUI";
$lang['checkbox_com_non']="NON";
// IHM/chaine de valeur/commerçants/modifier
$lang['titre_com_mod']="Modifier le commerçant";
// IHM/chaine de valeur/commerçants/supprimer

$lang['sup_commerçant']="Voulez-vous supprimer le commerçant? ";
// IHM/chaine de valeur/commerçants/détail

$lang['detail']="Tableau de bord";
$lang['com_copie_nif']="COPIE NIF";
$lang['com_copie_rc']="COPIE RC";

// IHM/chaine de valeur/coopératives/list

$lang['titre_cooperative_list']="Liste des coopératives";
$lang['cooperative']="Coopérative";
$lang['responsable-coop']="Responsable";
$lang['date_creation_coop']="Date de création";

// IHM/chaine de valeur/coopératives/nouveau

$lang['titre_nouv_coop']="Nouvelle coopérative";
// IHM/chaine de valeur/coopératives/nouveau/form
$lang['tel_respo_coop']="Tél. responsable";
$lang['nbr_fond_coop']="Nombre des fondateurs";
$lang['mail_resp_coop']="E-mail responsable";
$lang['copie_st_not_com']="Copie statut notaire";
$lang['lieu_oper_coop']="Lieu responsable";
$lang['bouton_suivent']="Suivant";
$lang['bouton_precedent']="Précédent";
$lang['debut_contrat_coop']="Début du contrat";
$lang['fin_contrat_coop']="Fin du contrat";
$lang['qte_contract_coop']="Quantité contractuelle";
$lang['point_collecte']="Point de collecte";
$lang['selectionner']="--Séléctionner--";
// IHM/chaine de valeur/coopératives/dashbord


$lang['localité']="LOCALITE";
$lang['information']="INFORMATIONS";
$lang['information_contrant']="Informations sur le contrat";
$lang['geolocalisation']="GEOLOCALISATION";
$lang['qte_rçu_cont']="QUANTITE REÇUE VS QUANTITE CONTRACTUALLE";
$lang['tout_copie']="COPIE STATUT RC COPIE STATUT NIF COPIE STATUT NOTAIRE";

// IHM/chaine de valeur/coopératives/MODIFIER

$lang['titre_coop_mod']="Modifier la coopérative";
$lang['latitude']="Latitude";
$lang['longititude']="Longitude";

// IHM/chaine de valeur/coopératives/supprimer

$lang['sms_sup_coop']="Voulez-vous supprimer la coopérative?";
// IHM/chaine de valeur/grand producteur/list

$lang['titre_grand_p']="Grand producteurs";
$lang['titre_grand_p_m']="Grand producteur";

$lang['nom_prenom']="Identification";
// IHM/chaine de valeur/grand producteur/détail
$lang['loc_terrain_gp']="Localité du terrain cultivé";
$lang['sous_colline']="Sous-colline";
$lang['proprietaire_gp']="Propriétaire";
$lang['taille_terrian_gp']="Taille du terrain";
$lang['qte_reçu']="Quantité reçu";
$lang['qte_cont_gp']="Quantité contractuelle";
$lang['qte_attendue_gp']="Quantité attendue";
$lang['statut']="Statut";
$lang['carte']="Carte";

// IHM/chaine de valeur/grand producteur/modifier

$lang['prov_terrain_cultive']="Province du terrain cultivé";
$lang['propriete_terrain_cult']="Propriétaire du terrain cultivé";
$lang['com_terrain_cultive']="Commune du terrain cultivé";
$lang['tail_terrain_cult']="Taille du terrain cultivé";
$lang['col_terrain_cultive']="Colline du terrain cultivé";
$lang['sous_col_terrain_cultive']="Sous-colline du terrain cultivé";
$lang['registre_com']="Registre du commerce";

// IHM/chaine de valeur/grand producteur/supprimer

$lang['sms_supp_gp']="Voulez-vous supprimer";
// IHM/chaine de valeur/Ménage/list

$lang['titre_menage']="Liste des ménages";
$lang['menage_nom']="Nom du chef de ménage";
$lang['site']="Site";
$lang['profil']="Profil";
// IHM/chaine de valeur/Ménage/détail
$lang['titre_detail']="Détail du Ménage";
$lang['info_menage']="Information du ménage";
$lang['num_pt_colt_menage']="Numéro des points de collectes";
$lang['menage']="Ménage de";
$lang['info_production']="Information sur la production";
$lang['cultivez_vous']="Cultivez-vous le sorgho?";
$lang['depuis_qd']="Dépuis quand?";
$lang['vs_avez_cult']="Avez-vous cultivé cette année?";
$lang['vs_avez_vdue']="Avez-vous vendu?";
$lang['qte_vdue']="Quantité vendue";
$lang['det_prix_unitaire']="Prix Unitaire";
$lang['det_porquoi']="Pourquoi?";
$lang['det_souh_cult']="Souhaitez-vous cultiver?";
$lang['det_colla_dir']="Collaboration direct aevc Brarudi";
$lang['det_production']="PRODUCTION DE LA MENAGE";
// IHM/chaine de valeur/Ménage/SUPPRIMER

$lang['sms_menage_sup']="Voulez-vous supprimer le ménage ?";

// IHM/chaine de valeur/PRODUCTEZUR/list

$lang['titre_produceteur']="Liste des fermiers";
// IHM/chaine de valeur/PRODUCTEZUR/modifier

$lang['titre_prod_mofi']="Modifier fermier";

// IHM/chaine de valeur/PRODUCTEZUR/supp

$lang['sms_supp_prod']="Voulez-vous supprimer le producteur";

// IHM/chaine de valeur/semence/list

$lang['titre_semence']="Liste de demandeur des semences";
$lang['semence_typ_demandeur']="Type demandeur";
$lang['semence_demandeur']="Demandeur";
$lang['sem_qte_accord']="Quantité accordée";
$lang['sem_dat_distr']="Date de distribution";
$lang['sem_dte_remb']="Date de remboursement";
// IHM/chaine de valeur/semence/modifier


$lang['titre_sem_modi']="Modifier la demande";
// IHM/chaine de valeur/semence/supp

$lang['sms_semence_sup']="Voulez vous supprimer la semence  ";
// IHM/chaine de valeur/type de coopérative/list

$lang['titre_type_coop']="Liste de type des coopératives";
// IHM/chaine de valeur/type de coopérative/modifier

$lang['type_coop_descr']="Description type coopérative";
// IHM/chaine de valeur/type de coopérative/modifier

$lang['sms_sup_type']="Voulez vous supprimer le type de coopérative";
//Administration/profils et droits/LIST

$lang['titre_administration']="Profils et Droits";
$lang['admin_description']="Description profil";
$lang['admin_gestion']="Gestion des utilisateurs";
$lang['admin_rapport']="Rapport";
$lang['admin_carto']="Cartographie";
//Administration/profils et droits/modifier

$lang['titre_admin_mod']="Modification du profils et ses droits";
$lang['admin_droit']="Droits";

//Administration/profils et droits/supprimer

$lang['sms_sup_admin']="Voulez vous supprimer le profil";

//rapports
//rapport/ Répartition de points de collecte

$lang['titre_rp_rpc']="Répartion des points de collecte";
$lang['rap_nbre_point']="Nombre des points de collecte";
$lang['rap_nbre_point_par_province']="Nombre des points de collecte par province";
//rapport/ Répartition de types de demande de semence
$lang['qte_accorde_type_demande']="Quantité accordée par type des semences";
//rapport/ Répartition des agronomes par provinc d'intervention
$lang['titre_rap_agronomr']="Rapport de nombre des agronomes";
$lang['nbr_agronome']="Nombre des agronomes par province";
$lang['agronome']="Agronome(s)";

//rapport/ semences accordées par province

$lang['rapport_du']="Rapport du";

$lang['titre_sem_accord']="Quantité(s) des semences accordée(s) pour tous les types des commandes";
$lang['qte_accordee']="Quantité accordée";
$lang['qte_accordee_p_prov']="Quantité accordée par province";

//rapport/ répartition des coopératives par points de collecte
$lang['nbre_coope_par_poit_col']="Nombre des coopératives par points de collecte";
//rapport/ répartition de ménages par profile
$lang['titre_rep_menage']="Rapport des ménages";
$lang['rep_de_men_profil']="Répartition des ménages par profil";

//rapport/ quantité contractuelle vs quantité reçue par coopérative
$lang['titre_qte_con']="Rapport quantité contractuelle Vs Quantité reçue par coopération";
$lang['quantite_kg']="Quantité en Kg";
$lang['qte_contractuelle']="Quantité Contractuelle de";

$lang['anne']="Année";
$lang['mois']="Mois";

//rapport/ quantité accordées aux cultivateurs

$lang['titre_qte_acc']="Quantité accordée aux cultivateurs";
$lang['qté_accorde']="Quantité accordée";
$lang['qte_accode_prov']="Rapport de la quantité acoordée";

//rapport/ quantité collectées par point de collecte
$lang['titre_qte_collecte']="Rapport de la quantité collectée de sorgho ";
$lang['qte_sorgho_col']="Quantité collectée de sorgho ";
//rapport/ centre de négociation par province
$lang['titre_centre']="Répartition des centres de négoce du sorgho";
$lang['rep_de_centre']="Répartition des centres de négoce du sorgho par province";
$lang['Liste_coopératives_sous']="Liste des coopératives sous responsabilitées";
$lang['sms_Supprimer_point_collecte']="Voulez_vous Supprimer le point de collecte";
//ajout
$lang['nom_prenom']="Nom & Prénom";
$lang['choisir']="--Choisir--";
$lang['Qte_livrée_Vs_Qte_contra']="Qté livrée Vs Qté contractuelle";
$lang['Qte_livrée_Vs_Qte_attendue']="Qté livrée Vs Qté attendue";
$lang['Info_grand_producteur']="Info du Grand Producteur";
$lang['propriètiare_terrain_ultivé']="Propriétaire du terrain cultivé";
$lang['est_obligatoire']="est obligatoire";
$lang['est_unique']="est unique";
$lang['La_province']="Province";
$lang['description_point_collecte']="La Description du point de collecte";
$lang['La_commune']="Commune";
$lang['La_colline']="Colline";
$lang['nom_Agronome']="Le nom d'Agronome";
$lang['prénom_Agronome']="Le prénom d'Agronome";
$lang['Le_lieu_naissance']="Lieu de naissance";
$lang['La_date_naissance']="Date de naissance";
$lang['Le_numéro']="Le numéro de téléphone";
$lang['existe_deja']="existe déjà!";
$lang['est_invalide']="est invalide!";





//------------------------raoul-------------------------------------

//Agronome-------

$lang['Le_champ']="Le champ";
$lang['province']="Province";
$lang['commune']="Commune";
$lang['cooperative']="Coopératives";
$lang['Employeur_agr']="Employeurs";
$lang['Employeur']="Employeur";
$lang['Date_embauche']="Date d'embauche";
$lang['cooperatv_sous_respons']="Coopératives sous responsabilitée";
$lang['lieu_interva']="Lieu d'intervention";
$lang['Modif_employ']="Modification";
$lang['operatio_reussi']="Opération faite avec succés!";
$lang['operatio_echoue']="Opération échouée!";
$lang['description']="Description";
$lang['Employeur_plur']="Ses employeurs";






//Moniteur-----------------------------------------

$lang['annuler']="Annuler";
$lang['question_suppression']="Voulez-vous supprimer";
$lang['Detail_moniteur']="Détails du moniteur";
$lang['Ajouter_moniteur']="Ajout d' un moniteur";
$lang['colline_interva']="Collines d'intervention";
$lang['message_validation']="Il faut compléter tous les champs!";
$lang['liste']="Liste";
$lang['nouveau']="Nouveau";



//Fammer--------------------------------------------------------
$lang['nom_prenom']="Nom et Prénom";
$lang['contrat_debut']="Date début du contrat";
$lang['contrat_fin']="Date fin du contrat";
$lang['taille_terrain']="Taille du terrain";
$lang['product_attendu']="Production attendue";
$lang['qte_contract']="Quantité contractuelle";
$lang['qte_recu']="Quantité réçue";
$lang['description_unique']="La description existe déjà!";
$lang['date_creation']="Date de création";
$lang['modifier_le_contrat']="Modifier le contrat";
$lang['Info_Fammer']="Info du producteur";
$lang['nouveau_product']="Nouveau  Producteur";
$lang['modif_product']="Modifier un producteur";
$lang['nouvel_contrat']="Nouveau contrat";
$lang['message_quantite_contrat']="La quantité Reçue est supérieure à la quantité contractuelle";
$lang['producteur']="Producteur";
$lang['liste_producteur']="Liste des producteurs";
$lang['qte_livre']="Quantité livreé";



//////kabafu
//Rapport Commande_Semences
$lang['quantite_accordee']="<b>Quantité accordée à</b>";
$lang['quantites_accordees']="Quantité(s) accordée(s)";
$lang['Date_creation']='Date de création';
$lang['title_detail_point']="Détail du point de collectes";

//Rapport Rapport_centre_negoce_sorgho
$lang['title_centre_repport']="Répartition des centres de négoce sorgho par province";
$lang['title_centre_repport1']="<b>Nombre de Répartition de centre négoce sorgho à </b>";
$lang['title_centre_serie1']="Répartition des centres négoce sorgho";

//Rapport Rapport_Cooperative_Point_Collecte

$lang['title_Cooperative_Point1']='Rapport du'; 
$lang['title_Cooperative_Point2']="Nombre de points de collecte par coopérative"; 

//Rapport Rapport_demande
$lang['title_Rapport_demande']="Rapport de la quantité accordée ";

//Rapport Rapport_Nombre_Agronome

$lang['title_Nombre_Agronome1']="Nombre des agronomes par Province";
$lang['title_Nombre_Agronome2']="Rapport du nombre des agronomes";

//Rapport Rapport_Nombre_Cooperative
$lang['title_Nombre_Cooperative1']="Nombre des coopératives par Province";
$lang['title_Nombre_Cooperative2']="Rapport du nombre des coopératives";

//Rapport Rapport_profil_menage

$lang['title_profil_menage']="Répartition des ménages par profil";

//Rapport Rapport_QC_VS_QR
$lang['title_profil_QC_serie1']="Quantité Contractuelle de";
$lang['title_profil_QC_serie2']="Quantité reçue de"; 

// Rappot Rapport_QC_VS_QR_BF
$lang['title_profil_QC_serie2']="Quantité reçue de"; 
$lang['title_profil_sur_sorgho']="Rapport sur la quantité collectée de sorgho ";
$lang['title_quantite_accordee']="Quantinté accordée par type de demande des semences"; 

$lang['title_point_collect']="Nombre de points de collectes par province"; 
$lang['title_point_collect1']="<b>Nombre de points de collecte à</b>";
$lang['title_point_collect2']="Points de collecte";
$lang['title_point_collect3']="<b>Liste des points de collectes à</b>";
$lang['Colline']="Colline";
//$lang['Detail_point']=="Détail points de collectes";

//Rapport Repartition_Point_collect_vesion
$lang['nbr_point_collect']="Nombre de points de collecte par province";
$lang['nbr_point_collect1']="<b>Nombre de points de collectes à </b>";
$lang['nbr_point_collect2']="Nombre de points de collectes";

$lang['nbr_point_collect3']="Points de collecte";





///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Raoul///////////////////////////////////////////////

//Rapport des points de collectes par coopérative

$lang['nbr_point_collect_cooperative']="Rapport du nombre de points de collecte par coopérative";
$lang['nbr_coop']="Nbre de coopératives";
//rapport répartition des agronomes
$lang['repart_agronom']="Répartition des agronomes";

//rapport répartition des coopérative
$lang['repart_cooper']="Répartition des coopératives";
$lang['coop_serie']="coopérative(s)";

//rapport profils ménages

$lang['detail_menage']="Détails du profil";


//rapport qte contracuelle vs qt recu

$lang['titre_qtc_vs_qtr']="Rapport Quantité Contractuelle Vs Quantité Reçue par coopérative";
$lang['qtc_vs_qtr']="Quantité Contractuelle Vs Quantité Reçue par coopérative";
$lang['qte_en_tonne']="Quantité en T";
$lang['affiche_qtec_si_vide']="Quantité contractuelle(0 T)";
$lang['affiche_qter_si_vide']="Quantité récue(0 T)";
$lang['total']="Total";

//rapport qtc vs qter pou bigfammer


$lang['titre_rapport_pr_bigfammer']="Rapport Quantité Contractuelle Vs Quantité Reçue par grand producteur";
$lang['name_rapport_pr_bigfammer']="Quantité Contractuelle Vs Quantité Reçue par grand producteur";
$lang['affiche_qtec_si_vide_kg']="Quantité contractuelle(0 T)";
$lang['affiche_qter_si_vide_kg']="Quantité récue(0 T)";

//rapport qtc vs qter pour f
$lang['titre_rapport_fammer']="Rapport Quantité Contractuelle Vs Quantité Reçue par producteur";
$lang['name_rapport_pr_fammer']="Quantité Contractuelle Vs Quantité Reçue par  producteur";

//rapport qtc vs qter pour traider
$lang['titre_rapport_traider']="Rapport Quantité Contractuelle Vs Quantité Reçue par  commerçant";
$lang['name_rapport_pr_traider']="Quantité Contractuelle Vs Quantité Reçue par commerçant";

//rapports répartition des points de collectes

$lang['nom_ordonne']="Nombre de points de collecte";

//rapports répartition des points de collectes

$lang['titre_rapport_pointcollect_2']="Nombre de points de collecte par province";

//Dashboard

$lang['titre_coop_pointcollect']="Nombre de coopératives par points de collecte";







//Administration//emery

 $lang['password_confirm']=" Echec! Le nouveau mot de passe et le mot de passe de confirmation sont differents";

 $lang['Nouveau_password']="Mot de passe modifié avec Succès";

  $lang['connect_nouveau']="<br> Vueillez vous reconnecter avec le <b>Nouveau mot de Passe</b>";
  //profils

  $lang['description_uniq']="La description du profil doit être unique";
   $lang['description_prof']="Description Profil";

   $lang['gestion_user']="Gestion des Utilisateurs";
   $lang['carte']="Cartographie";

   $lang['profile']="La description du profil est obligatoire";

   $lang['supp_profile']="suppression du profil";
   //region
   $lang['nom_region']="Le nom est obligatoire";
   $lang['prov']="La Province  est obligatoire";
   //Users

   $lang['nom_user']="Le champ pour nom est obligatoire";
   $lang['prenom_user']="Le champ pour prénom est obligatoire";
   $lang['emailuser']="Le champ pour email est obligatoire";
   $lang['emailerreur']="le Email déjà utilisé!";
   $lang['teluser']="Le champ pour téléphone est obligatoire";
   $lang['telerreur']="le numéro de téléphone déjà utilisé!";

    $lang['validemail']="Le numéro est invalide";
    $lang['validefone']="Le mail  est déjà utilisé";
    $lang['modifmail']="Modification est faite avec succès";
   
   $lang['suppmail']="la suppression  est faite avec succès";
   
  
  $lang['changepswd']="Changer le Mot de Passe!";

  $lang['old_pswd']="Ancien mot de passe";
   $lang['new_pswd']="Nouveau mot de passe";
   $lang['pswd_confirm']="Confirmer le mot de passe";
   $lang['changnew']="Changer";
   $lang['ajoutprofil']="Ajout des profils et droits";
   $lang['Descriprofil']="Description du profil";
   $lang['user_report']="Reporting";
   $lang['Enregi']="Enregistrer";
   $lang['profildroit']="Profils et droits";
   $lang['modprofildroit']="Modification du profils et ses droits";
   $lang['modif']="Modifier";
   $lang['listuser']="Liste des utilisateurs";
   $lang['adduser']="Ajout d'un utilisateur";
   $lang['prof']="Profil";
   $lang['teluser']="Tél";
   $lang['modusers']="Modification d'un utilisateur";
   $lang['daitls']="Détails";
   $lang['contrat']="CONTRAT";
   $lang['deletepoint']="Voulez_vous Supprimer le point de collecte ";
   $lang['vente']="Vente";
   $lang['Enregistrement']="Enregistrement fait avec succès";
   $lang['produit']="Produit";
   $lang['restant']="Restant";
   $lang['vendu']="Vendu";
   $lang['prix_unitaire']="Prix Unitaire";
   $lang['prix_total']="Prix Total";
   $lang['validevente']="Valider la vente";
   $lang['listetraider']="Liste des commerçants";
   $lang['commerce']="Commerçants";
   $lang['informations']="Informations concernant le contrat";
   $lang['addcommerçants']="Nouveau commerçant";
   $lang['traider']="Traider";
   $lang['nif']="NIF";
   $lang['RC']="RC";
   $lang['copiestatut']="Copie Statut RC";
   $lang['copiestatutnif']="Copie Statut NIF";
   $lang['wi']="OUI";
   $lang['non']="NON";
   $lang['modifitraider']="Modification d'un commerçant";



   $lang['farmer']=" Farmer";
   $lang['obligatoire']=" Le Champ  est obligatoire";
   $lang['modification_demande']="Modification de la Demande";
   $lang['nouvelle_demande']="Nouvelle Semence";
   $lang['titre_semence']="Liste de demandeurs des semences";



   
////////////////////////////////raoul/////////////////////////////////



$lang['identif']="Identification";
$lang['localiser']="Localiser";
$lang['modif_photo']="Mettre à jour la photo";
$lang['agr_respo']="Agronome responsable";
$lang['photo']="Photo";
$lang['qte_vendu_menage']="Quantité vendue par Menage";
$lang['nve_point_collecte']="Nouveau point de collecte";
$lang['descript_point_collecte']="Description du point de collecte";
$lang['modif_point_collecte']="Modification du point de collecte";
$lang['product_de']="Production de";
$lang['num_pt_collect']="Numéro du point de collectes";
$lang['info_product']="Informations sur sa production";
$lang['tot_qte_produit']="Total de quantité produite";

$lang['responsable_coop']="Responsable coopérative";
$lang['coop_membre']="Membres coopérative";

//emery contrat

   $lang['farmer']="farmer";
   $lang['obligatoire']="Champ  est obligatoire";
   $lang['modification_demande']="Modification Demande";
   $lang['nouvelle_demande']="Nouvelle Semence";
   $lang['titre_semence']="Liste de demandeurs des semences";
   $lang['titre_contrat']="Liste des Contrats";
   $lang['nouveau_contrat']="Nouveau Contrat";
   $lang['typ_contrat']="Type Contractant";
   $lang['deb_contrat']="Début Contrat";
   $lang['fin_contrat']="Fin Contrat";
   $lang['modif_contrat']="Modification du Contrat";
   $lang['descri']="Description";
   $lang['semence_demandeur']="Contractant";
   $lang['delecontra']="Voulez-vous Supprimer le Contractant ";



   ////alexis
   $lang['qte_rec_qte_con']='Qté livrée Vs Qté contractuelle';
   //Point de collecte
$lang['titre_point']="Nouveau point de collecte";
$lang['liste_collectes']="Liste des points de collectes";
$lang['modifier_point_collecte']="Modification du point de collecte";
$lang['point_collecte']="Point de Collecte";
$lang['qte_vendu_men']="Quantité vendue par Menage";
$lang['mettre_jour_photo']="Mettre à jour la photo";
$lang['int_mod_phot']="Interface de modification du photo";
$lang['agro_respo']="Agronome responsable";
$lang['localiser']="Localiser";

$lang['type_collecteur']="Type de Collecteur";
$lang['date_collecte']="Date de collecte";

//23/09/2019
$lang['famer']="Producteur";
$lang['Big_Famer']="Grand Producteur";
$lang['type_collecteur']="Type de collecteur";




////////////////////autres//////////////////


$lang['title_profil_QC_serie_name1']="Quantité contractuelle";
$lang['title_profil_QC_serie_name2']="Quantité réçue";
$lang['contrat_satut']="Statut contrat";
$lang['en_cours']="En cours";
$lang['termine']="Terminé";



//////////le 23/09/2019 //////////////////////////////////

$lang['qte_vdu_par_menage']="Quantité vendue par Ménage";

$lang['srogho_collecct']="Sorgho collect";
$lang['supp_coopp']="Voulez-vous Supprimer la coopérative ";

$lang['oper_fait']="Enregistrement fait avec succès ";


//////////nouveau
$lang['sa_qte_par_date']="Quantité par date";
$lang['quantite']="Quantité";
$lang['rapport_pr_lui']="Qtés selon les dates de collection";





///////////////////Le 24/09/2019//////////////////////////////////

$lang['rapport_quantite_par_contrat']="Contrat en cours Vs Terminé";
$lang['rapport_quantite_par_contrat2']="Contrat en cours Vs Terminé";
$lang['trimestre']="Trimestre";
$lang['trimestre1']="1er trimestre";
$lang['trimestre2']="2ème trimestre";
$lang['trimestre3']="3ème trimestre";
$lang['trimestre4']="4ème trimestre";
//$lang['commercant1']="Commerçant";
//$lang['montant13']="Montant";

//////////nouveau
$lang['sa_qte_par_date']="Quantité par date";
$lang['quantite']="Quantité";
$lang['rapport_pr_lui']="Quatintés collectée par dates";

//new

$lang['sous_menu_contra']="Rapport sur les contrats";
$lang['quantite_contr_en_cour']="Quantité des contrats en cours Vs contrats Terminés";
$lang['nbre_contr_en_cour']="Nbre des contrats en cours Vs contrats Terminés";


$lang['centre_negoce']="Centre de négoce";
$lang['institution_financiere']="Institution financière";


$lang['raport_du']="Rapport du";
$lang['rapport_title']="Rapport des Status des Contrats";



$lang['touts_acteur']="Tous les acteurs";


// emery centre negoce
$lang['centre_negoces']="La description du centre de négoce est obligatoire";
$lang['enregi_negoce']="Enregistrement d'un centre de négoce est fait avec succès";
$lang['nom_negoce']="Nom du centre de négoce";
$lang['modi_negoce']="Modification d'un centre de négoce est fait avec succès ";
$lang['del_negoce']="suppression d'un centre de négoce est fait avec succès ";
$lang['foto_negoce']="la modification d'une photo";
$lang['nouvo_negoce']="Nouveau centre de négoce";
$lang['repo_quant']="Quantité collectée";
$lang['repo_quantde']="Centre de négoce de";


$lang['enregi_fina']="Enregistrement d'une institution financière est fait avec succès";
$lang['supp_fina']="Voulez vous Supprimer cette institution";
$lang['nom_fina']="Nom de l'institution financière";
$lang['modi_fina']="la modification d'une institution financière est faite avec succès";
$lang['del_fina']="la suppression de cette  institution financière est faite avec succès";
$lang['foto_fina']="la modification d'une photo est faite avec succès";
$lang['foto_echou']="la modification d'une photo  echoue";
$lang['list_negoce']="Liste des centres de négoces";
$lang['list_fina']="Liste des institutions financières";

$lang['modifi_cente']="Modification d'un centre de négoce";
$lang['modifi_fina']="la modification d'une institution financière";
$lang['institu_fina']="Institution Financière";
$lang['nouvell_fina']="Nouvelle institution financière";

 //Bpeae/////
 $lang['servic']="Services";
 $lang['ser']="SERVICE";
 $lang['servichef']="CHEF DE SERVICE";

  $lang['annuler']="Annuler";
  $lang['deja']="la Description est déjà utilisé ";
  $lang['supp_bpea']="Voulez vous Supprimer le BPEAE ";
  $lang['listservi']="Liste des services ";
  $lang['modifi_bpea']="Modification faite avec succès";
  $lang['modi_bpea']="Modifier le BPEAE";
  $lang['ajout_bpea']="Ajout d'un BPEAE";
   $lang['listsebpea']="Liste de BPEAE";
 $lang['nom_ville']="Nom de la ville";
$lang['nom_commune']="Nom de la commune";
$lang['nom_zone']="Nom de la zone";
$lang['nom_quartier']="Nom du quartier";

$lang['eau']="PDL eau";
$lang['electricity']="PDL éléctricité";
$lang['detail']="Tableau de bord";

$lang['quartier_detail']="Détail du quartier";
$lang['zone_detail']="Détail de la zone";
$lang['commune_detail']="Détail de la commune";
$lang['ville_detail']="Détail de la ville";
$lang['relev']="Relevés";
$lang['nrelev']="Nombre des relevés";
$lang['revenu']="Revenu";
$lang['recouvrement']="Recouvrement";
$lang['consommation']="Consommation";
$lang['repartition']="Repartition des abonnés";
$lang['no_abonne']="Nombre des abonnés";
$lang['no_plainte']="Nombre des plaintes";
$lang['localisation']="localisation";
$lang['consommation_totale']="Consommation totale";
$lang['repartition_materiel']="Repartition du materiel";
$lang['nbre_arrier']="Nombre des arriérés";
$lang['montant_arrier']="Montant des arriérés";
$lang['plainte']="Plaintes";
$lang['liste']="Liste de PDL eau,PDL éléctricité et des plainte";
$lang['neau']="Eau";
$lang['montant']="Montant";
$lang['nelectricity']="Eléctricité";
$lang['description_maison']="Description maison";
$lang['compteur_eau']="Compteur eau";
$lang['compteur_el']="Compteur éléctricité";
$lang['compteur_type']="Type de Compteur";
$lang['compteur_no']="Numéro du compteur";
$lang['nom_prop']="Nom du propriétaire";
$lang['tel']="Téléphone";
$lang['plainte_ref']="Plainte réference";
$lang['commentaire']="Commentaire";

$lang['relev_montant']="Relevé montant";
$lang['montant_paye']="Montant payé";
$lang['notif']="Notification aux quartiers";

$lang['envoyer_a']="envoyer à";
$lang['envoyer']="envoyer";
$lang['monde']="Tout le monde";
$lang['facture_non_pay']="Facture non payée";



$lang['notif_zone']="Notification de la zone";
$lang['notif_commune']="Notification de la commune";
$lang['notif_ville']="Notification de la ville";
$lang['arriere']="Arriérés";
$lang['ville']="Ville";
$lang['total_abonnee']="Total d'abonnées";
$lang['perc_abonnee']="% d'abonnées";
$lang['moyenne']="Moyenne";


///EMERY  acteur type///////////////

$lang['options']="Options";
$lang['action']="Action";
$lang['bouton_nouveau']="Nouveau";
$lang['bouton_list']="Liste";
$lang['discription']="Description";
$lang['modifier']="Modifier";
$lang['enregistree']="Enregistrer";
$lang['typestructure']="Type Equipement";
$lang['supprimer']="Supprimer";
$lang['selectio']="selectionner";
$lang['bouton_quitter']="Quitter"; 
$lang['structuressa']="Liste des types  Acteurs";
$lang['structuresajout']="Ajout d'un acteur";
$lang['structuresmodif']="Modification  d'un acteur";
$lang['modifi_reussi']="La modification faite avec succes";
$lang['operatio_echoue']="La modification echoue";
$lang['enreg_reussi']="L'enregistrement fait avec succes";
$lang['operatio_reussi']="La Suppression faite avec succes";
$lang['champ_obligatoire']="Le Champ est obligatoire";

$lang['ajout_type_equipement']="Ajout d'un type equipement";
$lang['list_type_equipement']="Liste des types des equipements";
$lang['modifi_type_equipement']="Modifier d'un type equipement";



$lang['nouveau']="Nouveau";
$lang['liste']="Liste";
$lang['categorie']="Categorie";
$lang['capacite']="Capacité";
$lang['equipement']="Equipement";
$lang['unite']="Unité";
$lang['photo']="Photo";
$lang['enregistrer']="Enregister";
$lang['quartier']="Quartier";
$lang['localite']="Localité";
$lang['etat']="Etat";
$lang['coordon']="Coordonnées geographiques";
$lang['modifier']="Modifier";
$lang['supprimer']="Supprimer";
$lang['quitter']="Quitter";
$lang['question']="Voulez-vous le supprimer";


/*PDL*/
/*
**MODULE MAISON
*Proprietaire maison*/
$lang['proprietaire_list_titre']="Abonnée";
$lang['proprietaire_th1_titre']="Nom";
$lang['proprietaire_th2_titre']="Prénom";
$lang['proprietaire_th3_titre']="Nombre  Maison";
$lang['proprietaire_option_modifier']="Modifier";
$lang['proprietaire_option_detail']="Détail";
$lang['proprietaire_succes_message']="Opération faite avec succès";
$lang['proprietaire_fail_message']="Opération echouée";
$lang['proprietaire_info']="INFORMATION DU PROPRIETAIRE";
$lang['proprietaire_tel']="Téléphone";
$lang['proprietaire_button_quitter']="Quitter";
$lang['proprietaire_date_creation']="Date de création";
$lang['proprietaire_modal_for_edit_title']="Modifier les informations de l'Abonné";
$lang['data_table_en_francais']=1;
$lang['proprietaire_option_historique']="Historique";
#sub_menu_maison
$lang['pdl_sub_menu1']="Nouveau";
$lang['pdl_sub_menu2']="Liste";
$lang['pdl_sub_menu3']="PDL";
$lang['pdl_sub_menu4']="Abonnée";
$lang['pdl_sub_menu5']="REGICOME EAU";
$lang['pdl_sub_menu6']="REGICOME ELECT";
$lang['pdl_sub_menu7']="SUPRIMA EAU";
$lang['pdl_sub_menu8']="SUPRIMA ELECT";
$lang['pdl_sub_menu9']="INCONNU";

#PDL FORM
$lang['PDL']="PDL";
$lang['province']="Province";
$lang['commune']="Commune";
$lang['zone']="Zone";
$lang['colline_quartier']="Colline/Quartier";
$lang['compteur_eau']="Compteur Eau";
$lang['compteur_electricite']="Compteur Electricité";
$lang['description']="Description";
$lang['photo']="Photo";
$lang['abonne']="Abonné";
$lang['selectioner']="Sélectionner";
$lang['connu']="Connu";
$lang['non_connu']="Non Connu";
$lang['choisir']="Choisir";
$lang['enregistrer']="Enregistrer";
$lang['description_du_maison']="Description du PDL";

$lang['date_releve']="Date Relevé";
$lang['index_anterieure']="Index Anterieur";
$lang['index_actuel']="Index Actuel";
$lang['montant_a_payer']="Montant à Payer";
$lang['type_releve']="Type relevé";
$lang['facture']="Facture";
$lang['maison_de']="Statement History of ";

$lang['pdf_fail_message']="File not supported or corrupted";

$lang['succes_message']="Opération faite avec succès";
$lang['fail_message']="Opération echouée";
$lang['record_not_found']="Enregistrement Non trouver";
$lang['compteur_eau_existe']="Ce Compteur Eau existe déjà !";
$lang['compteur_electricite_existe']="Ce Compteur Electricité existe déjà !";
$lang['required_field']="Compléter tous les champs !";
$lang['choix_photo_maison']="Sélectionner une photo du PDL svp!";
$lang['choix_photo_propietaire']="Sélectionner une photo du propriétaire svp!";
$lang['un_des_compteur_requis']="Completer au moins un des champs pour le Compteur de l'eau ou electricité ☺ !";
$lang['existe']="Existe sur un autre propriétaire!";
$lang['detail_maison']="DETAILS MAISON";

$lang['list_option_dashboard']="Tableau de bord";
$lang['list_option_historique_releve']="Historique de Relevé";
$lang['list_option_modifier']="Tableau de bord";
$lang['list_option_supprimer']="Supprimer";
$lang['alerte_supprimer']="Voulez vous Supprimer ce PDL?";

/**/
/**/
/*COMPTEUR_PRE_EXISTANT*/
$lang['compteur_prexistant']="Compteur Près Existant";
$lang['numero_compteur']="Numéro de compteur";
$lang['type_compteur']="Type de compteur";
$lang['localite']="Localité";
$lang['compteur_pres_existant']="Compteur Près Existant";
$lang['alerte_supprimer_cpx']="Voulez vous Supprimer ce Compteur?";
$lang['required']="Ce champs est requis";
$lang['is_unique']="Ce donné existe déjà dans le système!";
/**/





$lang['percevoir']="Percevoir";
$lang['historique']="Historique";

$lang['image_releve']="Image relevé";
$lang['relance']="Relance";

$lang['abonne']="Abonnées";
$lang['date_releve']="Date relevée";
$lang['index_actuel']="index actuel";
$lang['index_anterieur']="index anterieur";


$lang['montant_exigible']="Amount due";
$lang['montant_restant']="Remaining amount";
$lang['menage']="Ménage";
$lang['hist_relv']="Historique des relevés et des factures des ménages";
$lang['list_pay']="Liste du paiement d'eau ";
$lang['payement_eau_par']="paiement d'eau par";
$lang['montant_exige']="Montant exigé";
$lang['fermer']="Fermer";
$lang['team']="Relance des équipes pour les nouveaux relevés";
$lang['payement_eau_facture']="Relance Paiement Facture Eau de";
$lang['en_date_du']="en date du";
$lang['bonjour']="Bonjour";
$lang['erreur_facture']="Sauf erreur de notre part, votre facture d\'eau d\'un Montant de";
$lang['relative_au_relev']="relative au relevé";
$lang['effectue_le']="effectué le";
$lang['aupr_votr_maison']="auprès votre maison";
$lang['cordialement']="est restée impayée. Nous vous prions de bien vouloir vous en acquitter dans les plus brefs délais.<br> Cordialement<br>";
$lang['image_du_relv']="Image du relevé";
$lang['image']="Image";
$lang['pay_bill']="Historique de paiement de la facture de l'eau
";
$lang['relev_l']="relevé le";





//Alphonse




$lang['ihm_Equipe_table_title_nom']="NOM DE L'EQUIPE";
$lang['ihm_Equipe_table_title_description']="DESCRIPTION";
$lang['ihm_Equipe_table_title_action']="Action";

$lang['ihm_Equipe_add_save_title']="Liste des Equipes";
$lang['ihm_patient_add_messageSuppression']="Suppression faite avec succès";
$lang['ihm_Equipe_add_save_requid']="La description est unique";
$lang['ihm_Equipe_add_save_requid_nom']="Le nom est obligatoire";
$lang['ihm_Equipe_add_save_requid_desc']="La description est obligatoire";
$lang['ihm_patient_add_messageModification']="Modification réussie";

$lang['ihm_acteur_horaire_add_ajoutercart']="Ajouter";
$lang['ihm_Equipe_add_save_requid_design']="Ajouter une designation";
$lang['ihm_Equipe_add_save_requid_existe']="Equipe existe deja";
$lang['ihm_patient_message_delete']="Voulez-vous supprimer?";


$lang['ihm_patient_Modify_button']="Modifier";
$lang['ihm_patient_Delete_button']="Supprimer";
$lang['ihm_patient_supprimer_buttonOui']="Oui";
$lang['ihm_Equipe_updat_title']="Modification";
$lang['ihm_Equipe_menu_new']="Nouveau";
$lang['ihm_Equipe_menu_list']="Liste";



//Equipe_information_prive

$lang['ihm_Equipe_add_listing_litre']="Liste des Equipes";
$lang['ihm_Equipe_add_litre']="Nouvelle Equipe";
$lang['ihm_Equipe_add_descrip']="Entre Description equipe";
$lang['ihm_Equipe_add_nom']="Entre nom equipe";
$lang['ihm_Equipe_add_save_boutton']="Enregistrer";


//Tarif 


$lang['ihm_Tarif_add_litre']="Nouveau Tarif";
$lang['ihm_Tarif_add_Electricite']="Electricite";
$lang['ihm_Tarif_add_Eau']="Eau";
$lang['ihm_Tarif_add_mesure']="Mesure Unitaire";
$lang['ihm_Tarif_add_montant']="Montant";
$lang['ihm_Tarif_add_description']="Description";


$lang['ihm_Tarif_list_requi1']="Ajouter mesure";
$lang['ihm_Tarif_list_requi2']="Entre montant";
$lang['ihm_Tarif_list_requi3']="Entrer une description";
$lang['ihm_Tarif_list_succes_ad']="Ajoutée avec succès";


// $lang['ihm_patient_Modify_button']="Modifier";
// $lang['ihm_patient_Delete_button']="Supprimer";
// $lang['ihm_patient_supprimer_buttonOui']="Oui";
$lang['ihm_patient_supprimer_buttonNon']="Non";

$lang['ihm_Tarif_list_td1']="CODE";
$lang['ihm_Tarif_list_td2']="MESURE UNITAIRE";
$lang['ihm_Tarif_list_td3']="MONTANT";
$lang['ihm_Tarif_list_td4']="DATE DE TARIF";
$lang['ihm_Tarif_list_td5']="DESCRIPTION";
$lang['ihm_Tarif_list_title']="Regles des tarifs";




// $lang['ihm_Equipe_login_username']="Nom d'utilisateur";
// $lang['ihm_Equipe_login_password']="Mot de passe";
// $lang['ihm_Equipe_login_boutton']="Se connecter";


// //Equipe_boutton_de_parcour
// $lang['ihm_Equipe_boutton_parcour_mon_profil_et_mes_details']="Mon profil et Mes détails";
// $lang['ihm_Equipe_boutton_parcour_changer_le_mot_de_paase']="Changer le mot de passe";
// $lang['ihm_Equipe_boutton_parcour_modifier_mes_informations']="Modifier mes informations";

// //Equipe_information_public
// $lang['ihm_Equipe_add_save_title_info_public']="Complete mes informations";
// $lang['ihm_Equipe_add_save_nationalite']="Pays de nationalite";
// $lang['ihm_Equipe_add_save_province_actuel']="Province actuel";
// $lang['ihm_Equipe_add_save_province_de_naissance']="Province de naissance";
// $lang['ihm_Equipe_add_save_commune_actuel']="Commune actuel";
// $lang['ihm_Equipe_add_save_commune_de_naissance']="Commune de naissance";
// $lang['ihm_Equipe_add_save_telephone_2']="Téléphone 2";
// $lang['ihm_Equipe_add_save_site_web']="Site web";
// $lang['ihm_Equipe_add_save_bp']="Bp";
// $lang['ihm_Equipe_add_save_skype']="Skype";
// $lang['ihm_Equipe_add_save_boutton_enregistrer']="Enregistrer";

//Equipe_add_form_validation
$lang['ihm_Equipe_add_save_form_validation_nom_prenom_required']="Le champ est obligatoire";
$lang['ihm_Equipe_add_save_form_validation_telephone_is_unique']="Un autre personne a été inscrit sur ce numero téléphone";
$lang['ihm_Equipe_add_save_form_validation_telephone_required']="Le champ est obligatoire";
$lang['ihm_Equipe_add_save_form_validation_numero_orde_national_is_unique']="Un autre personne a été inscrit sur ce numero d'ordre national";
$lang['ihm_Equipe_add_save_form_validation_numero_orde_national_required']="Le champ est obligatoire";
$lang['ihm_Equipe_add_save_form_validation_email_is_unique']="Un autre personne a été inscrit sur ce email";
$lang['ihm_Equipe_add_save_form_validation_email_required']="Le champ est obligatoire";
$lang['ihm_Equipe_add_save_form_validation_pay_residence_required']="Le champ est obligatoire";
$lang['ihm_Equipe_add_save_form_validation_profil_required']="Le champ est obligatoire";

//Equipe_login_form_validation
$lang['ihm_Equipe_login_form_validation_username_required']="Le champ est obligatoire";
$lang['ihm_Equipe_login_form_validation_password_required']="Le champ est obligatoire";

//Equipe_login_message
$lang['ihm_Equipe_login_message_incorrect']="Le nom d'utilisateur et le mot de passe sont incorrects";

//Equipe_message
$lang['ihm_Equipe_message_enregistrement_succes']="L'enregistrement est faite avec succe";


//Equipe_changement_de_mot_passe
$lang['ihm_Equipe_update_password_title']="Changement du mot de passe";
$lang['ihm_Equipe_update_ancien_mot_de_passe']="Ancien mot de passe";
$lang['ihm_Equipe_update_password_nouveau_mot_de_passe']="Nouveau mot de passe";
$lang['ihm_Equipe_update_password_confirmation_du_nouveau_mot_de_passe']="Confirmation du nouveau mot de passe";
$lang['ihm_Equipe_update_password_enregistrer']="Enregistrer";
$lang['ihm_Equipe_update_ancien_mot_de_passe_incorrect_message']="Le mot de passe est incorrect";
$lang['ihm_Equipe_update_changement_mot_de_passe_message_succes']="Le changement du mot de passe est faite avec succe";
$lang['ihm_Equipe_update_mot_de_passe_ne_correspondent_pas_message']="Les mots de passe sont incorrects";


//Equipe_profil
$lang['ihm_Equipe_profil_title']="Mon profil et mes détails";

//Equipe_update_info
$lang['ihm_Equipe_update_info_title']="Mise a jour de mes informations";
$lang['ihm_Equipe_update_info_boutton']="Enregistrer";
$lang['ihm_Equipe_update_info_update_succe_message']="Le mise a jour de mes informations est fait avec succe";
$lang['ihm_Equipe_update_info_autre_personnel_email_message']="Une autre personne a été inscrit sur cet email";
$lang['ihm_Equipe_update_info_autre_personnel_telephone_message']="Une autre personne a été inscrit sur ce numéro téléphone";
$lang['ihm_Equipe_update_info_autre_personnel_numero_d_ordre_national_message']="Un autre personne a été inscrit sur ce numero d'ordre national";

//la neuve
 
$lang['ihm_Patient_add_save_Nom']="Nom";
$lang['ihm_Patient_add_save_Prénom']="Prénom";
$lang['ihm_Patient_add_save_Téléphone']="Téléphone";
$lang['ihm_Patient_add_save_Email']="Email";
$lang['ihm_Patient_add_save_Sexe']="Sexe";
$lang['ihm_Patient_add_save_Date_de_naissance']="Date de naissance";
$lang['ihm_Patient_add_save_Profession']="Profession";
$lang['ihm_Patient_add_save_Pays']="Pays";
$lang['ihm_Patient_add_save_Adresse']="Adresse";
$lang['ihm_Patient_add_save_Province']="Province";
$lang['ihm_Patient_add_save_Commune']="Commune";
$lang['ihm_Patient_add_save_Photo']="Photo";
$lang['ihm_patient_button_enregistrer']="Enregistrer";
$lang['ihm_Patient_title']="Enregistrement d'un patient";
$lang['ihm_Patient_menu_Nouveau']="Nouveau";
$lang['ihm_Patient_menu_Liste']="Liste";
$lang['ihm_Patient_select_profession']="Selectionnez votre profession";
$lang['ihm_Patient_select_pays']="Selectionnez le pays";
$lang['ihm_Patient_select_province']="Selectionnez la Province";
$lang['ihm_Patient_select_commune']="Selectionez la Commune";
$lang['ihm_patient_sexeM']="Masculin";
$lang['ihm_patient_sexeF']="Féminin";
$lang['ihm_patient_liste_title']="Liste des patients";
$lang['ihm_patient_add_form_validation_required']="Ce champ est obligatoire";
$lang['ihm_patient_user_title']="S'inscrire";

$lang['ihm_patient_modif_button']="Enregistrer les modifications";


$lang['ihm_patient_add_form_validation_unique_number']="Est-ce votre numéro ?réessayer?";
$lang['ihm_patient_add_form_validation_unique_email']="Is this your email?réessayer";
$lang['ihm_patient_Affiliate']="Filiale";
$lang['ihm_patient_liste_AffiliateNon']="Non";
$lang['ihm_patient_liste_AffiliateOui']="Oui";
$lang['ihm_patient_add_messageEnregistrement']="Enregistrement réussi";








// Chandelle
/// chandelle 
$lang['ihm_Equipe_horaire_add_horaire']="Horaire";

$lang['ihm_Equipe_horaire_add_Equipe']="Equipe";
$lang['ihm_Equipe_horaire_add_Equipe']="select nom et prenom";
$lang['ihm_Equipe_horaire_add_structure']="Structure sanitaire";
$lang['ihm_Equipe_horaire_add_select']="choisir";
$lang['ihm_Equipe_horaire_add_jour']="JOUR";
$lang['ihm_Equipe_horaire_add_lundi']="Lundi";
$lang['ihm_Equipe_horaire_add_mardi']="Mardi";
$lang['ihm_Equipe_horaire_add_mercredi']="Mercredi";
$lang['ihm_Equipe_horaire_add_jeudi']="Jeudi";
$lang['ihm_Equipe_horaire_add_vendredi']="Vendredi";
$lang['ihm_Equipe_horaire_add_samedi']="Samedi";
$lang['ihm_Equipe_horaire_add_dimanche']="Dimanche";
$lang['ihm_Equipe_horaire_add_debut']="Heure debut";
$lang['ihm_Equipe_horaire_add_fin']="Heure fin";
$lang['ihm_Equipe_horaire_menu_centre_nouveau']="Nouveau";
$lang['ihm_Equipe_horaire_menu_centre_liste']="Liste";
$lang['ihm_Equipe_horaire_list_listes']="Listes des horaires";
///listing
$lang['ihm_Equipe_horaire_list_act']="Equipe";
$lang['ihm_Equipe_horaire_list_structure']="Structure sanitaire";
$lang['ihm_Equipe_horaire_list_jour']="Jour";
$lang['ihm_Equipe_horaire_list_debut']="Heure debut";
$lang['ihm_Equipe_horaire_list_fin']="Heure fin";
$lang['ihm_Equipe_horaire_list_status']="Status";
$lang['ihm_Equipe_horaire_list_action']="Action";
$lang['ihm_Equipe_horaire_list_supprimer']="Supprimer";
$lang['ihm_Equipe_horaire_list_modifier']="Modifier";
$lang['ihm_Equipe_horaire_list_message']="Voulez-vous supprimer";
$lang['ihm_Equipe_horaire_list_suppr']="Supprimer";
$lang['ihm_Equipe_horaire_list_quitter']="Quitter";




///update
$lang['ihm_Equipe_horaire_update_modifier']="Modifier l’horraire";
$lang['ihm_Equipe_horaire_update_modifier']="Equipe";
$lang['ihm_Equipe_horaire_update_select']="select nom et prenom";
$lang['ihm_Equipe_horaire_update_structure']="Structure sanitaire";
$lang['ihm_Equipe_horaire_update_select']="choisir";
$lang['ihm_Equipe_horaire_update_jour']="JOUR";
$lang['ihm_Equipe_horaire_update_lundi']="Lundi";
$lang['ihm_Equipe_horaire_update_mardi']="Mardi";
$lang['ihm_Equipe_horaire_update_mercredi']="Mercredi";
$lang['ihm_Equipe_horaire_update_jeudi']="Jeudi";
$lang['ihm_Equipe_horaire_update_vendredi']="Vendredi";
$lang['ihm_Equipe_horaire_update_samedi']="Samedi";
$lang['ihm_Equipe_horaire_update_Dimanche']="Dimanche";
$lang['ihm_Equipe_horaire_update_debut']="Heure debut";
$lang['ihm_Equipe_horaire_update_fin']="Heure fin";
$lang['ihm_Equipe_horaire_update_enregistre']="Enregistre";
///ajoutcart

$lang['ihm_Equipe_horaire_add_message']="Enregistrement faite avec succes";
$lang['ihm_acteur_horaire_add_title']="Horraire déjà enregistré";
$lang['ihm_acteur_horaire_add_ajout']="Medecin";
$lang['ihm_acteur_horaire_add_ajoutcart']="Jour";
$lang['ihm_acteur_horaire_add_ajoutstruct']="Structure";
$lang['ihm_acteur_horaire_add_ajoutdebut']="Début";
$lang['ihm_acteur_horaire_add_ajoutfin']="Fin";

$lang['ihm_acteur_horaire_add_actif']="Actif";
$lang['ihm_acteur_horaire_add_inactif']="Inactif";







///Etablissement
$lang['ihm_etablissement_view_titre']="Etablissement";
$lang['ihm_etablissement_view_description']="Description de lʾétablissement";
$lang['ihm_etablissement_view_country']="Pays";
$lang['ihm_etablissement_view_countryselect']="choisir";
$lang['ihm_etablissement_view_countryenregistre']="Enregistrer";

///modifier
$lang['ihm_etablissement_update_titre']="Etablissement";
$lang['ihm_etablissement_update_description']="Description de lʾétablissement";
$lang['ihm_etablissement_update_country']="Pays";
$lang['ihm_etablissement_update_countryselect']="choisir";
$lang['ihm_etablissement_update_countryregister']="Enregistrer";

///listing
$lang['ihm_etablissement_list_description']="Nom de lʾuniversité";
$lang['ihm_etablissement_list_descriptionpays']="Pays";
$lang['ihm_etablissement_list_descriptionaction']="Action";
$lang['ihm_acteur_etablissement_list_supprimer']="Supprimer";
$lang['ihm_acteur_etablissement_list_modifier']="Modifier";
$lang['ihm_acteur_etablissement_list_message']="Voulez-vous supprimer";
$lang['ihm_acteur_etablissement_list_suppr']="Supprimer";
$lang['ihm_acteur_etablissement_list_exit']="Quitter";


///Acteur_grade
$lang['ihm_grade_view_titre']="Grade académique";
$lang['ihm_grade_view_description']="Description grade";
$lang['ihm_grade_view_enregistre']="Enregistre";
$lang['ihm_acteur_grade_menu_grade_nouveau']="Nouveau";
$lang['ihm_acteur_grade_menu_grade_liste']="Liste";

///modifier
$lang['ihm_grade_update_titre']="Grade académique";
$lang['ihm_grade_update_description']="Description grade";
$lang['ihm_grade_update_Enregistre']="Enregistrer";

///listing
$lang['ihm_grade_list_titre']="Description grade";
$lang['ihm_grade_list_description']="Description grade";
$lang['ihm_grade_list_action']="Action";
$lang['ihm_acteur_grade_list_supprimer']="Supprimer";
$lang['ihm_acteur_grade_list_modifier']="Modifier";
$lang['ihm_acteur_grade_list_message']="Voulez-vous supprimer";
$lang['ihm_acteur_grade_list_suppr']="Supprimer";
$lang['ihm_acteur_grade_list_exit']="Quitter";




//cedric enqueteur
$lang['modification']="Modification est faite avec succès";
$lang['suppression']="la suppression  est faite avec succès";
$lang['liste_enqueteur']="Liste des enquêteurs";
$lang['nouveau_enqueteur']="Nouvel enquêteur";
$lang['modif_enqueteur']="Enquêteur - Modification";
$lang['msg_suppression']="Voulez - vous supprimer : ";

//didace//modifier

/**************************************************** RAPPORT TYPE DE PRODUIT*/

$lang['num_obr']="Numérotation OBR";
$lang['num_parcelle']="Numéro du Parcelle";
$lang['avenue']="Av.";
$lang['categorie_abone']="Catégorie d'Abonné";
$lang['type_client']="Type  Client";
$lang['type_abonne']="Type d\'abonné";
$lang['type_compteur']="Type Compteur";
$lang['type_produit']="Type Produit";
$lang['type_beneficiaire']="Type de Bénéficiaire";
$lang['nature_local']="Nature du local";
$lang['detail_list']="Liste pour";
$lang['rapport_du']="Rapport du";
$lang['s_ville']="Ville";
$lang['s_commune']="Commune";
$lang['s_zone']="Zone";
$lang['s_quartier']="Quartier";
$lang['s_selectionner']="Sélectionner";//
/**************** RAPPORT TYPE DE PRODUIT //modifier*/


$lang['pdl_electicite_valide']="Points de livraison valide - Electricité";
$lang['pdl_electicite_invalide']="Points de livraison invalide - Electricité";
$lang['pdl_eau_valide']="Points de livraison valide - Eau";
$lang['pdl_eau_invalide']="Points de livraison invalide - Eau";
$lang['numero_obr']="Numérotation OBR";
$lang['numero_parcelle']="Numérotation de la parcelle";


$lang['select_data']="sélectionner";
$lang['men_menage']="Ménages";
$lang['fact_n_paye']="Facture non payée";
$lang['fact_paye']="Facture payée";
$lang['fact_en_cour_paye']="Facture en cours de paiement";
$lang['compt_pop']="Compteurs";
$lang['eau_pop']="Eau";
$lang['elec_pop']="Electricité";
$lang['propr_pop']="Propriétaire";
$lang['tel_pop']="Téléphone";
$lang['compt_recher']="Rechercher compteur";
$lang['sms_releve_1']="Aucun relevé du type d\'Eau trouvé pour ce ménage";
$lang['sms_releve_2']="Aucun relevé du type d\'Electricité trouvé pour ce ménage";

$lang['pdl_enqueteur'] = 'Close up par enqu&ecirc;teur';

$lang['nom_abonne_pdl_list']="Nom Abonné";
$lang['compteur_eau_abonne_pdl_list']="Compteur Eau";
$lang['compteur_electricite_abonne_pdl_list']="Compteur Electricité";
$lang['ville_abonne_pdl_list']="Ville";
$lang['commune_abonne_pdl_list']="Commune";
$lang['zone_abonne_pdl_list']="Quartier";
$lang['zone_abonne_pdl_list']="Quartier";
$lang['Liste_Pdl']="Liste des PDL";
$lang['repartion_pdl_produit']="Répartition des PDL par Produits";
$lang['repartion_pdl_produit_jour']="Collecte journalière  par types d\'abonnement";
$lang['repartion_pdl_jour']="Collecte journalière des PDLs";



//rapport de doublon//modifier/
$lang['Nombre_doubons_compteurs_eau']="Nombre des doublons pour les compteurs d\'eau";
$lang['Nombre_maisons']="Nombre des PDL";
$lang['Nombre_doubons_compteurs_electrique']="Nombre des doublons pour les compteurs d \'électricité";

$lang['comp_name']="Ses compteurs";
$lang['photo_elec']="Photo compteur Electricité";
$lang['photo_eau']="Photo compteur Eau";



$lang['mar_comp_ele']='Marque Compteur Electricité';
$lang['mar_comp_eau']='Marque Compteur Eau';
$lang['ti_tle']='Nbre de PDLs journalier par enquêteur ';

$lang['marque']='Marque';
$lang['compteur_eau']='Compteur Eau';
$lang['compteur_electricite']='Compteur Electricité';
$lang['info_agent']='Info Enquêteur';
$lang['compteur']='Compteur';
$lang['localite']='localité';
$lang['num_parcelle']='Numéro de la parcelle';


$lang['nombre_compteur']="Nombre des compteurs";
$lang['found']="Trouvé";
$lang['not_found']="Non trouvé";

//rapport type cnsentement

$lang['rapport_consentementprov']="Province";
$lang['rapport_consentementcomm']="Commune";
$lang['rapport_consentementzone']="Zone";

$lang['rapport_consentementprovsel']="Sélectionner la province";
$lang['rapport_consentementcommsel']="Sélectionner la commune";
$lang['rapport_consentementzonesel']="Sélectionner la zone";
$lang['rapport_consentementtitre']="Nombre de PDL par type consentement";





//emery//modifier//
//emery le 20/02/2020
$lang['compteur_electricite_type_pdl_list']="Type de produit";
$lang['Info_du_Proprietaire']="Info du  propriétaire";
$lang['Info_sur_Eau']="Info sur Eau";
$lang['Info_sur_Eau']="Eau";
$lang['electricite_redouble']="Electricité";
$lang['Info_sur_Electricite']="Info sur Electricité";
$lang['Proprietaire']="Propriétaire";
$lang['Numero_OBR']="Numérotation OBR";
$lang['avenue']="Avenue";
$lang['Numro_du_Parcelle']="Numéro de la parcelle";
$lang['Date_Creation']="Date Création";
$lang['categorie_abonnement']="Catégorie d'abonnement";
$lang['Date_Debut_Formulaire']="Date début formulaire";
$lang['Consentement']="Consentement";

$lang['Type_Produit']="Type Produit";
$lang['Type_Beneficaire']="Type Bénéficaire";
$lang['Type_Abonne']="Type Abonné";
$lang['Type_Beneficaire']="Type Bénéficaire";
$lang['Type_Client']="Type Client";
$lang['Type_Commercial']="Type Commercial";
$lang['Compteur_eau']="Compteur Eau";
$lang['Ce_Compteur_est_accesible']="Ce Compteur est accessible";
$lang['Marque_du_Compteur']="Marque Compteur";
$lang['Compteur_depose']="Compteur déposé";
$lang['Type_Compteur']="Type Compteur";
$lang['Index_Eau']="Index Eau";
$lang['Montage_eau']="Montage Eau";
$lang['Credit']="Crédit";
$lang['Compteur_Eau_Attente']="Compteur Eau Attente";
$lang['Branchement_Eau_sans_compteur']="Branchement Eau sans compteur";
$lang['Etat_du_Compteur']="Etat du compteur";
$lang['Compteur_electricite']="Compteur Electricité";
$lang['Ce_compteur_est_accesible']="Ce compteur est accessible";
$lang['Ce_Electricite_a_plusieurs_activite']="Electricité à  plusieurs activités";
$lang['index_electricite']="Index Electricité";
$lang['Consommation']="Consommation";
$lang['Cable_Avant']="Cablé avant";
$lang['Compteur_electricite_Attente']="Compteur Electricité Attente";
$lang['Golocalisation']="Géolocalisation";


$lang['rapport_consentementcodepdl']="Pdl";
$lang['rapport_consentementdetquartier']="Quartier";
$lang['rapport_consentementprovdetail']=" Province";

$lang['repartition_pdl_produit']=" Répartition des PDLs par produits";

//rapport de branchement electrique
$lang['nombre_branchement_electrique_title']="Nombre des branchements électriques";
$lang['nombre_branchement_electrique']="Nombre des branchements";


// Dashboard//emery//Modifier
$lang['dashboard_pdl_type_eau']="Répartition des Compteurs d\'Eau par catégorie";
$lang['dashboard_pdl_etat_eau']="Répartition des PDLs d\'Eau par état";
$lang['dashboard_pdl_type_el']="Répartition des Compteurs d\'Electricité par catégorie";
$lang['dashboard_pdl_etat_el']="Répartition des PDLs d\'électricité par état";
$lang['dashboard_pdl_conso_el']="Répartition des Compteurs d\'électricité par consommation";
$lang['dashboard_pdl_montage_eau']="Répartition des Compteurs d\'eau par montage";


$lang['detail_pdl_type_pdl_list']="Client : ";

$lang['Type_du_local']="Type du local";

$lang['rapport_consentementdetcom']="Commune";
$lang['rapport_consentementdetzone']=" Zone";


// cedric 21022020
$lang['nbr_compteur_type_consommation'] = 'Nombre de compteurs par type de consommation';
$lang['nbr_type_abonne'] = "Répartition des PDL par type de clients";



$lang['Nombre_found_compteurs_eau']="Nombre des compteurs d\'eau par type des sources";
$lang['Nombre_found_compteurs_electrique']="Nombre des compteurs d\'électricité par type des sources";


$lang['dashboard_pdl']=" Tableau de  bord des PDLs";
$lang['accessibilie_eau']="Accessibilité  Eau";
$lang['accessibilie_el']="Accessibilité Electricité ";
$lang['accessibilie_compteur']="Accessibilité des PDLs ";
$lang['dashboard_pdl_blanchema_el']=" Répartition des PDLs d\'électricité par branchements";

//emery
$lang['nombre_identification_client']="Nombre des PDL par type Identification des clients";
$lang['ihm_rapport_view_numb']="Nombres";
$lang['datee_debut_formulaire_numb']="Date Début du formulaire";

$lang['rapport_compt_titre']=" Rapport compteur préexistant";
$lang['rapport_compt_trouve']=" Trouvé";
$lang['rapport_compt_non_trouve']=" Non trouvé";
$lang['rapport_compt_eau']=" Eau";
$lang['rapport_compt_electricite']=" Electricité";



$lang['Nom_Prenom']="Nom et Prénom";
$lang['enqueteur']="Enquêteur";
$lang['ce_numero_existe']="Ce numero existe déjà";
$lang['ajout_controller']="Ajout d\'un contrôleur ";
$lang['modifier_controller']="Modification d'un contrôleur";
$lang['Liste_des_Controlleur']="Liste des contrôleurs ";
//$lang['Liste_des_Controlleur']="Liste des Controlleur";

$lang['rapport_compt_titre']=" Rapport compteur préexistant pour SUPRIMA";
$lang['rapport_compt_titre2']=" Rapport compteur préexistant pour REGICOM";

//ecart 26-02-2020//modifier
$lang['Nouveau_ecart']="Nouvel écart";
$lang['ecart']="Ecarts";
$lang['Description_action']="Description d'une action";
$lang['Traiter_status']="Traitement";
$lang['Liste_des_ecarts']="Liste des écarts";
$lang['modification_ecarts']="Traitement d'un écart";
$lang['date_ecart']="Date d'écart";
$lang['historique_ecart']="Historique d'un écart";

$lang['envoi_msg']="Envoyer SMS";
$lang['succes_msg']="Envoyé avec succès!";
$lang['echec_msg']="Echeck! sms non envoyé ";
$lang['comfirm_msg']="Voulez-vous vraiment envoyer sms à cet enquêteur?";


$lang['nbre_compteurs'] = 'Nombre de commandes';
$lang['pdl_cmd'] = 'Nombre de PDL(s) qui ont fait des commandes';
$lang['pdl_no_cmd'] = "Nombre de PDL(s) qui n\'ont pas fait des commandes";

$lang['compteur_pres_existant_trouve'] = 'Compteurs préexistant trouvés';

$lang['destinataire']='Destinataire';
$lang['expediteur']='Expediteur';

$lang['tout_le_pays'] = 'Dans tout le pays';
$lang['toute_la_ville'] = 'Ville de : ';
$lang['toute_la_commune'] = 'Commune de : ';
$lang['toute_la_zone'] = 'Zone de : ';
$lang['toute_la_colline'] = 'Colline de : ';
$lang['sms_list'] = 'Liste des SMS';

$lang['nombre_branchement_electrique_title']="Nombre des branchements électriques";
$lang['nombre_branchement_electrique_title_liste']="Liste des branchements électriques";
// $lang['Nombre_maisons']="Nombre des PDL";
$lang['Nombre_found_compteurs_eau_liste']="Liste des compteurs d\'eau par type des sources";
$lang['Nombre_found_compteurs_electrique_liste']="Liste des compteurs d\'électricité par type des sources";

$lang['Liste_des_doublons']="Liste des doublons des compteurs d\électricité";
$lang['Liste_des_doublons_eau']="Liste des doublons des compteurs d\'eau";

$lang['Nom_Enqueteur']="Nom Enquêteur";
$lang['Nom_telephone']="Téléphone";
$lang['Details_des_enqueteur_du_Superviseur']="Détails des Enquêteurs du Superviseur";
$lang['Releve_par']="Relevé par";



//desire

// Listes des compteures pre_existant

$lang['compteur_num']="Numéro du compteur";
$lang['compteur_source']="Type de source";
$lang['site_number']="Numéro du site";
$lang['date_abonnement']=" Date d'abonnement";
$lang['quarter']="Quartier";
$lang['statu_found']="Trouvé/Non trouvé";
$lang['Status_correct']="correct/Non correct";
$lang['liste_preexistants']="Liste des compteurs préexistants";
$lang['is_found']="Trouvé";
$lang['no_found']="Non Trouvé";

//enqueteur dashbord
$lang['Dashboard_de_enqueteur']="Tableau de bord d'un enquêteur";
$lang['Nombre_doublons_enqueteur_compteur_electricite']="Nombre des doublons faite par un enquêteur pour les compteurs d\'électricite";
$lang['Nombre_doublons_enqueteur_compteur_eau']="Nombre des doublons faite par un enquêteur pour les compteurs d\'eau";
$lang['Nombre_compteurs_eau_trouves_enqueteur']="Nombre des compteurs d\'eau trouvés par un enquêteur";
$lang['Nombre_compteurs_electricite_trouves_enqueteur']="Nombre des compteurs d\'électricité trouvés par un enquêteur";
$lang['List_doublons_enqueteur_compteur_electricite']="Liste des doublons faite par un enqueteur sur les compteurs d\'électricité";
$lang['List_doublons_enqueteur_compteur_eau']="Liste des doublons faite par un enquêteur pour les compteurs d\'eau";
$lang['Date_debut_formulaire']="Date début formulaire";
$lang['Liste_compteurs_eau_trouves_enqueteur']="Liste des compteurs d\'eau trouvés par un enquêteur";
$lang['Liste_compteurs_electricite_trouves_enqueteur']="Liste des compteurs d\'électricité trouvés par un enquêteur";

///emery03/3/2020
$lang['pdl_ecart']="Description des ecarts";
$lang['pdl_historique_ecart']="Historique des ecarts";
$lang['Correction_des_Ecarts']="Correction des ecarts";
$lang['Statut_pdl']="Statut";
$lang['ecart_pdl_title']="Ecart";
$lang['Information_des_Enqueteurs']="Information des Enquêteurs";
//$lang['Information_des_Enqueteurs']="Information des Enquêteurs";
$lang['pdl_releve_des_Enqueteurs']="Pdl Relevé";
$lang['pdl_releve_des_geolocalisation']="Géolocalisation";
$lang['Proprietaire_du_Maison']="Propriétaire du Maison";
$lang['commune_pdl']="Commune";
$lang['zone_abonne_pdl_list_zonne']="Zone";
$lang['zone_abonne_pdl_list_avenue']="Avenue";


//Ella//modifier//
$lang['rapport_client']="Rapport client";
$lang['rapport_ben']="Rapport Bénéficiaire";

$lang['rapport_commerce']="Rapport commerce";
$lang['nature_local']="Rapport nature local";
$lang['anomalie_eau']="Rapport des anomalies pour Compteur Eau";
$lang['anomalie_el']="Rapport des anomalies pour Compteur Electricité";
$lang['service']="Rapport des services par écart";


$lang['personne_assigne']="Personne Assignée";
$lang['eau']='Eau';
$lang['electricite']='Electricité';
$lang['date_ouverture']='Ouverture';
$lang['date_fermeture']='Fermeture';



//didace//modifier//tout
$lang['Liste_Pdl_eau']=" Liste Pdl Eau";
$lang['Liste_Pdl_electrique']=" Liste Pdl Electricité";
$lang['pdl_eau_numero']=" Numéro PDL Eau";
$lang['pdl_electrique_numero']="Numéro PDL Electricité";
$lang['pdl_par_enqueteur']=" Type PDL par enquêteur";
$lang['pdl_apres_traitement']=" Type PDL après traitement";

$lang['personne_assigne']="Personne Assignée";
$lang['eau']='Eau';
$lang['electricite']='Electricité';
$lang['date_ouverture']='Date Ouverture';
$lang['date_fermeture']='Date Fermeture';
$lang['Nouveau_ecart']="Nouvel Ecart";


$lang['Liste_Pdl_anomarie']=" Liste des anomalies sur les catégories de compteurs";
$lang['Liste_Pdl_anomarie_eau']=" Anomalies sur les catégories de compteurs d\'eau";
$lang['Liste_Pdl_anomarie_ele']=" Anomalies sur les catégories de Compteurs d\'électricité";


$lang['mofif_type_compteur_eau']=" Modification du type de compteur d\'eau";
$lang['mofif_type_compteur_ele']=" Modification du type de compteur d\'électricité";

$lang['dashbord_obj']=" Tableau de Bord Objectifs";


$lang['regicom']=" REGICOM";
$lang['supprima']=" SUPPRIMA";
$lang['consomateur']=" Consommateur";
$lang['num_abonne']=" Numéro Abonné";
$lang['nom_beneficiaire']=" Bénéficaire";

$lang['compteur_trouver']="Trouvé";
$lang['compteur_non_trouver']="Non trouvé";

$lang['Liste_Pdl_anomarie_number']=" Liste des anomalies pour Numéro de PDLs";

//enqueteur donnees//modifier

$lang['title_enqueteur_tab_doublon_trouve']="Doublon et Trouvé";
$lang['title_enqueteur_tab_ecart']="Ecart";
$lang['title_enqueteur_tab_carte']="Carte";
$lang['carte_form_enqueteur_date']="Date Enquête";
$lang['carte_form_enqueteur_menage']="Ménages visités";

$lang['Nombre_ecart_enqueteur_compteur_electricite']="Nombre des PDL qu\'un enquêteur a fait sur un écart pour les compteurs d\'électricité";
$lang['Nombre_ecart_enqueteur_compteur_eau']="Nombre des PDL qu\'un enquêteur a fait sur un écart pour les compteurs d\'eau";

$lang['Dashboard_de_enqueteur']="Tableau de bord d'un enquêteur";
$lang['Nombre_doublons_enqueteur_compteur_electricite']="Nombre des doublons faits par un enquêteur pour les compteurs d\'électricité";
$lang['Nombre_doublons_enqueteur_compteur_eau']="Nombre des doublons faits par un enquêteur pour les compteurs d\'eau";
$lang['Nombre_compteurs_eau_trouves_enqueteur']="Nombre des compteurs d\'eau trouvés par un enquêteur";
$lang['Nombre_compteurs_electricite_trouves_enqueteur']="Nombre des compteurs d\'électricité trouvés par un enquêteur";
$lang['List_doublons_enqueteur_compteur_electricite']="Liste des doublons faite par un enquêteur sur les compteurs d'électricite";
$lang['List_doublons_enqueteur_compteur_eau']="Liste des doublons faite par un enquêteur pour les compteurs d'eau";
$lang['Date_debut_formulaire']="Date début du formulaire";
$lang['Liste_compteurs_eau_trouves_enqueteur']="Liste des compteurs d'eau trouvés par un enquêteur";
$lang['Liste_compteurs_electricite_trouves_enqueteur']="Liste des compteurs d\'électricité trouvés par un enquêteur";

$lang['nbr_ecart_par_agent']='Nbre de tickets par enquêteur';




// //$lang['anomalie_el']="Rapports des anomalies pour Compteur Electricité ";//ccccccccccccccccccccc
// $lang['selectionner']="--Sélectionner --";////ccccccccccccccccccc
// $lang['neau']="Eau";///ccccccccccccccccccccc
// $lang['nelectricity']="Electricité";//cccccccccccccccccccccccccccccccccccccccc

// $lang['s_selectionner']="Sélectionner";//cccccccccccccccccccccccccccccccc
// $lang['selectio']="Sélectionner ";//ccccccccccccccccccccccc
// $lang['compteur_eau']="Compteur Eau";//ccccccccccc
// // $lang['selectioner']="Sélectionner";//cccccccccccccc
// $lang['compteur_electricite']="Compteur Electricité";//cccccccccccc

// $lang['repartion_pdl_produit']=":Répartition des PDL par produit ";//cccccccccccccc
// $lang['repartion_pdl_produit_jour']="Collecte journalière par types d’abonnement ";//cccccccccccccccccccccc
// $lang['repartion_pdl_jour']=": Collecte journalière des PDLs";//cccccccccccccccc
//$lang['nom_abonne_pdl_list']="Nom Abonné";///ccccccccccccccc
//$lang['compteur_eau_abonne_pdl_list']="Compteur Eau";//ccccccccccccccccc

// $lang['Nombre_doubons_compteurs_electrique']=" Nombre de doublons pour compteurs Electricité";//ccccccccccccccccc
// $lang['Nombre_doubons_compteurs_eau']="Nombre de doublons pour compteurs Eau ";//ccccccccccccccccccccc
// $lang['ti_tle']='NNbre de PDL journaliers par enquêteur  ';//cccccccccccccccccccc
// $lang['compteur_eau']='Compteur Eau';//ccccccccccc
// $lang['compteur_electricite']='Compteur Electricité';//cccccccccccc
// $lang['mar_comp_ele']=': Marque Compteur Electricité ';//cccccccccccccccccccc


// $lang['rapport_consentementprovsel']=" Sélectionner la province";//cccccccccccc
// $lang['rapport_consentementcommsel']="Sélectionner la commune";//ccccccccc
// $lang['rapport_consentementzonesel']="Sélectionner la zone";//cccccccccccccccccccc


// $lang['Info_sur_Electricite']="Info sur Electricité";//cccccccc
// $lang['Numro_du_Parcelle']="Numéro de la parcelle";//cccccccc
// $lang['compteur_electricite_type_pdl_list']="Type de produit";//ccccccccc
// $lang['Info_du_Proprietaire']="Info du propriétaire ";//ccccccc
// $lang['dashboard_pdl_type_eau']=": Répartition des compteurs d'Eau par catégorie ";//cccccccccccc
// $lang['dashboard_pdl_etat_eau']="Répartition des compteurs d’Eau par état ";//cccccccccc
// $lang['dashboard_pdl_type_el']=": Répartition des compteurs d'Electricité par catégorie ";//cccccccc
// $lang['dashboard_pdl_etat_el']="Repartition des PDLs d'Electricité par etat";//ccccccccccccc
// $lang['dashboard_pdl_conso_el']="Repartition des Compteurs d\'éléctricité par consommation";
// $lang['dashboard_pdl_montage_eau']="Repartition des Compteurs d\'eau par montage";


// $lang['detail_pdl_type_pdl_list']="Détails du PDL de";//ccccccccccc


// $lang['nbr_compteur_type_consommation'] = 'Nombre de compteurs par type de consommation';//ccccccccccccccc
// $lang['nbr_type_abonne'] = "Répartition des PDL par types de clients  ";//ccccccccccccccccccccc
// $lang['Nombre_found_compteurs_eau']="Nombre de compteurs Eau par types de sources ";//cccccccccccccccccccccccc
// $lang['Nombre_found_compteurs_electrique']=" Nombre de compteurs Electricité par  types de sources";//cccccccccccccccccccc


//$lang['dashboard_pdl']=" Tableau de  bord des PDLs";
//$lang['accessibilie_eau']="Accessibilité Eau";//ccccccc
//$lang['accessibilie_el']="Accessibilité Electricité ";//cccccccccc
//$lang['accessibilie_compteur']=": Accessibilité des PDL ";///ccccccccccccc
//$lang['dashboard_pdl_blanchema_el']=" Répartition des PDLs d\'électricité par branchements";

//emery
//$lang['nombre_identification_client']=" Nombre de PDL par type Identification des  clients ";///cccccccccc

//$lang['pdl_cmd'] = ': Nombre de PDL qui ont fait des commandes ';//ccccccccc
//$lang['pdl_no_cmd'] = "Nombre de PDL qui  n’ont fait de commandes ";///cccccccccc

//$lang['compteur_pres_existant_trouve'] = 'Compteurs préexistants trouvés';//cccccccccccccccccc
//$lang['nombre_branchement_electrique_title']="Nombre de branchements électriques ";//cccccccccccccccccccc
//$lang['anomalie_el']="Rapports des anomalies pour Compteur Electricité ";//
$lang['map_pdl_ecart_titre']=": Carte centre de situation";//

$lang['map_pdl_ecart_rechercher']="Chercher écarts";//cccccccccccnn





 $lang['menu_adninistration_mofif_titre']="Modification d'un utilisateur";
 $lang['menu_adninistration_mofif_nom']="Nom";
 $lang['menu_adninistration_mofif_prenom']="Prénom";
 $lang['menu_adninistration_modif_email']="Email";
 $lang['menu_adninistration_modif_tel']="Téléphone";
 $lang['menu_adninistration_modif_profil']="Profils";
$lang['menu_adninistration_modif_modifier']="Modifier";
//ajout/users
$lang['menu_adninistration_aj_titre']="Ajout d'un nouvel utilisateur";
 $lang['menu_adninistration_aj_nom']="Nom";
 $lang['menu_adninistration_aj_prenom']="Prénom";
 $lang['menu_adninistration_aj_email']="Email";
 $lang['menu_adninistration_aj_tel']="Téléphone";
 $lang['menu_adninistration_aj_profil']="Profils";
$lang['menu_adninistration_btnenreg']="Enregistrer";
$lang['menu_adninistration_select']="Sélectionner";




$lang['aucun_compteur_eau']="Aucun copmteur eau";
$lang['aucun_compteur_elect']="Aucun copmteur électricité";
$lang['nom_abones']="nom de l'abonné";
$lang['DATE_ABONNEMENT']="Date d'abonnemnt";
$lang['profil_conso']="Profil de Consommation";
$lang['PERSONNE_REFERENCE']="Personne de reference";
$lang['NUM_SITE']="Numero du site";
$lang['DERNIER_INDEX']="Dernier index";



$lang['Evolution_ecarts_title']="Evolution des écarts";
$lang['Nombre_ecart_yAxis']="Nombre des écarts";
$lang['list_evolution_ecart_title']="Liste de l'évolution d'un écart numéro ";
$lang['list_evolution_ecart_title_au_dela']=" à la date ";

$lang['NUM_ABONNEMENT']="Numero d'abonnement";

$lang['base_reference']="SUPPRIMA-PDL";
$lang['regicom_eau']=" REGICOM-PDL Eau";
$lang['regicom_ele']=" REGICOM-PDL Electricité";
$lang['Counter']="Compteur";


$lang['Traiter_par']="Traité par";
$lang['ecart_du_client']="du client";
$lang['residant_aa_buja']="Résidant à";
$lang['repartition_geographique_ecart_title']="Répartition géographique des écarts";
$lang['repartition_par_pourcentage']="Répartition par pourcentage des écarts";




$lang['repartition_ecart']="Répartition global des écarts";
$lang['repartition_ecart_detail']="Détail global des écarts";
$lang['Tableau_bord_global_des_ecarts']="Tableau de bord global des écarts";
$lang['repartition_ecart_status']="Répartition global des écarts par statut";
$lang['repartition_par_valeur']="Répartition des écarts par valeur";
$lang['dashbord_ecart_date_avant']="Date d'Avant";


$lang['nombre_compteur_pre_conteur_preexistant']="Nombre des modifications faites pour les compteurs préexistants";



//Cedric
$lang['ecarts_doublons']=" Ecarts et Doublons";



$lang['detail_traite_par']="Traité par";
$lang['detail_traite_par_Liste_supprima']="Liste Compteurs Eau non trouvés SUPPRIMA";
$lang['detail_traite_par_Liste_regicom']="Liste Compteurs Eau non trouvés REGICOM";
$lang['detail_traite_par_Liste_regicom_elc']="Liste Compteurs Electricité non trouvés REGICOM";
$lang['detail_traite_par_Liste_regicom_elc_regicom']="Liste Compteurs Electricité non trouvés REGICOM";
$lang['detail_traite_par_Liste_regicom_elc']="Liste des compteurs Electriques non trouvé SUPPRIMA";

$lang['detail_traite_par_Liste_regicom']="Liste Compteurs Eau non trouvés REGICOM";
$lang['detail_traite_par_Enqueteur_regicom']="enqu&ecirc;teur";
$lang['detail_traite_fermer']="Fermer";
$lang['enregistrer_modifications']="Enregistrer les modifications";




$lang['taux_ecart'] = "Taux de chaque écart.";


$lang['regicom_not_eau_terrain']="REGICOM non trouvé";
$lang['tot_pdl']="Total PDL";
$lang['supprima_not_eau_terrain']="SUPRIMA non trouvé";
$lang['regicom_not_ele_terrain']="REGICOM Electricity non trouvé";
$lang['supprima_not_ele_terrain']="REGICOM Water non trouvé";
$lang['grob_pdl']="Rapport Grobal des PDLs";
$lang['grob_enquete']="Rapport Grobal des Enquêteurs";
$lang['prepayement']="à Prépayement";
$lang['normaliser']="Normaliser";
$lang['normalisation']="Normalisation";


$lang['nbr_entree']="Nombre d'entree";
$lang['nbr_sortie']="Nombre de sortie";
$lang['production']="Production et Adduction";
$lang['source']="Source de Production et Adduction";
$lang['compteur_source']="Compteur de la Source de Production et Adduction";
$lang['debut_min']="Début Min du pompte de la Source";
$lang['debut_max']="Début Max du pompte de la Source";
$lang['destination']="Lieu de Production et Adduction";
$lang['compteur_destination']="Compteur  de Production et Adduction";
 
?>


