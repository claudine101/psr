<?php

//MENU PRINCIPAL

//emery//10/03/2020
$lang['Info_sur_Eau']="Water";
$lang['electricite_redouble']="Electricity";
$lang['Type_du_local']="Type of local";
$lang['categorie_abonnement']="Subscription category";

	//Tableau de borb

$lang['Photo_Compteur']="Photo Counter";

$lang['menu_principal_nav_dashbord']="Dashboard";
$lang['menu_principal_nav_dashbord_tableau']="Dashboard";

	// Rapporting
$lang['menu_principal_reporting']="Reporting";
	
		//sous menus rapport
$lang['rapport_repartition_de_points']="Distribution of collection points by localities";
$lang['rapport_repartition_des_types']="Distribution of types of seed applications";

$lang['rapport_des_repartition_des_agronomes']="Distribution of agronomists by intervention provinces";
$lang['rapport_semence_accordées']="Seeds granted by province";
$lang['rapport_repartition_des_cooperative']="Distribution of cooperatives by collection points";

$lang['rapport_repartition_ménage']="Distribution of households by profile";

$lang['rapport_quantite_contractuelle']="Contract Quantity VS Quantity Received by Cooperative";
$lang['rapport_quantité_accordees_aux_culti']="Quantity granted to growers";
$lang['rapport_qte_collecte_par_point']="Quantity collected by collection points";
$lang['rapport_centre_de_negoce']="Trading Centers by Provinces";

	//IHM
$lang['ihm_chaine_de_valeur']="Value chain";
		//IHM sous menus chaine de valeurMot de passe modifié avec Succès

$lang['ihm_chaine_agronome']="Agronomists";
$lang['ihm_chaine_monuteurs_agricoles']="Farm monitors";
$lang['ihm_chaine_commerçants']="Traders";
$lang['ihm_chaine_cooperative']="cooperatives";
$lang['ihm_chaine_grands_producteurs']="Big Farmer";
$lang['ihm_chaine_menage']="households";
$lang['ihm_chaine_producteurs']="Farmers";
$lang['ihm_chaine_semences']="Seeds";
$lang['ihm_chaine_type_de_cooperatives']="Types of cooperatives";
	//IHM
$lang['ihm_points_de_collecte']="Collection points";
$lang['ihm_collecte_sorgho']="Sorghum collection";
	//cartographie
$lang['menu_principal_carto']="Monitoring";

	//sous menus cartographie

$lang['cartographie_carte_globale']="Cartographic Record of Sorghum Collection Points";
$lang['recheche_oper']='Operational research';

	//Administration
$lang['menu_principal_administration']="Administration";
	// sous menus administration
$lang['administration_utilisateurs']="Users";
$lang['administration_profils']="Profiles and Rights";

	//Admin
$lang['menu_principal_admin']="admin";
	//sous menus admin

$lang['admin_modifier_mdp']="change the password";
$lang['admin_deconnexion']="Log Out";

//IHM /chaine de valeur/agronome

$lang['titre_page_agronome']="Add a new agronomist";
$lang['bouton_nouveau']="New";
$lang['bouton_list']="List";

//IHM/cahine de valeur/agronome/form

//alphonse


$lang['nom']="Last name";
$lang['prenom']="First name";
$lang['lieu_naissance_agro']="Place of birth";
$lang['date_naissance_agro']="Birth date";
$lang['cni']="CNI";
$lang['telephone']="Phone number";
$lang['contrat_agronome']="Contract";
$lang['employeur_agronome']="Employer";
$lang['date_embauche_agro']="Hiring date";
$lang['provine']="Province";
$lang['commune']="Commune";
$lang['commune_interva']="Commune of intervention";
$lang['cooperative_sr_agro']="Cooperative under responsibility";
$lang['bouton_enregistrer']="Save";
$lang['alert_compléter_tous_champs']="We must complete all the fields!";
$lang['champ_obligatoire']="The field is mandatory";

//IHM/chaine de valeur/agronome/liste
$lang['titre_agronome_liste']="List of agronomists";
$lang['options']="Options";
$lang['action']="Action";
$lang['modifier']="Edit";
$lang['lieu_interva']="Place of intervention";
$lang['dashbord_agronome']="Dashboard";
$lang['employeur_agronome']="Employer";
$lang['supprimer']="delete";

	//IHM/chaine de valeur/agronome/modifier

$lang['titre_agro_modifier']="Modification of an agronomist";
	//IHM/chaine de valeur/agronome/dashbord
$lang['Admin_Brarudi']="Admin Brarudi";
$lang['description']="Description";
$lang['titre_agronome']="Agronomist";
$lang['idendatite_m']="Identification";
$lang['idendatite']="IDENTIFICATION";
$lang['contrat']="CONTRACT";
$lang['qte_coolecte_date']="QUANTITY COLLECTED BY DATE";
$lang['quantite']="Quantities";
$lang['Qte_collecte_date']="Quantity collected by date ";
$lang['rapport_qte_collect']="Quantity collected by par ";
	//IHM/chaine de valeur/agronome/employeur

$lang['titre_employeur']="List of employers";
$lang['rechercher']="Search";
$lang['cooperative']="cooperatives";

//IHM/chaine de valeur/agronome/employeur/modification

$lang['titre_Mod_d_employeur']="Modification of an employer";
	//IHM/chaine de valeur/agronome/supprimer

$lang['message_supprimer']="Do you want to delete the agronomist??";
$lang['bouton_supprimer']="delete";
$lang['bouton_quitter']="leave";
//IHM/chaine de valeur/moniteur/liste

$lang['titre_moniteur']="List of  monitors";
//IHM/chaine de valeur/moniteur/modifier
$lang['titre_moniteur_modifier']="Changing a monitor";
$lang['bouton_modifier']="Edit";
//IHM/chaine de valeur/moniteur/supprimer

$lang['sms_supprimer']=" Do you want to remove the monitor from";
// IHM/chaine de valeur/commerçants/list
$lang['titre_commerçant']="List of Traders";
$lang['email']="E-mail";
$lang['colline']="Hill";
$lang['production_commerçant']="Production";

// IHM/chaine de valeur/commerçants/nauveau

$lang['titre_comm_nauvau']="New trader";
// IHM/chaine de valeur/commerçants/nauveau/form

$lang['com_prodt_attendue']="Expected production";
$lang['nif']="NIF";
$lang['rc']="RC";
$lang['copie_st_com']="Copy status RC ";
$lang['copie_st_nif_com']="Copy status NIF";
$lang['checkbox_com_ok']="YES";
$lang['checkbox_com_non']="NO";
// IHM/chaine de valeur/commerçants/modifier
$lang['titre_com_mod']="Modify the Trader";
// IHM/chaine de valeur/commerçants/supprimer

$lang['sup_commerçant']="Do you want to delete the Trader";
// IHM/chaine de valeur/commerçants/détail

$lang['detail']="Dashboard";
$lang['com_copie_nif']="NIF COPY";
$lang['com_copie_rc']="RC COPY";

// IHM/chaine de valeur/coopératives/list

$lang['titre_cooperative_list']="List of cooperatives";
$lang['cooperative']="Cooperative";
$lang['responsable-coop']="Responsible";
$lang['date_creation_coop']="Creation date";

// IHM/chaine de valeur/coopératives/nouveau

$lang['titre_nouv_coop']="New cooperative";
// IHM/chaine de valeur/coopératives/nouveau/form
$lang['tel_respo_coop']="Phone.responsible";
$lang['nbr_fond_coop']="Number of founders";
$lang['mail_resp_coop']="Responsible e-mail";
$lang['copie_st_not_com']="Copy notary status";
$lang['lieu_oper_coop']="Responsible place";
$lang['bouton_suivent']="Next";
$lang['bouton_precedent']="Previous";
$lang['debut_contrat_coop']="Beginning of the contract";
$lang['fin_contrat_coop']="End of the contract";
$lang['qte_contract_coop']="Contractual quantity";
$lang['point_collecte']="Collection point";
$lang['selectionner']="--select--";
// IHM/chaine de valeur/coopératives/dashbord


$lang['localité']="LOCALITY";
$lang['information']="INFORMATIONS";
$lang['information_contrant']="Contract Information";
$lang['geolocalisation']="TRACKING";
$lang['qte_rçu_cont']="QUANTITY RECEIVED VS CONTRACTUAL QUANTITY";
$lang['tout_copie']="COPY STATUS RC COPY STATUS NIF COPY NOTARY STATUS";

// IHM/chaine de valeur/coopératives/MODIFIER

$lang['titre_coop_mod']="Modify the cooperative";
$lang['latitude']="Latitude";
$lang['longititude']="Longitude";

// IHM/chaine de valeur/coopératives/supprimer

$lang['sms_sup_coop']="Do you want to delete the cooperative?";
// IHM/chaine de valeur/grand producteur/list

$lang['titre_grand_p']="Big Farmer";
$lang['titre_grand_p_m']="Big Farmer";

$lang['nom_prenom']="Identification";
// IHM/chaine de valeur/grand producteur/détail
$lang['loc_terrain_gp']="Locality of cultivated land";
$lang['sous_colline']="Sub-hill";
$lang['proprietaire_gp']="Owner";
$lang['taille_terrian_gp']="Size of the land";
$lang['qte_reçu']="Quantity received";
$lang['qte_cont_gp']="Contract quantity";
$lang['qte_attendue_gp']="Expected quantity";
$lang['statut']="Status";
$lang['carte']="Map";

// IHM/chaine de valeur/grand producteur/modifier

$lang['prov_terrain_cultive']="Province of cultivated land";
$lang['propriete_terrain_cult']="Owner of the cultivated land";
$lang['com_terrain_cultive']="the Commune of cultivated land";
$lang['tail_terrain_cult']="Size of cultivated land";
$lang['col_terrain_cultive']="Hill of cultivated land";
$lang['sous_col_terrain_cultive']="Sub-hill of cultivated land";
$lang['registre_com']="Trade register";

// IHM/chaine de valeur/grand producteur/supprimer

$lang['sms_supp_gp']="Do you want to delete?";
// IHM/chaine de valeur/Ménage/list

$lang['titre_menage']="List of households";
$lang['menage_nom']="Name of the head of the household";
$lang['site']="Site";
$lang['profil']="Profile";
// IHM/chaine de valeur/Ménage/détail
$lang['titre_detail']="Household detail";
$lang['info_menage']="Household information";
$lang['num_pt_colt_menage']="Collection Point Numbers";
$lang['menage']="Household of";
$lang['info_production']="Production information";
$lang['cultivez_vous']="Do you grow sorghum?";
$lang['depuis_qd']="Since when?";
$lang['vs_avez_cult']="Did you grow this year?";
$lang['vs_avez_vdue']="Have you sold?";
$lang['qte_vdue']="Quantity sold";
$lang['det_prix_unitaire']="Unit price";
$lang['det_porquoi']="Why?";
$lang['det_souh_cult']="Would you like to cultivate?";
$lang['det_colla_dir']="Direct collaboration with Brarudi";
$lang['det_production']="HOUSEHOLD PRODUCTION";
// IHM/chaine de valeur/Ménage/SUPPRIMER

$lang['sms_menage_sup']="Do you want to delete the household? ?";

// IHM/chaine de valeur/PRODUCTEZUR/list

$lang['titre_produceteur']="List of farmers";
// IHM/chaine de valeur/PRODUCTEZUR/modifier

$lang['titre_prod_mofi']="Edit farmer";

// IHM/chaine de valeur/PRODUCTEZUR/supp

$lang['sms_supp_prod']="Do you want to delete the trader?";

// IHM/chaine de valeur/semence/list

$lang['titre_semence']="Seed Applicant List";
$lang['semence_typ_demandeur']="Type of applicant";
$lang['semence_demandeur']="Applicant";
$lang['sem_qte_accord']="Quantity granted";
$lang['sem_dat_distr']="Date of distribution";
$lang['sem_dte_remb']="Repayment date";
// IHM/chaine de valeur/semence/modifier


$lang['titre_sem_modi']="Modify the request";
// IHM/chaine de valeur/semence/supp

$lang['sms_semence_sup']="Do you want to delete the seed? ";
// IHM/chaine de valeur/type de coopérative/list

$lang['titre_type_coop']="List of types of cooperatives";
// IHM/chaine de valeur/type de coopérative/modifier

$lang['type_coop_descr']="Description of the cooperative type";
// IHM/chaine de valeur/type de coopérative/modifier

$lang['sms_sup_type']="Do you want to delete the type of cooperative?";
//Administration/profils et droits/LIST

$lang['titre_administration']="Profiles and Rights";
$lang['admin_description']="Profile description";
$lang['admin_gestion']="User Management";
$lang['admin_rapport']="Reppoting";
$lang['admin_carto']="cartography";
//Administration/profils et droits/modifier

$lang['titre_admin_mod']="Editing profiles and rights";
$lang['admin_droit']="Rights";

//Administration/profils et droits/supprimer

$lang['sms_sup_admin']="Do you want to delete the profile?";

//rapports
//rapport/ Répartition de points de collecte

$lang['titre_rp_rpc']="Distribution of collection points";
$lang['rap_nbre_point']="Number of collection points";
$lang['rap_nbre_point_par_province']="Number of collection points by provinces";
//rapport/ Répartition de types de demande de semence
$lang['qte_accorde_type_demande']="Quantity granted by seed type";
//rapport/ Répartition des agronomes par provinc d'intervention
$lang['titre_rap_agronomr']="Reporting of the number of agronomists
";
$lang['nbr_agronome']="Number of agronomists by provinces";
$lang['agronome']="Agronomist (s)";

//rapport/ semences accordées par province

$lang['rapport_du']="Reporting of";

$lang['titre_sem_accord']="Seed quantity (s) granted for all types of orders";
$lang['qte_accordee']="Quantity granted";
$lang['qte_accordee_p_prov']="Quantity granted by provinces";

//rapport/ répartition des coopératives par points de collecte
$lang['nbre_coope_par_poit_col']="Number of cooperatives by collection points";
//rapport/ répartition de ménages par profile
$lang['titre_rep_menage']="Household Reporting";
$lang['rep_de_men_profil']="Distribution of households by profile";

//rapport/ quantité contractuelle vs quantité reçue par coopérative
$lang['titre_qte_con']="RContract quantity Reporting Vs Quantity received by cooperation";
$lang['quantite_kg']="Quantity in Kgs";
$lang['qte_contractuelle']="Contractual quantity of";

$lang['anne']="Year";
$lang['mois']="Month";

//rapport/ quantité accordées aux cultivateurs

$lang['titre_qte_acc']="Quantity granted to growers";
$lang['qté_accorde']="Quantity granted";
$lang['qte_accode_prov']="Reporting of the quantity granted";

//rapport/ quantité collectées par point de collecte
$lang['titre_qte_collecte']="Reporting of the amount of sorghum collected ";
$lang['qte_sorgho_col']="Collected quantity of sorghum";
//rapport/ centre de négociation par province
$lang['titre_centre']="Breakdown of sorghum trading centers";

///////////////////niyongabo



$lang['rep_de_centre']="Breakdown of sorghum trading centers by provinces";
$lang['Liste_coopératives_sous']="List of cooperatives under responsibility";
$lang['sms_Supprimer_point_collecte']="Do you want to delete the collection point";
//ajout
$lang['nom_prenom']="Last name & First Name";
$lang['choisir']="-- choose--";
$lang['Qte_livrée_Vs_Qte_contra']="Quantity delivered Vs Contract quantity";
$lang['Qte_livrée_Vs_Qte_attendue']="Quantity delivered Vs Quantity expected";
$lang['Info_grand_producteur']="Info of the Major Farmer";
$lang['propriètiare_terrain_ultivé']="Owner of the cultivated land";
$lang['est_obligatoire']="is obligatory";
$lang['est_unique']="is unique";
$lang['La_province']="Province";
$lang['description_point_collecte']="The description of the collection point";
$lang['La_commune']="Commune";
$lang['La_colline']="Hill";
$lang['nom_Agronome']="The Agronome Last Name";
$lang['prénom_Agronome']="The Agronome First Name";
$lang['Le_lieu_naissance']="Place of birth";
$lang['La_date_naissance']="Birth date";
$lang['Le_numéro']="Telephone number";
$lang['existe_deja']="Already exists!";
$lang['est_invalide']="is invalid!";





//------------------------raoul-------------------------------------

//Agronome-------

$lang['Le_champ']="Field";
$lang['province']="Province";
$lang['commune']="Commune";
$lang['cooperative']="Cooperatives";
$lang['Employeur_agr']="Employers";
$lang['Employeur']="Employer";
$lang['Date_embauche']="Hiring date";
$lang['cooperatv_sous_respons']="Cooperatives under responsibility";
$lang['lieu_interva']="Place of intervention";
$lang['Modif_employ']="Modification";
$lang['operatio_reussi']="Operation done successfully!";
$lang['operatio_echoue']="Operation failed!";
$lang['description']="Description";
$lang['Employeur_plur']="His employers";






//Moniteur-----------------------------------------

$lang['annuler']="Cancel";
$lang['question_suppression']="Do you want to delete";
$lang['Detail_moniteur']="Monitor details";
$lang['Ajouter_moniteur']="Adding a monitor";
$lang['colline_interva']="Intervention Hills";
$lang['message_validation']="We must complete all the fields!";
$lang['liste']="List";
$lang['nouveau']="New";



//Fammer--------------------------------------------------------
$lang['nom_prenom']="Last name and first name";
$lang['contrat_debut']="Start date of the contract";
$lang['contrat_fin']="End date of the contract";
$lang['taille_terrain']="Size of the land";
$lang['product_attendu']="Expected production";
$lang['qte_contract']="Contract quantity";
$lang['qte_recu']="Quantity received";
$lang['description_unique']="The description already exists!";
$lang['date_creation']="Creation date";
$lang['modifier_le_contrat']="Modify the contract";
$lang['Info_Fammer']="Farmer Info";
$lang['nouveau_product']="New  farmer";
$lang['modif_product']="Edit a farmer";
$lang['nouvel_contrat']="New contract";
$lang['message_quantite_contrat']="The quantity received is greater than the contract quantity";
$lang['producteur']="Farmers";
$lang['liste_producteur']="List of Farmers";
$lang['qte_livre']="Delivered quantity";





//////kabafu
//Rapport Commande_Semences
$lang['quantite_accordee']="<b>Quantity (s) grantedto</b>";
$lang['quantites_accordees']="Quantity (s) granted";
$lang['Date_creation']='Creation date';
$lang['title_detail_point']="Detail of the collection point";

//Rapport Rapport_centre_negoce_sorgho
$lang['title_centre_repport']="Repartition of sorghum trading centers by province";
$lang['title_centre_repport1']="<b>Distribution of sorghum trading center in </b>";
$lang['title_centre_serie1']="Breakdown of sorghum trading centers";

//Rapport Rapport_Cooperative_Point_Collecte

$lang['title_Cooperative_Point1']='Reporting of'; 
$lang['title_Cooperative_Point2']="Number of collection points by cooperative"; 

//Rapport Rapport_demande
$lang['title_Rapport_demande']="Reporting of the quantity granted";

//Rapport Rapport_Nombre_Agronome

$lang['title_Nombre_Agronome1']="Number of agronomists by Province";
$lang['title_Nombre_Agronome2']="Reporting on the number of agronomists";

//Rapport Rapport_Nombre_Cooperative
$lang['title_Nombre_Cooperative1']="Number of cooperatives by province";
$lang['title_Nombre_Cooperative2']="Reporting on the number of cooperatives";

//Rapport Rapport_profil_menage

$lang['title_profil_menage']="Distribution of households by profile";

//Rapport Rapport_QC_VS_QR
$lang['title_profil_QC_serie1']="Contractual Quantity of";
$lang['title_profil_QC_serie2']="Quantity received from"; 

// Rappot Rapport_QC_VS_QR_BF
$lang['title_profil_QC_serie2']="Quantity received from"; 
$lang['title_profil_sur_sorgho']="Report on the amount of sorghum collected";
$lang['title_quantite_accordee']="Quantity granted by type of seed demand"; 

$lang['title_point_collect']="Number of collection points by province"; 
$lang['title_point_collect1']="<b>Number of collection points at</b>";
$lang['title_point_collect2']="Collection points";
$lang['title_point_collect3']="<b>List of collection points at</b>";

$lang['Colline']="Hill";
//$lang['Detail_point']=="Détail points de collectes";

//Rapport Repartition_Point_collect_vesion
$lang['nbr_point_collect']="Number of collection points by province";
$lang['nbr_point_collect1']="<b>Number of collection points to</b>";
$lang['nbr_point_collect2']="Number of collection points";

$lang['nbr_point_collect3']="Collection points";





///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Raoul///////////////////////////////////////////////

//Rapport des points de collectes par coopérative

$lang['nbr_point_collect_cooperative']="Reporting on the number of collection points by cooperative";
$lang['nbr_coop']="Number of cooperatives";
//rapport répartition des agronomes
$lang['repart_agronom']="Distribution of agronomists";

//rapport répartition des coopérative
$lang['repart_cooper']="Repartition of cooperatives";
$lang['coop_serie']="cooperative (s)";

//rapport profils ménages

$lang['detail_menage']="Profile Details";


//rapport qte contracuelle vs qt recu

$lang['titre_qtc_vs_qtr']="Reporting Quantity Contractual Vs Quantity Received";
$lang['qtc_vs_qtr']="Contract Quantity Vs Quantity Received by cooperative";
$lang['qte_en_tonne']="Quantity (T)";
$lang['affiche_qtec_si_vide']="Contractual quantity (0 T)";
$lang['affiche_qter_si_vide']="Received quantity(0 T)";
$lang['total']="Total";

//rapport qtc vs qter pou bigfammer


$lang['titre_rapport_pr_bigfammer']="Contract Quantity Vs Quantity Received by Major Farmer";
$lang['name_rapport_pr_bigfammer']="Contract Quantity Vs Quantity Received by Major Farmer";
$lang['affiche_qtec_si_vide_kg']="Contractual quantity (0 T)";
$lang['affiche_qter_si_vide_kg']="Received quantity(0 T)";

//rapport qtc vs qter pour f
$lang['titre_rapport_fammer']="Reporting Quantity Contractual Vs Quantity Received by Farmer";
$lang['name_rapport_pr_fammer']="Contract Quantity Quantity Received by Farmer";

//rapport qtc vs qter pour traider
$lang['titre_rapport_traider']="Contract Quantity Reporting Vs Quantity Received Traider";
$lang['name_rapport_pr_traider']="Contract Quantity Vs Quantity Received by Traider";

//rapports répartition des points de collectes

$lang['nom_ordonne']="Number of collection points";

//rapports répartition des points de collectes

$lang['titre_rapport_pointcollect_2']="Number of collection points by province";

//Dashboard

$lang['titre_coop_pointcollect']="Number of cooperatives by collection points";

//Administration//emery

 $lang['password_confirm']="Failure! The new password and the confirmation password are different";

 $lang['Nouveau_password']="Password changed with success";


///alexis///////////////




  $lang['connect_nouveau']="Watch you reconnect with the New password";
  //profils

  $lang['description_uniq']="Profile description must be unique";
   $lang['description_prof']="Description Profile";

   $lang['gestion_user']="Gestion des Utilisateurs";
   $lang['carte']="cartography";

   $lang['profile']="Profile description is required";

   $lang['supp_profile']="deleting the profile";
   //region
   $lang['nom_region']="The name is required";
   $lang['prov']="Province is mandatory";
   //Users

   $lang['nom_user']="The field for name is required";
   $lang['prenom_user']="The field for first name is required";
   $lang['emailuser']="The field for email is required";
   $lang['emailerreur']="Email already used!";
   $lang['teluser']="Phone field is required";
   $lang['telerreur']="the phone number already used!";

    $lang['validemail']="The number is invalid";
    $lang['validefone']="Email already used!";
    $lang['modifmail']="Modification is done successfully";
   
   $lang['suppmail']="the deleting is done successfully";
   
  
  $lang['changepswd']="change the password!";

  $lang['old_pswd']="old password";
   $lang['new_pswd']="New Password";
   $lang['pswd_confirm']="Confirm password";
   $lang['changnew']="Change";
   $lang['ajoutprofil']="Adding profiles and rights";
   $lang['Descriprofil']="Profile description";
   $lang['user_report']="Reporting";
   $lang['Enregi']="Save";
   $lang['profildroit']="Profiles and rights";
   $lang['modprofildroit']="Editing profiles and rights";
   $lang['modif']="Edit";
   $lang['listuser']="Users list";
   $lang['adduser']="Add a user";
   $lang['prof']="Profile";
   $lang['teluser']="phone";
   $lang['modusers']="Editing a user";
   $lang['daitls']="Details";
   $lang['contrat']="CONTRACT";
   $lang['deletepoint']="Do you want to delete the collection point ";
   $lang['vente']="Sale";
   $lang['Enregistrement']="Recording done successfully";
   $lang['produit']="Product";
   $lang['restant']="Remaining";
   $lang['vendu']="Sold";
   $lang['prix_unitaire']="Unit price";
   $lang['prix_total']="Total price";
   $lang['validevente']="Validate the sale";
   $lang['listetraider']="List of traders";
   $lang['commerce']="Trader";
   $lang['informations']="Information about the contract";
   $lang['addcommerçants']="New trader";
   $lang['traider']="Trader";
   $lang['nif']="NIF";
   $lang['RC']="RC";
   $lang['copiestatut']="RC Status Copy";
   $lang['copiestatutnif']="Copy Status NIF";
   $lang['wi']="YES";
   $lang['non']="NO";
   $lang['modifitraider']="Editing a trader";



   $lang['farmer']="Farmer";
   $lang['obligatoire']=" Field is required";
   $lang['modification_demande']="Modification of the Request";
   $lang['nouvelle_demande']="New Seed";
   $lang['titre_semence']="List of seed applicants";

  
////////////////////////////////raoul/////////////////////////////////

$lang['identif']="Identification";
$lang['localiser']="Locate";
$lang['modif_photo']="update the picture";
$lang['agr_respo']="Responsible Agronomist";
$lang['photo']="picture";
$lang['qte_vendu_menage']="Quantité vendue par Menage";
$lang['nve_point_collecte']="New collection point";


















////////////ALPHONSE///////

$lang['descript_point_collecte']="Description of the collection point";
$lang['modif_point_collecte']="Editing the collection point";
$lang['product_de']="Production of";
$lang['num_pt_collect']="Collection point number";
$lang['info_product']="Information on its production";
$lang['tot_qte_produit']="Total quantity produced";

$lang['responsable_coop']="Cooperative manager";
$lang['coop_membre']="Cooperative members";

//emery contrat

   $lang['farmer']="farmer";
   $lang['obligatoire']="Field is required";
   $lang['modification_demande']="Modification Request";
   $lang['nouvelle_demande']="New Seed";
   $lang['titre_semence']="List of seed applicants";
   $lang['titre_contrat']="List of Contracts";
   $lang['nouveau_contrat']="New Contract";
   $lang['typ_contrat']="Contracting type";
   $lang['deb_contrat']="Start Contract";
   $lang['fin_contrat']="End Contract";
   $lang['modif_contrat']="Modification of the Contract";
   $lang['descri']="Description";
   $lang['semence_demandeur']="Contractor";
   $lang['delecontra']="Do you want to delete the contracto";



   ////alexis





////alexis
$lang['qte_rec_qte_con']='Quantity delivered Vs Contract Quantity';
   //Point de collecte
$lang['titre_point']="New collection point";
$lang['liste_collectes']="List of collection points";
$lang['modifier_point_collecte']="Editing the collection point";
$lang['point_collecte']="Collection Point";
$lang['qte_vendu_men']="Quantity sold by Menage";
$lang['mettre_jour_photo']="Update the photo";
$lang['int_mod_phot']="Photo editing interface";
$lang['agro_respo']="Responsible Agronomist";
$lang['localiser']="Localiser";


$lang['type_collecteur']="Collector Type";
$lang['date_collecte']="Date of collection";

//23/09/2019
$lang['famer']="Producer";
$lang['Big_Famer']="Great Producer";
$lang['type_collecteur']="Collector type";




////////////////////autres//////////////////


$lang['title_profil_QC_serie_name1']="Contract quantity";
$lang['title_profil_QC_serie_name2']="Quantity received";
$lang['contrat_satut']="Contract status";
$lang['en_cours']="In progress";
$lang['termine']="Completed";



//////////le 23/09/2019 //////////////////////////////////

$lang['qte_vdu_par_menage']="Quantity sold by household";

$lang['srogho_collecct']="Sorghum collect";
$lang['supp_coopp']="Do you want to delete the cooperative ";

$lang['oper_fait']="Recording done successfully ";


//////////nouveau
$lang['sa_qte_par_date']="Quantity by date";
$lang['quantite']="Quantité";
$lang['rapport_pr_lui']="Quantities according to the dates of collection";





///////////////////Le 24/09/2019//////////////////////////////////

$lang['rapport_quantite_par_contrat']="Current Contract Vs Completed";
$lang['rapport_quantite_par_contrat2']="Current Contract Vs Completed";
$lang['trimestre']="Quarter";
$lang['trimestre1']="1st trimester";
$lang['trimestre2']="2nd quarter";
$lang['trimestre3']="3rd quarter";
$lang['trimestre4']="4th quarter";
//$lang['commercant1']="Commerçant";
//$lang['montant13']="Montant";

//////////nouveau
$lang['sa_qte_par_date']="Quantity by date";
$lang['quantite']="Quantity";
$lang['rapport_pr_lui']="quantities collected by date";


$lang['sous_menu_contra']="Report on the contracts";
$lang['quantite_contr_en_cour']="Quantities of current contracts Vs contracts completed";
$lang['nbre_contr_en_cour']="Number of current contracts Vs contracts completed";


$lang['centre_negoce']="Trading Center";
$lang['institution_financiere']="Financial institution";



//26/09/2019

$lang['raport_du']="Report of";
$lang['rapport_title']="Contract Status Report";


$lang['touts_acteur']="All actors";

// emery centre negoce
$lang['centre_negoces']="The description of the trading center is mandatory";
$lang['enregi_negoce']="Registration of a trading center is done successfully";
$lang['nom_negoce']="Name of the trading center";
$lang['modi_negoce']="Modification of a trading center is done successfully ";
$lang['del_negoce']="deleting of a trading center is done successfully ";
$lang['foto_negoce']="editing a picture";
$lang['nouvo_negoce']="New trading center";
$lang['repo_quant']="Quantity collected";
$lang['repo_quantde']="Trading Center of";


$lang['enregi_fina']="Registration of a financial institution is done successfully";
$lang['supp_fina']="Do you want to delete this institution";
$lang['nom_fina']="Name of the financial institution";
$lang['modi_fina']="Modification of a financial institution is done successfully";
$lang['del_fina']="the removal of this financial institution is done successfully";
$lang['foto_fina']="Editing a photo is done successfully";
$lang['foto_echou']="Editing a photo fails";
$lang['list_negoce']="List of trading centers";
$lang['list_fina']="List of financial institutions";

$lang['modifi_cente']="Modification of a trading center";
$lang['modifi_fina']="changing a financial institution";
$lang['institu_fina']="Financial institution";
$lang['nouvell_fina']="New financial institution";


$lang['servic']="Services";
 $lang['ser']="SERVICE";
 $lang['servichef']="HEAD OF SERVICE";

  $lang['annuler']="Cancel";
  $lang['deja']="Description is already used ";
  $lang['supp_bpea']="Do you want to delete the Bpeae ";
  $lang['listservi']="List of services ";
  $lang['modifi_bpea']="Modification done successfully";
  $lang['modi_bpea']="Modify the BPEAE";
  $lang['ajout_bpea']="Addition of a BPEAE";
   $lang['listsebpea']="List of BPEAE";





 $lang['nom_ville']="Town Name";
$lang['nom_commune']="Commune Name";
$lang['nom_zone']="Zone Name";
$lang['nom_quartier']="Quarter Name";

$lang['nombre']="Number";

$lang['eau']="PDL water";
$lang['electricity']="PDL electricity";
$lang['detail']="Dashboard";
$lang['quartier_detail']="Detail of the quarter";
$lang['zone_detail']="Detail of the zone";
$lang['commune_detail']="Detail of the commune";
$lang['ville_detail']="Detail of the town";
$lang['relev']="Statement";
$lang['nrelev']="No. of Statement";
$lang['revenu']="Earnings";
$lang['recouvrement']="Recovery";
$lang['consommation']="consumption";
$lang['repartition']="Distribution of subscribers";
$lang['no_abonne']="No. of subscribers";
$lang['no_plainte']="No. of complaints";
$lang['localisation']="location";
$lang['consommation_totale']="Total consumption";
$lang['repartition_materiel']="Distribution of material";
$lang['nbre_arrier']="No. of arrears";
$lang['montant_arrier']="Amount of arrears";
$lang['plainte']="Complaint";
$lang['liste']="List of PDL water, PDL electricity and complaints";
$lang['neau']="Water";
$lang['montant']="amount";
$lang['nelectricity']="Electricity";
$lang['description_maison']="House Description";
$lang['compteur_eau']="Water Counter";
$lang['compteur_el']="Electricity Counter";
$lang['compteur_type']="Type of Counter";
$lang['compteur_no']="No. of the Counter";
$lang['nom_prop']="Owner's name";
$lang['tel']="Phone number";
$lang['plainte_ref']="Reference complaint";
$lang['commentaire']="Comment";

$lang['relev_montant']="Amount statement";
$lang['montant_paye']="Amount paid";
$lang['notif']="Notification at quarter";

$lang['envoyer_a']="Send to";
$lang['envoyer']="Send";
$lang['monde']="Everyone";
$lang['facture_non_pay']="Bill not paid";



$lang['notif_zone']="Notification at zone";
$lang['notif_commune']="Notification at commune";
$lang['notif_ville']="Notification at town";
$lang['arriere']="Arrears";
$lang['ville']="Town";
$lang['total_abonnee']="Total of subscribers";
$lang['perc_abonnee']="% of subscribers";
$lang['moyenne']="Average";



///EMERY acteur type///////////////



$lang['options']="options";
$lang['action']="Action";
$lang['bouton_nouveau']="New";
$lang['bouton_list']="List";
$lang['discription']="Description";
$lang['modifier']="Edit";
$lang['supprimer']="delete";
$lang['bouton_quitter']="leave";
$lang['enregistree']="Save";
$lang['typestructure']="Type Equipment";
$lang['selectio']="select";
$lang['structuressa']="List of types Actors";
$lang['structuresajout']="Adding an actor";
$lang['structuresmodif']="Editing an actor";
$lang['modifi_reussi']="The modification made successfully";
$lang['operatio_echoue']="The change fails";
$lang['enreg_reussi']="Registration is successful";
$lang['operatio_reussi']="Deletion made successfully";
$lang['champ_obligatoire']="Field is required";

$lang['ajout_type_equipement']="Adding a type of equipment";
$lang['list_type_equipement']="List of equipment types";
$lang['modifi_type_equipement']="Modify an equipment type";



$lang['nouveau']="New";
$lang['liste']="List";
$lang['categorie']="Category";
$lang['capacite']="Capacity";
$lang['equipement']="Equipment";
$lang['unite']="Unity";
$lang['photo']="Picture";
$lang['enregistrer']="Register";
$lang['quartier']="Quarter";
$lang['localite']="Locality";
$lang['etat']="Status";
$lang['coordon']="geographical coordinates";
$lang['modifier']="Edit";
$lang['supprimer']="Delete";
$lang['quitter']="Leave";
$lang['question']="Do you want to delete it";



/*PDL*/
/*
**MODULE MAISON 
*Proprietaire maison*/
$lang['proprietaire_list_titre']="Consumer";
$lang['proprietaire_th1_titre']="Last name";  
$lang['proprietaire_th2_titre']="First name";
$lang['proprietaire_th3_titre']="Number of House";
$lang['proprietaire_option_modifier']="Edit";
$lang['proprietaire_option_historique']="Historique";
$lang['proprietaire_option_detail']="Detail";
$lang['proprietaire_succes_message']="Operation done successfully";
$lang['proprietaire_fail_message']="Operation failed";
$lang['proprietaire_info']="OWNER INFORMATION";
$lang['proprietaire_tel']="Phone";
$lang['proprietaire_button_quitter']="Leave";
$lang['proprietaire_date_creation']="Creation date";
$lang['proprietaire_modal_for_edit_title']="Edit Consumer Information";
$lang['data_table_en_francais']=0;
#sub_menu_maison
$lang['pdl_sub_menu1']="New";
$lang['pdl_sub_menu2']="List";
$lang['pdl_sub_menu3']="PDL";
$lang['pdl_sub_menu4']="Consumer";
$lang['pdl_sub_menu5']="REGICOME EAU";
$lang['pdl_sub_menu6']="REGICOME ELECT";
$lang['pdl_sub_menu7']="SUPRIMA EAU";
$lang['pdl_sub_menu8']="SUPRIMA ELECT";
$lang['pdl_sub_menu9']="UNKOWN";
#PDL FORM
$lang['PDL']="PDL";
$lang['province']="Province";
$lang['commune']="Commune";
$lang['zone']="Zone";
$lang['colline_quartier']="Quarter";
$lang['compteur_eau']="Water meter";
$lang['compteur_electricite']="Electricity meter";
$lang['description']="Description";
$lang['photo']="Photo";
$lang['abonne']="Consumer";
$lang['selectioner']="Select";
$lang['connu']="known";
$lang['non_connu']="Unknown";
$lang['choisir']="Choose";
$lang['enregistrer']="Register";
$lang['description_du_maison']="PDL Description";

$lang['date_releve']="Statement date";
$lang['index_anterieure']="Previous Index";
$lang['index_actuel']="Current Index";
$lang['montant_a_payer']="Amount to be paid";
$lang['type_releve']="Type of statement";
$lang['facture']="Bill";
$lang['maison_de']="Historique de relevé de ";
$lang['pdf_fail_message']="Fichier non supporter ou corrompue";
$lang['succes_message']="Operation done successfully";
$lang['fail_message']="Operation failed";
$lang['record_not_found']="Record Not found";
$lang['compteur_eau_existe']="This Water Meter already exists!";
$lang['compteur_electricite_existe']="This Electricity Meter already exists!";
$lang['required_field']="Complete all the fields!";
$lang['choix_photo_maison']="Select a photo of the PDL please!";
$lang['choix_photo_propietaire']="Select a photo of the owner please!";
$lang['un_des_compteur_requis']="Completing at least one of the fields for the water meter or electricity ☺!";
$lang['existe']="Exists on another owner!";
$lang['detail_maison']="DETAILS HOUSE";
$lang['list_option_dashboard']="Dashboard";
$lang['list_option_historique_releve']="Statement History";
$lang['list_option_modifier']="Edit";
$lang['list_option_supprimer']="Delete";
$lang['alerte_supprimer']="Do you want to delete this PDL?";
/**/
/**/
/*COMPTEUR_PRE_EXISTANT*/
$lang['compteur_prexistant']="Compteur Près Existant";
$lang['numero_compteur']="Meter number";
$lang['localite']="Locality";
$lang['type_compteur']="Meter type";
$lang['compteur_pres_existant']="Compteur Près Existant";
$lang['alerte_supprimer_cpx']="Do you want to delete this Meter?";
$lang['required']="The field is required";
$lang['is_unique']="This datum already exists in the system!";



$lang['percevoir']="Perceive";
$lang['historique']="Historical";

$lang['image_releve']="Picture taken";
$lang['relance']="Revival";

$lang['abonne']="Subscribers";
$lang['date_releve']="Date taken";
$lang['index_actuel']="Current index";
$lang['index_anterieur']="Previous index";


$lang['montant_exigible']="Amount due";
$lang['montant_restant']="Remaining amount";
$lang['menage']="Household";
$lang['hist_relv']="History of Household Statements and Invoices";
$lang['list_pay']="List of  water payment ";
$lang['payement_eau_par']="Water payment by";
$lang['montant_exige']="Amount required";
$lang['fermer']="Close";
$lang['team']="Relaunch teams for new surveys";
$lang['payement_eau_facture']="Relaunch Payment Invoice Water of";
$lang['en_date_du']="dated";
$lang['bonjour']="Good Morning";
$lang['erreur_facture']="Except error on our part, your water bill of Amount of";
$lang['relative_au_relev']="on the statement";
$lang['effectue_le']="performed on the";
$lang['aupr_votr_maison']="near your house";
$lang['cordialement']="remained unpaid.<br>We kindly ask you to pay as soon as possible.<br>Cordially";
$lang['image_du_relv']="Picture of the 
statement";
$lang['image']="Picture";
$lang['pay_bill']="Payment history of the water bill
";
$lang['relev_l']="picked up on";






//cedric


$lang['modification']="Modification is done successfully";
$lang['suppression']="the deleting is done successfully";
$lang['liste_enqueteur']="List of pollsters";
$lang['nouveau_enqueteur']="New pollster";
$lang['modif_enqueteur']="Pollsters - Edit";
$lang['msg_suppression']="Do you want delete : ";


//didace

/**************************************************** RAPPORT TYPE DE PRODUIT*/
$lang['num_obr']="OBR number";
$lang['num_parcelle']="Parcel number";
$lang['avenue']="AV.";
$lang['categorie_abone']="Subscriber Category";
$lang['type_client']="Customer type";
$lang['type_abonne']="Subscriber Type";
$lang['type_compteur']="Counter Type";
$lang['type_produit']="Product Type";
$lang['type_beneficiaire']="Beneficiary Type";
$lang['nature_local']="Local Number";
$lang['detail_list']="List for";
$lang['rapport_du']="Report of";
$lang['s_ville']="Town";
$lang['s_commune']="Commune";
$lang['s_zone']="Zone";
$lang['s_quartier']="Quarter";
$lang['s_selectionner']="Select";
/* ******************************************************RAPPORT TYPE DE PRODUIT*/





$lang['pdl_electicite_valide']="Valid delivery points - electricity";
$lang['pdl_electicite_invalide']="Invalid delivery point number - electricity";
$lang['pdl_eau_valide']="Valid delivery points - Water";
$lang['pdl_eau_invalide']="Invalid delivery points - Water";
$lang['numero_obr']="OBR Number";
$lang['numero_parcelle']="Plot Number";


$lang['select_data']="select";
$lang['men_menage']="Households";
$lang['fact_n_paye']="Unpaid bill";
$lang['fact_paye']="Bill paid";
$lang['fact_en_cour_paye']="Invoice being paid";
$lang['compt_pop']="Counters";
$lang['eau_pop']="Water";
$lang['elec_pop']="Electricity";
$lang['propr_pop']="Owner";
$lang['tel_pop']="Phone";
$lang['compt_recher']="Search counter";
$lang['sms_releve_1']="No water type record found for this household";
$lang['sms_releve_2']="No record of the type of Electricity found for this household";

$lang['pdl_enqueteur'] = 'Close up par enqu&ecirc;teur';



$lang['nom_abonne_pdl_list']="Subscriber Name";
$lang['compteur_eau_abonne_pdl_list']="Water counter number";
$lang['compteur_electricite_abonne_pdl_list']="Electricity counter number";
$lang['ville_abonne_pdl_list']="City";
$lang['commune_abonne_pdl_list']="Commun";
$lang['zone_abonne_pdl_list']="Quarter";
$lang['Liste_Pdl']="List of Pdl";
$lang['repartion_pdl_produit']="Distribution of PDL by Products";
$lang['repartion_pdl_produit_jour']="Daily collection  by Type of Subscriber";
$lang['repartion_pdl_jour']="Daily collection  PDL";

//rapport de doublon
$lang['Nombre_doubons_compteurs_eau']="Number of duplicates for water meters";
// $lang['Nombre_maisons']="Number of houses";
$lang['Nombre_doubons_compteurs_electrique']="Number of duplicates for electric meters";

/**/
$lang['comp_name']="His counters";
$lang['photo_elec']="Picture of electricity counter";
$lang['photo_eau']="Picture of water counter";



$lang['mar_comp_ele']='Electricity meter brand';
$lang['mar_comp_eau']='Water meter brand';
$lang['ti_tle']='PDL record by agent per day';

$lang['marque']='Brand';
$lang['compteur_eau']='Water meter';
$lang['compteur_electricite']='Electricity meter';
$lang['info_agent']='Investigator Info';

$lang['compteur']='Meter';
$lang['localite']='locality';

$lang['num_parcelle']='Num Plot';




$lang['nombre_compteur']="Number of meters";
$lang['found']="Found";
$lang['not_found']="Not found";







//rapport type cnsentement

$lang['rapport_consentementprov']="Province";
$lang['rapport_consentementcomm']="town";
$lang['rapport_consentementzone']="Zoned";
$lang['rapport_consentementprovsel']=" Select";
$lang['rapport_consentementcommsel']="Select";
$lang['rapport_consentementzonesel']="Select";
$lang['rapport_consentementtitre']="Number of PDLs by consent type";


//emery
//emery le 20/02/2020
//french
$lang['detail_pdl_type_pdl_list']="Customer : ";
$lang['compteur_electricite_type_pdl_list']="Type of product";
$lang['Info_du_Proprietaire']="proprietor Info";
$lang['Info_sur_Eau']="Info of  Water Counter";
$lang['Info_sur_Electricite']="Info on electricity Counter";
$lang['Proprietaire']="proprietor";
$lang['Numero_OBR']="OBR number";
$lang['avenue']="Avenue";
$lang['Numro_du_Parcelle']="Parcel number";
$lang['Date_Creation']="Cration Date";

$lang['Date_Debut_Formulaire']="Date Start Form";
$lang['Consentement']="Consent";

$lang['Type_Produit']="Product Type";
$lang['Type_Beneficaire']="Beneficiary Type";
$lang['Type_Abonne']="Subscriber Type";
$lang['Type_Client']="Customer Type";
$lang['Type_Commercial']="Commercial Type";
$lang['Compteur_eau']="Water counter";
$lang['Ce_Compteur_est_accesible']="This Counter is accessible";
$lang['Marque_du_Compteur']="Counter Mark";
$lang['Compteur_depose']="Counter deposited";
$lang['Type_Compteur']="Counter Type";
$lang['Index_Eau']="Water Index";
$lang['Montage_eau']="Water mounting";
$lang['Credit']="Credit";
$lang['Compteur_Eau_Attente']="Pending Water Counter";
$lang['Branchement_Eau_sans_compteur']="Water connection without Counter";
$lang['Etat_du_Compteur']="Counter status";
$lang['Compteur_electricite']="Electricity Counter";
$lang['Ce_compteur_est_accesible']="This counter is accessible";
$lang['Ce_Electricite_a_plusieurs_activite']="Electricity has several activities";
$lang['index_electricite']="Electricity index";
$lang['Consommation']="Consumption";
$lang['Cable_Avant']="Front Wired";
$lang['Compteur_electricite_Attente']="Electricity counter Waiting";
$lang['Golocalisation']="Geolocation";




$lang['repartition_pdl_produit']=" Répartition des PDLs par produits";

$lang['rapport_consentementcodepdl']="Pdl";
$lang['rapport_consentementdetquartier']="District";
$lang['rapport_consentementprovdetail']=" Province";

//rapport de branchement electrique
$lang['nombre_branchement_electrique_title']="Number of electrical connections";
$lang['nombre_branchement_electrique']="Number of connections";

// Dashboard
$lang['dashboard_pdl_type_eau']="Distribution of water meters by category";
$lang['dashboard_pdl_etat_eau']="Distribution of water meters by state";
$lang['dashboard_pdl_type_el']="Distribution of Electricity Meters by Category";
$lang['dashboard_pdl_etat_el']="Distribution of electricity meters by State";
$lang['dashboard_pdl_conso_el']="Distribution of electricity meters by consumption";
$lang['dashboard_pdl_montage_eau']="Distribution of water meters by assembly";

$lang['rapport_consentementdetcom']="Commune";
$lang['rapport_consentementdetzone']=" Zone";


//English cedric
$lang['nbr_compteur_type_consommation'] = 'Number of meter per type consumming';
$lang['nbr_type_abonne'] = 'Distribution of PDLs by type of customer';


$lang['Nombre_found_compteurs_eau']="Number of water meters by type of source";
$lang['Nombre_found_compteurs_electrique']="Number of electricity meters by type of source";



$lang['dashboard_pdl']=" Dashboard  PDL";
$lang['accessibilie_eau']="Water Accessibility ";
$lang['accessibilie_el']=" Electricity accessibility ";
$lang['accessibilie_compteur']="Accessibility PDL";
$lang['dashboard_pdl_blanchema_el']=" Distribution of PDLs of electricity by connections";


$lang['nombre_identification_client']="Number of Pdl by type Identification of customers";
$lang['ihm_rapport_view_numb']="Numbers";
$lang['datee_debut_formulaire_numb']="Date Start of Form";


$lang['rapport_compt_titre']="Preexisting counter report";
$lang['rapport_compt_trouve']="Found";
$lang['rapport_compt_non_trouve']="Not found";
$lang['rapport_compt_eau']=" Water";
$lang['rapport_compt_electricite']="Electricity";


$lang['Nom_Prenom']="Last name and first name";
$lang['enqueteur']="Investigator";
$lang['ce_numero_existe']="This number already exists";
$lang['ajout_controller']="Adding a Controller";
$lang['modifier_controller']="Modify a Controller";
$lang['ihm_Patient_add_save_Téléphone']="Phone";
$lang['Liste_des_Controlleur']="List of Controllers";
$lang['ce_email_existe']="This mail already exists";


$lang['rapport_compt_titre']="Pre-existing meter report for SUPRIMA";
$lang['rapport_compt_titre2']="Preexisting counter report for REGICOM";


//ecart 26-02-2020
$lang['Nouveau_ecart']="New gap";
$lang['ecart']="Difference";
$lang['Description_action']="Description of an action";
$lang['Traiter_status']="Treatment";
$lang['Liste_des_ecarts']="List of deviations";
$lang['modification_ecarts']="Treatment of a deviation";
$lang['date_ecart']="Discrepancy date";
$lang['historique_ecart']="History of a deviation";


$lang['envoi_msg']="Send SMS";
$lang['succes_msg']="Succefully sent!";
$lang['echec_msg']="Not sent!";
$lang['comfirm_msg']="Are you sure you want to text this investigator?";



$lang['nbre_compteurs'] = 'Number of commands';
$lang['pdl_cmd'] = 'Number of PDL(s) wchich commanded';
$lang['pdl_no_cmd'] = 'Number of PDL(s) which not commanded';

$lang['compteur_pres_existant_trouve']='Preexisting meters found';

$lang['destinataire']='Recipient';
$lang['expediteur']='Sender';



//English
$lang['tout_le_pays'] = 'Nationaly';
$lang['toute_la_ville'] = 'Town : ';
$lang['toute_la_commune'] = 'Commune : ';
$lang['toute_la_zone'] = 'Zone : ';
$lang['toute_la_colline'] = 'Hill : ';

$lang['sms_list'] = 'SMS List';

$lang['nombre_branchement_electrique_title_liste']="List of electrical connections";
$lang['Nombre_maisons']="Number of PDL";
$lang['Nombre_found_compteurs_eau_liste']="List of water meters by type of source";
$lang['Nombre_found_compteurs_electrique_liste']="List of electricity meters by type of source";

$lang['Liste_des_doublons']="List of duplicate electric meters";
$lang['Liste_des_doublons_eau']="List of duplicate water meters";

$lang['Nom_Enqueteur']="Name of Investigator";
$lang['Nom_telephone']="Phone";
$lang['Details_des_enqueteur_du_Superviseur']="
Details of Supervisor's Investigators";
$lang['Releve_par']="Recorded by";


//desire
// Listes des compteures pre_existant

$lang['compteur_num']="Counter number";
$lang['compteur_source']="Source type";
//$lang['compteur_type']="Source type";
$lang['site_number']="Subscriber name";
$lang['date_abonnement']=" Subscription date";
$lang['quarter']="Quarter";
$lang['statu_found']="Found/Not Found";
$lang['Status_correct']="Correct/Not correct";
$lang['is_found']="Found";
$lang['no_found']="Not found";
$lang['liste_preexistants']="List of pre-existing meters";



//enqueteur dashbord

$lang['Dashboard_de_enqueteur']="Investigator dashboard";
$lang['Nombre_doublons_enqueteur_compteur_electricite']="Number of duplicates made by an investigator for electricity meters";
$lang['Nombre_doublons_enqueteur_compteur_eau']="Number of duplicates made by an investigator for water meters";
$lang['Nombre_compteurs_eau_trouves_enqueteur']="Number of water meters found by an investigator";
$lang['Nombre_compteurs_electricite_trouves_enqueteur']="Number of electricity meters found by an investigator";
$lang['List_doublons_enqueteur_compteur_electricite']="List of duplicates made by an investigator for electricity meters";
$lang['List_doublons_enqueteur_compteur_eau']="List of duplicates made by an investigator for water meters";
$lang['Date_debut_formulaire']="Start date form";
$lang['Liste_compteurs_eau_trouves_enqueteur']="List of water meters found by an investigator";
$lang['Liste_compteurs_electricite_trouves_enqueteur']="List of electricity meters found by an investigator";


//emery le 29/02/2020:English
$lang['pdl_ecart']="Description of deviations";
$lang['pdl_historique_ecart']="History of deviations";
$lang['Correction_des_Ecarts']="Correction des Ecarts";
$lang['Statut_pdl']="Status";
$lang['ecart_pdl_title']="Ecart";
$lang['Information_des_Enqueteurs']="Information for Investigators";
$lang['pdl_releve_des_Enqueteurs']="Pdl Recorded ";
$lang['pdl_releve_des_geolocalisation']="Geolocation";
$lang['Proprietaire_du_Maison']="House owner";
$lang['commune_pdl']="Commune";
$lang['zone_abonne_pdl_list_zonne']="Zone";
$lang['zone_abonne_pdl_list_avenue']="Avenue";

//Ella
$lang['rapport_client']="Client Reporting";
$lang['rapport_ben']="Beneficiary reporting";

$lang['rapport_commerce']="Trade reporting";
$lang['nature_local']="Local staff reporting";

$lang['anomalie_eau']="Anomaly reporting for water meter";
$lang['anomalie_el']="Anomaly reporting for Electricity meter";
$lang['service']="Reporting of services per Anomaly";



//didace
$lang['Liste_Pdl_eau']=" Pdl list of Water";
$lang['Liste_Pdl_electrique']="Pdl list of electricity";
$lang['pdl_elctrique_numero']=" Electric PDL number";
$lang['pdl_par_enqueteur']=" PDL type per investigator";
$lang['pdl_apres_traitement']=" PDL type after Treatment";

$lang['pdl_eau_numero']=" Water PDL number";
$lang['pdl_electrique_numero']=" Electric PDL number";


$lang['personne_assigne']="Assigned Person";
$lang['eau']='Water';
$lang['electricite']='Electricity';
$lang['date_ouverture']='Opening';
$lang['date_fermeture']='Closing';


$lang['Liste_Pdl_anomarie']=" List of anomalies for type of PDLs";
$lang['Liste_Pdl_anomarie_eau']=" Anomalies for Water meter";
$lang['Liste_Pdl_anomarie_ele']=" Anomalies for Electricity meter";


$lang['mofif_type_compteur_eau']=" Changing the type of water meter number";
$lang['mofif_type_compteur_ele']=" Changing the type of Electricity meter number";

$lang['dashbord_obj']=" Dashboard Objectifs";


$lang['regicom']=" REGICOM";
$lang['supprima']=" SUPPRIMA";
$lang['consomateur']=" Consumer";
$lang['num_abonne']=" Subscriber Number";
$lang['nom_beneficiaire']=" Beneficiary";

$lang['compteur_trouver']="Found";
$lang['compteur_non_trouver']="Not found";
$lang['Liste_Pdl_anomarie_number']=" List of anomalies for Number of PDLs";




//enqueteur donnees
$lang['title_enqueteur_tab_doublon_trouve']="Duplicates and Found";
$lang['title_enqueteur_tab_ecart']="Difference";
$lang['title_enqueteur_tab_carte']="Map";
$lang['carte_form_enqueteur_date']="Date Investigation";
$lang['carte_form_enqueteur_menage']="Households visited";


$lang['Nombre_ecart_enqueteur_compteur_electricite']="Number of PDLs that an investigator has to do on a gap for electricity meters";
$lang['Nombre_ecart_enqueteur_compteur_eau']="Number of PDLs that an investigator has to do on a gap for water meters";




$lang['Dashboard_de_enqueteur']="Investigator dashboard";
$lang['Nombre_doublons_enqueteur_compteur_electricite']="Number of duplicates made by an investigator for electricity meters";
$lang['Nombre_doublons_enqueteur_compteur_eau']="Number of duplicates made by an investigator for water meters";
$lang['Nombre_compteurs_eau_trouves_enqueteur']="Number of water meters found by an investigator";
$lang['Nombre_compteurs_electricite_trouves_enqueteur']="Number of electricity meters found by an investigator";
$lang['List_doublons_enqueteur_compteur_electricite']="List of duplicates made by an investigator for electricity meters";
$lang['List_doublons_enqueteur_compteur_eau']="List of duplicates made by an investigator for water meters";
$lang['Date_debut_formulaire']="Start date form";
$lang['Liste_compteurs_eau_trouves_enqueteur']="List of water meters found by an investigator";
$lang['Liste_compteurs_electricite_trouves_enqueteur']="List of electricity meters found by an investigator";
$lang['nbr_ecart_par_agent']='No. of tickets per investigator';





$lang['map_pdl_ecart_titre']=": Situation center map";//cccnnnn

$lang['map_pdl_ecart_rechercher']="Find deviations";//cccccccccccnn





 $lang['menu_adninistration_mofif_titre']="Editing a user";
 $lang['menu_adninistration_mofif_nom']="Last name";
 $lang['menu_adninistration_mofif_prenom']="First name";
 $lang['menu_adninistration_modif_email']="E-mail";
 $lang['menu_adninistration_modif_tel']="Phone";
 $lang['menu_adninistration_modif_profil']="Profiles";
$lang['menu_adninistration_modif_modifier']="Edit";
//ajout/users
$lang['menu_adninistration_aj_titre']="Adding a new user";
 $lang['menu_adninistration_aj_nom']="Last name";
 $lang['menu_adninistration_aj_prenom']="First name";
 $lang['menu_adninistration_aj_email']="E-mail";
 $lang['menu_adninistration_aj_tel']="Phone";
 $lang['menu_adninistration_aj_profil']="Profiles";
$lang['menu_adninistration_btnenreg']="Save";
$lang['menu_adninistration_select']="Select";


$lang['aucun_compteur_eau']="No Water Counter";
$lang['aucun_compteur_elect']="No Electricity Counter";
$lang['nom_abones']="Subscriber name";
$lang['DATE_ABONNEMENT']="Subscription date";
$lang['profil_conso']="Consumption Profile";
$lang['PERSONNE_REFERENCE']="Reference person";
$lang['NUM_SITE']="Site number";
$lang['DERNIER_INDEX']="Last index";



$lang['Evolution_ecarts_title']="Evolution of deviations";
$lang['Nombre_ecart_yAxis']="Number of deviations";
$lang['list_evolution_ecart_title']="List of changes in number ";
$lang['list_evolution_ecart_title_au_dela']=" as of ";

$lang['NUM_ABONNEMENT']="Subscription number";


$lang['base_reference']="SUPPRIMA-PDL";
$lang['regicom_eau']="REGICOM-PDL Water";
$lang['regicom_ele']="REGICOM-PDL Electricity";
$lang['Counter']="Counter";


$lang['Traiter_par']="Treated by";
$lang['ecart_du_client']="of customer";
$lang['residant_aa_buja']="Living at";
$lang['repartition_geographique_ecart_title']="Geographical distribution of differences";
$lang['repartition_par_pourcentage']="Percentage distribution of deviations";

$lang['repartition_ecart']="Overall distribution of differences";
$lang['repartition_ecart_detail']="Overall detail of deviations";
$lang['Tableau_bord_global_des_ecarts']="Global deviation dashboard";
$lang['repartition_ecart_status']="Global breakdown of differences by status";
$lang['repartition_par_valeur']="Distribution of differences by value";
$lang['dashbord_ecart_date_avant']="Before Date";


$lang['nombre_compteur_pre_conteur_preexistant']="Number of modifications made for pre-existing meters";


//emery//le 13/03/2020
$lang['detail_traite_par']="Treated by";
$lang['detail_traite_par_Liste_supprima']="List of Water Meters not found SUPPRIMA";
$lang['detail_traite_par_Liste_regicom']="List of Water Meters not found REGICOM";
$lang['detail_traite_par_Liste_regicom_elc']="List of Electricity Meters not found REGICOM";
$lang['detail_traite_par_Liste_regicom_elc_regicom']="List of Electricity Meters not found REGICOM";
$lang['detail_traite_par_Liste_regicom_elc']="List of Electric meters not found SUPPRIMA";
$lang['detail_traite_par_Liste_regicom']="List of Water Meters not found REGICOM";
$lang['detail_traite_par_Enqueteur_regicom']="Investigators";
$lang['detail_traite_fermer']="Close";
$lang['enregistrer_modifications']="Save Changes";


$lang['taux_ecart'] = "Taux de chaque écart.";


$lang['regicom_not_eau_terrain']="REGICOM not found";
$lang['tot_pdl']="Total PDL";
$lang['supprima_not_eau_terrain']="SUPRIMA not found";
$lang['regicom_not_ele_terrain']="REGICOM Electricity not found";
$lang['supprima_not_ele_terrain']="REGICOM Water not found";

$lang['grob_pdl']="PDL Grobal Report";
$lang['grob_enquete']="Grobal Report of Investigators";
$lang['prepayement']="Prepaid ";
$lang['normaliser']="Normalize";
$lang['normalisation']="Normalization";

$lang['nbr_entree']="In put";
$lang['nbr_sortie']="Out put";
$lang['production']="Production et Adduction";
$lang['nbr_entree']="Nombre d'entree";
$lang['nbr_sortie']="Nombre de sortie";
$lang['production']="Production et Adduction";
$lang['source']="Source de Production et Adduction";
$lang['compteur_source']="Compteur de la Source de Production et Adduction";
$lang['debut_min']="Début Min du pompte de la Source";
$lang['debut_max']="Début Max du pompte de la Source";
$lang['destination']="Lieu de Production et Adduction";
$lang['compteur_destination']="Compteur  de Production et Adduction";
 
?>